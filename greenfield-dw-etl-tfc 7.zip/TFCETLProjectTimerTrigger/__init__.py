from datetime import datetime, timezone

from azure.functions import TimerRequest

from shared.tfc_workflow import TFCWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="tfc_etl_project_timer_trigger")


async def main(mytimer: TimerRequest) -> None:
    utc_timestamp = datetime.now(timezone.utc).isoformat()

    if mytimer.past_due:
        logger.info('The timer is past due!')
    job = 'etl-project'
    logger.info('Python timer trigger function ran at %s', utc_timestamp)
    wf = TFCWorkflow()
    await wf.execute_job(job)
