import azure.functions as func

from shared.tfc_workflow import TFCWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="tfc_etl-run-http-trigger")


async def main(req: func.HttpRequest) -> func.HttpResponse:
    job = 'etl-run'
    logger.info(f'TFC {job} HTTP trigger function processed a request.')
    wf = TFCWorkflow()
    await wf.execute_job(job)
    return func.HttpResponse(f"{job} has been triggerred successfully")
