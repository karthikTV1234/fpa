from datetime import datetime

from sqlalchemy.orm import Session

from shared.models.organization import DimTFCOrganization
from shared.repositories.base_repo import BaseRepo
# from shared.models.all_models import DimTFCOrganization
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="OrganizationRepo")


class OrganizationRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimTFCOrganization)

    def get_or_create_organization(self, organization_id, organization_name=None):
        """
        Check if an organization record exists, and if not, create it.
        :param organization_id: The unique identifier of the organization.
        :param organization_name: Optional name of the organization.
        :return: ID of the `DimTFCOrganization` record.
        """
        try:
            # Check if the organization already exists
            existing_organization = self.session.query(DimTFCOrganization).filter_by(
                organization_id=organization_id,
                isactive=True
            ).first()

            if existing_organization:
                logger.info(f"Organization {organization_id} already exists.")
                return existing_organization.organization_row_id

            # Create a new organization record
            new_organization = DimTFCOrganization(
                organization_id=organization_id,
                organization_name=organization_name or f"Org_{organization_id}",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                isactive=True,
            )

            self.session.add(new_organization)
            self.session.commit()  # Commit to get the `organization_row_id`
            logger.info(f"Organization {organization_id} created successfully.")
            return new_organization.organization_row_id

        except Exception as e:
            logger.error(f"Error in get_or_create_organization for ID {organization_id}: {e}")
            self.session.rollback()
            raise
