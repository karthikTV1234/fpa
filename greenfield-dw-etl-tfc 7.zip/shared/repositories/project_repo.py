from datetime import datetime

from sqlalchemy.orm import Session

from shared.models.project import DimTFCProjects, FactTFCProject, SummaryTFCProjects
from shared.repositories.base_repo import BaseRepo


class DimTFCProjectsRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimTFCProjects)

    def get_by_project_name(self, project_name):
        """Get project by name"""
        return self.session.query(DimTFCProjects).filter_by(project_name=project_name, isactive=True).first()

    def update_project(self, project_dim_rowid, **kwargs):
        """Update a project record in dim_tf_projects"""
        filter_criteria = DimTFCProjects.project_dim_rowid == project_dim_rowid
        return super().update(filter_criteria, kwargs)


class FactTFCProjectsRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactTFCProject)

    def get_by_project_dim_rowid(self, project_dim_rowid):
        """Get fact record by project_dim_rowid"""
        return self.session.query(FactTFCProject).filter_by(project_dim_rowid=project_dim_rowid, isactive=True).first()

    def update_fact_project(self, project_fact_row_id, **kwargs):
        """Update a fact project record"""
        filter_criteria = FactTFCProject.project_fact_row_id == project_fact_row_id
        return super().update(filter_criteria, kwargs)

    def add_fact_project(self, project_dim_rowid, workspace_count, team_count, stack_count, auto_destroy_activity_duration, start_dateref, end_dateref, **kwargs):
        """Add a new fact project record"""
        fact_project = FactTFCProject(
            project_dim_rowid=project_dim_rowid,
            workspace_count=workspace_count,
            team_count=team_count,
            stack_count=stack_count,
            auto_destroy_activity_duration=auto_destroy_activity_duration,
            start_dateref=start_dateref,
            end_dateref=end_dateref,
            create_date=datetime.now(),
            **kwargs,
        )
        self.session.add(fact_project)
        self.session.commit()
        return fact_project

    def deactivate_fact_project(self, project_fact_row_id):
        """Soft delete a fact project record"""
        self.update_fact_project(project_fact_row_id, isactive=False)


class SummaryTFCProjectsRepo:
    def __init__(self, session: Session):
        self.session = session

    def get_all(self):
        """Retrieve all summary records"""
        return self.session.query(SummaryTFCProjects).all()

    def load_summary_data(self, current_date):
        """Load summary data up to the current date"""
        query = self.session.query(SummaryTFCProjects).filter(
            SummaryTFCProjects.create_date <= current_date
        )
        return query.count()

    def populate_summary_table(self):
        """Populate summary_tf_project table"""
        try:
            report_dateref = int(datetime.now().strftime("%Y%m%d"))
            projects_count = self.session.query(DimTFCProjects).filter_by(isactive=True).count()

            summary_entry = SummaryTFCProjects(
                report_dateref=report_dateref,
                projects_count=projects_count,
                create_date=datetime.now()
            )
            self.session.add(summary_entry)
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            raise Exception(f"Error populating summary table: {e}")
