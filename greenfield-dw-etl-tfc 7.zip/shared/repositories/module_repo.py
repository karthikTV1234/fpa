from sqlalchemy.orm import Session

from shared.models.module import DimTFCModules, FactTFCModules, SummaryTFCModules
from shared.repositories.base_repo import BaseRepo


class DimTFCModulesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimTFCModules)

    def get_by_module_name(self, module_name):
        """Get module by name"""
        return self.session.query(DimTFCModules).filter_by(module_name=module_name).first()

    def update_module(self, modulelist_dim_row_id, **kwargs):
        """Update a module record in dim_tf_modulelist"""
        filter_criteria = DimTFCModules.modulelist_dim_row_id == modulelist_dim_row_id
        return super().update(filter_criteria, kwargs)


class FactTFCModulesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactTFCModules)

    def get_by_module_row_id(self, moduleslist_dim_row_id):
        """Get fact record by module row ID"""
        return self.session.query(FactTFCModules).filter_by(moduleslist_dim_row_id=moduleslist_dim_row_id).first()

    def update_fact_module(self, modulelist_fact_row_id, **kwargs):
        """Update a fact module record"""
        filter_criteria = FactTFCModules.modulelist_fact_row_id == modulelist_fact_row_id
        return super().update(filter_criteria, kwargs)

    def add_fact_module(self, moduleslist_dim_row_id, version_status, organization_id, load_date, start_dateref, end_dateref, **kwargs):
        """Add a new fact module record"""
        fact_module = FactTFCModules(
            moduleslist_dim_row_id=moduleslist_dim_row_id,
            version_status=version_status,
            organization_id=organization_id,
            load_date=load_date,
            start_dateref=start_dateref,
            end_dateref=end_dateref,
            **kwargs,
        )
        self.session.add(fact_module)
        self.session.commit()
        return fact_module


class SummaryTFCModulesRepo:
    def __init__(self, session):
        self.session = session

    def get_all(self):
        return self.session.query(SummaryTFCModules).all()

    def load_summary_data(self, current_date):
        # Example logic for loading summary data
        query = self.session.query(SummaryTFCModules).filter(
            SummaryTFCModules.created_date <= current_date
        )
        return query.count()
