from requests import Session

from shared.models.run import FactRun, FactRunStatus
from shared.repositories.base_repo import BaseRepo


class FactRunRepo (BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactRun)

    def get_by_workspace_dim_rowid(self, row_id):
        return self.session.query(FactRun).filter_by(workspace_dim_rowid=row_id).first()

class FactRunStatusRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactRunStatus)

