from sqlalchemy.orm import Session

from shared.models.workspace import DimTFCWorkspaces, FactTFCWorkspaces, SummaryTFCWorkspaces
from shared.repositories.base_repo import BaseRepo


class DimTFCWorkspacesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimTFCWorkspaces)

    def get_by_workspace_name(self, workspace_name):
        """Get workspace by name"""
        return self.session.query(DimTFCWorkspaces).filter_by(workspace_name=workspace_name).first()

    def update_workspace(self, workspace_row_id, **kwargs):
        """Update a workspace record in dim_tfc_workspaces"""
        filter_criteria = DimTFCWorkspaces.workspace_row_id == workspace_row_id
        return super().update(filter_criteria, kwargs)


class FactTFCWorkspacesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactTFCWorkspaces)

    def get_by_workspace_row_id(self, workspace_row_id):
        """Get fact record by workspace row ID"""
        return self.session.query(FactTFCWorkspaces).filter_by(workspace_row_id=workspace_row_id).first()

    def update_fact_workspace(self, workspace_fact_row_id, **kwargs):
        """Update a fact workspace record"""
        filter_criteria = FactTFCWorkspaces.workspace_fact_row_id == workspace_fact_row_id
        return super().update(filter_criteria, kwargs)

    def add_fact_workspace(self, workspace_row_id, terraform_version, execution_mode, organization_id, api_link, **kwargs):
        """Add a new fact workspace record"""
        fact_workspace = FactTFCWorkspaces(
            workspace_row_id=workspace_row_id,
            terraform_version=terraform_version,
            execution_mode=execution_mode,
            organization_id=organization_id,
            api_link=api_link,
            **kwargs,
        )
        self.session.add(fact_workspace)
        self.session.commit()
        return fact_workspace


class SummaryTFCWorkspacesRepo:
    def __init__(self, session):
        self.session = session

    def get_all(self):
        return self.session.query(SummaryTFCWorkspaces).all()

    def load_summary_data(self, current_date):
        """Load summary data based on the current date"""
        query = self.session.query(SummaryTFCWorkspaces).filter(
            SummaryTFCWorkspaces.report_dateref <= current_date
        )
        return query.count()
