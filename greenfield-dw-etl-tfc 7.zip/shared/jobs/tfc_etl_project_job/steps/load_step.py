import traceback
from datetime import datetime, date

from sqlalchemy import func

from shared.models.organization import DimTFCOrganization
from shared.models.project import DimTFCProjects, FactTFCProjects, SummaryTFCProjects
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadStep")


class LoadStep:
    def __init__(self, config, context):
        self.config = config
        self.context = context
        self.existing_org = None

    async def execute(self):
        try:
            if self.context.transformed_data_frame is None:
                logger.error("No transformed data to load.")
                return

            current_date = date.today()
            dateref = int(current_date.strftime("%Y%m%d"))

            for _, row in self.context.transformed_data_frame.iterrows():
                try:
                    # 1. Handle DimTFCProjects (Upsert Logic with SCD Type 2)
                    dim_project_entry = self.context.database_manager.session.query(DimTFCProjects).filter_by(
                        project_id=row["project_id"], isactive=1
                    ).one_or_none()

                    org = (
                        self.context.database_manager.session.query(DimTFCOrganization)
                        .filter_by(organization_id=row["organization_id"], isactive=1)
                        .one_or_none()
                    )
                    self.existing_org = org

                    if self.existing_org:
                        # Read primary key and workspace id
                        organization_dim_rowid = self.existing_org.organization_dim_rowid
                        org_id = self.existing_org.organization_id
                        org_name = self.existing_org.organization_name
                        org_rowid = self.existing_org.organization_dim_rowid

                        if dim_project_entry:
                            if (dim_project_entry.project_name != row["project_name"]):
                                # Deactivate old record
                                dim_project_entry.end_date = current_date
                                dim_project_entry.isactive = 0
                                self.context.database_manager.session.commit()

                                # Insert new record
                                dim_project_entry = DimTFCProjects(
                                    project_id=row["project_id"],
                                    project_name=row["project_name"],
                                    create_date=row["created_date"],
                                    organization_dim_rowid=organization_dim_rowid,
                                    start_date=current_date,
                                    end_date=None,
                                    isactive=1
                                )
                                self.context.database_manager.session.add(dim_project_entry)
                                self.context.database_manager.session.commit()
                        else:
                            # Check for inactive duplicate records
                            # inactive_record = self.context.database_manager.session.query(DimTFCProjects).filter_by(
                            #     project_id=row["project_id"], isactive=0
                            # ).one_or_none()

                            # if inactive_record:
                            #     logger.warning(f"Project ID {row['project_id']} already exists as an inactive record.")
                            #     continue  # Skip processing for duplicate inactive records

                            # Insert new project
                            dim_project_entry = DimTFCProjects(
                                project_id=row["project_id"],
                                project_name=row["project_name"],
                                create_date=row["created_date"],
                                organization_dim_rowid=organization_dim_rowid,
                                start_date=current_date,
                                end_date=None,
                                isactive=1
                            )
                            self.context.database_manager.session.add(dim_project_entry)
                            self.context.database_manager.session.commit()

                        # Validate `dim_project_entry`
                        if not dim_project_entry:
                            logger.error(
                                f"Failed to create or retrieve DimTFCProjects entry for project_id: {row['project_id']}.")
                            continue

                        # 2. Handle FactTFCProjects (Upsert Logic with SCD Type 2)
                        fact_project_entry = self.context.database_manager.session.query(FactTFCProjects).filter_by(
                            project_dim_rowid=dim_project_entry.project_dim_rowid, isactive=1
                        ).one_or_none()

                        if fact_project_entry:
                            if (fact_project_entry.workspace_count != row["workspace_count"] or
                                    fact_project_entry.team_count != row["team_count"] or
                                    fact_project_entry.stack_count != row["stack_count"] or
                                    fact_project_entry.auto_destroy_activity_duration != row[
                                        "auto_destroy_activity_duration"]):
                                # Deactivate old record
                                fact_project_entry.end_dateref = dateref
                                fact_project_entry.isactive = 0
                                self.context.database_manager.session.commit()

                                # Insert new fact record
                                fact_project_entry = FactTFCProjects(
                                    project_dim_rowid=dim_project_entry.project_dim_rowid,
                                    workspace_count=row["workspace_count"],
                                    team_count=row["team_count"],
                                    stack_count=row["stack_count"],
                                    auto_destroy_activity_duration=row["auto_destroy_activity_duration"],
                                    start_dateref=dateref,
                                    end_dateref=None,
                                    create_date=datetime.now(),
                                    isactive=1
                                )
                                self.context.database_manager.session.add(fact_project_entry)
                                self.context.database_manager.session.commit()
                        else:
                            # Insert new fact record
                            fact_project_entry = FactTFCProjects(
                                project_dim_rowid=dim_project_entry.project_dim_rowid,
                                workspace_count=row["workspace_count"],
                                team_count=row["team_count"],
                                stack_count=row["stack_count"],
                                auto_destroy_activity_duration=row["auto_destroy_activity_duration"],
                                start_dateref=dateref,
                                end_dateref=None,
                                create_date=datetime.now(),
                                isactive=1
                            )
                            self.context.database_manager.session.add(fact_project_entry)
                            self.context.database_manager.session.commit()
                    else:
                        logger.error(f"No organization information found for project")

                except Exception as e:
                    logger.error(f"Error processing row: {row}. Error: {e}")
                    logger.debug(f"Full error stack trace: {traceback.format_exc()}")
                    self.context.database_manager.session.rollback()

            self.update_summary_table(dateref)

        except Exception as e:
            logger.error(f"Error in load step: {e}")
            logger.debug(f"Full error stack trace: {traceback.format_exc()}")
            self.context.database_manager.session.rollback()

    def update_summary_table(self, dateref):
        try:
            logger.info("Updating SummaryTFCProjects table...")

            summary_data = (
                self.context.database_manager.session.query(
                    DimTFCProjects.organization_dim_rowid,
                    func.count(DimTFCProjects.project_dim_rowid).label("projects_count")
                )
                .join(FactTFCProjects, FactTFCProjects.project_dim_rowid == DimTFCProjects.project_dim_rowid)
                .filter(FactTFCProjects.isactive == 1)
                .group_by(DimTFCProjects.organization_dim_rowid)
                .all()
            )

            for record in summary_data:
                summary_entry = SummaryTFCProjects(
                    organization_dim_rowid=record.organization_dim_rowid,
                    projects_count=record.projects_count,
                    report_dateref=dateref,
                    create_date=datetime.now()
                )
                self.context.database_manager.session.add(summary_entry)

            self.context.database_manager.session.commit()
            logger.info("SummaryTFCProjects table updated successfully.")
        except Exception as e:
            logger.error(f"Error updating summary table: {e}")
            self.context.database_manager.session.rollback()
