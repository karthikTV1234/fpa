import traceback
from datetime import datetime

import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_project_job.tfc_etl_project_job_context import TFCETLProjectJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLProjectJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            if self.context.extracted_data_frame is not None:
                self.context.extracted_data_frame = pd.json_normalize(
                    self.context.extracted_data_frame.to_dict(orient='records'))

                logger.info(f"Extracted DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of extracted data:\n{self.context.extracted_data_frame.head()}")

                required_columns = [
                    "id", "attributes.name",
                    "attributes.description",
                    "attributes.created-at",
                    "relationships.organization.data.id",
                    "links.self",
                    "attributes.workspace-count",
                    "attributes.team-count",
                    "attributes.stack-count",
                    "attributes.auto-destroy-activity-duration"
                ]


                missing_columns = [col for col in required_columns if col not in self.context.extracted_data_frame.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in the extracted data frame: {missing_columns}")

                for column in required_columns:
                    if column not in self.context.extracted_data_frame.columns:
                        self.context.extracted_data_frame[column] = None

                logger.info(f"Modified DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of modified extracted data:\n{self.context.extracted_data_frame.head()}")

                transformed_df = self.context.extracted_data_frame[required_columns].rename(
                    columns={
                        "id": "project_id",
                        "attributes.name": "project_name",
                        "attributes.description": "description",
                        "attributes.created-at": "create_date",
                        "relationships.organization.data.id": "organization_id",
                        "links.self": "api_link",
                        "attributes.workspace-count": "workspace_count",
                        "attributes.team-count": "team_count",
                        "attributes.stack-count": "stack_count",
                        "attributes.auto-destroy-activity-duration": "auto_destroy_activity_duration"
                    }
                )




                logger.info(f"Transformed DataFrame columns: {transformed_df.columns}")
                logger.info(f"First few rows of transformed data:\n{transformed_df.head()}")

                transformed_df["created_date"] = pd.to_datetime(
                    transformed_df.get("created_date", pd.Series(datetime.now(), index=transformed_df.index)),
                    errors="coerce"
                ).dt.tz_localize(None)

               # transformed_df["load_date"] = datetime.now()

                logger.info(f"After datetime conversion:\n{transformed_df[['created_date']].head()}")

                self.context.transformed_data_frame = transformed_df

                logger.info("Transformation step completed successfully.")
            else:
                logger.warning("Extracted data frame is None. Skipping transformation step.")

        except Exception as e:
            logger.error(f"Error in transforming project data: {e}")
            logger.debug(f"Full error stack trace: {traceback.format_exc()}")
