from typing import Optional

import pandas as pd

from shared.repositories.date_repo import DateRepo
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager


class TFCETLRunJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.database_manager: Optional[DatabaseManager] = None
        self.date_repo: Optional[DateRepo] = None
        self.extracted_data_frame: Optional[pd.DataFrame] = None
        self.transformed_data_frame: Optional[pd.DataFrame] = None
