import traceback
from datetime import datetime
from typing import Any

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_run_job.tfc_etl_run_job_context import TFCETLRunJobContext
from shared.models.run import FactRun, FactRunStatus, SummaryRun
from shared.models.workspace import DimTFCWorkspaces
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="LoadStep")


def batch_to_sql(df, table_name, engine, chunk_size=1000):
    df.to_sql(
        table_name,
        engine,
        if_exists='append',
        index=False,
        chunksize=chunk_size,  # Number of rows to insert at a time
    )


class LoadStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            # Validate transformed data frame
            if self.context.transformed_data_frame is not None:
                current_date = datetime.today().date()
                self.workspace:Any
                logger.info(f"DB Session Check: {self.context.database_manager.session}")
                if not self.context.database_manager.session:
                    logger.error("Database session is None. Ensure session is initialized correctly.")
                    return
                for index, row in self.context.transformed_data_frame.iterrows():
                    try:
                        #fact table
                        self.workspace = (
                            self.context.database_manager.session.query(DimTFCWorkspaces)
                            .filter_by(workspace_id=row["workspace_id"], isactive=1)
                            .one_or_none()
                        )

                        if self.workspace:
                            # Read primary key and workspace id
                            workspace_id = self.workspace.workspace_id
                            workspace_rowid = self.workspace.workspace_dim_rowid

                            # Look into the fact_tf_run table using the fetched workspace_dim_rowid
                            fact_run:FactRun = self.context.database_manager.session.query(FactRun).filter_by(
                                workspace_dim_rowid=workspace_rowid, run_id=row["run_id"], isactive=1).one_or_none()

                            if fact_run is None:
                                # insert new record after soft delete
                                fact_run_new = FactRun(
                                    run_id=row["run_id"],
                                    start_dateref=row["start_dateref"],
                                    end_dateref=row["end_dateref"],
                                    workspace_dim_rowid=workspace_rowid,
                                    apply_id=row["apply_id"],
                                    configuration_version_id=row["configuration_version_id"],
                                    created_by=row["created_by"],
                                    plan_id=row["plan_id"],
                                    task_stages=row["task_stages"],
                                    policy_checks=row["policy_checks"],
                                    comments=row["comments"],
                                    create_date=row["create_date"],
                                    isactive=1
                                )
                                self.context.database_manager.session.add(fact_run_new)
                                self.context.database_manager.session.commit()
                                fact_run = fact_run_new
                            else:
                                logger.info(f"Found existing record; Check for any changes")
                                if fact_run.apply_id != row["apply_id"] or fact_run.plan_id != row["plan_id"] or fact_run.task_stages != row["task_stages"] or fact_run.policy_checks != row["policy_checks"] or fact_run.comments != row["comments"]:
                                    fact_run.end_dateref = current_date,
                                    fact_run.isactive =0
                                    self.context.database_manager.session.add(fact_run)
                                    self.context.database_manager.session.commit()

                                    # insert new record after soft delete
                                    fact_run_new = FactRun(
                                        run_id=row["run_id"],
                                        start_dateref = row["start_dateref"],
                                        end_dateref = row["end_dateref"],
                                        workspace_dim_rowid = workspace_rowid,
                                        apply_id = row["apply_id"],
                                        configuration_version_id = row["configuration_version_id"],
                                        created_by = row["created_by"],
                                        plan_id = row["plan_id"],
                                        task_stages = row["task_stages"],
                                        policy_checks = row["policy_checks"],
                                        comments = row["comments"],
                                        create_date = row["create_date"],
                                        isactive = 1
                                    )
                                    self.context.database_manager.session.add(fact_run_new)
                                    self.context.database_manager.session.commit()
                                    fact_run = fact_run_new

                            line_no = 1
                            run_status = row['run_status']
                            if run_status:
                                bulk_run_status_record = []
                                for key, value in run_status.items():
                                    # Check if the record exists for the given field_name
                                    existing_record = (
                                        self.context.database_manager.session.query(FactRunStatus)
                                        .filter_by(
                                            run_dim_row=fact_run.run_dim_row,
                                            field_name=key, isactive=1)
                                        .first()
                                    )
                                    # Insert the new record
                                    fact_new_record = FactRunStatus(
                                        run_dim_row =fact_run.run_dim_row,
                                        line_no=line_no,
                                        field_name=key,
                                        field_value=value,
                                        start_date=datetime.now().date(),
                                        end_date=None,
                                        create_date=datetime.now(),
                                        update_date=datetime.now(),
                                        isactive=1  # Active record
                                    )
                                    bulk_run_status_record.append(fact_new_record)
                                    line_no += 1
                                if bulk_run_status_record:
                                    self.context.database_manager.session.bulk_save_objects(bulk_run_status_record)
                                    self.context.database_manager.session.commit()
                        else:
                            run_id = row["run_id"]
                            logger.error(f"No workspace record for run id: {run_id}")
                    except Exception as row_error:
                        logger.error(
                            f"Error processing row {index} (resource_id={row.get('resource_id', 'Unknown')}): {row_error}")
                        logger.error(traceback.format_exc())
                if self.workspace:
                    # Populate the summary table
                    self.populate_summary_run_table(self.workspace.workspace_dim_rowid)
            else:
                logger.warn(f"data frame is not transformed, hence skipping the loading")
        except Exception as e:
            logger.error(f"Error in loading workspace: {e}")

    def populate_summary_run_table(self, workspace_dim_rowid):
        """Populate summary table with the count of active run."""
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            run_count = (
                self.context.database_manager.session.query(FactRun)
                .filter(FactRun.isactive == 1, FactRun.end_dateref.is_(None))
                .count()
            )

            summary_entry = SummaryRun(
                workspace_dim_rowid=workspace_dim_rowid,
                report_dateref=dateref,
                run_count=run_count,
                create_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active run count: {run_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())