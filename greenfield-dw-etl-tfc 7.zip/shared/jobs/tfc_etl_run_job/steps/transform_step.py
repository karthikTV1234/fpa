from datetime import datetime

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_run_job.tfc_etl_run_job_context import TFCETLRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            if self.context.extracted_data_frame is not None and len(self.context.extracted_data_frame)>0:
                transformed_df = self.context.extracted_data_frame[["id",
                                                                    "relationships.workspace.data.id",
                                                                    "relationships.apply.data.id",
                                                                    "relationships.configuration-version.data.id",
                                                                    "relationships.created-by.data.id",
                                                                    "relationships.plan.data.id",
                                                                    "relationships.task-stages.links.related",
                                                                    "relationships.policy-checks.links.related",
                                                                    "relationships.comments.links.related",
                                                                    "attributes.status-timestamps",
                                                                    "attributes.created-at"
                                                                    ]]
                transformed_df = transformed_df.rename(
                    columns={
                        "id": "run_id",
                        "relationships.workspace.data.id": "workspace_id",
                        "relationships.apply.data.id": "apply_id",
                        "relationships.configuration-version.data.id": "configuration_version_id",
                        "relationships.created-by.data.id": "created_by",
                        "relationships.plan.data.id": "plan_id",
                        "relationships.task-stages.links.related": "task_stages",
                        "relationships.policy-checks.links.related": "policy_checks",
                        "relationships.comments.links.related": "comments",
                        "attributes.status-timestamps": "run_status",
                        "attributes.created-at":"create_date"

                    }
                )

                # Ensure that the column is converted to datetime without timezone information
                # Assign today's date for `start_date`
                transformed_df["start_dateref"] = datetime.today().date()
                transformed_df["end_dateref"] = None
                # Store the transformed data frame in the context for loading
                self.context.transformed_data_frame = transformed_df
        except Exception as e:
            logger.error(f"Error in transforming runs: {e}")