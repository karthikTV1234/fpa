from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_run_job.tfc_etl_run_job_context import TFCETLRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ExtractFromBlobStep")


class ExtractFromBlobStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        directory_path = f"{self.config.dw_tfc_home_directory}/run"
        try:
            data = self.context.azure_blob_manager.extract_run_data_from_directory(
                directory_path=directory_path
            )
            self.context.extracted_data_frame = data
        except Exception as e:
            logger.error(f"Error in extracting workspace: {e}")
