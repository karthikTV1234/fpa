from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_run_job.tfc_etl_run_job_context import TFCETLRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TeardownStep")


class TeardownStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        self.context.database_manager.close_session()
        self.context.azure_blob_manager.close()
