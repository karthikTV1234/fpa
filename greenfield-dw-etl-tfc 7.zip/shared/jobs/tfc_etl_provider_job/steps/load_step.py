import traceback
from datetime import datetime
from typing import Any

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_provider_job.tfc_etl_provider_job_context import TFCETLProviderJobContext
from shared.models.organization import DimTFCOrganization
from shared.models.provider import DimTFCProviderList, FactTFCProviderList, SummaryTFCProvider
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="LoadStep")


class LoadStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLProviderJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            # Validate transformed data frame
            if self.context.transformed_data_frame is not None:
                current_date = datetime.today().date()
                self.existing_org:Any
                logger.info(f"DB Session Check: {self.context.database_manager.session}")
                if not self.context.database_manager.session:
                    logger.error("Database session is None. Ensure session is initialized correctly.")
                    return
                for index, row in self.context.transformed_data_frame.iterrows():
                    try:
                        # org table
                        # Check if the organization already exists in the database
                        self.existing_org = self.context.database_manager.session.query(DimTFCOrganization).filter(
                            DimTFCOrganization.organization_id == row["organization_id"]
                        ).first()

                        if self.existing_org:
                            # Read primary key and workspace id
                            org_id = self.existing_org.organization_id
                            org_name = self.existing_org.organization_name
                            org_rowid = self.existing_org.organization_dim_rowid

                            # Provider list
                            provider:DimTFCProviderList = self.context.database_manager.session.query(DimTFCProviderList).filter_by(
                                provider_id=row["provider_id"], isactive=1).one_or_none()

                            if provider is None:
                                # insert new record after soft delete
                                provider_new = DimTFCProviderList(
                                    provider_id=row["provider_id"],
                                    organization_dim_rowid=org_rowid,
                                    provider_name=row["provider_name"],
                                    namespace=row["namespace"],
                                    registry_name=row["registry_name"],
                                    created_at= self.string_to_datetime(row["created_at"]),
                                    updated_at=self.string_to_datetime(row["updated_at"]),
                                    start_date=row["start_date"],
                                    end_date=row["end_date"],
                                    isactive=1
                                )
                                self.context.database_manager.session.add(provider_new)
                                self.context.database_manager.session.commit()
                                provider = provider_new
                            else:
                                logger.info(f"Found existing record; Check for any changes"),
                                api_updated_at = self.string_to_datetime(row["updated_at"])
                                if provider.provider_name != row["provider_name"] or provider.namespace != row["namespace"] or provider.registry_name != row["registry_name"] or provider.updated_at != api_updated_at:
                                    # Soft delete existing record
                                    provider.end_date = current_date,
                                    provider.isactive = 0
                                    self.context.database_manager.session.add(provider)
                                    self.context.database_manager.session.commit()

                                    # insert new record after soft delete
                                    provider_new = DimTFCProviderList(
                                        provider_id=row["provider_id"],
                                        organization_dim_rowid=org_rowid,
                                        provider_name=row["provider_name"],
                                        namespace=row["namespace"],
                                        registry_name=row["registry_name"],
                                        created_at=self.string_to_datetime(row["created_at"]),
                                        updated_at=self.string_to_datetime(row["updated_at"]),
                                        start_date=row["start_date"],
                                        end_date=row["end_date"],
                                        isactive=1
                                    )
                                    self.context.database_manager.session.add(provider_new)
                                    self.context.database_manager.session.commit()
                                    provider = provider_new

                            # Provider fact table
                            fact_provider_record = (
                                self.context.database_manager.session.query(FactTFCProviderList)
                                .filter_by(
                                    providerlist_dim_rowid=provider.providerlist_dim_rowid,
                                    isactive=1)
                                .one_or_none()
                            )

                            if fact_provider_record:
                                logger.info(f"Found existing record")
                                if fact_provider_record.updated_at != self.string_to_datetime(row["updated_at"]):
                                    # Soft delete existing record
                                    fact_provider_record.end_date = current_date
                                    fact_provider_record.isactive = 0
                                    self.context.database_manager.session.add(fact_provider_record)
                                    self.context.database_manager.session.commit()

                                    # insert new record after soft delete
                                    fact_provider_new = FactTFCProviderList(
                                        providerlist_dim_rowid=provider.providerlist_dim_rowid,
                                        organization_dim_rowid=org_rowid,
                                        created_at=self.string_to_datetime(row["created_at"]),
                                        updated_at=self.string_to_datetime(row["updated_at"]),
                                        start_date=row["start_date"],
                                        end_date=row["end_date"],
                                        isactive=1
                                    )

                                    self.context.database_manager.session.add(fact_provider_new)
                                    self.context.database_manager.session.commit()
                                    fact_provider_record = fact_provider_new
                            else:
                                # insert new record after soft delete
                                fact_provider_new = FactTFCProviderList(
                                    providerlist_dim_rowid=provider.providerlist_dim_rowid,
                                    organization_dim_rowid=org_rowid,
                                    created_at=self.string_to_datetime(row["created_at"]),
                                    updated_at=self.string_to_datetime(row["updated_at"]),
                                    start_date=row["start_date"],
                                    end_date=row["end_date"],
                                    isactive=1
                                )

                                self.context.database_manager.session.add(fact_provider_new)
                                self.context.database_manager.session.commit()
                                fact_provider_record = fact_provider_new

                        else:
                            logger.error(f"No organization information found for provider")
                    except Exception as row_error:
                        logger.error(
                            f"Error processing row {index} (resource_id={row.get('resource_id', 'Unknown')}): {row_error}")
                        logger.error(traceback.format_exc())
                if self.existing_org:
                    # Populate the summary table
                    self.populate_summary_provider_table(self.existing_org.organization_dim_rowid)
            else:
                logger.warn(f"data frame is not transformed, hence skipping the loading")
        except Exception as e:
            logger.error(f"Error in loading workspace: {e}")

    def populate_summary_provider_table(self, organization_dim_rowid):
        """Populate summary table with the count of active provider."""
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            active_count = (
                self.context.database_manager.session.query(DimTFCProviderList)
                .filter(DimTFCProviderList.isactive == 1, DimTFCProviderList.end_date.is_(None))
                .count()
            )

            summary_entry = SummaryTFCProvider(
                organization_dim_rowid=organization_dim_rowid,
                report_dateref=dateref,
                provider_count=active_count,
                create_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active provider count: {active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())

    def  string_to_datetime(self, datetime_str):
        return datetime.strptime(datetime_str, "%Y-%m-%dT%H:%M:%S.%fZ")