from datetime import datetime

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_provider_job.tfc_etl_provider_job_context import TFCETLProviderJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLProviderJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):

        try:
            if self.context.extracted_data_frame is not None and len(self.context.extracted_data_frame) > 0:
                transformed_df = self.context.extracted_data_frame[["id",
                                                                    "type",
                                                                    "attributes.name",
                                                                    "attributes.namespace",
                                                                    "attributes.registry-name",
                                                                    "attributes.created-at",
                                                                    "attributes.updated-at",
                                                                    "relationships.organization.data.id"]]
                # Rename columns for better clarity
                transformed_df = transformed_df.rename(
                    columns={
                        "id": "provider_id",
                        "type": "provider_type",
                        "attributes.name": "provider_name",
                        "attributes.namespace": "namespace",
                        "attributes.registry-name": "registry_name",
                        "attributes.created-at": "created_at",
                        "attributes.updated-at": "updated_at",
                        "relationships.organization.data.id": "organization_id"
                    }
                )
                # Assign today's date for `start_date`
                transformed_df["start_date"] = datetime.today().date()
                transformed_df["end_date"] = None
                self.context.transformed_data_frame = transformed_df
            else:
                logger.warn(f"data frame is not extracted, hence skipping the transformation")
        except Exception as e:
            logger.error(f"Error in transforming provider: {e}")
