from datetime import datetime
from pathlib import Path

from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ArchiveStep")


@measure_time
class ArchiveStep:
    def __init__(self, config, context):
        self.config = config
        self.context = context
        self.source_dirs = [
            f"{self.config.dw_tfc_home_directory}/cv/module",
            f"{self.config.dw_tfc_home_directory}/cv/provider"
        ]
        self.archive_base_dir = "archived_data/cv"

    async def execute(self):
        """
        Move files from source_dirs to archive_base_dir/yyyy/mm/dd/.
        """
        try:
            archive_base_dir = self.archive_base_dir
            current_date = datetime.now()
            date_path = f"{current_date.strftime('%Y/%m/%d')}"

            for source_dir in self.source_dirs:
                files = self.context.azure_blob_manager.list_blobs(directory_name=source_dir)
                if not files:
                    logger.info(f"No files found in {source_dir} to archive.")
                    continue

                archive_dir = f"{archive_base_dir}/{date_path}/{Path(source_dir).name}"

                for file in files:
                    sanitized_file = Path(file).name
                    source_path = f"{source_dir}/{sanitized_file}"
                    destination_path = f"{archive_dir}/{sanitized_file}"

                    self.context.azure_blob_manager.move_blob(
                        source_directory=source_dir,
                        source_path=source_path,
                        destination_directory=archive_dir,
                        destination_path=destination_path,
                    )
                    logger.info(f"Archived file {sanitized_file} to {destination_path}")

        except Exception as e:
            logger.error(f"Error during file archival: {e}", exc_info=True)
