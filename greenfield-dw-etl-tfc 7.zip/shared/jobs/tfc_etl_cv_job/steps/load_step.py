import traceback
from datetime import datetime, date

from shared.models.configuration_version import DimTFCProviderVersion, DimTFCModuleVersions, SummaryTFCModuleVersions, \
    FactTFCModuleVersions, SummaryTFCProviderVersion, FactTFCProviderVersion
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadStep")


class LoadStep:
    def __init__(self, config, context):
        self.config = config
        self.context = context

    async def execute(self):
        try:
            self.populate_module_data()
            self.populate_provider_data()

        except Exception as e:
            logger.error(f"General error in LoadStep.execute: {e}")
            logger.error(traceback.format_exc())

    def populate_module_data(self):
        try:
            if self.context.transformed_module_data_frame is None:
                logger.error("No transformed module data to load.")
                return

            current_date = date.today()

            if not self.context.database_manager.session:
                logger.error("Database session is None.")
                return

            for index, row in self.context.transformed_module_data_frame.iterrows():
                try:
                    # Process dimension table
                    dim_entry_module = (
                        self.context.database_manager.session.query(DimTFCModuleVersions)
                        .filter_by(cv_id=row["cv_id"], module_key=row["module_key"],
                                   module_source=row["module_source"],
                                   module_version=row["module_version"],
                                   module_dir=row["module_dir"],
                                   isactive=1)
                        .one_or_none()
                    )

                    if not dim_entry_module:
                        new_dim_entry_module = DimTFCModuleVersions(
                            module_key=row["module_key"],
                            module_source=row["module_source"],
                            module_version=row["module_version"],
                            module_dir=row["module_dir"],
                            cv_id=row["cv_id"],
                            start_date=current_date,
                            end_date=None,
                            create_date=current_date,
                            isactive=1,
                        )
                        self.context.database_manager.session.add(new_dim_entry_module)
                        self.context.database_manager.session.commit()
                        dim_entry_module = new_dim_entry_module
                    else:
                        if (
                                dim_entry_module.module_key != row["module_key"]
                                or dim_entry_module.module_source != row["module_source"]
                                or dim_entry_module.module_version != row["module_version"]
                                or dim_entry_module.module_dir != row["module_dir"]
                                or dim_entry_module.cv_id != row["cv_id"]
                        ):
                            dim_entry_module.end_date = current_date
                            dim_entry_module.isactive = 0
                            self.context.database_manager.session.commit()

                            new_dim_entry_module = DimTFCModuleVersions(
                                module_key=row["module_key"],
                                module_source=row["module_source"],
                                module_version=row["module_version"],
                                module_dir=row["module_dir"],
                                cv_id=row["cv_id"],
                                start_date=current_date,
                                end_date=None,
                                isactive=1,
                            )
                            self.context.database_manager.session.add(new_dim_entry_module)
                            self.context.database_manager.session.commit()
                            dim_entry_module = new_dim_entry_module

                    # Process fact table
                    fact_entry = (
                        self.context.database_manager.session.query(FactTFCModuleVersions)
                        .filter_by(moduleversion_dim_rowid=dim_entry_module.moduleversion_dim_rowid, isactive=1)
                        .one_or_none()
                    )
                    if not fact_entry:
                        new_fact_entry = FactTFCModuleVersions(
                            moduleversion_dim_rowid=dim_entry_module.moduleversion_dim_rowid,
                            start_dateref=current_date,
                            end_dateref=None,
                            created_date=current_date,
                            isactive=1,
                        )
                        self.context.database_manager.session.add(new_fact_entry)
                        self.context.database_manager.session.commit()
                        fact_entry = new_fact_entry

                except Exception as e:
                    logger.error(f"Error processing row {row}: {e}")
                    logger.error(traceback.format_exc())

            # Populate the summary table
            self.populate_summary_tf_module_version_table()

        except Exception as e:
            logger.error(f"General error in LoadStep.populate_module_data: {e}")
            logger.error(traceback.format_exc())

    def populate_provider_data(self):
        try:
            if self.context.transformed_provider_data_frame is None:
                logger.error("No transformed provider data to load.")
                return

            current_date = date.today()

            if not self.context.database_manager.session:
                logger.error("Database session is None.")
                return

            for index, row in self.context.transformed_provider_data_frame.iterrows():
                try:
                    # Process provider table
                    dim_entry_provider = (
                        self.context.database_manager.session.query(DimTFCProviderVersion)
                        .filter_by(cv_id=row["cv_id"], provider_name=row["provider_name"],
                                   provider_version=row["provider_version"], isactive=1)
                        .one_or_none()
                    )

                    if not dim_entry_provider:
                        new_dim_entry_provider = DimTFCProviderVersion(
                            provider_name=row["provider_name"],
                            provider_version=row["provider_version"],
                            cv_id=row["cv_id"],
                            start_date=current_date,
                            end_date=None,
                            create_date=current_date,
                            isactive=1,
                        )
                        self.context.database_manager.session.add(new_dim_entry_provider)
                        self.context.database_manager.session.commit()
                        dim_entry_provider = new_dim_entry_provider
                    else:
                        if (
                                dim_entry_provider.provider_name != row["provider_name"]
                                or dim_entry_provider.provider_version != row["provider_version"]
                                or dim_entry_provider.cv_id != row["cv_id"]
                        ):
                            dim_entry_provider.end_date = current_date
                            dim_entry_provider.isactive = 0
                            self.context.database_manager.session.commit()

                            new_dim_entry_provider = DimTFCProviderVersion(
                                provider_name=row["provider_name"],
                                provider_version=row["provider_version"],
                                cv_id=row["cv_id"],
                                start_date=current_date,
                                end_date=None,
                                isactive=1,
                            )
                            self.context.database_manager.session.add(new_dim_entry_provider)
                            self.context.database_manager.session.commit()
                            dim_entry_provider = new_dim_entry_provider

                    # Process fact table
                    fact_entry = (
                        self.context.database_manager.session.query(FactTFCProviderVersion)
                        .filter_by(providerversion_dim_rowid=dim_entry_provider.providerversion_dim_rowid, isactive=1)
                        .one_or_none()
                    )
                    if not fact_entry:
                        new_fact_entry = FactTFCProviderVersion(
                            providerversion_dim_rowid=dim_entry_provider.providerversion_dim_rowid,
                            start_dateref=current_date,
                            end_dateref=None,
                            created_date=current_date,
                            isactive=1,
                        )
                        self.context.database_manager.session.add(new_fact_entry)
                        self.context.database_manager.session.commit()
                        fact_entry = new_fact_entry

                except Exception as e:
                    logger.error(f"Error processing row {row}: {e}")
                    logger.error(traceback.format_exc())

            self.populate_summary_tf_provider_version_table()

        except Exception as e:
            logger.error(f"General error in LoadStep.populate_provider_data: {e}")
            logger.error(traceback.format_exc())

    def populate_summary_tf_module_version_table(self):
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            active_count = (
                self.context.database_manager.session.query(DimTFCModuleVersions)
                .filter(DimTFCModuleVersions.isactive == 1, DimTFCModuleVersions.end_date.is_(None))
                .count()
            )

            summary_az_entry = SummaryTFCModuleVersions(
                report_dateref=dateref,
                total_modules_used=active_count,
                created_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_az_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active modules count: {active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())

    def populate_summary_tf_provider_version_table(self):
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            active_count = (
                self.context.database_manager.session.query(DimTFCProviderVersion)
                .filter(DimTFCProviderVersion.isactive == 1, DimTFCProviderVersion.end_date.is_(None))
                .count()
            )

            summary_az_entry = SummaryTFCProviderVersion(
                report_dateref=dateref,
                total_providers_used=active_count,
                created_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_az_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active providers count: {active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())