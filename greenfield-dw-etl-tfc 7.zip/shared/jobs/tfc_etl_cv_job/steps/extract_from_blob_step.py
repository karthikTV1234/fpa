import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_cv_job.tfc_etl_cv_job_context import TFCETLCVJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ExtractFromBlobStep")


class ExtractFromBlobStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLCVJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        base_directory = f"{self.config.dw_tfc_home_directory}/cv"
        subdirectories = ["module", "provider"]  # Subfolders containing JSON files

        try:
            module_data = []
            provider_data = []
            module_files = 0
            provider_files = 0

            for subdir in subdirectories:
                directory = f"{base_directory}/{subdir}"

                # Get a list of all JSON files in the subdirectory
                json_files = self.context.azure_blob_manager.list_blobs(directory_name=directory)
                json_files = [f for f in json_files if f.endswith(".json")]

                for filename in json_files:
                    # Extract JSON data from each file
                    data = self.context.azure_blob_manager.read_json_from_blob(
                        directory_name=directory,
                        file_path=filename
                    )
                    if isinstance(data, list):  # If the file contains a list of dictionaries
                        if subdir == "module":
                            module_data.extend(data)
                        else:
                            provider_data.extend(data)
                    elif isinstance(data, dict):  # If the file contains a single dictionary
                        if subdir == "module":
                            module_data.append(data)
                        else:
                            provider_data.append(data)
                    else:
                        logger.warning(f"Unexpected data format in file: {filename}")

                if subdir == "module":
                    module_files += len(json_files)
                else:
                    provider_files += len(json_files)

                if module_data:
                    self.context.extracted_module_data_frame = pd.DataFrame(module_data)
                if provider_data:
                    self.context.extracted_provider_data_frame = pd.DataFrame(provider_data)

            logger.info(f"Read data from {module_files} JSON files in module folder")
            logger.info(f"Read data from {provider_files} JSON files in provider folder")
        except Exception as e:
            logger.error(f"Error in extracting data from directory: {e}")

