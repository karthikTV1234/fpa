import traceback

import numpy as np
import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_cv_job.tfc_etl_cv_job_context import TFCETLCVJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLCVJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            # ===== MODULE DATAFRAME TRANSFORMATION ===== #
            if self.context.extracted_module_data_frame is not None:
                # Flatten nested JSON fields in extracted DataFrame
                self.context.extracted_module_data_frame = pd.json_normalize(
                    self.context.extracted_module_data_frame.to_dict(orient='records'),
                    record_path=["Modules"]  # Extract from the nested "Modules" list
                )
                logger.info(f"Extracted Module DataFrame columns: {self.context.extracted_module_data_frame.columns}")
                logger.info(
                    f"First few rows of module extracted data:\n{self.context.extracted_module_data_frame.head()}")

                required_columns_module = ["Key", "Source", "Version", "Dir", "cv_id"]

                # Ensure all required columns exist, fill missing ones with None
                missing_columns = [col for col in required_columns_module if
                                   col not in self.context.extracted_module_data_frame.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in module data frame: {missing_columns}")

                self.context.extracted_module_data_frame = self.context.extracted_module_data_frame.reindex(
                    columns=required_columns_module, fill_value=None)

                # Transform DataFrame
                transformed_df_module = self.context.extracted_module_data_frame.rename(
                    columns={"Key": "module_key",
                             "Source": "module_source",
                             "Version": "module_version",
                             "Dir": "module_dir",
                             "cv_id": "cv_id"}
                )

                logger.info(f"Transformed Module DataFrame columns: {transformed_df_module.columns}")
                logger.info(f"First few rows of module transformed data:\n{transformed_df_module.head()}")

                # Ensure consistent missing value representation
                transformed_df_module = transformed_df_module.replace({np.nan: None})

                logger.info(f"Final Transformed Module DataFrame:\n{transformed_df_module.head()}")

                self.context.transformed_module_data_frame = transformed_df_module

            # ===== PROVIDER DATAFRAME TRANSFORMATION ===== #
            if self.context.extracted_provider_data_frame is not None:
                # Flatten nested JSON fields in extracted DataFrame
                self.context.extracted_provider_data_frame = pd.json_normalize(
                    self.context.extracted_provider_data_frame.to_dict(orient='records'))

                logger.info(
                    f"Extracted Provider DataFrame columns: {self.context.extracted_provider_data_frame.columns}")
                logger.info(
                    f"First few rows of provider extracted data:\n{self.context.extracted_provider_data_frame.head()}")

                required_columns_provider = ["provider_name", "version", "cv_id"]

                # Ensure all required columns exist, fill missing ones with None
                missing_columns = [col for col in required_columns_provider if
                                   col not in self.context.extracted_provider_data_frame.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in provider data frame: {missing_columns}")

                self.context.extracted_provider_data_frame = self.context.extracted_provider_data_frame.reindex(
                    columns=required_columns_provider, fill_value=None)

                # Transform DataFrame
                transformed_df_provider = self.context.extracted_provider_data_frame.rename(
                    columns={"provider_name": "provider_name",
                             "version": "provider_version",
                             "cv_id": "cv_id"}
                )

                logger.info(f"Transformed Provider DataFrame columns: {transformed_df_provider.columns}")
                logger.info(f"First few rows of provider transformed data:\n{transformed_df_provider.head()}")

                # Ensure consistent missing value representation
                transformed_df_provider = transformed_df_provider.replace({np.nan: None})

                logger.info(f"Final Transformed Provider DataFrame:\n{transformed_df_provider.head()}")

                self.context.transformed_provider_data_frame = transformed_df_provider

            logger.info("Transformation step completed successfully.")

        except Exception as e:
            logger.error(f"Error in transforming workspace data: {e}")
            logger.debug(f"Full error stack trace: {traceback.format_exc()}")
