import traceback
from datetime import datetime

import numpy as np
import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_workspace_job.tfc_etl_workspace_job_context import TFCETLWorkspaceJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLWorkspaceJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            # Check if extracted data is available
            if self.context.extracted_data_frame is not None:
                # Flatten nested JSON fields in extracted DataFrame
                self.context.extracted_data_frame = pd.json_normalize(
                    self.context.extracted_data_frame.to_dict(orient='records'))

                # Log the structure of the extracted DataFrame
                logger.info(f"Extracted DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of extracted data:\n{self.context.extracted_data_frame.head()}")

                # Define the required columns
                required_columns = [
                    "id", "attributes.name",
                    "attributes.apply-duration-average",
                    "attributes.allow-destroy-plan",
                    "attributes.auto-apply-run-trigger",
                    "attributes.auto-apply",
                    "attributes.auto-destroy-activity-duration",
                    "attributes.auto-destroy-at",
                    "attributes.auto-destroy-status",
                    "attributes.assessments-enabled",
                    "attributes.last-assessment-result-at",
                    "attributes.created-at",
                    "attributes.updated-at",
                    "attributes.description",
                    "attributes.environment",
                    "attributes.file-triggers-enabled",
                    "attributes.global-remote-state",
                    "attributes.locked",
                    "attributes.locked-reason",
                    "attributes.inherits-project-auto-destroy",
                    "attributes.plan-duration-average",
                    "attributes.policy-check-failures",
                    "attributes.queue-all-runs",
                    "attributes.run-failures",
                    "attributes.resource-count",
                    "attributes.speculative-enabled",
                    "attributes.structured-run-output-enabled",
                    "attributes.source",
                    "attributes.source-name",
                    "attributes.terraform-version",
                    "attributes.tag-names",
                    "attributes.working-directory",
                    "attributes.actions.is-destroyable",
                    "attributes.setting-overwrites.execution-mode",
                    "attributes.setting-overwrites.agent-pool",
                    "relationships.project.data.id",
                    "relationships.locked-by.data.id",
                    "relationships.locked-by.links.related",
                    "relationships.current-run.data.id",
                    "relationships.latest-run.data.id",
                    "relationships.outputs",
                    "relationships.remote-state-consumers.links.related",
                    "relationships.current-state-version.data.id",
                    "relationships.current-state-version.links.related",
                    "relationships.current-configuration-version.data.id",
                    "relationships.current-configuration-version.links.related",
                    "relationships.agent-pool.data.id",
                    "relationships.readme",
                    "relationships.current-assessment-result",
                    "relationships.organization.data.id",
                    "links.self"
                ]

                # Check if all required columns are in the extracted DataFrame
                missing_columns = [col for col in required_columns if
                                   col not in self.context.extracted_data_frame.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in the extracted data frame: {missing_columns}")

                # Ensure "relationships.outputs" is extracted properly before handling required columns
                if "relationships.outputs.data" in self.context.extracted_data_frame.columns:
                    self.context.extracted_data_frame["relationships.outputs"] = self.context.extracted_data_frame[
                        "relationships.outputs.data"].astype(str)
                else:
                    self.context.extracted_data_frame["relationships.outputs"] = [[]] * len(
                        self.context.extracted_data_frame)  # Corrected empty list handling

                # Ensure "attributes.tag-names" is extracted properly before handling required columns
                if "relationships.tag-names" in self.context.extracted_data_frame.columns:
                    self.context.extracted_data_frame["relationships.tag-names"] = self.context.extracted_data_frame[
                            "relationships.tag-names"].astype(str)
                else:
                    self.context.extracted_data_frame["relationships.tag-names"] = [[]] * len(
                            self.context.extracted_data_frame)  # Corrected empty list handling

                # Ensure all required columns exist in the DataFrame, add defaults where missing
                for column in required_columns:
                    if column not in self.context.extracted_data_frame.columns:
                        if column in {
                            "relationships.readme",
                            "relationships.current-assessment-result",
                            "attributes.tag-names"
                        }:
                            # Store as an empty string "" instead of an empty list []
                            self.context.extracted_data_frame[column] = ""
                        else:
                            self.context.extracted_data_frame[
                                column] = None  # Default to None for missing scalar values

                # Debug: Check if the columns are added correctly
                logger.info(f"Columns after adding defaults: {self.context.extracted_data_frame.columns}")

                # Log the modified extracted data after adding missing columns
                # logger.info(f"Modified DataFrame columns: {self.context.extracted_data_frame.columns}")
                # logger.info(f"First few rows of modified extracted data:\n{self.context.extracted_data_frame.head()}")

                # Select and rename relevant fields for transformation
                transformed_df = self.context.extracted_data_frame[required_columns].rename(
                    columns={
                        "id": "workspace_id", "attributes.name": "workspace_name",
                        "attributes.actions.is-destroyable": "actions_is_destroyable",
                        "attributes.apply-duration-average": "apply_duration_average",
                        "attributes.allow-destroy-plan": "allow_destroy_plan",
                        "attributes.auto-apply-run-trigger": "auto_apply_run_trigger",
                        "attributes.auto-apply": "auto_apply",
                        "attributes.auto-destroy-activity-duration": "auto_destroy_activity_duration",
                        "attributes.auto-destroy-at": "auto_destroy_at",
                        "attributes.auto-destroy-status": "auto_destroy_status",
                        "attributes.assessments-enabled": "assessments_enabled",
                        "attributes.last-assessment-result-at": "last_assessment_result_at",
                        "attributes.created-at": "created_at",
                        "attributes.updated-at": "updated_at",
                        "attributes.description": "description",
                        "attributes.environment": "environment",
                        "attributes.file-triggers-enabled": "file_triggers_enabled",
                        "attributes.global-remote-state": "global_remote_state",
                        "attributes.locked": "locked",
                        "attributes.locked-reason": "locked_reason",
                        "attributes.inherits-project-auto-destroy": "inherits_project_auto_destroy",
                        "attributes.plan-duration-average": "plan_duration_average",
                        "attributes.policy-check-failures": "policy_check_failures",
                        "attributes.queue-all-runs": "queue_all_runs",
                        "attributes.run-failures": "run_failures",
                        "attributes.resource-count": "resource_count",
                        "attributes.speculative-enabled": "speculative_enabled",
                        "attributes.structured-run-output-enabled": "structured_run_output_enabled",
                        "attributes.source": "source",
                        "attributes.source-name": "source_name",
                        "attributes.setting-overwrites.execution-mode": "setting_overwrites_execution_mode",
                        "attributes.setting-overwrites.agent-pool": "setting_overwrites_agent_pool",
                        "attributes.terraform-version": "terraform_version",
                        "attributes.tag-names": "tag_names",
                        "attributes.working-directory": "working_directory",
                        "relationships.project.data.id": "project_id",
                        "relationships.locked-by.data.id": "locked_by_id",
                        "relationships.locked-by.links.related": "locked_by_links_related",
                        "relationships.current-run.data.id": "current_run_id",
                        "relationships.latest-run.data.id": "latest_run_id",
                        "relationships.outputs": "outputs",
                        "relationships.remote-state-consumers.links.related": "remote_state_consumers_links_related",
                        "relationships.current-state-version.data.id": "current_state_version_data_id",
                        "relationships.current-state-version.links.related": "current_state_version_links_related",
                        "relationships.current-configuration-version.data.id": "current_configuration_version_data_id",
                        "relationships.current-configuration-version.links.related": "current_configuration_version_links_related",
                        "relationships.agent-pool.data.id": "agent_pool_data_id",
                        "relationships.readme": "readme",
                        "relationships.current-assessment-result": "current_assessment_result",
                        "relationships.organization.data.id": "organization_id",
                        "links.self": "api_link"
                    }
                )

                # Log transformed DataFrame to check intermediate state
                # logger.info(f"Transformed DataFrame columns: {transformed_df.columns}")
                # logger.info(f"First few rows of transformed data:\n{transformed_df.head()}")

                # Ensure that the column is converted to datetime without timezone information
                transformed_df["created_at"] = pd.to_datetime(
                    transformed_df.get("created_at", pd.Series(datetime.now(), index=transformed_df.index)),
                    errors="coerce"
                ).dt.tz_localize(None)

                transformed_df["updated_at"] = pd.to_datetime(
                    transformed_df.get("updated_at", pd.Series(datetime.now(), index=transformed_df.index)),
                    errors="coerce"
                ).dt.tz_localize(None)

                transformed_df = transformed_df.replace({np.nan: None})

                # Log datetime conversion check
                logger.info(f"After datetime conversion:\n{transformed_df[['created_at', 'updated_at']].head()}")

                # Log the final transformed data
                logger.info(f"Transformed DataFrame (final):\n{transformed_df.head()}")

                # Store the transformed DataFrame in the context for loading
                self.context.transformed_data_frame = transformed_df

                logger.info("Transformation step completed successfully.")
            else:
                logger.warning("Extracted data frame is None. Skipping transformation step.")

        except Exception as e:
            logger.error(f"Error in transforming workspace data: {e}")
            logger.debug(f"Full error stack trace: {traceback.format_exc()}")
