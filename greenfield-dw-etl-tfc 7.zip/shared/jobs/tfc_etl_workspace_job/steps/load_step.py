import traceback
from datetime import date, datetime

import pandas as pd

from shared.models.organization import DimTFCOrganization
from shared.models.project import DimTFCProjects
from shared.models.workspace import DimTFWorkspaceRelationship, FactTFCWorkspaces, DimTFCWorkspaces, \
    SummaryTFCWorkspaces
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadStep")


class LoadStep:
    def __init__(self, config, context):
        self.config = config
        self.context = context
        self.org_dim_rowid = None
        self.project_dim_rowid = None

    async def execute(self):
        try:
            if self.context.transformed_data_frame is None:
                logger.error("No transformed data to load.")
                return

            fact_data = []
            current_date = date.today()

            if not self.context.database_manager.session:
                logger.error("Database session is None.")
                return

            for index, row in self.context.transformed_data_frame.iterrows():
                try:
                    # org data
                    org = (
                        self.context.database_manager.session.query(DimTFCOrganization)
                        .filter_by(organization_id=row["organization_id"], isactive=1)
                        .one_or_none()
                    )

                    if org is not None:
                        self.org_dim_rowid = org.organization_dim_rowid
                        # project data
                        project = (
                            self.context.database_manager.session.query(DimTFCProjects)
                            .filter_by(project_id=row["project_id"], isactive=1)
                            .one_or_none()
                        )
                        self.project_dim_rowid = project.project_dim_rowid
                        # Process dimension table
                        dim_entry = (
                            self.context.database_manager.session.query(DimTFCWorkspaces)
                            .filter_by(workspace_id=row["workspace_id"], isactive=1)
                            .one_or_none()
                        )

                        if not dim_entry:
                            new_dim_entry = DimTFCWorkspaces(
                                workspace_id=row["workspace_id"],
                                workspace_name=row["workspace_name"],
                                project_dim_rowid=self.project_dim_rowid,
                                created_at=row["created_at"],
                                updated_at=row["updated_at"],
                                allow_destroy_plan=row.get("allow_destroy_plan"),
                                auto_apply=row.get("auto_apply"),
                                auto_apply_run_trigger=row.get("auto_apply_run_trigger"),
                                auto_destroy_activity_duration=row.get("auto_destroy_activity_duration"),
                                auto_destroy_at=row.get("auto_destroy_at"),
                                auto_destroy_status=row.get("auto_destroy_status"),
                                environment=row.get("environment"),
                                global_remote_state=row.get("global_remote_state"),
                                inherits_project_auto_destroy=row.get("inherits_project_auto_destroy"),
                                terraform_version=row.get("terraform_version"),
                                locked=row.get("locked"),
                                queue_all_runs=row.get("queue_all_runs"),
                                speculative_enabled=row.get("speculative_enabled"),
                                structured_run_output_enabled=row.get("structured_run_output_enabled"),
                                working_directory=row.get("working_directory"),
                                description=row.get("description"),
                                file_triggers_enabled=row.get("file_triggers_enabled"),
                                assessments_enabled=row.get("assessments_enabled"),
                                last_assessment_result_at=row.get("last_assessment_result_at"),
                                locked_reason=row.get("locked_reason"),
                                source=row.get("source"),
                                source_name=row.get("source_name"),
                                source_url=row.get("source_url"),
                                tag_names=row.get("tag_names"),
                                setting_overwrites_execution_mode=row.get("setting_overwrites_execution_mode"),
                                setting_overwrites_agent_pool=row.get("setting_overwrites_agent_pool"),
                                start_date=current_date,
                                end_date=None,
                                create_date=row.get("created_at"),
                                isactive=1,
                            )

                            self.context.database_manager.session.add(new_dim_entry)
                            self.context.database_manager.session.commit()
                            dim_entry = new_dim_entry
                        else:
                            if (
                                    dim_entry.workspace_name != row["workspace_name"]
                            ):
                                dim_entry.end_date = current_date
                                dim_entry.isactive = 0
                                self.context.database_manager.session.commit()

                                new_dim_entry = DimTFCWorkspaces(
                                    workspace_id=row["workspace_id"],
                                    workspace_name=row["workspace_name"],
                                    project_dim_rowid=self.project_dim_rowid,
                                    created_at=row["created_at"],
                                    updated_at=row["updated_at"],
                                    allow_destroy_plan=row.get("allow_destroy_plan"),
                                    auto_apply=row.get("auto_apply"),
                                    auto_apply_run_trigger=row.get("auto_apply_run_trigger"),
                                    auto_destroy_activity_duration=row.get("auto_destroy_activity_duration"),
                                    auto_destroy_at=row.get("auto_destroy_at"),
                                    auto_destroy_status=row.get("auto_destroy_status"),
                                    environment=row.get("environment"),
                                    global_remote_state=row.get("global_remote_state"),
                                    inherits_project_auto_destroy=row.get("inherits_project_auto_destroy"),
                                    terraform_version=row.get("terraform_version"),
                                    locked=row.get("locked"),
                                    queue_all_runs=row.get("queue_all_runs"),
                                    speculative_enabled=row.get("speculative_enabled"),
                                    structured_run_output_enabled=row.get("structured_run_output_enabled"),
                                    working_directory=row.get("working_directory"),
                                    description=row.get("description"),
                                    file_triggers_enabled=row.get("file_triggers_enabled"),
                                    assessments_enabled=row.get("assessments_enabled"),
                                    last_assessment_result_at=row.get("last_assessment_result_at"),
                                    locked_reason=row.get("locked_reason"),
                                    source=row.get("source"),
                                    source_name=row.get("source_name"),
                                    source_url=row.get("source_url"),
                                    tag_names=row.get("tag_names"),
                                    setting_overwrites_execution_mode=row.get("setting_overwrites_execution_mode"),
                                    setting_overwrites_agent_pool=row.get("setting_overwrites_agent_pool"),
                                    start_date=current_date,
                                    end_date=None,
                                    isactive=1,
                                )
                                self.context.database_manager.session.add(new_dim_entry)
                                self.context.database_manager.session.commit()
                                dim_entry = new_dim_entry

                        # Process workspace relationship table
                        relationship_entry = (
                            self.context.database_manager.session.query(DimTFWorkspaceRelationship)
                            .filter_by(workspace_dim_rowid=dim_entry.workspace_dim_rowid, isactive=1)
                            .one_or_none()
                        )

                        if not relationship_entry:
                            new_relationship_entry = DimTFWorkspaceRelationship(
                                workspace_dim_rowid=dim_entry.workspace_dim_rowid,
                                locked_by_id=row.get("locked_by_id"),
                                locked_by_links_related=row.get("locked_by_links_related"),
                                current_run_id=row.get("current_run_id"),
                                latest_run_id=row.get("latest_run_id"),
                                outputs=row.get("outputs"),
                                remote_state_consumers_links_related=row.get("remote_state_consumers_links_related"),
                                current_state_version_data_id=row.get("current_state_version_data_id"),
                                current_state_version_links_related=row.get("current_state_version_links_related"),
                                current_configuration_version_data_id=row.get("current_configuration_version_data_id"),
                                current_configuration_version_links_related=row.get(
                                    "current_configuration_version_links_related"),
                                agent_pool_data_id=row.get("agent_pool_data_id"),
                                readme=row.get("readme"),
                                current_assessment_result=row.get("current_assessment_result"),
                                start_date=current_date,
                                end_date=None,
                                create_date=current_date,
                                isactive=1,
                            )
                            self.context.database_manager.session.add(new_relationship_entry)
                            self.context.database_manager.session.commit()
                            relationship_entry = new_relationship_entry
                        else:
                            # Check for changes in Fact table fields
                            if (
                                    relationship_entry.locked_by_id != row["locked_by_id"]
                                    or relationship_entry.locked_by_links_related != row["locked_by_links_related"]
                                    or relationship_entry.current_run_id != row["current_run_id"]
                                    or relationship_entry.latest_run_id != row["latest_run_id"]
                                    or relationship_entry.outputs != row["outputs"]
                                    or relationship_entry.remote_state_consumers_links_related != row[
                                "remote_state_consumers_links_related"]
                                    or relationship_entry.current_state_version_data_id != row[
                                "current_state_version_data_id"]
                                    or relationship_entry.current_state_version_links_related != row[
                                "current_state_version_links_related"]
                                    or relationship_entry.current_configuration_version_data_id != row[
                                "current_configuration_version_data_id"]
                                    or relationship_entry.current_configuration_version_links_related != row[
                                "current_configuration_version_links_related"]
                                    or relationship_entry.agent_pool_data_id != row["agent_pool_data_id"]
                                    or relationship_entry.readme != row["readme"]
                                    or relationship_entry.current_assessment_result != row["current_assessment_result"]
                            ):
                                relationship_entry.end_date = current_date
                                relationship_entry.isactive = 0
                                self.context.database_manager.session.commit()

                                new_relationship_entry = DimTFWorkspaceRelationship(
                                    workspace_dim_rowid=dim_entry.workspace_dim_rowid,
                                    locked_by_id=row.get("locked_by_id"),
                                    locked_by_links_related=row.get("locked_by_links_related"),
                                    current_run_id=row.get("current_run_id"),
                                    latest_run_id=row.get("latest_run_id"),
                                    outputs=row.get("outputs"),
                                    remote_state_consumers_links_related=row.get(
                                        "remote_state_consumers_links_related"),
                                    current_state_version_data_id=row.get("current_state_version_data_id"),
                                    current_state_version_links_related=row.get("current_state_version_links_related"),
                                    current_configuration_version_data_id=row.get(
                                        "current_configuration_version_data_id"),
                                    current_configuration_version_links_related=row.get(
                                        "current_configuration_version_links_related"),
                                    agent_pool_data_id=row.get("agent_pool_data_id"),
                                    readme=row.get("readme"),
                                    current_assessment_result=row.get("current_assessment_result"),
                                    start_date=current_date,
                                    end_date=None,
                                    isactive=1,
                                )
                                self.context.database_manager.session.add(new_relationship_entry)
                                self.context.database_manager.session.commit()
                                relationship_entry = new_relationship_entry

                        # Process fact table
                        fact_entry = (
                            self.context.database_manager.session.query(FactTFCWorkspaces)
                            .filter_by(workspace_dim_rowid=dim_entry.workspace_dim_rowid, isactive=1)
                            .one_or_none()
                        )

                        if fact_entry:
                            fact_entry.isactive = 0
                            fact_entry.end_date = current_date
                            self.context.database_manager.session.commit()

                        fact_data.append(
                            FactTFCWorkspaces(
                                workspace_dim_rowid=dim_entry.workspace_dim_rowid,
                                resource_count=row.get("resource_count"),
                                apply_duration_average=row.get("apply_duration_average"),
                                plan_duration_average=row.get("plan_duration_average"),
                                policy_check_failures=row.get("policy_check_failures"),
                                run_failures=row.get("run_failures"),
                                workspace_kpis_runs_count=row.get("workspace_kpis_runs_count"),
                                latest_change_at=pd.to_datetime(row.get("latest_change_at"), errors="coerce"),
                                operations=row.get("operations"),
                                execution_mode=row.get("execution_mode"),
                                vcs_repo=row.get("vcs_repo"),
                                vcs_repo_identifier=row.get("vcs_repo_identifier"),
                                start_date=current_date,
                                end_date=None,
                                isactive=1,
                            )
                        )
                    else:
                        logger.error(f"No organization information found for workspace")
                except Exception as row_error:
                    logger.error(
                        f"Error processing row {index} (workspace_id={row.get('workspace_id', 'Unknown')}): {row_error}")
                    logger.error(traceback.format_exc())
                    self.context.database_manager.session.rollback()

            if fact_data:
                try:
                    self.context.database_manager.session.bulk_save_objects(fact_data)
                    self.context.database_manager.session.commit()
                    logger.info(f"Inserted {len(fact_data)} records into fact_tfc_workspaces.")
                except Exception as bulk_error:
                    logger.error(f"Error during bulk insert: {bulk_error}")
                    logger.error(traceback.format_exc())
                    self.context.database_manager.session.rollback()

            # Populate the summary table
            self.populate_summary_tf_workspace_table()

        except Exception as e:
            logger.error(f"General error in LoadStep: {e}")
            logger.error(traceback.format_exc())

    def populate_summary_tf_workspace_table(self):
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            workspace_active_count = (
                self.context.database_manager.session.query(DimTFCWorkspaces)
                .filter(DimTFCWorkspaces.isactive == 1, DimTFCWorkspaces.end_date.is_(None))
                .count()
            )

            summary_az_entry = SummaryTFCWorkspaces(
                organization_dim_rowid=self.org_dim_rowid,
                report_dateref=dateref,
                workspace_count=workspace_active_count,
                create_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_az_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active workspace count: {workspace_active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())
