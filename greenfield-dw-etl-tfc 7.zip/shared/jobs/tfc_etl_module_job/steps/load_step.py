import json
import traceback
from datetime import datetime, date

from sqlalchemy import func

from shared.models.module import DimTFCModules, FactTFCModules, SummaryTFCModules, DimTFCModuleVersionStatus
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadStep")


class LoadStep:
    def __init__(self, config, context):
        self.config = config
        self.context = context

    async def execute(self):
        try:
            if self.context.transformed_data_frame is None:
                logger.error("No transformed data to load.")
                return

            dateref = int(datetime.now().strftime("%Y%m%d"))  # Current date reference
            current_date = date.today()

            for _, row in self.context.transformed_data_frame.iterrows():
                try:
                    dim_module_entry = self.context.database_manager.session.query(DimTFCModules).filter_by(
                        module_id=row["module_id"],
                        isactive=1
                    ).one_or_none()

                    if dim_module_entry:
                        if any([
                            dim_module_entry.module_name != row["module_name"],
                            dim_module_entry.namespace != row["namespace"],
                            dim_module_entry.provider != row["provider"],
                            dim_module_entry.status != row["status"],
                            dim_module_entry.registry_name != row["registry_name"],
                            dim_module_entry.nocode != row["nocode"],
                            dim_module_entry.publishing_mechanism != row["publishing_mechanism"],
                            dim_module_entry.created_at != row["created_at"],
                            dim_module_entry.updated_at != row["updated_at"]
                        ]):
                            existing_entries = self.context.database_manager.session.query(DimTFCModules).filter_by(
                                module_id=row["module_id"],
                                isactive=1
                            ).all()
                            for entry in existing_entries:
                                entry.end_date = current_date
                                entry.isactive = 0
                                entry.updated_at = datetime.now()
                            self.context.database_manager.session.commit()

                            dim_module_entry = DimTFCModules(
                                module_id=row["module_id"],
                                organization_dim_rowid=row["organization_id"],
                                module_name=row["module_name"],
                                namespace=row["namespace"],
                                provider=row["provider"],
                                registry_name=row["registry_name"],
                                nocode=row["nocode"],
                                publishing_mechanism=row["publishing_mechanism"],
                                status=row["status"],
                                start_date=current_date,
                                end_date=None,
                                created_at=row["created_at"],
                                updated_at=row["updated_at"],
                                isactive=1
                            )
                            self.context.database_manager.session.add(dim_module_entry)
                            self.context.database_manager.session.commit()
                    else:
                        dim_module_entry = DimTFCModules(
                            module_id=row["module_id"],
                            organization_dim_rowid=row["organization_id"],
                            module_name=row["module_name"],
                            namespace=row["namespace"],
                            provider=row["provider"],
                            registry_name=row["registry_name"],
                            nocode=row["nocode"],
                            publishing_mechanism=row["publishing_mechanism"],
                            status=row["status"],
                            start_date=current_date,
                            end_date=None,
                            created_at=row["created_at"],
                            updated_at=row["updated_at"],
                            isactive=1
                        )
                        self.context.database_manager.session.add(dim_module_entry)
                        self.context.database_manager.session.commit()

                    # Step 2: Insert or Update DimTFCModuleVersionStatus
                    module_dim_rowid = dim_module_entry.modulelist_dim_row_id
                    version_statuses = json.loads(row.get("version_statuses", "[]"))

                    for version_data in version_statuses:
                        version = version_data.get("version")
                        status = version_data.get("status")

                        existing_version_entry = self.context.database_manager.session.query(DimTFCModuleVersionStatus).filter_by(
                            module_dim_rowid=module_dim_rowid,
                            version=version,
                            isactive=1
                        ).one_or_none()

                        if existing_version_entry:
                            if existing_version_entry.status != status:
                                # Soft delete existing record
                                existing_version_entry.isactive = 0
                                existing_version_entry.updated_at = datetime.now()
                                self.context.database_manager.session.commit()

                                # Insert new version entry
                                new_version_entry = DimTFCModuleVersionStatus(
                                    module_dim_rowid=module_dim_rowid,
                                    version=version,
                                    status=status,
                                    created_at=datetime.now(),
                                    updated_at=datetime.now(),
                                    isactive=1
                                )
                                self.context.database_manager.session.add(new_version_entry)
                                self.context.database_manager.session.commit()
                        else:
                            # Insert new version entry if not exists
                            new_version_entry = DimTFCModuleVersionStatus(
                                module_dim_rowid=module_dim_rowid,
                                version=version,
                                status=status,
                                created_at=datetime.now(),
                                updated_at=datetime.now(),
                                isactive=1
                            )
                            self.context.database_manager.session.add(new_version_entry)
                            self.context.database_manager.session.commit()

                    existing_fact_entry = self.context.database_manager.session.query(FactTFCModules).filter_by(
                        moduleslist_dim_row_id=dim_module_entry.modulelist_dim_row_id,
                        organization_id=row["organization_id"],
                        isactive=1
                    ).one_or_none()

                    if existing_fact_entry:
                        if existing_fact_entry.version_status != row.get("version_status"):
                            existing_fact_entry.isactive = 0
                            existing_fact_entry.end_dateref = dateref
                            self.context.database_manager.session.commit()

                            fact_module_entry = FactTFCModules(
                                moduleslist_dim_row_id=dim_module_entry.modulelist_dim_row_id,
                                version_status=row.get("version_status"),
                                organization_id=row["organization_id"],
                                load_date=datetime.now(),
                                start_dateref=dateref,
                                end_dateref=None,
                                isactive=1
                            )
                            self.context.database_manager.session.add(fact_module_entry)
                            self.context.database_manager.session.commit()
                    else:
                        fact_module_entry = FactTFCModules(
                            moduleslist_dim_row_id=dim_module_entry.modulelist_dim_row_id,
                            version_status=row.get("version_status"),
                            organization_id=row["organization_id"],
                            load_date=datetime.now(),
                            start_dateref=dateref,
                            end_dateref=None,
                            isactive=1
                        )
                        self.context.database_manager.session.add(fact_module_entry)
                        self.context.database_manager.session.commit()
                    # Populate summary table
                    self.populate_summary_table()
                except Exception as e:
                    logger.error(f"Error processing row: {row}. Error: {e}")
                    logger.debug(f"Full error stack trace: {traceback.format_exc()}")
                    self.context.database_manager.session.rollback()

        except Exception as e:
            logger.error(f"Error in load step: {e}")
            self.context.database_manager.session.rollback()

    def populate_summary_table(self):
        try:
            logger.info("Populating summary_tf_modulelist...")
            dateref = int(datetime.now().strftime("%Y%m%d"))

            # Get module count grouped by organization_id
            module_counts = (
                self.context.database_manager.session.query(
                    FactTFCModules.organization_id,
                    func.count(FactTFCModules.modulelist_fact_row_id).label("module_count")
                )
                .filter(FactTFCModules.isactive == 1)
                .group_by(FactTFCModules.organization_id)
                .all()
            )

            for org_id, module_count in module_counts:
                summary_entry = SummaryTFCModules(
                    report_dateref=dateref,
                    organization_id=org_id,
                    module_count=module_count,
                    created_date=datetime.now(),
                )
                self.context.database_manager.session.add(summary_entry)

            self.context.database_manager.session.commit()
            logger.info("Summary table populated successfully.")
        except Exception as e:
            logger.error(f"Error populating summary table: {e}")
            self.context.database_manager.session.rollback()
