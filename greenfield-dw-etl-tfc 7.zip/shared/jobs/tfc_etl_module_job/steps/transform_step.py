import json
import traceback
from datetime import datetime

import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_module_job.tfc_etl_module_job_context import TFCETLModuleJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")


class TransformStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLModuleJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            # Check if extracted data is available
            if self.context.extracted_data_frame is not None:
                # Flatten nested JSON fields in extracted DataFrame
                self.context.extracted_data_frame = pd.json_normalize(
                    self.context.extracted_data_frame.to_dict(orient='records'))

                # Log the structure of the extracted DataFrame
                logger.info(f"Extracted DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of extracted data:\n{self.context.extracted_data_frame.head()}")

                # Define the required columns
                required_columns = [
                    "id",
                    "attributes.name",
                    "attributes.namespace",
                    "attributes.provider",
                    "attributes.status",
                    "attributes.registry-name",
                    "attributes.no-code",
                    "attributes.publishing-mechanism",
                    "attributes.created-at",
                    "attributes.updated-at",
                    "attributes.version-statuses",
                    "relationships.organization.data.id",
                    "links.self"
                ]
                missing_columns = [col for col in required_columns if
                                   col not in self.context.extracted_data_frame.columns]
                if missing_columns:
                    logger.warning(f"Missing columns in the extracted data frame: {missing_columns}")

                # Ensure all required columns exist in the DataFrame, add defaults where missing
                for column in required_columns:
                    if column not in self.context.extracted_data_frame.columns:
                        self.context.extracted_data_frame[column] = [{}] * len(
                            self.context.extracted_data_frame) if column == "attributes.version-statuses" else None

                # Log the modified extracted data after adding missing columns
                logger.info(f"Modified DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of modified extracted data:\n{self.context.extracted_data_frame.head()}")

                # Select and rename relevant fields for transformation
                transformed_df = self.context.extracted_data_frame[required_columns].rename(
                    columns={
                        "id": "module_id",
                        "attributes.name": "module_name",
                        "attributes.namespace": "namespace",
                        "attributes.provider": "provider",
                        "attributes.status": "status",
                        "attributes.registry-name": "registry_name",
                        "attributes.no-code": "nocode",
                        "attributes.publishing-mechanism": "publishing_mechanism",
                        "attributes.created-at": "created_at",
                        "attributes.updated-at": "updated_at",
                        "attributes.version-statuses": "version_statuses",
                        "relationships.organization.data.id": "organization_id"

                    }
                )

                # Log transformed DataFrame to check intermediate state
                logger.info(f"Transformed DataFrame columns: {transformed_df.columns}")
                logger.info(f"First few rows of transformed data:\n{transformed_df.head()}")

                # Ensure that the column is converted to datetime without timezone information
                transformed_df["created_at"] = pd.to_datetime(
                    transformed_df.get("created_at", pd.Series(datetime.now(), index=transformed_df.index)),
                    errors="coerce"
                ).dt.tz_localize(None)

                transformed_df["updated_at"] = pd.to_datetime(
                    transformed_df.get("updated_at", pd.Series(datetime.now(), index=transformed_df.index)),
                    errors="coerce"
                ).dt.tz_localize(None)

                # Log datetime conversion check
                logger.info(f"After datetime conversion:\n{transformed_df[['created_at', 'updated_at']].head()}")

                # Process version statuses as JSON strings
                transformed_df["version_statuses"] = transformed_df["version_statuses"].apply(
                    lambda x: json.dumps(x) if isinstance(x, (dict, list)) else "[]"
                )

                # Log the final transformed data
                logger.info(f"Transformed DataFrame (final):\n{transformed_df.head()}")

                # Store the transformed DataFrame in the context for loading
                self.context.transformed_data_frame = transformed_df

                logger.info("Transformation step completed successfully.")
            else:
                logger.warning("Extracted data frame is None. Skipping transformation step.")

        except Exception as e:
            logger.error(f"Error in transforming module data: {e}")
            logger.debug(f"Full error stack trace: {traceback.format_exc()}")
