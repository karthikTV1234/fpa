import pandas as pd

from shared.config_loader.config_loader import TFCETLJobConfig
from shared.jobs.tfc_etl_module_job.tfc_etl_module_job_context import TFCETLModuleJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ExtractFromBlobStep")

class ExtractFromBlobStep:
    def __init__(self, config: TFCETLJobConfig, context: TFCETLModuleJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        directory = f"{self.config.dw_tfc_home_directory}/module"
        try:
            # Get a list of all JSON files in the directory
            json_files = self.context.azure_blob_manager.list_blobs(directory_name=directory)
            json_files = [f for f in json_files if f.endswith(".json")]
            all_data = []
            for filename in json_files:
                # Extract JSON data from each file
                data = self.context.azure_blob_manager.read_json_from_blob(
                    directory_name=directory,
                    file_path=filename
                )
                if isinstance(data, list):  # If the file contains a list of dictionaries
                    all_data.extend(data)
                elif isinstance(data, dict):  # If the file contains a single dictionary
                    all_data.append(data)
                else:
                    logger.warning(f"Unexpected data format in file: {filename}")
            # Convert the list of dictionaries into a pandas DataFrame
            if all_data:
                self.context.extracted_data_frame = pd.DataFrame(all_data)
            else:
                self.context.extracted_data_frame = pd.DataFrame()  # Empty DataFrame
            logger.info(f"Read data from {len(json_files)} JSON files in {directory}")
        except Exception as e:
            logger.error(f"Error in extracting data from directory: {e}")