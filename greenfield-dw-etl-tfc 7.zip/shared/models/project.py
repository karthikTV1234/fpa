from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Date
from sqlalchemy.orm import relationship

from shared.models.base import Base


class DimTFCProjects(Base):
    __tablename__ = 'dim_tf_projects'

    project_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)  # Matches the schema
    project_id = Column(String(255), nullable=False)  # Unique project identifier
    # organization_dim_rowid = Column(
    #     Integer,
    #     ForeignKey("dim_organization.organization_dim_rowid"),
    #     nullable=False
    # )  # Foreign key to organization
    organization_dim_rowid = Column(String(255), nullable=False)
    project_name = Column(String(255), nullable=False)  # Project name
    start_date = Column(Date, nullable=True)  # Start date
    end_date = Column(Date, nullable=True, default=None)  # End date
    create_date = Column(DateTime, nullable=False)  # Creation date
    isactive = Column(Integer, nullable=True)

    # Relationships
    #organization = relationship("DimOrganization", back_populates="dim_tf_projects")
    fact_tf_project = relationship("FactTFCProjects", back_populates="dim_tf_projects")


class FactTFCProjects(Base):
    __tablename__ = 'fact_tf_projects'

    project_fact_row_id = Column(Integer, primary_key=True, autoincrement=True)  # Matches the schema
    project_dim_rowid = Column(
        Integer,
        ForeignKey("dim_tf_projects.project_dim_rowid"),
        nullable=False
    )  # Foreign key to dim_tf_projects
    workspace_count = Column(Integer, nullable=False)  # Workspace count
    team_count = Column(Integer, nullable=False)  # Team count
    stack_count = Column(Integer, nullable=False)  # Stack count
    start_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)  # Start date reference
    end_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)  # End date reference
    create_date = Column(DateTime, nullable=False)  # Creation date
    auto_destroy_activity_duration = Column(String(255), nullable=True)  # Auto-destroy activity duration
    isactive = Column(Integer, nullable=True)

    # Relationship with DimTFCProjects
    dim_tf_projects = relationship("DimTFCProjects", back_populates="fact_tf_project")


class SummaryTFCProjects(Base):
    __tablename__ = 'summary_tf_project'

    project_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)  # Primary key
    # organization_dim_rowid = Column(
    #     Integer,
    #     ForeignKey("dim_organization.organization_dim_rowid"),
    #     nullable=False
    # )  # Foreign key to organization
    organization_dim_rowid = Column(String(255), nullable=False)
    report_dateref = Column(
        Integer,
        ForeignKey("dim_date.dateref"),
        nullable=False
    )  # Foreign key to dim_date
    projects_count = Column(Integer, nullable=False)  # Total count of projects
    create_date = Column(DateTime, nullable=False)  # Creation date

    # Relationships (if needed)
    def __repr__(self):
        return (
            f"<SummaryTFCProjects(project_summary_rowid={self.project_summary_rowid}, "
           # f"organization_dim_rowid={self.organization_dim_rowid}, report_dateref={self.report_dateref}, "
            f"projects_count={self.projects_count}, create_date={self.create_date})>"
        )
