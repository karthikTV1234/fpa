from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Date

from shared.models.base import Base


class DimTFCModuleVersions(Base):
    __tablename__ = 'dim_tf_moduleversions'

    moduleversion_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    module_key = Column(String(255), nullable=True)
    module_source = Column(String(255), nullable=True)
    module_version = Column(String(255), nullable=True)
    module_dir = Column(String(255), nullable=True)
    cv_id = Column(String(255), nullable=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class FactTFCModuleVersions(Base):
    __tablename__ = 'fact_tf_moduleversions'

    moduleversion_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)
    moduleversion_dim_rowid = Column(Integer, ForeignKey("dim_tf_moduleversions.moduleversion_dim_rowid"), nullable=False)
    start_dateref = Column(Date, nullable=True)  # Date format (YYYY-MM-DD)
    end_dateref = Column(Date, nullable=True, default=None)  # Date format (YYYY-MM-DD)
    created_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class SummaryTFCModuleVersions(Base):
    __tablename__ = 'summary_tf_moduleversions'

    moduleversion_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)
    total_modules_used = Column(Integer, nullable=True)
    created_date = Column(DateTime, nullable=True)


class DimTFCProviderVersion(Base):
    __tablename__ = 'dim_tf_providerversions'

    providerversion_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    provider_name = Column(String(255), nullable=True)
    provider_version = Column(String(255), nullable=True)
    cv_id = Column(String(255), nullable=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class FactTFCProviderVersion(Base):
    __tablename__ = 'fact_tf_providerversions'

    providerversion_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)
    providerversion_dim_rowid = Column(Integer, ForeignKey("dim_tf_providerversions.providerversion_dim_rowid"), nullable=False)
    start_dateref = Column(Date, nullable=True)  # Date format (YYYY-MM-DD)
    end_dateref = Column(Date, nullable=True, default=None)  # Date format (YYYY-MM-DD)
    created_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class SummaryTFCProviderVersion(Base):
    __tablename__ = 'summary_tf_providerversions'

    providerversion_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)
    total_providers_used = Column(Integer, nullable=True)
    created_date = Column(DateTime, nullable=True)
