from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Date
from sqlalchemy.orm import relationship

from shared.models.base import Base


class DimTFCModules(Base):
    __tablename__ = 'dim_tf_modulelist'

    modulelist_dim_row_id = Column(Integer, primary_key=True, autoincrement=True)
    module_id = Column(String(255), nullable=False)  # maps to `id`
    organization_dim_rowid = Column(String(255), nullable=False)  # Use String if organization IDs are alphanumeric
    module_name = Column(String(255), nullable=False)  # maps to `attributes.name`
    namespace = Column(String(255), nullable=False)  # maps to `attributes.namespace`
    provider = Column(String(255), nullable=False)  # maps to `attributes.provider`
    registry_name = Column(String(255), nullable=False)  # maps to `attributes.registry-name`
    nocode = Column(String(255), nullable=False)  # maps to `attributes.nocode`
    publishing_mechanism = Column(String(255), nullable=False)  # maps to `attributes.publishing-mechanism`
    status = Column(String(255), nullable=False)  # maps to `attributes.status`
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    created_at = Column(DateTime, nullable=False)  # maps to `attributes.created-at`
    updated_at = Column(DateTime, nullable=False)  # maps to `attributes.updated-at`
    isactive = Column(Integer, nullable=True)

    # Define relationship to FactTFCModules
    fact_tfc_moduleslist = relationship(
        "FactTFCModules",
        back_populates="dim_tf_modules",
        cascade="all, delete-orphan"
    )

    # Define relationship to DimTFCModuleVersionStatus
    version_statuses = relationship("DimTFCModuleVersionStatus", back_populates="module")


class DimTFCModuleVersionStatus(Base):
    __tablename__ = 'dim_tf_module_version_status'

    version_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    module_dim_rowid = Column(Integer, ForeignKey('dim_tf_modulelist.modulelist_dim_row_id'), nullable=False)
    version = Column(String(255), nullable=False)
    status = Column(String(255), nullable=False)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    isactive = Column(Integer, nullable=True)

    # Relationship back to DimTFCModules
    module = relationship("DimTFCModules", back_populates="version_statuses")


class FactTFCModules(Base):
    __tablename__ = 'fact_tf_modulelist'

    modulelist_fact_row_id = Column(Integer, primary_key=True, autoincrement=True)
    moduleslist_dim_row_id = Column(
        Integer,
        ForeignKey("dim_tf_modulelist.modulelist_dim_row_id"),
        nullable=False
    )
    version_status = Column(String(255), nullable=True)  # maps to `attributes.version-statuses[]`
    organization_id = Column(String(255), nullable=False)  # maps to `relationships.organization.data.id`
    load_date = Column(DateTime, nullable=True)
    start_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)
    end_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=True)
    isactive = Column(Integer, nullable=True)

    # Establish relationship with DimTFCModules
    dim_tf_modules = relationship(
        "DimTFCModules",
        back_populates="fact_tfc_moduleslist"
    )


class SummaryTFCModules(Base):
    __tablename__ = 'summary_tf_modulelist'

    module_sum_row_id = Column(Integer, primary_key=True, autoincrement=True)
    organization_id = Column(String(255), nullable=False)  # maps to `relationships.organization.data.id`
    module_count = Column(Integer, nullable=False)  # Summarized count of modules
    report_dateref = Column(
        Integer,
        ForeignKey("dim_date.dateref"),
        nullable=False
    )
    created_date = Column(DateTime, nullable=True)
