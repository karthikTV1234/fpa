from sqlalchemy import Column, Integer, String, ForeignKey, DateTime

from shared.models.base import Base


class DimTFCProviderList(Base):
    __tablename__ = 'dim_tfc_provider_list'

    providerlist_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    provider_id = Column(String, nullable=True)
    organization_dim_rowid = Column(Integer, ForeignKey("dim_tfc_organization.organization_dim_rowid"), nullable=False)
    provider_name = Column(String, nullable=True)
    namespace = Column(String, nullable=True)
    registry_name = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class FactTFCProviderList(Base):
    __tablename__ = 'fact_tfc_provider_list'

    providerlist_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)
    providerlist_dim_rowid = Column(Integer, ForeignKey("dim_tfc_provider_list.providerlist_dim_rowid"), nullable=False)
    organization_dim_rowid = Column(Integer, ForeignKey("dim_tfc_organization.organization_dim_rowid"), nullable=False)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class SummaryTFCProvider(Base):
    __tablename__ = 'summary_tfc_provider'

    provider_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    organization_dim_rowid = Column(Integer, ForeignKey("dim_tfc_organization.organization_dim_rowid"), nullable=False)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=False)
    provider_count = Column(Integer, nullable=False)
    create_date = Column(DateTime, nullable=True)
