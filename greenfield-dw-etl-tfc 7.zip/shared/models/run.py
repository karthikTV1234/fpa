from sqlalchemy import Column, Integer, String, Date, ForeignKey, DateTime

from shared.models.base import Base


class FactRun(Base):
    __tablename__ = "fact_tf_run"

    run_dim_row = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String, nullable=True)
    start_dateref = Column(DateTime, nullable=True)
    end_dateref = Column(DateTime, nullable=True)
    workspace_dim_rowid = Column(Integer, ForeignKey("dim_tfc_workspaces.workspace_dim_rowid"), nullable=False)
    apply_id = Column(String, nullable=True)
    configuration_version_id = Column(String, nullable=True)
    created_by = Column(String, nullable=True)
    plan_id = Column(String, nullable=True)
    task_stages = Column(String, nullable=True)
    policy_checks = Column(String, nullable=True)
    comments = Column(String, nullable=True)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)


class FactRunStatus(Base):
    __tablename__ = "fact_tf_run_status"

    run_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)
    run_dim_row = Column(Integer, ForeignKey("fact_tf_run.run_dim_row"), nullable=False)
    line_no = Column(Integer, nullable=True)
    field_name = Column(String, nullable=True)
    field_value = Column(String, nullable=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    update_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

class SummaryRun(Base):
    __tablename__ = 'summary_tfc_run'

    run_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    workspace_dim_rowid = Column(Integer, ForeignKey("dim_tfc_workspaces.workspace_dim_rowid"), nullable=False)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=False)
    run_count = Column(Integer, nullable=False)
    create_date = Column(DateTime, nullable=True)

