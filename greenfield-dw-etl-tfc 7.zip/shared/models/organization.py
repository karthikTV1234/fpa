from sqlalchemy import Column, Integer, String, DateTime

from shared.models.base import Base


class DimTFCOrganization(Base):
    __tablename__ = 'dim_tfc_organization'

    organization_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    organization_id = Column(String, nullable=True)
    organization_name = Column(String, nullable=True)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    created_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)
