from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Numeric, Date
from sqlalchemy.orm import relationship

from shared.models.base import Base


class DimTFCWorkspaces(Base):
    __tablename__ = 'dim_tfc_workspaces'

    workspace_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)  # maps to `workspace_dim_rowid`
    workspace_id = Column(String(255), nullable=False)  # maps to `workspace_id`
    project_dim_rowid = Column(Integer, ForeignKey("dim_tf_projects.project_dim_rowid"), nullable=False)
    workspace_name = Column(String(255), nullable=False)  # maps to `workspace_name`
    allow_destroy_plan = Column(Boolean, nullable=True)  # maps to `allow_destroy_plan`
    auto_apply = Column(Boolean, nullable=True)  # maps to `auto_apply`
    auto_apply_run_trigger = Column(Boolean, nullable=True)  # maps to `auto_apply_run_trigger`
    auto_destroy_activity_duration = Column(Integer, nullable=True)  # maps to `auto_destroy_activity_duration`
    auto_destroy_at = Column(DateTime, nullable=True)  # maps to `auto_destroy_at`
    auto_destroy_status = Column(String(50), nullable=True)  # maps to `auto_destroy_status`
    inherits_project_auto_destroy = Column(Boolean, nullable=True)  # maps to `inherits_project_auto_destroy`
    created_at = Column(DateTime, nullable=False)  # maps to `created_at`
    environment = Column(String(50), nullable=True)  # maps to `environment`
    locked = Column(Boolean, nullable=True)  # maps to `is_locked`
    queue_all_runs = Column(Boolean, nullable=True)  # maps to `queue_all_runs`
    speculative_enabled = Column(Boolean, nullable=True)  # maps to `speculative_enabled`
    structured_run_output_enabled = Column(Boolean, nullable=True)  # maps to `structured_run_output_enabled`
    terraform_version = Column(String(50), nullable=False)  # maps to `terraform_version`
    working_directory = Column(String(255), nullable=True)  # maps to `working_directory`
    global_remote_state = Column(Boolean, nullable=True)  # maps to `global_remote_state`
    updated_at = Column(DateTime, nullable=False)  # maps to `updated_at`
    description = Column(String(255), nullable=True)  # maps to `description`
    file_triggers_enabled = Column(Boolean, nullable=True)  # maps to `file_triggers_enabled`
    assessments_enabled = Column(Boolean, nullable=True)  # maps to `assessments_enabled`
    last_assessment_result_at = Column(DateTime, nullable=True)  # maps to `last_assessment_result_at`
    locked_reason = Column(String(255), nullable=True)  # maps to `locked_reason`
    source = Column(String(255), nullable=True)  # maps to `source`
    source_name = Column(String(255), nullable=True)  # maps to `source_name`
    source_url = Column(String(255), nullable=True)  # maps to `source_url`
    tag_names = Column(String, nullable=True)  # maps to `tag_names`
    setting_overwrites_execution_mode = Column(Boolean, nullable=True)  # maps to `setting_overwrites_execution_mode`
    setting_overwrites_agent_pool = Column(Boolean, nullable=True)  # maps to `setting_overwrites_agent_pool`
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

    # Relationships
    fact_tfc_workspaces = relationship("FactTFCWorkspaces", back_populates="dim_tfc_workspaces")
    workspace_relationship = relationship("DimTFWorkspaceRelationship", back_populates="dim_tfc_workspaces")


class FactTFCWorkspaces(Base):
    __tablename__ = 'fact_tfc_workspaces'

    workspace_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)  # maps to `workspace_fact_rowid`
    workspace_dim_rowid = Column(Integer, ForeignKey("dim_tfc_workspaces.workspace_dim_rowid"), nullable=False)
    resource_count = Column(Integer, nullable=True)  # maps to `resource_count`
    apply_duration_average = Column(Numeric(10, 2), nullable=True)  # maps to `apply_duration_average`
    plan_duration_average = Column(Numeric(10, 2), nullable=True)  # maps to `plan_duration_average`
    policy_check_failures = Column(Integer, nullable=True)  # maps to `policy_check_failures`
    run_failures = Column(Integer, nullable=True)  # maps to `run_failures`
    workspace_kpis_runs_count = Column(Integer, nullable=True)  # maps to `workspace_kpis_runs_count`
    latest_change_at = Column(DateTime, nullable=True)  # maps to `latest_change_at`
    operations = Column(Integer, nullable=True)  # maps to `operations`
    execution_mode = Column(String(50), nullable=True)  # maps to `execution_mode`
    vcs_repo = Column(String(255), nullable=True)  # maps to `vcs_repo`
    vcs_repo_identifier = Column(String(255), nullable=True)  # maps to `vcs_repo_identifier`
    start_date = Column(Date, nullable=True)  # Date format (YYYY-MM-DD)
    end_date = Column(Date, nullable=True, default=None)  # Date format (YYYY-MM-DD)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

    # Relationships
    dim_tfc_workspaces = relationship("DimTFCWorkspaces", back_populates="fact_tfc_workspaces")


class DimTFWorkspaceRelationship(Base):
    __tablename__ = 'dim_tf_workspace_relationship'

    workspace_relationship_rowid = Column(Integer, primary_key=True, autoincrement=True)
    workspace_dim_rowid = Column(Integer, ForeignKey("dim_tfc_workspaces.workspace_dim_rowid"), nullable=True)
    locked_by_id = Column(String(255), nullable=True)
    locked_by_links_related = Column(String(255), nullable=True)
    current_run_id = Column(String(255), nullable=True)  # maps to `current_run_id`
    latest_run_id = Column(String(255), nullable=True)  # maps to `latest_run_id`
    outputs = Column(String, nullable=True)  # maps to `outputs`
    remote_state_consumers_links_related = Column(String, nullable=True)  # maps to `remote_state_consumers`
    current_state_version_data_id = Column(String, nullable=True)  # maps to `current_state_version`
    current_state_version_links_related = Column(String, nullable=True)  # maps to `current_state_version`
    current_configuration_version_data_id = Column(String, nullable=True)  # maps to `current_configuration_version`
    current_configuration_version_links_related = Column(String, nullable=True)
    agent_pool_data_id= Column(String, nullable=True)  # maps to `agent_pool`
    readme = Column(String, nullable=True)  # maps to `readme`
    current_assessment_result = Column(String, nullable=True)  # maps to `current_assessment_result`
    start_date = Column(Date, nullable=True)  # Date format (YYYY-MM-DD)
    end_date = Column(Date, nullable=True, default=None)  # Date format (YYYY-MM-DD)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

    # Relationships
    dim_tfc_workspaces = relationship("DimTFCWorkspaces", back_populates="workspace_relationship")


class SummaryTFCWorkspaces(Base):
    __tablename__ = 'summary_tf_workspace'

    workspace_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    organization_dim_rowid = Column(Integer, ForeignKey("dim_tfc_organization.organization_dim_rowid"), nullable=False)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=False)
    workspace_count = Column(Integer, nullable=True)
    create_date = Column(DateTime, nullable=True)
