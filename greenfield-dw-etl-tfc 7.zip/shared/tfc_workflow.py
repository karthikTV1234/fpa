from shared.jobs.tfc_etl_cv_job.tfc_etl_cv_job import TFCETLCVJob
from shared.jobs.tfc_etl_module_job.tfc_etl_module_job import TFCETLModuleJob
from shared.jobs.tfc_etl_project_job.tfc_etl_project_job import TFCETLProjectJob
from shared.jobs.tfc_etl_provider_job.tfc_etl_provider_job import TFCETLProviderJob
from shared.jobs.tfc_etl_run_job.tfc_etl_run_job import TFCETLRunJob
from shared.jobs.tfc_etl_workspace_job.tfc_etl_workspace_job import TFCETLWorkspaceJob
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="TFCWorkflow")


class TFCWorkflow:
    jobs: dict = {}

    def __init__(self, **kwargs):
        self.jobs['etl-workspace'] = TFCETLWorkspaceJob()
        self.jobs['etl-workspace'].initialize()

        self.jobs['etl-run'] = TFCETLRunJob()
        self.jobs['etl-run'].initialize()

        self.jobs['etl-provider'] = TFCETLProviderJob()
        self.jobs['etl-provider'].initialize()

        self.jobs['etl-configuration_version'] = TFCETLCVJob()
        self.jobs['etl-configuration_version'].initialize()

        self.jobs['etl-module'] = TFCETLModuleJob()
        self.jobs['etl-module'].initialize()

        self.jobs['etl-project'] = TFCETLProjectJob()
        self.jobs['etl-project'].initialize()

    async def execute_job(self, job_name: str) -> bool:
        if not self.jobs.get(job_name):
            logger.critical(
                f"error in job execution, job={job_name} is not registered")
            return False
        else:
            logger.info(f"{job_name} is about to execute")
            job = self.jobs[job_name]
            await job.trigger_event('start')
            return True
