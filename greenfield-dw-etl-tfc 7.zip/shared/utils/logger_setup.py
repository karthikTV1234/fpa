# logger_setup.py

import logging
import os


def setup_logger(name=__name__, level=os.getenv("LOGGING_LEVEL") or logging.DEBUG):
    """Function to set up a logger"""

    logger = logging.getLogger(name)

    # Clear any existing handlers
    logger.handlers.clear()

    # Set propagate to False to prevent duplicate logging
    logger.propagate = False

    logger.setLevel(level)

    # Create handler
    stream_handler = logging.StreamHandler()

    # Create formatter and add it to handler
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    stream_handler.setFormatter(formatter)

    # Add handler to the logger
    logger.addHandler(stream_handler)

    return logger
