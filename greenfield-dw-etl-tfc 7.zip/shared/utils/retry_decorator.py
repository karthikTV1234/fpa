import asyncio
import functools
import inspect
from time import sleep

from shared.utils.logger_setup import setup_logger

logger = setup_logger("Retry")


def retry_with_backoff(retries=3, backoff_in_seconds=0.5):
    """
    A decorator that implements retry logic with exponential backoff for both sync and async functions.

    """

    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            retry_count = 0
            wait_time = backoff_in_seconds

            while retry_count < retries:
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    retry_count += 1
                    if retry_count == retries:
                        logger.error(
                            f"All {retries} attempts failed for {func.__name__}. Final error: {str(e)}")
                        raise

                    logger.warning(
                        f"Attempt {retry_count} failed for {func.__name__}: {str(e)}. "
                        f"Retrying in {wait_time} seconds..."
                    )
                    await asyncio.sleep(wait_time)
                    wait_time *= 2  # Exponential backoff

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            retry_count = 0
            wait_time = backoff_in_seconds

            while retry_count < retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    retry_count += 1
                    if retry_count == retries:
                        logger.error(
                            f"All {retries} attempts failed for {func.__name__}. Final error: {str(e)}")
                        raise

                    logger.warning(
                        f"Attempt {retry_count} failed for {func.__name__}: {str(e)}. "
                        f"Retrying in {wait_time} seconds..."
                    )
                    sleep(wait_time)
                    wait_time *= 2  # Exponential backoff

        # Check if the decorated function is async or sync
        return async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper

    return decorator
