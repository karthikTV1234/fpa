import unittest

from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger("TestWatermarkManagerBlob")


class TestWatermarkManagerBlob(unittest.TestCase):
    def setUp(self):
        accountName = "devstoreaccount1"
        accountKey = "Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=="
        CONNECTION_STRING = f"DefaultEndpointsProtocol=http;AccountName={accountName};AccountKey={accountKey};BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1"
        CONTAINER_NAME = "testcontainer"

        self.manager = WatermarkManagerBlob(CONNECTION_STRING, CONTAINER_NAME)

    def tearDown(self):
        # Code to clean up after tests (e.g., closing database connections)
        pass

    def test_watermark(self):
        # Example data for a Terraform run
        terraform_data = [
            {"id": "run-1", "created-at": "2024-12-07T12:00:00Z"},
            {"id": "run-2", "created-at": "2024-12-08T12:00:00Z"},
            {"id": "run-3", "created-at": "2024-12-09T12:00:00Z"},
        ]

        # Set an initial watermark for Terraform runs
        self.manager.update_watermark("terraform_runs", "2024-12-07T12:00:00")

        # Filter Terraform runs
        filtered_runs = self.manager.filter_data(
            "terraform_runs", terraform_data, "created-at")
        logger.info(f"Filtered Terraform Runs:{filtered_runs}")

        # Update watermark after processing
        if filtered_runs:
            latest_run = max(run["created-at"] for run in filtered_runs)
            self.manager.update_watermark("terraform_runs", latest_run)

        logger.info(f"Updated Watermarks: {self.manager.watermarks}")


if __name__ == '__main__':
    unittest.main()
