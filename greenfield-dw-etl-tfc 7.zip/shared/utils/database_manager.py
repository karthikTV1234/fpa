import numpy as np
from sqlalchemy import create_engine
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import sessionmaker

from shared.models.base import Base
from shared.repositories.run_repo import FactRunRepo, FactRunStatusRepo
from shared.utils.logger_setup import setup_logger

logger = setup_logger("DatabaseManager")


class DatabaseManager:
    def __init__(self, database_url: str):
        # Initialize the engine and session
        self.engine = create_engine(database_url, echo=False)
        Session = sessionmaker(bind=self.engine)
        self.session = Session()

        # Create tables if they don't exist
        Base.metadata.create_all(self.engine)
        self.fact_run_repo = FactRunRepo(self.session)
        self.fact_run_status_repo = FactRunStatusRepo(self.session)

    def upsert_to_sql(self, df, model_class, index_elements, batch_size=1000):
        """
        Upserts a DataFrame to a PostgreSQL table with batch processing.

        :param df: The DataFrame to upsert.
        :param model_class: The SQLAlchemy model class to upsert to.
        :param index_elements: List of columns that form the primary key or unique constraint.
        :param batch_size: Number of rows to process in each batch.
        """

        num_batches = int(np.ceil(len(df) / batch_size))

        for i in range(num_batches):
            # Slice the DataFrame into the current batch
            batch = df.iloc[i * batch_size:(i + 1) * batch_size]
            data = batch.to_dict(orient='records')  # Convert batch to list of dicts

            # Create an insert statement for batch
            for row in data:
                stmt = insert(model_class).values(row)
                # Only update non-NaN values in case of conflict
                update_dict = {key: stmt.excluded[key] for key in row.keys() if row[key] == row[key]}  # Check for NaN
                stmt = stmt.on_conflict_do_update(
                    index_elements=index_elements,  # Specify the unique or primary key
                    set_=update_dict
                )
                self.session.execute(stmt)

            # Commit the transaction after each batch
            self.session.commit()
            logger.info(f"Processed batch {i + 1} of {num_batches}")

    def close_session(self):
        self.session.close_all()
