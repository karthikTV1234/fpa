import io
import json
import os
import re
from urllib.parse import quote

import pandas as pd
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import BlobServiceClient

from shared.utils.logger_setup import setup_logger

logger = setup_logger("AzureBlobContainerManager")


class AzureBlobContainerManager:
    def __init__(self, connection_string, container_name):
        """
        Initialize the Azure Blob Container Manager.
        :param connection_string: Connection string for Azure Blob Storage.
        :param container_name: Name of the container to manage.
        """
        self.container_name = container_name
        self.blob_service_client = BlobServiceClient.from_connection_string(
            connection_string)
        self.container_client = self._get_or_create_container(container_name)

    def _get_or_create_container(self, container_name):
        try:
            container_client = self.blob_service_client.get_container_client(
                container_name)
            if not container_client.exists():
                container_client.create_container()
                logger.info(f"Container '{container_name}' created.")
            return container_client
        except Exception as e:
            logger.error(f"Error creating or accessing container: {e}")
            raise Exception(f"Error creating or accessing container: {e}")

    def upload_object(self, obj: any, directory_name, file_path: str, overwrite=True):
        # Convert the array of objects to a JSON string
        json_data = json.dumps(obj, indent=4)

        # Convert the JSON string to bytes (required for uploading)
        json_data_bytes = io.BytesIO(json_data.encode('utf-8'))

        # Connect to Azure Blob Storage
        blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
            file_path)
        blob_client = self.container_client.get_blob_client(blob=blob_name)

        # Upload the file, replacing the existing blob if it exists, or creating it if it doesn't
        try:
            blob_client.upload_blob(json_data_bytes,
                                    overwrite=overwrite)  # overwrite=True will replace the file if it exists
            logger.info(
                f"Blob '{file_path}' in container has been uploaded/replaced.")
        except Exception as e:
            logger.error(f"An error occurred: {e}")

    def upload_file(self, directory_name, file_path, overwrite=True):
        """
        Upload a file to a specified directory.
        :param overwrite: whether file to be overwritten
        :param directory_name: Directory (prefix) in the container.
        :param file_path: Path of the file to upload.
        """
        blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
            file_path)
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=overwrite)
        logger.info(f"Uploaded file: {blob_name}")

    def download_file(self, blob_name, download_path):
        """
        Download a file from the container.
        :param blob_name: Full blob path (directory/file).
        :param download_path: Local path to save the downloaded file.
        """
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        with open(download_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())
        logger.info(f"Downloaded file: {blob_name} to {download_path}")

    def delete_file(self, blob_name):
        """
        Delete a specific file in the container.
        :param blob_name: Full blob path (directory/file).
        """
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        blob_client.delete_blob()
        logger.info(f"Deleted file: {blob_name}")

    def create_directory(self, directory_name):
        """
        Create a directory by adding an empty blob as a placeholder.
        :param directory_name: Name of the directory (prefix).
        """
        placeholder_blob_name = f"{directory_name}/.placeholder"
        blob_client = self.container_client.get_blob_client(
            blob=placeholder_blob_name)
        blob_client.upload_blob(b"", overwrite=True)
        logger.info(f"Directory created: {directory_name}")

    def delete_directory(self, directory_name):
        """
        Delete a directory by removing all blobs with the specified prefix.
        :param directory_name: Name of the directory (prefix).
        """
        blobs = self.container_client.list_blobs(
            name_starts_with=f"{directory_name}/")
        for blob in blobs:
            self.delete_file(blob.name)
        logger.info(f"Deleted directory: {directory_name}")

    def list_files(self, directory_name=None):
        """
        List all files in the container or a specific directory.
        :param directory_name: Directory (prefix) to list files from. If None, list all files.
        """
        prefix = f"{directory_name}/" if directory_name else ""
        blobs = self.container_client.list_blobs(name_starts_with=prefix)
        logger.info(f"Files in directory '{directory_name or 'root'}':")
        return [blob.name for blob in blobs]

    def read_json_from_blob(self, directory_name=None, file_path=None):
        try:
            # Connect to Azure Blob Storage
            blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
                file_path)
            blob_client = self.container_client.get_blob_client(blob=blob_name)

            # Check if blob exists
            # This raises an exception if the blob doesn't exist
            blob_client.get_blob_properties()

            # Download blob content
            blob_data = blob_client.download_blob()
            content = blob_data.readall()

            # Parse the content as JSON
            json_content = json.loads(content)
            return json_content

        except ResourceNotFoundError:
            logger.error(
                f"Blob '{file_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")

    def extract_run_data_from_directory(self, directory_path=None):
        data_list = []
        try:
            # List blobs within the specified directory
            blobs = self.container_client.list_blobs(name_starts_with=f"{directory_path}/")
            for blob_obj in blobs:
                # Download blob content
                blob_client = self.container_client.get_blob_client(blob=blob_obj.name)
                blob_data = blob_client.download_blob().readall().decode('utf-8')
                # Parse JSON data
                contents = json.loads(blob_data)
                for content in contents:
                    data_list.append(content)
        except ResourceNotFoundError:
            logger.error(f"Blob '{directory_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")

        # Extract "attributes.status-timestamps" separately
        status_timestamps_list = [item["attributes"]["status-timestamps"] for item in data_list]  # Extract as JSON
        # Remove it from the main data to avoid flattening
        for item in data_list:
            del item["attributes"]["status-timestamps"]
        df = pd.json_normalize(data_list)
        # Append "status-timestamps" JSON back as a new column
        df["attributes.status-timestamps"] = status_timestamps_list
        return df

    def extract_data_from_directory(self, directory_path=None):
        data_list = []
        try:
            # List blobs within the specified directory
            blobs = self.container_client.list_blobs(name_starts_with=f"{directory_path}/")
            for blob_obj in blobs:
                # Download blob content
                blob_client = self.container_client.get_blob_client(blob=blob_obj.name)
                blob_data = blob_client.download_blob().readall().decode('utf-8')
                # Parse JSON data
                contents = json.loads(blob_data)
                for content in contents:
                    data_list.append(content)
        except ResourceNotFoundError:
            logger.error(f"Blob '{directory_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")
        return data_list

    def extract_data(self, directory_name=None, file_path=None) -> pd.DataFrame:
        try:
            # Connect to Azure Blob Storage
            blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
                file_path)
            blob_client = self.container_client.get_blob_client(blob=blob_name)

            # Check if blob exists
            # This raises an exception if the blob doesn't exist
            blob_client.get_blob_properties()

            # Download blob content
            blob_data = blob_client.download_blob()
            content = blob_data.readall()

            # Parse the content as JSON
            json_content = json.loads(content)
            df = pd.json_normalize(json_content)
            return df

        except ResourceNotFoundError:
            logger.error(
                f"Blob '{file_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")

    def list_blobs(self, directory_name=None):
        """
        List all blobs in the container or a specific directory.
        :param directory_name: Directory (prefix) to list blobs from. If None, list all blobs.
        :return: List of blob names.
        """
        try:
            prefix = f"{directory_name}/" if directory_name else ""
            blobs = self.container_client.list_blobs(name_starts_with=prefix)
            blob_list = [blob.name for blob in blobs]
            logger.info(f"Blobs in directory '{directory_name or 'root'}': {blob_list}")
            return blob_list
        except Exception as e:
            logger.error(f"Error listing blobs in directory '{directory_name or 'root'}': {str(e)}")
            return []

    @staticmethod
    def sanitize_path(path):
        """
        Sanitize the provided path to remove invalid characters.
        Args:
            path (str): The original path.
        Returns:
            str: The sanitized path.
        """
        # Replace invalid characters with underscores
        sanitized_path = re.sub(r'[\\:*?"<>|]', '_', path)
        # Ensure forward slashes are used
        return sanitized_path.replace('\\', '/')

    @staticmethod
    def validate_blob_name(name):
        """
        Validate blob names to ensure compliance with Azure Blob Storage naming rules.
        Args:
            name (str): The blob name.
        Raises:
            ValueError: If the blob name is invalid.
        """
        if not name or len(name) > 1024:
            raise ValueError(f"Blob name '{name}' is invalid or exceeds 1,024 characters.")
        invalid_chars = r'[\\:*?"<>|]'
        if re.search(invalid_chars, name):
            raise ValueError(f"Blob name '{name}' contains invalid characters.")

    def move_blob(self, source_directory, source_path, destination_directory, destination_path):
        """
        Move a blob from the source directory to the destination directory.
        Args:
            source_directory (str): The source directory in the blob container.
            source_path (str): The blob name in the source directory.
            destination_directory (str): The destination directory in the blob container.
            destination_path (str): The blob name in the destination directory.
        """
        try:
            # Define container and blob names

            logger.info(f"source_directory - {source_directory}  :")
            logger.info(f"source_path - {source_path}  :")
            logger.info(f"destination_directory - {destination_directory}  :")
            logger.info(f"destination_path - {destination_path}  :")
            container_name = source_directory.split('/')[0]
            source_path = self.sanitize_path(source_path)
            destination_path = self.sanitize_path(destination_path)

            source_blob_name = source_path
            destination_blob_name = destination_path

            # Validate names
            self.validate_blob_name(source_blob_name)
            self.validate_blob_name(destination_blob_name)

            # Get blob clients
            source_blob_client = self.container_client.get_blob_client(
                blob=source_blob_name
            )
            destination_blob_client = self.container_client.get_blob_client(
                blob=destination_blob_name
            )

            # Encode URL
            source_url = quote(source_blob_client.url, safe=':/')

            # Copy the blob to the new location
            copy_status = destination_blob_client.start_copy_from_url(source_url)
            logger.info(
                f"Started copying blob: {source_blob_name} to {destination_blob_name} (Copy Status: {copy_status})")

            # Delete the source blob after the copy completes
            source_blob_client.delete_blob()
            logger.info(f"Deleted source blob: {source_blob_name}")

        except Exception as e:
            logger.error(f"Error moving blob from {source_path} to {destination_path}: {e}", exc_info=True)
            raise

    def close(self):
        """
        close the Azure Blob Service Client
        """
        self.blob_service_client.close()
