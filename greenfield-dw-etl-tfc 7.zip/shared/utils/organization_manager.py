from datetime import datetime

from sqlalchemy.orm import Session

from shared.models.organization import DimTFCOrganization
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="OrganizationManager")


class OrganizationManager:
    def __init__(self, session: Session):
        """
        Initialize with a SQLAlchemy session.
        """
        self.session = session

    def insert_organization(self, organization_id: str, organization_name: str):
        """
        Insert a new organization record if it doesn't already exist.
        """
        # Check if the organization already exists in the database
        existing_org = self.session.query(DimTFCOrganization).filter(
            DimTFCOrganization.organization_id == organization_id,
            DimTFCOrganization.organization_name == organization_name
        ).first()

        if existing_org:
            logger.warning(
                f"Record with organization_id: {organization_id} and organization_name: {organization_name} already exists. Skipping insert.")
        else:
            # Create a new Organization record
            new_organization = DimTFCOrganization(
                organization_id=organization_id,
                organization_name=organization_name,
                start_date=datetime.today(),
                end_date=None,  # Set to None for a NULL value
                isactive=1,  # Assuming it's active (1)
                created_date=None  # Set to None if the created_date is not provided
            )

            # Add the new record to the session
            self.session.add(new_organization)

            # Commit the transaction to save the record
            self.session.commit()
            logger.info(f"New organization with ID {organization_id} inserted successfully.")
