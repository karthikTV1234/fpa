import unittest

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger("TestAzureBlobContainerManager")


class TestAzureBlobContainerManager(unittest.TestCase):
    def setUp(self):
        accountName = "devstoreaccount1"
        accountKey = "Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=="
        CONNECTION_STRING = f"DefaultEndpointsProtocol=http;AccountName={accountName};AccountKey={accountKey};BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1"
        CONTAINER_NAME = "testcontainer"

        self.manager = AzureBlobContainerManager(
            CONNECTION_STRING, CONTAINER_NAME)

    def tearDown(self):
        # Code to clean up after tests (e.g., closing database connections)
        pass

    def test_create_directories(self):
        self.manager.create_directory("project1")
        self.manager.create_directory("project2")
        self.manager.create_directory("project3/2025/09/12")

    def test_upload_files(self):
        # Upload files
        with open("example1.txt", "w") as f:
            f.write("Content of example1.")
        with open("example2.txt", "w") as f:
            f.write("Content of example2.")

        self.manager.upload_file("project1", "example1.txt")
        self.manager.upload_file("project2", "example2.txt")

    def test_list_files(self):
        # List files
        logger.info(self.manager.list_files("project1"))
        logger.info(self.manager.list_files("project2"))


if __name__ == '__main__':
    unittest.main()
