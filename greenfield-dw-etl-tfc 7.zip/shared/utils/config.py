import json
import logging
from functools import wraps

import requests
import urllib3

logger = logging.getLogger(__name__)


def cache_response(func):
    cache = {}

    @wraps(func)
    def wrapper(*args, **kwargs):
        key = json.dumps(sorted(kwargs.items()))
        if key in cache:
            # print(f"Returning cached result for {key}")
            return cache[key]
        result = func(*args, **kwargs)
        cache[key] = result
        return result

    return wrapper


class MissingConfigSetting(Exception):
    """Exception raised for missing configuration settings.

    Attributes:
        message (str): Returned explanation of Error.
    """

    def __init__(self, setting):
        """Initialize Exception with Setting that is missing and message."""
        self.setting = setting
        self.message = f"Missing configuration setting - {setting}!"
        self.logger = logger
        super().__init__(self.message)


class Config:
    def __init__(self, base_url: str = None, verify: bool = True, headers: dict = None,
                 default_params: dict = None, env_type: str = None):
        """Create API connection."""
        self.base_url = base_url
        self.verify = verify
        self.headers = headers or {}
        self.headers.update({"Content-Type": "application/json"})
        self.default_params = default_params
        self.env_type = env_type
        if verify is False:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def validate_url(self, path):
        """Validate URL formatting is correct."""
        if not self.base_url.endswith("/") and not path.startswith("/"):
            full_path = f"{self.base_url}/{path}"
        else:
            full_path = f"{self.base_url}{path}"
        if not full_path.endswith("/"):
            return full_path
        return full_path

    @cache_response
    def api_call(self, path: str, method: str = "GET", params: dict = None, payload: dict = None,
                 headers: dict = None):
        """Method to send Request to Device42 of type `method`. Defaults to GET request.

        Args:
            path (str): API path to send request to.
            method (str, optional): API request method. Defaults to "GET".
            params (dict, optional): Additional parameters to send to API. Defaults to None.
            payload (dict, optional): Message payload to be sent as part of API call.

        Raises:
            Exception: Error thrown if request errors.

        Returns:
            dict: JSON payload of API response.
        """
        if self.base_url:
            url = self.validate_url(path)
        else:
            url = path
        return_data = {}

        if params is None:
            params = {}

        if headers is not None:
            self.headers.update(headers)

        if self.default_params is not None:
            params.update(self.default_params)

        resp = None
        if self.headers['Content-Type'] == 'application/json':
            resp = requests.request(
                method=method,
                headers=self.headers,
                url=url,
                params=params,
                verify=self.verify,
                json=payload,
            )
        elif self.headers['Content-Type'] == 'application/x-www-form-urlencoded':
            resp = requests.request(
                method=method,
                headers=self.headers,
                url=url,
                params=params,
                verify=self.verify,
                data=payload,
            )
        try:
            resp.raise_for_status()
        except requests.exceptions.HTTPError as err:
            logger.error(f"Error in communicating to API: {err}")
            if err.response is not None:
                # Print additional details if the response is available
                logger.error("Status Code:", err.response.status_code)
                logger.error("Response Headers:", err.response.headers)
                logger.error("Response Body:", err.response.text)
            return False

        return_data = resp.json()

        return return_data
