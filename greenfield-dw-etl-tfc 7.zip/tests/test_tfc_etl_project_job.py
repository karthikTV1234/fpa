# Mock the dependencies
import os
from unittest import mock

import pytest

from shared.jobs.tfc_etl_project_job.tfc_etl_project_job import TFCETLProjectJob


@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        'DW_SQL_DB_CONNECTION_STRING': 'test_connection_string',
        'DW_CONTAINER_NAME': 'test_container',
        'DW_TFC_HOME_DIRECTORY': 'test_home',
        'AZURE_BLOB_ACCOUNT_NAME': 'test_account',
        'AZURE_BLOB_ACCOUNT_KEY': 'test_key',
        'AZURE_BLOB_ENDPOINT': 'test_endpoint',
    }):
        yield

@pytest.fixture
def mock_dependencies(mock_env_vars):
    # Mock ConfigLoader and JobConfig
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.tfc_etl_job_config = mock_job_config

    # Ensure all required fields exist
    required_fields = [
        'greet_prefix', 'dw_sql_db_connection_string', 'dw_container_name',
        'dw_tfc_home_directory', 'azure_blob_account_name', 'azure_blob_account_key',
        'azure_blob_endpoint'
    ]

    for field in required_fields:
        if not getattr(mock_config_loader, field, None):
            raise ValueError(f"Missing required config field: {field}")

    # Mock managers
    mock_azure_blob_manager = mock.Mock()
    mock_database_manager = mock.Mock()

    # Mock each step
    mock_extract_step = mock.Mock()
    mock_transform_step = mock.Mock()
    mock_load_step = mock.Mock()
    mock_archive_step = mock.Mock()
    mock_teardown_step = mock.Mock()

    # Mock async `execute` method for each step
    mock_extract_step.execute = mock.AsyncMock()
    mock_transform_step.execute = mock.AsyncMock()
    mock_load_step.execute = mock.AsyncMock()
    mock_archive_step.execute = mock.AsyncMock()
    mock_teardown_step.execute = mock.AsyncMock()

    # Mock the context
    mock_context = mock.Mock()
    mock_context.azure_blob_manager = mock_azure_blob_manager
    mock_context.database_manager = mock_database_manager

    # Create the ETL job instance and assign mocks
    job = TFCETLProjectJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context

    job._extract_step = mock_extract_step
    job._transform_step = mock_transform_step
    job._load_step = mock_load_step
    job._archive_step = mock_archive_step
    job._teardown_step = mock_teardown_step

    return job, mock_extract_step, mock_transform_step, mock_load_step, mock_archive_step, mock_teardown_step


# Test case for the full job execution flow
@pytest.mark.asyncio
async def test_tfc_project_job_flow(mock_dependencies):
    # Unpack the mocked dependencies
    job, mock_extract_step, mock_transform_step, mock_load_step, mock_archive_step, mock_teardown_step = mock_dependencies

    # Call the actual execution methods
    await job._extract_step.execute()
    await job._transform_step.execute()
    await job._load_step.execute()
    await job._archive_step.execute()
    await job._teardown_step.execute()

    # Assert that the steps were executed in the correct order
    mock_extract_step.execute.assert_called_once()
    mock_transform_step.execute.assert_called_once()
    mock_load_step.execute.assert_called_once()
    mock_archive_step.execute.assert_called_once()
    mock_teardown_step.execute.assert_called_once()

    # Alternatively, check call count (same as assert_called_once)
    assert mock_extract_step.execute.call_count == 1
    assert mock_transform_step.execute.call_count == 1
    assert mock_load_step.execute.call_count == 1
    assert mock_archive_step.execute.call_count == 1
    assert mock_teardown_step.execute.call_count == 1

@pytest.mark.asyncio
async def test_tfc_project_job_flow_exception_in_extract(mock_dependencies):
    """
    Simulates an exception in the extract step and checks if it is properly handled.
    """
    job, mock_extract_step, mock_transform_step, mock_load_step, mock_archive_step, mock_teardown_step = mock_dependencies

    # Configure extract step to raise an exception
    mock_extract_step.execute.side_effect = Exception("Extract step failed!")

    with pytest.raises(Exception, match="Extract step failed!"):
        await job._extract_step.execute()

    # Ensure other steps were NOT called
    mock_transform_step.execute.assert_not_called()
    mock_load_step.execute.assert_not_called()
    mock_archive_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()


@pytest.mark.asyncio
async def test_tfc_project_job_flow_exception_in_transform(mock_dependencies):
    """
    Simulates an exception in the transform step.
    """
    job, mock_extract_step, mock_transform_step, mock_load_step, mock_archive_step, mock_teardown_step = mock_dependencies

    # Ensure extract step executes successfully
    await job._extract_step.execute()

    # Configure transform step to raise an exception
    mock_transform_step.execute.side_effect = Exception("Transform step failed!")

    with pytest.raises(Exception, match="Transform step failed!"):
        await job._transform_step.execute()

    # Ensure load, archive, and teardown steps were NOT called
    mock_load_step.execute.assert_not_called()
    mock_archive_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()


@pytest.mark.asyncio
async def test_tfc_project_job_flow_exception_in_load(mock_dependencies):
    """
    Simulates an exception in the load step.
    """
    job, mock_extract_step, mock_transform_step, mock_load_step, mock_archive_step, mock_teardown_step = mock_dependencies

    # Ensure extract and transform steps execute successfully
    await job._extract_step.execute()
    await job._transform_step.execute()

    # Configure load step to raise an exception
    mock_load_step.execute.side_effect = Exception("Load step failed!")

    with pytest.raises(Exception, match="Load step failed!"):
        await job._load_step.execute()

    # Ensure archive and teardown steps were NOT called
    mock_archive_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()