-- Name: dim_date; Type: TABLE
CREATE TABLE public.dim_date (
    id uuid NOT NULL,
    full_date date NOT NULL,
    year integer NOT NULL,
    quarter integer NOT NULL,
    month integer NOT NULL,
    day integer NOT NULL,
    day_of_week character varying NOT NULL,
    is_weekend boolean NOT NULL,
    hour integer NOT NULL,
    minute integer NOT NULL,
    second integer NOT NULL,
    dateref integer NOT NULL
);

-- Name: dim_tf_module_version_status; Type: TABLE
CREATE TABLE public.dim_tf_module_version_status (
    version_dim_rowid integer NOT NULL,
    module_dim_rowid integer NOT NULL,
    version character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    isactive integer
);

-- Name: dim_tf_modulelist; Type: TABLE
CREATE TABLE public.dim_tf_modulelist (
    modulelist_dim_row_id integer NOT NULL,
    module_id character varying(255) NOT NULL,
    organization_dim_rowid character varying(255) NOT NULL,
    module_name character varying(255) NOT NULL,
    namespace character varying(255) NOT NULL,
    provider character varying(255) NOT NULL,
    registry_name character varying(255) NOT NULL,
    nocode character varying(255) NOT NULL,
    publishing_mechanism character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    start_date date,
    end_date date,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    isactive integer
);

-- Name: dim_tf_moduleversions; Type: TABLE
CREATE TABLE public.dim_tf_moduleversions (
    moduleversion_dim_rowid integer NOT NULL,
    module_key character varying(255),
    module_source character varying(255),
    module_version character varying(255),
    module_dir character varying(255),
    cv_id character varying(255),
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);



--
-- Name: dim_tf_projects; Type: TABLE; Schema: public; Owner: dwa_user
--

CREATE TABLE public.dim_tf_projects (
    project_dim_rowid integer NOT NULL,
    project_id character varying(255) NOT NULL,
    organization_dim_rowid character varying(255) NOT NULL,
    project_name character varying(255) NOT NULL,
    start_date date,
    end_date date,
    create_date timestamp without time zone NOT NULL,
    isactive integer
);

-- Name: dim_tf_providerversions; Type: TABLE
CREATE TABLE public.dim_tf_providerversions (
    providerversion_dim_rowid integer NOT NULL,
    provider_name character varying(255),
    provider_version character varying(255),
    cv_id character varying(255),
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: dim_tf_workspace_relationship; Type: TABLE
CREATE TABLE public.dim_tf_workspace_relationship (
    workspace_relationship_rowid integer NOT NULL,
    workspace_dim_rowid integer,
    locked_by_id character varying(255),
    locked_by_links_related character varying(255),
    current_run_id character varying(255),
    latest_run_id character varying(255),
    outputs character varying,
    remote_state_consumers_links_related character varying,
    current_state_version_data_id character varying,
    current_state_version_links_related character varying,
    current_configuration_version_data_id character varying,
    current_configuration_version_links_related character varying,
    agent_pool_data_id character varying,
    readme character varying,
    current_assessment_result character varying,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: dim_tfc_organization; Type: TABLE
CREATE TABLE public.dim_tfc_organization (
    organization_dim_rowid integer NOT NULL,
    organization_id character varying,
    organization_name character varying,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    created_date timestamp without time zone,
    isactive integer
);

-- Name: dim_tfc_provider_list; Type: TABLE
CREATE TABLE public.dim_tfc_provider_list (
    providerlist_dim_rowid integer NOT NULL,
    provider_id character varying,
    organization_dim_rowid integer NOT NULL,
    provider_name character varying,
    namespace character varying,
    registry_name character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    isactive integer
);

-- Name: dim_tfc_workspaces; Type: TABLE
CREATE TABLE public.dim_tfc_workspaces (
    workspace_dim_rowid integer NOT NULL,
    workspace_id character varying(255) NOT NULL,
    project_dim_rowid integer NOT NULL,
    workspace_name character varying(255) NOT NULL,
    allow_destroy_plan boolean,
    auto_apply boolean,
    auto_apply_run_trigger boolean,
    auto_destroy_activity_duration integer,
    auto_destroy_at timestamp without time zone,
    auto_destroy_status character varying(50),
    inherits_project_auto_destroy boolean,
    created_at timestamp without time zone NOT NULL,
    environment character varying(50),
    locked boolean,
    queue_all_runs boolean,
    speculative_enabled boolean,
    structured_run_output_enabled boolean,
    terraform_version character varying(50) NOT NULL,
    working_directory character varying(255),
    global_remote_state boolean,
    updated_at timestamp without time zone NOT NULL,
    description character varying(255),
    file_triggers_enabled boolean,
    assessments_enabled boolean,
    last_assessment_result_at timestamp without time zone,
    locked_reason character varying(255),
    source character varying(255),
    source_name character varying(255),
    source_url character varying(255),
    tag_names character varying,
    setting_overwrites_execution_mode boolean,
    setting_overwrites_agent_pool boolean,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tf_modulelist; Type: TABLE
CREATE TABLE public.fact_tf_modulelist (
    modulelist_fact_row_id integer NOT NULL,
    moduleslist_dim_row_id integer NOT NULL,
    version_status character varying(255),
    organization_id character varying(255) NOT NULL,
    load_date timestamp without time zone,
    start_dateref integer,
    end_dateref integer,
    isactive integer
);

-- Name: fact_tf_moduleversions; Type: TABLE
CREATE TABLE public.fact_tf_moduleversions (
    moduleversion_fact_rowid integer NOT NULL,
    moduleversion_dim_rowid integer NOT NULL,
    start_dateref date,
    end_dateref date,
    created_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tf_projects; Type: TABLE
CREATE TABLE public.fact_tf_projects (
    project_fact_row_id integer NOT NULL,
    project_dim_rowid integer NOT NULL,
    workspace_count integer NOT NULL,
    team_count integer NOT NULL,
    stack_count integer NOT NULL,
    start_dateref integer,
    end_dateref integer,
    create_date timestamp without time zone NOT NULL,
    auto_destroy_activity_duration character varying(255),
    isactive integer
);

-- Name: fact_tf_providerversions; Type: TABLE
CREATE TABLE public.fact_tf_providerversions (
    providerversion_fact_rowid integer NOT NULL,
    providerversion_dim_rowid integer NOT NULL,
    start_dateref date,
    end_dateref date,
    created_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tf_run; Type: TABLE
CREATE TABLE public.fact_tf_run (
    run_dim_row integer NOT NULL,
    run_id character varying,
    start_dateref timestamp without time zone,
    end_dateref timestamp without time zone,
    workspace_dim_rowid integer NOT NULL,
    apply_id character varying,
    configuration_version_id character varying,
    created_by character varying,
    plan_id character varying,
    task_stages character varying,
    policy_checks character varying,
    comments character varying,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tf_run_status; Type: TABLE
CREATE TABLE public.fact_tf_run_status (
    run_fact_rowid integer NOT NULL,
    run_dim_row integer NOT NULL,
    line_no integer,
    field_name character varying,
    field_value character varying,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    update_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tfc_provider_list; Type: TABLE
CREATE TABLE public.fact_tfc_provider_list (
    providerlist_fact_rowid integer NOT NULL,
    providerlist_dim_rowid integer NOT NULL,
    organization_dim_rowid integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    isactive integer
);

-- Name: fact_tfc_workspaces; Type: TABLE
CREATE TABLE public.fact_tfc_workspaces (
    workspace_fact_rowid integer NOT NULL,
    workspace_dim_rowid integer NOT NULL,
    resource_count integer,
    apply_duration_average numeric(10,2),
    plan_duration_average numeric(10,2),
    policy_check_failures integer,
    run_failures integer,
    workspace_kpis_runs_count integer,
    latest_change_at timestamp without time zone,
    operations integer,
    execution_mode character varying(50),
    vcs_repo character varying(255),
    vcs_repo_identifier character varying(255),
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: summary_tf_modulelist; Type: TABLE
CREATE TABLE public.summary_tf_modulelist (
    module_sum_row_id integer NOT NULL,
    organization_id character varying(255) NOT NULL,
    module_count integer NOT NULL,
    report_dateref integer NOT NULL,
    created_date timestamp without time zone
);

-- Name: summary_tf_moduleversions; Type: TABLE
CREATE TABLE public.summary_tf_moduleversions (
    moduleversion_summary_rowid integer NOT NULL,
    report_dateref integer,
    total_modules_used integer,
    created_date timestamp without time zone
);

-- Name: summary_tf_project; Type: TABLE
CREATE TABLE public.summary_tf_project (
    project_summary_rowid integer NOT NULL,
    organization_dim_rowid character varying(255) NOT NULL,
    report_dateref integer NOT NULL,
    projects_count integer NOT NULL,
    create_date timestamp without time zone NOT NULL
);

-- Name: summary_tf_providerversions; Type: TABLE
CREATE TABLE public.summary_tf_providerversions (
    providerversion_summary_rowid integer NOT NULL,
    report_dateref integer,
    total_providers_used integer,
    created_date timestamp without time zone
);

-- Name: summary_tf_workspace; Type: TABLE
CREATE TABLE public.summary_tf_workspace (
    workspace_summary_rowid integer NOT NULL,
    organization_dim_rowid integer NOT NULL,
    report_dateref integer NOT NULL,
    workspace_count integer,
    create_date timestamp without time zone
);

-- Name: summary_tfc_provider; Type: TABLE
CREATE TABLE public.summary_tfc_provider (
    provider_summary_rowid integer NOT NULL,
    organization_dim_rowid integer NOT NULL,
    report_dateref integer NOT NULL,
    provider_count integer NOT NULL,
    create_date timestamp without time zone
);

-- Name: summary_tfc_run; Type: TABLE
CREATE TABLE public.summary_tfc_run (
    run_summary_rowid integer NOT NULL,
    workspace_dim_rowid integer NOT NULL,
    report_dateref integer NOT NULL,
    run_count integer NOT NULL,
    create_date timestamp without time zone
);

-- Name: workspace_run_control; Type: TABLE
CREATE TABLE public.workspace_run_control (
    id integer NOT NULL,
    workspace_id character varying(255) NOT NULL,
    run_id character varying(255) NOT NULL,
    workspace_status integer NOT NULL,
    run_status integer NOT NULL
);

