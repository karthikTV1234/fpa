import azure.functions as func

from shared.tfc_workflow import TFCWorkflow
from shared.utils.logger_setup import setup_logger

# Set up the logger
logger = setup_logger(name="tfc_etl_project_http_trigger")


async def main(req: func.HttpRequest) -> func.HttpResponse:
    job = 'etl-project'  # Correct job name as per the TFCWorkflow class
    logger.info(f'TFC {job} HTTP trigger function processed a request.')

    try:
        # Initialize TFCWorkflow
        wf = TFCWorkflow()

        # Execute the job
        success = await wf.execute_job(job)

        if success:
            logger.info(f"{job} executed successfully.")
            return func.HttpResponse(f"{job} has been triggered successfully", status_code=200)
        else:
            logger.error(f"{job} execution failed.")
            return func.HttpResponse(f"{job} execution failed", status_code=500)

    except Exception as e:
        logger.exception(f"An error occurred while triggering {job}: {e}")
        return func.HttpResponse(f"An error occurred: {e}", status_code=500)
