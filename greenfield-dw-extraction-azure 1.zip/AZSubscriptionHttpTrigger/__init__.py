import azure.functions as func

from shared.az_workflow import AZWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="az_subscription_http_trigger")

async def main(req: func.HttpRequest) -> func.HttpResponse:
    job = 'subscription'
    logger.info(f'AZ {job} HTTP trigger function processed a request.')
    azw = AZWorkflow()
    await azw.execute_job(job_name=job)
    return func.HttpResponse(f"{job} has been triggered successfully")
