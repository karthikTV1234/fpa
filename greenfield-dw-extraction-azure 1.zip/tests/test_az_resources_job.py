import os
from unittest import mock

import pytest

from shared.jobs.az_resources_job.az_resources_job import AZResourcesJob


@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        "DW_AZURE_HOME_DIRECTORY": "test_raw_data",
        'DW_CONTAINER_NAME': 'test_container',
        'AZURE_BLOB_ACCOUNT_NAME': 'test_account',
        'AZURE_BLOB_ACCOUNT_KEY': 'test_key',
        'AZURE_BLOB_ENDPOINT': 'test_endpoint',
        "AZURE_CLIENT_ID": "",
        "AZURE_CLIENT_SECRET": "",
        "AZURE_TENANT_ID": "",
        "AZURE_RESOURCE_MAX_PAGE_SIZE": 100,
        "AZURE_RESOURCE_WATERMARK_BLOB_NAME": "watermarks.json"
    }):
        yield

# Mock the dependencies
@pytest.fixture
def mock_dependencies():
    # Mock ConfigLoader and AZExtractionJobConfig
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.az_extraction_job_config = mock_job_config

    # Ensure all required fields exist
    required_fields = [
        'azure_blob_account_name',
        'azure_blob_account_key',
        'azure_blob_endpoint',
        'dw_container_name',
        'dw_azure_home_directory',
        'azure_resource_max_page_size',
        'azure_resource_watermark_blob_name',
        'az_resources_watermark_key'
    ]

    for field in required_fields:
        if not getattr(mock_config_loader.az_extraction_job_config, field, None):
            raise ValueError(f"Missing required config field: {field}")

    # Mock the Services
    mock_azure_client_service = mock.Mock()
    mock_azure_blob_manager = mock.Mock()
    mock_watermark_manager = mock.Mock()

    # Mock each step
    mock_fetch_active_subscription_step = mock.Mock()
    mock_store_resource_step = mock.Mock()
    mock_fetch_watermark_step = mock.Mock()
    mock_update_watermark_step = mock.Mock()

    # Mock async `execute` method for each step
    mock_fetch_active_subscription_step.execute = mock.AsyncMock()
    mock_store_resource_step.execute = mock.AsyncMock()
    mock_fetch_watermark_step.execute = mock.AsyncMock()
    mock_update_watermark_step.execute = mock.AsyncMock()

    # Mock the context and other services like WatermarkManager
    mock_context = mock.Mock()
    mock_context.azure_client_service = mock_azure_client_service
    mock_context.watermark_manager = mock.Mock()
    mock_context.azure_blob_manager = mock.Mock()

    # Create the AZResourcesJob instance with mocked dependencies
    job = AZResourcesJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context
    job._fetch_active_subscription_step = mock_fetch_active_subscription_step
    job._fetch_watermark_step = mock_fetch_watermark_step
    job._store_resource_step = mock_store_resource_step
    job._update_watermark_step = mock_update_watermark_step

    return job, mock_fetch_active_subscription_step, mock_fetch_watermark_step, mock_store_resource_step, mock_update_watermark_step


# Test case for the full job execution flow
@pytest.mark.asyncio
async def test_az_resources_job_flow(mock_dependencies):
    job, mock_fetch_active_subscription_step, mock_fetch_watermark_step, mock_store_resource_step, mock_update_watermark_step = mock_dependencies

    # Call the actual execution methods
    await job._fetch_active_subscription_step.execute()
    await job._fetch_watermark_step.execute()
    await job._store_resource_step.execute()
    await job._update_watermark_step.execute()

    # Assert that each step was called in the expected order
    mock_fetch_active_subscription_step.execute.assert_called_once()
    mock_fetch_watermark_step.execute.assert_called_once()
    mock_store_resource_step.execute.assert_called_once()
    mock_update_watermark_step.execute.assert_called_once()

    # Check that the state machine transitioned correctly
    assert mock_fetch_active_subscription_step.execute.call_count == 1
    assert mock_fetch_watermark_step.execute.call_count == 1
    assert mock_store_resource_step.execute.call_count == 1
    assert mock_update_watermark_step.execute.call_count == 1


# Test case for handling errors in the fetch resources step
@pytest.mark.asyncio
async def test_az_resources_job_fetch_error(mock_dependencies):
    job, mock_fetch_watermark_step, mock_fetch_resources_step, mock_store_resource_step, mock_update_watermark_step = mock_dependencies

    # Simulate an exception during the fetch resources step
    mock_fetch_resources_step.execute = mock.AsyncMock(side_effect=Exception("Fetch error"))

    # Trigger the start event
    with pytest.raises(Exception):
        await job.trigger_event("start")

    # Assert that the fetch resources step was called
    mock_fetch_resources_step.execute.assert_called_once()

    # Ensure that no further steps were executed
    mock_store_resource_step.execute.assert_not_called()
    mock_update_watermark_step.execute.assert_not_called()


# Test case for handling errors in the update watermark step
@pytest.mark.asyncio
async def test_az_resources_job_update_watermark_error(mock_dependencies):
    job, mock_fetch_watermark_step, mock_fetch_resources_step, mock_store_resource_step, mock_update_watermark_step = mock_dependencies

    # Simulate an exception during the update watermark step
    mock_update_watermark_step.execute = mock.AsyncMock(side_effect=Exception("Update watermark error"))

    # Trigger the start event
    await job.trigger_event("start")

    # Assert that the update watermark step was called
    mock_update_watermark_step.execute.assert_called_once()

    # Ensure that no further steps were executed
    mock_store_resource_step.execute.assert_called_once()
    mock_fetch_resources_step.execute.assert_called_once()
    mock_fetch_watermark_step.execute.assert_called_once()
