import os
from unittest import mock

import pytest

from shared.jobs.az_subscription_job.az_subscription_job import AZSubscriptionJob

@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        'DW_SQL_DB_CONNECTION_STRING': 'test_connection_string',
        'DW_CONTAINER_NAME': 'test_container',
        'DW_TFC_HOME_DIRECTORY': 'test_home',
        'AZURE_BLOB_ACCOUNT_NAME': 'test_account',
        'AZURE_BLOB_ACCOUNT_KEY': 'test_key',
        'AZURE_BLOB_ENDPOINT': 'test_endpoint',
    }):
        yield

# Mock the dependencies
@pytest.fixture
def mock_dependencies():
    # Mock ConfigLoader and AZExtractionJobConfig
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.az_extraction_job_config = mock_job_config

    # Ensure all required fields exist
    required_fields = [
        'azure_blob_account_name', 'dw_sql_db_connection_string', 'dw_container_name',
        'dw_tfc_home_directory', 'azure_blob_account_name', 'azure_blob_account_key',
        'azure_blob_endpoint'
    ]

    # Mock the AzureClientService
    mock_azure_client_service = mock.Mock()
    mock_azure_blob_manager = mock.Mock()

    # Mock the FetchSubscriptionStep and StoreSubscriptionStep
    mock_fetch_subscription_step = mock.Mock()
    mock_store_subscription_step = mock.Mock()

    # Mock async `execute` method for each step
    mock_fetch_subscription_step.execute = mock.AsyncMock()
    mock_store_subscription_step.execute = mock.AsyncMock()

    # Mock the context and AzureBlobContainerManager (if needed)
    mock_context = mock.Mock()
    mock_context.azure_client_service = mock_azure_client_service
    mock_context.azure_blob_manager = mock_azure_blob_manager

    # Create the AZSubscriptionJob instance with mocked dependencies
    job = AZSubscriptionJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context
    job._fetch_subscription_step = mock_fetch_subscription_step
    job._store_subscription_step = mock_store_subscription_step

    return job, mock_fetch_subscription_step, mock_store_subscription_step

# Test case for the full job execution flow
@pytest.mark.asyncio
async def test_az_subscription_job_flow(mock_dependencies):
    # Unpack the mocked dependencies
    job, mock_fetch_subscription_step, mock_store_subscription_step = mock_dependencies

    # Call the actual execution methods
    await job._fetch_subscription_step.execute()
    await job._store_subscription_step.execute()

    # Assert that the steps were executed in the correct order
    mock_fetch_subscription_step.execute.assert_called_once()
    mock_store_subscription_step.execute.assert_called_once()

    # We can assert that the correct methods were called in the expected sequence
    assert mock_fetch_subscription_step.execute.call_count == 1
    assert mock_store_subscription_step.execute.call_count == 1


# Test case for handling errors in the fetch subscription step
@pytest.mark.asyncio
async def test_az_subscription_job_fetch_error(mock_dependencies):
    job, mock_fetch_subscription_step, mock_store_subscription_step = mock_dependencies

    # Simulate an exception during the fetch subscription step
    mock_fetch_subscription_step.execute = mock.AsyncMock(side_effect=Exception("Fetch error"))

    # Trigger the start event
    with pytest.raises(Exception):
        await job.trigger_event("start")

    # Assert that the fetch subscription step was called
    mock_fetch_subscription_step.execute.assert_called_once()

