from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TeardownStep")

class TeardownStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZResourcesJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        self.context.azure_blob_manager.close()
        self.context.watermark_manager.close()