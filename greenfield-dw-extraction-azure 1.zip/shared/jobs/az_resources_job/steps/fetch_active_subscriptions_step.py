from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="FetchActiveSubscriptionsStep")

class FetchActiveSubscriptionsStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZResourcesJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        # Fetch subscription from blob
        directory_path = f"{self.config.dw_azure_home_directory}/subscription"
        subscription_list = self.context.azure_blob_manager.fetch_existing_data(directory_path=directory_path)

        if not subscription_list:
            logger.warning("No existing subscriptions")
        else:
            # Don't process soft delete subscription
            # Filter out soft deleted subscriptions
            active_subscriptions = [
                sub for sub in subscription_list if not (sub["end_date"] and not sub["is_active"])
            ]
            self.context.active_subscriptions = active_subscriptions
