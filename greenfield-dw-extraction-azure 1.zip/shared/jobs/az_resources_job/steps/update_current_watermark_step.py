from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="UpdateCurrentWatermarkStep")

class UpdateCurrentWatermarkStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZResourcesJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        if self.context.new_watermark is not None:
            watermark = self.context.new_watermark.isoformat()
            source_name = self.config.az_resources_watermark_key
            self.context.watermark_manager.update_watermark(source_name=source_name, new_watermark=watermark)
        else:
            logger.info('no new watermark to update')


