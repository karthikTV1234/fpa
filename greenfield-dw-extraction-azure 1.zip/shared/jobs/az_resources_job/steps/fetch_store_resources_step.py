import time
from datetime import datetime

from azure.core.exceptions import AzureError
from azure.mgmt.resourcegraph.models import QueryRequest, QueryResponse

from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="FetchStoreResourcesStep")


def resource_req_query(time_diff):
    if time_diff is None:
        query = "resources"
    else:
        if time_diff < 1:
            # Override time_hour for testing purpose
            time_diff = 1
        time_diff = str(time_diff) + "h"
        query = f"resourcechanges | where todatetime(properties.changeAttributes.timestamp) > ago({time_diff})"
    return query



def get_resources_for_subscription_paginated(context, subscription_id, records_per_page, time_diff, max_retries=3, retry_delay=5):
    if not subscription_id:
        raise ValueError("Subscription ID is required but was not provided.")
    try:
        query_request = QueryRequest(
            subscriptions=[subscription_id],
            query=resource_req_query(time_diff),
            options={"resultFormat": "objectArray", "$top": records_per_page}  # Set records per page
        )

        # Initial query
        result: QueryResponse = context.azure_client_service.resource_graph_client.resources(query_request)
        if hasattr(result, 'data') and isinstance(result.data, list):
            yield result.data  # Yield the first page of data

        # Handle pagination with skipToken
        while result.skip_token is not None:
            # Create a new QueryRequest with updated options
            re_query = QueryRequest(
                subscriptions=[subscription_id],
                query=resource_req_query(time_diff),
                options={
                    "resultFormat": "objectArray",
                    "$skipToken": result.skip_token  # Add skipToken here
                }
            )
            retries = 0
            while retries < max_retries:
                try:
                    result = context.azure_client_service.resource_graph_client.resources(re_query)
                    if hasattr(result, 'data') and isinstance(result.data, list):
                        yield result.data  # Yield each subsequent page
                    break  # Exit retry loop on success
                except AzureError as e:
                    retries += 1
                    logger.warning(
                        f"Retry {retries}/{max_retries} for subscription {subscription_id} due to Azure error: {str(e)}")
                    time.sleep(retry_delay * retries)  # Exponential backoff
                except Exception as e:
                    retries += 1
                    logger.warning(
                        f"Retry {retries}/{max_retries} for subscription {subscription_id} due to unexpected error: {str(e)}")
                    time.sleep(retry_delay * retries)

            if retries == max_retries:
                logger.error(
                    f"Failed to fetch page after {max_retries} retries for subscription {subscription_id}. Skipping remaining pages.")
                break  # Skip to the next subscription if retries are exhausted

    except AzureError as e:
        logger.error(f"Azure error occurred while fetching resources for subscription {subscription_id}: {str(e)}")
    except Exception as e:
        logger.error(
            f"Unexpected error occurred while fetching resources for subscription {subscription_id}: {str(e)}")

class FetchStoreResourcesStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZResourcesJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        empty_resource_subscriptions = []
        # Logic to fetch resource
        try:

            watermark = self.context.current_watermark
            time_diff_hours = None
            if watermark:
                last_execution_time = datetime.fromisoformat(watermark)
                time_diff_hours = (datetime.utcnow() - last_execution_time).total_seconds() / 3600
                logger.info(
                    f"Last execution time: {last_execution_time}, fetching changes since {time_diff_hours} hours.")
            else:
                logger.info("No previous execution time found. Fetching all resources.")

            # current execution time in the watermark
            current_execution_time = datetime.utcnow()
            self.context.new_watermark = current_execution_time

            # Fetch active subscriptions
            active_subscriptions = self.context.active_subscriptions
            # Process resources for each subscription
            if active_subscriptions is not None:
                for subscription in active_subscriptions:
                    subscription_id = subscription.get("subscription_id")
                    if not subscription_id:
                        logger.warning("Subscription ID is null or empty.")
                        continue

                    logger.info(f"Fetching resources for subscription: {subscription_id}")

                    try:
                        # Fetch resources for the given subscription with pagination
                        for page_number, resources_page_data in enumerate(get_resources_for_subscription_paginated(self.context, subscription_id, self.config.azure_resource_max_page_size,time_diff_hours),start=1):
                            logger.info(f"Fetched resources for subscription ID: {subscription_id} successfully.")

                            if not resources_page_data:
                                logger.warning(f"No resource data found for subscription ID: {subscription_id}. Skipping.")

                                empty_resource_subscriptions.append(subscription_id)
                                continue  # Skip to the next iteration if no resources are found

                            try:
                                # Generate a unique blob name with page number
                                blob_name = f"resource_{subscription_id}_page_{page_number}.json"
                                directory_path = f"{self.config.dw_azure_home_directory}/resources"
                                try:
                                    existing_blob_data = self.context.azure_blob_manager.read_json_from_blob(
                                        directory_name = directory_path, file_path = blob_name
                                    )

                                    if existing_blob_data is not None:
                                        # Compare and merge resources
                                        merged_resources = self.context.watermark_manager.merge_resources(existing_blob_data,
                                                                                                  resources_page_data)
                                    else:
                                        logger.info(
                                            "Blob file does not exist or could not be read; replace merged_resources with recent data.")
                                        merged_resources = resources_page_data
                                except Exception as e:
                                    logger.info(
                                        f"Error while fetching existing resource data for blob: {blob_name}. Starting fresh.")
                                    raise RuntimeError(f"Error while fetching existing resource data: {str(e)}") from e

                                # Upload the current page to Blob Storage
                                self.context.azure_blob_manager.upload_object(
                                    obj=merged_resources,
                                    directory_name=directory_path,
                                    file_path=blob_name
                                )
                                logger.info(
                                    f"Page {page_number} uploaded successfully for subscription ID {subscription_id}.")

                            except Exception as e:
                                logger.error(f"Failed to fetch resource data: {str(e)}")
                                raise RuntimeError(f"Error fetching resource data: {str(e)}") from e

                        # Log subscriptions with empty resource responses at the end
                        if empty_resource_subscriptions:
                            logger.info("subscriptions with empty resource responses")
                            self.context.empty_resource_subscriptions = empty_resource_subscriptions
                            for index, value in enumerate(self.context.empty_resource_subscriptions, start=1):
                                logger.info(f"{index}: {value}")

                    except Exception as e:
                        logger.error(f"Error in fetch resources: {str(e)}")
            else:
                logger.warning("No subscription to fetch resources")
        except Exception as e:
            logger.error(f"Error in fetch resources: {str(e)}")
