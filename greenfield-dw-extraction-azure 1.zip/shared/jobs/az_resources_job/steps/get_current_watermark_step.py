from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="GetCurrentWatermarkStep")

class GetCurrentWatermarkStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZResourcesJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        source_name = self.config.azure_resource_watermark_blob_name
        watermark = self.context.watermark_manager.get_watermark(source_name=source_name)
        if watermark is None:
            watermark = None
        self.context.current_watermark = watermark

