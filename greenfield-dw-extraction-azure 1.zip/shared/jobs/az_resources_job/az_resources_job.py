import statesman

from shared.config_loader.config_loader import ConfigLoader, AZExtractionJobConfig
from shared.jobs.az_resources_job.az_resources_job_context import AZResourcesJobContext
from shared.jobs.az_resources_job.steps.fetch_active_subscriptions_step import FetchActiveSubscriptionsStep
from shared.jobs.az_resources_job.steps.fetch_store_resources_step import FetchStoreResourcesStep
from shared.jobs.az_resources_job.steps.get_current_watermark_step import GetCurrentWatermarkStep
from shared.jobs.az_resources_job.steps.teardown_step import TeardownStep
from shared.jobs.az_resources_job.steps.update_current_watermark_step import UpdateCurrentWatermarkStep
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.azure_client_service import AzureClientService
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="AZResourcesJob")

class AZResourcesJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: AZExtractionJobConfig = None
    _context: AZResourcesJobContext = None
    _azure_client: AzureClientService = None

    _fetch_store_resources_step: FetchStoreResourcesStep = None
    _fetch_watermark_step: GetCurrentWatermarkStep = None
    _update_watermark_step: UpdateCurrentWatermarkStep = None
    _fetch_active_subscription_step: FetchActiveSubscriptionsStep = None
    _teardown_step: TeardownStep = None

    class States(statesman.StateEnum):
        start = "start"
        get_current_watermark = "get_current_watermark"
        fetch_active_subscriptions = " fetch_active_subscriptions"
        fetch_store_resources = "fetch_store_resources"
        update_watermark = "update_watermark"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = AZResourcesJobContext()
        self._job_config = self._config_loader.az_extraction_job_config

        self._context.azure_client_service = AzureClientService()

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.az_extraction_job_config.azure_connection_str,
            container_name= self._config_loader.az_extraction_job_config.dw_container_name)

        self._context.watermark_manager = WatermarkManagerBlob(container_name=self._config_loader.az_extraction_job_config.dw_container_name,
                                                           connection_string=self._config_loader.az_extraction_job_config.azure_connection_str,
                                                               blob_name=self._config_loader.az_extraction_job_config.azure_resource_watermark_blob_name)

        self._fetch_watermark_step = GetCurrentWatermarkStep(config=self._job_config, context=self._context)
        self._update_watermark_step = UpdateCurrentWatermarkStep(config=self._job_config, context=self._context)

        self._fetch_active_subscription_step = FetchActiveSubscriptionsStep(
            config=self._job_config, context=self._context)

        self._fetch_store_resources_step = FetchStoreResourcesStep(
            config=self._job_config, context=self._context)

        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)


    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("get_current_watermark")

    @statesman.event(States.start, States.get_current_watermark)
    async def get_current_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is retrieving current watermark")
        await self._fetch_watermark_step.execute()
        await self.trigger_event("fetch_active_subscriptions")

    @statesman.event(States.get_current_watermark, States.fetch_active_subscriptions)
    async def fetch_active_subscriptions(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetch active subscriptions")
        await self._fetch_active_subscription_step.execute()
        await self.trigger_event("fetch_store_resources")

    @statesman.event(States.fetch_active_subscriptions, States.fetch_store_resources)
    async def fetch_store_resources(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetch and store resources")
        await self._fetch_store_resources_step.execute()
        await self.trigger_event("update_watermark")

    @statesman.event(States.fetch_store_resources, States.update_watermark)
    async def update_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is update_watermark")
        await self._update_watermark_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.update_watermark, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is teardown")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
