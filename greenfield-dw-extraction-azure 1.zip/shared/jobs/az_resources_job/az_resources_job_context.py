from datetime import datetime
from typing import Optional, List

from shared.jobs.az_subscription_job.az_subscription_job_context import AZSubscriptionJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.azure_client_service import AzureClientService
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="AZResourcesJobContext")

class AZResourcesJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.azure_client_service: Optional[AzureClientService] = None
        self.watermark_manager: Optional[WatermarkManagerBlob] = None
        self.current_watermark: Optional[str] = None
        self.new_watermark: Optional[datetime] = None
        self.az_subscription_job_context: Optional[AZSubscriptionJobContext] = None
        self.empty_resource_subscriptions: Optional[List[str]] = None
        self.active_subscriptions: List[any] = []


