import statesman

from shared.config_loader.config_loader import ConfigLoader, AZExtractionJobConfig
from shared.jobs.az_subscription_job.az_subscription_job_context import AZSubscriptionJobContext
from shared.jobs.az_subscription_job.steps.fetch_subscription_step import FetchSubscriptionStep
from shared.jobs.az_subscription_job.steps.store_subscription_step import StoreSubscriptionStep
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.azure_client_service import AzureClientService
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AZSubscriptionJob")

class AZSubscriptionJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: AZExtractionJobConfig = None
    _context: AZSubscriptionJobContext = None
    _azure_client: AzureClientService = None

    _fetch_subscription_step: FetchSubscriptionStep = None
    _store_subscription_step: StoreSubscriptionStep = None

    class States(statesman.StateEnum):
        start = "start"
        fetch_subscription = "fetch_subscription"
        store_subscription = 'store_subscription'
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = AZSubscriptionJobContext()
        self._job_config = self._config_loader.az_extraction_job_config

        self._context.azure_client_service = AzureClientService()

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.az_extraction_job_config.azure_connection_str,
            container_name= self._config_loader.az_extraction_job_config.dw_container_name)

        self._fetch_subscription_step = FetchSubscriptionStep(
            config=self._job_config, context=self._context)

        self._store_subscription_step = StoreSubscriptionStep(
            config=self._job_config, context=self._context)


    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("fetch_subscription")

    @statesman.event(States.start, States.fetch_subscription)
    async def fetch_subscription(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching subscription")
        await self._fetch_subscription_step.execute()
        await self.trigger_event("store_subscription")

    @statesman.event(States.fetch_subscription, States.store_subscription)
    async def store_subscription(self) -> None:
        logger.info(f"{self.__class__.__name__} is storing subscription")
        await self._store_subscription_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.store_subscription, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")