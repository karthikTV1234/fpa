from datetime import datetime

import pandas as pd

from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_subscription_job.az_subscription_job_context import AZSubscriptionJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="FetchSubscriptionStep")

class FetchSubscriptionStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZSubscriptionJobContext):
        self.config = config
        self.context = context

    """Compare two list of azure subscription for each fields based on primary key field "subscription_id" and find any differ or changes, if changes are detected then do soft delete by updating the fields
     end_date to today date and is_active to false, if subscription_id not found in the existing record it means the record is new so just add it as a new record,
     if subscription_id found in the existing list and no changes are detected then don't do anything, use existing record as it is """
    @staticmethod
    def _scd_type_2_logic(existing_subscription_data_list, new_subscription_data_list):
        final_records = []
        current_date = datetime.now().strftime("%Y-%m-%d")
        try:
            existing_pd_dataframe = pd.DataFrame(existing_subscription_data_list)
            new_pd_dataframe = pd.DataFrame(new_subscription_data_list)

            for _, new_row in new_pd_dataframe.iterrows():
                subscription_id = new_row["subscription_id"]
                existing_row = existing_pd_dataframe[existing_pd_dataframe["subscription_id"] == subscription_id]
                if existing_row.empty:  # New record
                    final_records.append(new_row.to_dict())
                else:
                    # Check for changes
                    fields_to_check = ["display_name", "state", "tenant_id", "subscription_policies",
                                       "authorization_source", "managed_by_tenants", "tags"]
                    changes_detected = any(
                        existing_row.iloc[0].get(field, None) != new_row.get(field, None) for field in fields_to_check
                    )

                    if changes_detected:  # Update record with soft delete
                        # Soft delete old record
                        old_record = existing_row.iloc[0].to_dict()
                        old_record["end_date"] = current_date
                        old_record["is_active"] = False
                        final_records.append(old_record)

                        # Add new record
                        new_record = new_row.to_dict()
                        new_record["version"] = old_record["version"] + 1
                        final_records.append(new_record)
                    else:
                        # No changes
                        final_records.append(existing_row.iloc[0].to_dict())
        except Exception as e:
            logger.error(f"Error during compare old and new subscriptions: {str(e)}")
        return final_records

    @staticmethod
    def _include_extra_fields(subscription_list):
        subs_dataframe = pd.DataFrame(subscription_list)
        subs_dataframe["start_date"] = datetime.now().strftime("%Y-%m-%d")
        subs_dataframe["end_date"] = None
        subs_dataframe["is_active"] = True
        subs_dataframe["version"] = 1
        """Convert DataFrame back to JSON array"""
        return subs_dataframe.to_dict(orient='records')

    @measure_time
    async def execute(self):
        subscriptions_data = []
        # Logic to fetch subscriptions
        try:
            subs_data_list = self.context.azure_client_service.fetch_subscriptions()
            if not subs_data_list:
                logger.warning("No subscription data found or the request failed.")
            else:
                directory_path = f"{self.config.dw_azure_home_directory}/subscription"
                existing_subs_data_list = self.context.azure_blob_manager.fetch_existing_data(directory_path=directory_path)
                if existing_subs_data_list:
                    subscriptions_data = self._scd_type_2_logic(existing_subs_data_list, subs_data_list)
                else:
                    subscriptions_data = self._include_extra_fields(subs_data_list)
        except Exception as e:
            logger.error(f"Error in fetch subscriptions: {str(e)}")

        self.context.subscriptions_list = subscriptions_data
