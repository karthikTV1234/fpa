from shared.config_loader.config_loader import AZExtractionJobConfig
from shared.jobs.az_subscription_job.az_subscription_job_context import AZSubscriptionJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="StoreSubscriptionStep")

class StoreSubscriptionStep:
    def __init__(self, config: AZExtractionJobConfig, context: AZSubscriptionJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        obj = self.context.subscriptions_list
        if len(obj) == 0:
            logger.info(f"zero subscriptions fetched, hence skipping storage")
            return
        directory_path = f"{self.config.dw_azure_home_directory}/subscription"
        logger.info("Storing subscriptions...")
        # Upload subscription data to Azure Blob Storage
        file_name = "subscription.json"
        self.context.azure_blob_manager.upload_object(
            obj=obj, directory_name=directory_path, file_path=file_name)