from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.azure_client_service import AzureClientService
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AZSubscriptionJobContext")

class AZSubscriptionJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.azure_client_service: Optional[AzureClientService] = None
        self.subscriptions_list: List[any] = []
