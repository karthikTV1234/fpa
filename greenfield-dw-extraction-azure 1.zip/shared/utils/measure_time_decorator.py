import asyncio
import functools
import time
from typing import Callable, Any

from shared.utils.logger_setup import setup_logger

logger = setup_logger("MeasureTime")

def measure_time(func: Callable) -> Callable:
    """
    A decorator that measures the execution time of both regular and async functions.

    Example:
        @measure_time
        def regular_function():
            time.sleep(1)

        @measure_time
        async def async_function():
            await asyncio.sleep(1)
    """

    @functools.wraps(func)
    async def async_wrapper(*args, **kwargs) -> Any:
        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        logger.info(
            f"{func.__name__} took {end_time - start_time:.4f} seconds to execute")
        return result

    @functools.wraps(func)
    def sync_wrapper(*args, **kwargs) -> Any:
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        logger.info(
            f"{func.__name__} took {end_time - start_time:.4f} seconds to execute")
        return result

    return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper