import unittest

from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger("TestWatermarkManagerBlob")


class TestWatermarkManagerBlob(unittest.TestCase):
    def setUp(self):
        accountName = "devstoreaccount1"
        accountKey = "Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=="
        CONNECTION_STRING = f"DefaultEndpointsProtocol=http;AccountName={accountName};AccountKey={accountKey};BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1"
        CONTAINER_NAME = "testcontainer"
        WATERMARK_BLOB_NAME = "test_watermarks_key"

        self.manager = WatermarkManagerBlob(CONNECTION_STRING, CONTAINER_NAME, WATERMARK_BLOB_NAME)

    def tearDown(self):
        # Code to clean up resources which are being used after tests
        pass

    def test_watermark(self):
        # Example data for a Terraform run
        terraform_data = [
            {"id": "resource-1", "created-at": "2024-12-07T12:00:00Z"},
            {"id": "resource-2", "created-at": "2024-12-08T12:00:00Z"},
            {"id": "resource-3", "created-at": "2024-12-09T12:00:00Z"},
        ]

        # Set an initial watermark for Terraform runs
        self.manager.update_watermark("azure_resources", "2024-12-07T12:00:00")

        # Filter Terraform runs
        filtered_resource = self.manager.filter_data(
            "azure_resources", terraform_data, "created-at")
        logger.info(f"Filtered Azure resource:{filtered_resource}")

        # Update watermark after processing
        if filtered_resource:
            latest_resource = max(run["created-at"] for run in filtered_resource)
            self.manager.update_watermark("azure_resources", latest_resource)

        logger.info(f"Updated Watermarks: {self.manager.watermarks}")


if __name__ == '__main__':
    unittest.main()
