from typing import Any

from azure.core.exceptions import AzureError, ClientAuthenticationError
from azure.identity import DefaultAzureCredential, CredentialUnavailableError, \
    EnvironmentCredential
from azure.mgmt.resource import SubscriptionClient
from azure.mgmt.resourcegraph import ResourceGraphClient

from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AzureClientService")

class AzureClientService:
    credential = None
    resource_graph_client = None
    subscription_client = None

    def __init__(self):
        self.credential = self.authenticate_with_default_credential()
        self.subscription_client = SubscriptionClient(self.credential)
        logger.info("Initializing SubscriptionClient.")
        self.resource_graph_client = ResourceGraphClient(self.credential)

    def authenticate_with_default_credential(self):
        """
        Try to authenticate first with Azure CLI credentials, and fallback to local settings credentials.
        """
        try:
            # First, attempt to authenticate with Azure CLI (DefaultAzureCredential automatically checks this)
            credential = DefaultAzureCredential()

            # Test if the Azure CLI authentication works (by making a simple request or checking availability)
            # This ensures that the DefaultAzureCredential works without needing any explicit code for fallback
            credential.get_token("https://management.azure.com/.default")
            logger.info("Authenticated successfully with Azure CLI.")
            return credential
        except ClientAuthenticationError:
            try:
                logger.info(
                    "Azure CLI authentication failed, falling back to environment credentials from local.settings.json.")
                # Now authenticate using the environment variables
                credential = EnvironmentCredential()
                credential.get_token("https://management.azure.com/.default")
                logger.info("Authenticated successfully with environment credentials from local.settings.json.")
                return credential
            except CredentialUnavailableError as e:
                logger.error(f"Error while fetching azure credential: {e}")
                raise Exception(f"Error while fetching azure credential: {e}")

    def fetch_subscriptions(self) -> list[Any]:
        subscriptions_data = []
        try:
            logger.info("Fetching subscription list.")
            response = self.subscription_client.subscriptions.list()
            subscriptions_data = [sub.as_dict() for sub in response]
            logger.info("Successfully retrieved Azure subscriptions.")
        except AzureError as e:
            logger.error(f"AzureError encountered: {str(e)}")
        except Exception as e:
            logger.error(f"An unexpected error occurred: {str(e)}")
        return subscriptions_data