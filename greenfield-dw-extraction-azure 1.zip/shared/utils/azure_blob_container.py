import io
import json
import os

from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import BlobServiceClient

from shared.utils.logger_setup import setup_logger

logger = setup_logger("AzureBlobContainerManager")

class AzureBlobContainerManager:
    def __init__(self, connection_string, container_name):
        """
        Initialize the Azure Blob Container Manager.
        :param connection_string: Connection string for Azure Blob Storage.
        :param container_name: Name of the container to manage.
        """
        self.container_name = container_name
        self.blob_service_client = BlobServiceClient.from_connection_string(
            connection_string)
        self.container_client = self._get_or_create_container(container_name)

    def _get_or_create_container(self, container_name):
        try:
            container_client = self.blob_service_client.get_container_client(
                container_name)
            if not container_client.exists():
                container_client.create_container()
                logger.info(f"Container '{container_name}' created.")
            return container_client
        except Exception as e:
            logger.error(f"Error creating or accessing container: {e}")
            raise Exception(f"Error creating or accessing container: {e}")

    def fetch_existing_data(self, directory_path):
        data = []
        try:
            blobs = self.container_client.list_blobs(name_starts_with=f"{directory_path}/")
            for blob in blobs:
                blob_client = self.container_client.get_blob_client(blob.name)
                blob_data = blob_client.download_blob().readall().decode('utf-8')
                content = json.loads(blob_data)
                data.extend(content)
        except ResourceNotFoundError:
            logger.error(f"Blob '{directory_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            (
                logger.error(f"An error occurred: {str(e)}"))
        return data

    def upload_object(self, obj: any, directory_name, file_path: str, overwrite=True):
        # Convert the array of objects to a JSON string
        json_data = json.dumps(obj, indent=4)

        # Convert the JSON string to bytes (required for uploading)
        json_data_bytes = io.BytesIO(json_data.encode('utf-8'))

        # Connect to Azure Blob Storage
        blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
            file_path)
        blob_client = self.container_client.get_blob_client(blob=blob_name)

        # Upload the file, replacing the existing blob if it exists, or creating it if it doesn't
        try:
            blob_client.upload_blob(json_data_bytes,
                                    overwrite=overwrite)  # overwrite=True will replace the file if it exists
            logger.info(
                f"Blob '{file_path}' in container has been uploaded/replaced.")
        except Exception as e:
            logger.error(f"An error occurred: {e}")

    def upload_file(self, directory_name, file_path, overwrite=True):
        """
        Upload a file to a specified directory.
        :param overwrite: whether file to be overwritten
        :param directory_name: Directory (prefix) in the container.
        :param file_path: Path of the file to upload.
        """
        blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
            file_path)
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=overwrite)
        logger.info(f"Uploaded file: {blob_name}")

    def download_file(self, blob_name, download_path):
        """
        Download a file from the container.
        :param blob_name: Full blob path (directory/file).
        :param download_path: Local path to save the downloaded file.
        """
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        with open(download_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())
        logger.info(f"Downloaded file: {blob_name} to {download_path}")

    def delete_file(self, blob_name):
        """
        Delete a specific file in the container.
        :param blob_name: Full blob path (directory/file).
        """
        blob_client = self.container_client.get_blob_client(blob=blob_name)
        blob_client.delete_blob()
        logger.info(f"Deleted file: {blob_name}")

    def create_directory(self, directory_name):
        """
        Create a directory by adding an empty blob as a placeholder.
        :param directory_name: Name of the directory (prefix).
        """
        placeholder_blob_name = f"{directory_name}/.placeholder"
        blob_client = self.container_client.get_blob_client(
            blob=placeholder_blob_name)
        blob_client.upload_blob(b"", overwrite=True)
        logger.info(f"Directory created: {directory_name}")

    def delete_directory(self, directory_name):
        """
        Delete a directory by removing all blobs with the specified prefix.
        :param directory_name: Name of the directory (prefix).
        """
        blobs = self.container_client.list_blobs(
            name_starts_with=f"{directory_name}/")
        for blob in blobs:
            self.delete_file(blob.name)
        logger.info(f"Deleted directory: {directory_name}")

    def list_files(self, directory_name=None):
        """
        List all files in the container or a specific directory.
        :param directory_name: Directory (prefix) to list files from. If None, list all files.
        """
        prefix = f"{directory_name}/" if directory_name else ""
        blobs = self.container_client.list_blobs(name_starts_with=prefix)
        logger.info(f"Files in directory '{directory_name or 'root'}':")
        return [blob.name for blob in blobs]

    def read_json_from_blob(self, directory_name, file_path):
        try:
            # Connect to Azure Blob Storage
            blob_name = f"{directory_name}/{os.path.basename(file_path)}" if directory_name else os.path.basename(
                file_path)
            blob_client = self.container_client.get_blob_client(blob=blob_name)

            # Check if blob exists
            # This raises an exception if the blob doesn't exist
            blob_client.get_blob_properties()

            # Download blob content
            blob_data = blob_client.download_blob()
            content = blob_data.readall()

            # Parse the content as JSON
            json_content = json.loads(content)
            return json_content

        except ResourceNotFoundError:
            logger.error(
                f"Blob '{file_path}' not found in container '{self.container_name}'.")
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")

    def close(self):
        """
        close the Azure Blob Service Client
        """
        self.blob_service_client.close()

