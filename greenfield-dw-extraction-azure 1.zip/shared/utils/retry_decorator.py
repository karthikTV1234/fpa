from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="retry")

def retry_with_backoff(retries=3, backoff_in_seconds=1):
    logger.info("retry_with_backoff function")