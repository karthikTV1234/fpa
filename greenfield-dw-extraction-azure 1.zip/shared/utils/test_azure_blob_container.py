import unittest

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger("TestAzureBlobContainerManager")


class TestAzureBlobContainerManager(unittest.TestCase):
    def setUp(self):
        accountName = "devstoreaccount1"
        accountKey = "Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw=="
        CONNECTION_STRING = f"DefaultEndpointsProtocol=http;AccountName={accountName};AccountKey={accountKey};BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1"
        CONTAINER_NAME = "testcontainer"

        self.manager = AzureBlobContainerManager(
            CONNECTION_STRING, CONTAINER_NAME)

    def tearDown(self):
        # Code to clean up after tests (e.g., closing database connections)
        pass

    def test_create_directories(self):
        self.manager.create_directory("subscription1")
        self.manager.create_directory("subscription2")
        self.manager.create_directory("subscription/2025/01/29")

        self.manager.create_directory("resource1")
        self.manager.create_directory("resource2")
        self.manager.create_directory("resource/2025/01/29")

    def test_upload_files(self):
        # Upload files

        with open("subscription1.txt", "w") as f:
            f.write("Content of subscription1.")
        with open("subscription2.txt", "w") as f:
            f.write("Content of subscription2.")

        with open("resource1.txt", "w") as f:
            f.write("Content of resource1.")
        with open("resource2.txt", "w") as f:
            f.write("Content of resource2.")

        self.manager.upload_file("subscription1", "subscription1.txt")
        self.manager.upload_file("subscription2", "subscription2.txt")

        self.manager.upload_file("resource1", "resource1.txt")
        self.manager.upload_file("resource2", "resource2.txt")

    def test_list_files(self):
        # List files
        logger.info(self.manager.list_files("subscription1"))
        logger.info(self.manager.list_files("subscription2"))

        logger.info(self.manager.list_files("resource1"))
        logger.info(self.manager.list_files("resource2"))


if __name__ == '__main__':
    unittest.main()
