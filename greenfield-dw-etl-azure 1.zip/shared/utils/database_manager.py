import threading
from contextlib import contextmanager
from datetime import datetime

import numpy as np
from sqlalchemy import create_engine, insert
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from shared.models.base import Base
from shared.models.subscription import DimAzSubscription, FactAzSubscription
from shared.repositores.resources_repo import DimAzSubscriptionResourcesRepo, FactAzSubscriptionResourcesRepo, \
    SummaryAzSubscriptionResourcesRepo
from shared.repositores.subscription_repo import (DimAzSubscriptionRepo,
                                                  FactAzSubscriptionRepo, SummaryAzSubscriptionRepo)
from shared.utils.logger_setup import setup_logger

logger = setup_logger("DatabaseManager")

class DatabaseManager:
    _instance = None
    _lock = threading.Lock()  # Lock for thread-safe singleton

    def __new__(cls, database_url: str):
        """
        Creates a singleton instance of the DatabaseManager class.
        Ensures that only one instance exists in a multi-threaded environment.
        """
        if cls._instance is None:  # Check if instance already exists
            with cls._lock:  # Ensure thread-safety while creating the instance
                if cls._instance is None:  # Double-check to prevent race condition
                    cls._instance = super(DatabaseManager, cls).__new__(cls)
                    cls._instance._initialize(database_url)  # Initialize only once
        return cls._instance

    def _initialize(self, database_url: str):
        """
        Initializes the DatabaseManager with the specified database URL.
        This method is called only once during the first instantiation.
        """
        try:
            self.engine = create_engine(database_url, echo=False)
            Session = sessionmaker(bind=self.engine)
            self.session = Session()
            Base.metadata.create_all(self.engine)

            # Initialize repositories
            self.dim_subscription_repo = DimAzSubscriptionRepo(self.session)
            self.fact_subscription_repo = FactAzSubscriptionRepo(self.session)
            self.summary_subscription_repo = SummaryAzSubscriptionRepo(self.session)

            self.dim_az_sub_resources_repo = DimAzSubscriptionResourcesRepo(self.session)
            self.fact_az_sub_resources_repo = FactAzSubscriptionResourcesRepo(self.session)
            self.summary_az_sub_resources_repo = SummaryAzSubscriptionResourcesRepo(self.session)

            logger.info("DatabaseManager initialized successfully.")
        except SQLAlchemyError as e:
            logger.error(f"Failed to initialize DatabaseManager: {e}")
            raise

    def upsert_to_sql(self, df, model_class, index_elements, batch_size=1000):
        """
        Performs an upsert operation on the specified model class using the provided DataFrame.
        """
        num_batches = int(np.ceil(len(df) / batch_size))
        for i in range(num_batches):
            batch = df.iloc[i * batch_size: (i + 1) * batch_size]
            data = batch.to_dict(orient="records")
            for row in data:
                stmt = insert(model_class).values(row)
                update_dict = {
                    key: stmt.excluded[key] for key in row.keys() if row[key] == row[key]
                }
                stmt = stmt.on_conflict_do_update(index_elements=index_elements, set_=update_dict)
                self.session.execute(stmt)
            self.session.commit()
            logger.info(f"Processed batch {i + 1} of {num_batches}")

    def upsert_dim_dashboards(self, df, batch_size=1000):
        """
        Upserts data into the DimAzSubscription table.
        """
        self.upsert_to_sql(df, DimAzSubscription, ["subscription_dim_rowid"], batch_size)

    def upsert_fact_dashboards(self, df, batch_size=1000):
        """
        Upserts data into the FactAzSubscription table.
        """
        self.upsert_to_sql(df, FactAzSubscription, ["subscription_fact_rowid"], batch_size)

    def load_summary_subscription(self):
        """
        Aggregates data from FactAzSubscription and loads it into SummaryAzSubscription.
        """
        try:
            current_date = datetime.now()
            records_inserted = self.summary_subscription_repo.load_summary_data(current_date)
            logger.info(f"Inserted {records_inserted} records into SummaryAzSubscription.")
        except Exception as e:
            logger.error(f"Failed to load summary dashboards: {e}")
            raise

    def close_session(self):
        """
        Closes the persistent database session.
        """
        self.session.close_all()

    @contextmanager
    def get_session(self):
        """
        Provides a transactional scope around a series of operations.
        Automatically commits or rolls back transactions as needed.
        """
        session = self.session
        try:
            yield session
            session.commit()
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Database operation failed, transaction rolled back: {e}")
            raise
        finally:
            session.close()