#from shared.jobs.az_resource_etl_job.az_resource_etl_job import AzResourcesETLJob
from shared.jobs.az_resource_etl_job.az_resource_etl_job import AzResourcesETLJob
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job import AzSubscriptionETLJob
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AzSubscriptionWorkflow")


class AzSubscriptionWorkflow:
    jobs: dict = {}

    def __init__(self, **kwargs):
        self.jobs['etl_subscription'] = AzSubscriptionETLJob()
        self.jobs['etl_subscription'].initialize()

        self.jobs['etl_resource'] = AzResourcesETLJob()
        self.jobs['etl_resource'].initialize()

    async def execute_job(self, job_name: str) -> bool:
        if not self.jobs.get(job_name):
            logger.critical(
                f"error in job execution, job={job_name} is not registered")
            return False
        else:
            logger.info(f"{job_name} is about to execute")
            job = self.jobs[job_name]
            await job.trigger_event('start')
            return True