import statesman

from shared.config_loader.config_loader import ConfigLoader, AzETLJobConfig
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job_context import AZSubscriptionETLJobContext
from shared.jobs.az_subscription_etl_job.steps.archive_step import ArchiveStep
from shared.jobs.az_subscription_etl_job.steps.extract_from_blob_step import ExtractFromBlobStep
from shared.jobs.az_subscription_etl_job.steps.load_step import LoadStep
from shared.jobs.az_subscription_etl_job.steps.teardown_step import TeardownStep
from shared.jobs.az_subscription_etl_job.steps.transform_step import TransformStep
from shared.repositores.date_repo import DateRepo
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AzSubscriptionETLJob")


class AzSubscriptionETLJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: AzETLJobConfig = None
    _context: AZSubscriptionETLJobContext = None

    _extract_step: ExtractFromBlobStep = None
    _transform_step: TransformStep = None
    _load_step: LoadStep = None
    _archive_step: ArchiveStep = None
    _teardown_step: TeardownStep = None

    class States(statesman.StateEnum):
        start = "start"
        extract = "extract"
        transform = "transform"
        load = "load"
        archive = "archive"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        try:
            # Load configuration
            self._config_loader = ConfigLoader()
            self._job_config = self._config_loader.az_etl_job_config
            self._context = AZSubscriptionETLJobContext()

            # Validate configuration
            if not self._job_config.azure_connection_str:
                raise ValueError("Azure connection string is missing in the configuration.")
            if not self._job_config.dw_container_name:
                raise ValueError("Azure container name is missing in the configuration.")
            if not self._job_config.dw_sql_db_connection_string:
                raise ValueError("SQL database connection string is missing in the configuration.")

            self._context.azure_blob_manager = AzureBlobContainerManager(
                connection_string=self._job_config.azure_connection_str,
                container_name=self._job_config.dw_container_name)

            self._context.database_manager = DatabaseManager(
                database_url=self._job_config.dw_sql_db_connection_string
            )

            if not self._context.database_manager.session:
                raise ValueError("DatabaseManager session is not initialized. Check the database URL or connectivity.")

            # Initialize Steps
            self._extract_step = ExtractFromBlobStep(config=self._job_config, context=self._context)
            self._transform_step = TransformStep(config=self._job_config, context=self._context)
            self._load_step = LoadStep(config=self._job_config, context=self._context)
            self._archive_step = ArchiveStep(config=self._job_config, context=self._context)
            self._teardown_step = TeardownStep(config=self._config_loader, context=self._context)

        except Exception as e:
            logger.error(f"Initialization failed: {e}")


    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("extract")

    @statesman.event(States.start, States.extract)
    async def extract(self) -> None:
        try:
            logger.info(f"{self.__class__.__name__} is extracting data")

            logger.info(f"<<<< ExtractFromBlobStep: {self._extract_step}")

            await self._extract_step.execute()
            await self.trigger_event("transform")
        except Exception as e:
            logger.error(f"Extract step failed: {e}")
            raise

    @statesman.event(States.extract, States.transform)
    async def transform(self) -> None:
        try:
            logger.info(f"{self.__class__.__name__} is transforming data")
            await self._transform_step.execute()
            await self.trigger_event("load")
        except Exception as e:
            logger.error(f"Transform step failed: {e}")
            raise

    @statesman.event(States.transform, States.load)
    async def load(self) -> None:
        try:
            logger.info(f"{self.__class__.__name__} is loading data")
            await self._load_step.execute()
            await self.trigger_event("archive")
        except Exception as e:
            logger.error(f"Load step failed: {e}")
            raise

    @statesman.event(States.load, States.archive)
    async def archive(self) -> None:
        try:
            logger.info(f"{self.__class__.__name__} is archiving folder and subscription")
            await self._archive_step.execute()
            await self.trigger_event("teardown")
        except Exception as e:
            logger.error(f"Archive step failed: {e}")
            raise

    @statesman.event(States.archive, States.teardown)
    async def teardown(self) -> None:
        try:
            logger.info(f"{self.__class__.__name__} is tearing down")
            await self._teardown_step.execute()
            await self.trigger_event("end")
        except Exception as e:
            logger.error(f"Teardown step failed: {e}")
            raise

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")

