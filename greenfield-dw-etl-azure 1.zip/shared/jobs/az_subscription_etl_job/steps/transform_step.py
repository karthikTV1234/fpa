from datetime import datetime

from shared.config_loader.config_loader import AzETLJobConfig
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job_context import AZSubscriptionETLJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformStep")

class TransformStep:
    def __init__(self, config: AzETLJobConfig, context: AZSubscriptionETLJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            if self.context.extracted_data_frame is not None:
                # Log the structure of the extracted DataFrame
                # Select and rename relevant fields from the extracted data frame
                transformed_subscription = self.context.extracted_data_frame[
                    ["subscription_id", "tenant_id", "display_name", "authorization_source", "tags"]
                ].rename(
                    columns={
                        "subscription_id": "subscriptionId",
                        "tenant_id": "tenantId",
                        "display_name": "subscriptionName",
                        "authorization_source": "authorizationSource",
                        "tags": "tags"

                    }
                )
                # Assign today's date for `start_date`
                transformed_subscription["create_date"] = datetime.today().date()
                transformed_subscription["start_date"] = datetime.today().date()

                # Store the transformed data frame in the context for loading
                self.context.transformed_data_frame = transformed_subscription
                logger.info("Transformation step completed successfully.")
            else:
                logger.warn("Data frame is not extracted, hence skipping the transformation.")
        except Exception as e:
            logger.error(f"Error in transforming dashboard data: {e}")