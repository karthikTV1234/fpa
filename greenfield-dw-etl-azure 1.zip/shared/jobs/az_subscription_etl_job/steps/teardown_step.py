from shared.config_loader.config_loader import ConfigLoader
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job_context import AZSubscriptionETLJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TeardownStep")

class TeardownStep:
    def __init__(self,config: ConfigLoader, context: AZSubscriptionETLJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        self.context.database_manager.close_session()
        self.context.azure_blob_manager.close()