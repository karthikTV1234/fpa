import traceback
from datetime import datetime, timedelta
from typing import Any

import pandas as pd

from shared.config_loader.config_loader import AzETLJobConfig
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job_context import AZSubscriptionETLJobContext
from shared.models.dimdate import DimDate
from shared.models.subscription import DimAzTenant, DimAzSubscription, FactAzSubscription, SummaryAzSubscription, \
    DimAzSubscriptionTags
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadStep")

class LoadStep:
    def __init__(self,config: AzETLJobConfig, context: AZSubscriptionETLJobContext):
        self.config = config
        self.context = context

    def build_new_dim_az_tenant(self, row, start_date, create_date):
        return DimAzTenant(
            tenant_id=row["tenantId"],
            tenant_name=row["subscriptionName"],
            start_date=start_date,
            end_date=None,
            create_date=create_date,
            isactive=1
        )

    def build_new_dim_az_subscription(self, row, dim_tenant_record, start_date, create_date):
        return DimAzSubscription(
            subscription_id=row["subscriptionId"],
            #tenant_dim_rowid=dim_tenant_record.tenant_dim_rowid,
            subscription_name=row["subscriptionName"],
            start_date=start_date,
            end_date=None,
            create_date=create_date,
            isactive=1,
        )

    def build_new_fact_az_subscription(self, subscription_dim_rowid, tenant_dim_rowid, start_date, create_date):
        return FactAzSubscription(
            subscription_dim_rowid=subscription_dim_rowid,
            tenant_dim_rowid=tenant_dim_rowid,
            start_dateref=start_date,
            end_dateref=None,
            create_date=create_date,
            isactive=1,
        )

    async def execute(self):
        try:
            # Validate transformed data frame
            if self.context.transformed_data_frame is None:
                logger.error("No transformed data to load.")
                return

            fact_bulk_records = []
            self.dim_tenant_record:Any
            current_date = datetime.now().date()
            logger.info(f"DB Session Check: {self.context.database_manager.session}")
            if not self.context.database_manager.session:
                logger.error("Database session is None. Ensure session is initialized correctly.")
                return

            for index, row in self.context.transformed_data_frame.iterrows():
                try:
                    # Convert dates
                    start_date = pd.to_datetime(row.get("start_date"), errors="coerce").date() if row.get(
                        "start_date") else None
                    end_date = pd.to_datetime(row.get("end_date"), errors="coerce").date() if row.get(
                        "end_date") else None
                    create_date = pd.to_datetime(row.get("create_date"), errors="coerce")  # Keep as datetime

                    # Process tenant table
                    self.dim_tenant_record = (
                        self.context.database_manager.session.query(DimAzTenant)
                        .filter_by(tenant_id=row["tenantId"], isactive=1)
                        .one_or_none()
                    )

                    if not self.dim_tenant_record:
                        logger.debug(f"No matching dim_tenant found for tenant_id: {row['tenantId']}. Inserting new record.")
                        new_dim_az_tenant_record = self.build_new_dim_az_tenant(row, start_date, create_date)
                        self.context.database_manager.session.add(new_dim_az_tenant_record)
                        self.context.database_manager.session.commit()
                        self.dim_tenant_record = new_dim_az_tenant_record
                    else:
                        logger.info(f"Found existing dim_az_tenant for subscription: {row['subscriptionId']}.")
                        # Check if tenant name is changed then do soft delete by setting 'isactive' 0
                        if self.dim_tenant_record.tenant_name != row["subscriptionName"]:
                            self.dim_tenant_record.tenant_name = row["subscriptionName"]
                            self.dim_tenant_record.end_date = current_date
                            self.dim_tenant_record.isactive = 0
                            self.context.database_manager.session.add(self.dim_tenant_record)
                            self.context.database_manager.session.commit()

                            # insert new record after soft delete
                            new_dim_az_tenant_record = self.build_new_dim_az_tenant(row, start_date, create_date)
                            self.context.database_manager.session.add(new_dim_az_tenant_record)
                            self.context.database_manager.session.commit()
                            self.dim_tenant_record = new_dim_az_tenant_record

                    #Process dimension Az table
                    dim_az_subscription_record = (
                        self.context.database_manager.session.query(DimAzSubscription)
                        .filter_by(subscription_id=row["subscriptionId"], isactive=1)
                        .one_or_none()
                    )

                    if not dim_az_subscription_record:
                        logger.debug(
                            f"No matching dim_entry found for subscriptionId: {row['subscriptionId']}. Inserting new record.")
                        new_dim_az_entry = self.build_new_dim_az_subscription(row, self.dim_tenant_record, start_date, create_date)
                        self.context.database_manager.session.add(new_dim_az_entry)
                        self.context.database_manager.session.commit()
                        dim_az_subscription_record = new_dim_az_entry
                    else:
                        logger.info(f"Found existing dim_entry for subscriptionId: {row['subscriptionId']}.")
                        # Check if subscription Name is changed then do soft delete by setting 'isactive' 0
                        if dim_az_subscription_record.subscription_name != row["subscriptionName"]:
                            dim_az_subscription_record.subscription_name = row["subscriptionName"]
                            dim_az_subscription_record.end_date = current_date
                            dim_az_subscription_record.isactive = 0
                            self.context.database_manager.session.add(dim_az_subscription_record)
                            self.context.database_manager.session.commit()

                            # insert new record after soft delete
                            new_dim_az_entry = self.build_new_dim_az_subscription(row, self.dim_tenant_record, start_date,
                                                                                  create_date)
                            self.context.database_manager.session.add(new_dim_az_entry)
                            self.context.database_manager.session.commit()
                            dim_az_subscription_record = new_dim_az_entry

                    # Process tags
                    # Insert or update records in the tags table
                    line_no = 1
                    tags = row['tags']
                    if tags:
                        bulk_tags_record = []
                        for key, value in tags.items():
                            # Check if the record exists for the given field_name
                            existing_record = (
                                self.context.database_manager.session.query(DimAzSubscriptionTags)
                                .filter_by(subscription_dim_rowid=dim_az_subscription_record.subscription_dim_rowid, field_name=key, isactive=1)
                                .first()
                            )

                            if existing_record:
                                # If the value has changed, perform a soft delete
                                if existing_record.field_value != value:
                                    existing_record.isactive = 0
                                    existing_record.end_date = datetime.now().date()  # Set end_date to today's date
                                    bulk_tags_record.append(existing_record)
                                    #self.context.database_manager.session.add(existing_record)

                            # Insert the new record
                            new_record = DimAzSubscriptionTags(
                                subscription_dim_rowid=dim_az_subscription_record.subscription_dim_rowid,
                                line_no=line_no,
                                field_name=key,
                                field_value=value,
                                start_date=datetime.now().date(),  # Set start_date as today's date
                                end_date=None,  # New record, end_date is NULL
                                create_date=datetime.now(),  # Set create_date as current datetime
                                update_date=datetime.now(),  # Set create_date as current datetime
                                isactive=1  # Active recordpppppp
                            )
                            bulk_tags_record.append(new_record)
                            #self.context.database_manager.session.add(new_record)
                            line_no += 1
                        if bulk_tags_record:
                            self.context.database_manager.session.bulk_save_objects(bulk_tags_record)
                            self.context.database_manager.session.commit()


                    # Process fact table
                    fact_az_subscription_record = (
                        self.context.database_manager.session.query(FactAzSubscription)
                        .filter_by(subscription_dim_rowid=dim_az_subscription_record.subscription_dim_rowid, isactive=1)
                        .one_or_none()
                    )

                    if fact_az_subscription_record:
                        # Soft delete existing record
                        fact_az_subscription_record.isactive = 0
                        fact_az_subscription_record.end_dateref = current_date
                        self.context.database_manager.session.add(fact_az_subscription_record)
                        self.context.database_manager.session.commit()

                        # Insert updated record
                        new_fact_az_subscription = self.build_new_fact_az_subscription(dim_az_subscription_record.subscription_dim_rowid, self.dim_tenant_record.tenant_dim_rowid,start_date, create_date)
                        fact_bulk_records.append(new_fact_az_subscription)
                    else:
                        # Insert updated record
                        new_fact_az_subscription = self.build_new_fact_az_subscription(
                            dim_az_subscription_record.subscription_dim_rowid, self.dim_tenant_record.tenant_dim_rowid, start_date, create_date)
                        fact_bulk_records.append(new_fact_az_subscription)
                except Exception as row_error:
                    logger.error(
                        f"Error processing row {index} (subscriptionId={row.get('subscriptionId', 'Unknown')}): {row_error}")
                    logger.error(traceback.format_exc())

            # Bulk insert into the fact Az Subscription table
            if fact_bulk_records:
                try:
                    self.context.database_manager.session.bulk_save_objects(fact_bulk_records)
                    self.context.database_manager.session.commit()
                    logger.info(f"Inserted {len(fact_bulk_records)} records into fact_az_subscription.")
                except Exception as bulk_error:
                    logger.error(f"Error during bulk insert: {bulk_error}")
                    logger.error(traceback.format_exc())

            # Populate the summary table
            self.populate_summary_az_subscription_table(self.dim_tenant_record.tenant_dim_rowid)

        except Exception as e:
            logger.error(f"General error in LoadStep: {e}")
            logger.error(traceback.format_exc())

    def populate_dim_date(self, start_date, end_date):
        """Populate dim_date table with a date range."""
        logger.info("Checking existing records in dim_date table...")
        existing_dates = self.context.database_manager.session.query(DimDate).count()
        if existing_dates > 0:
            logger.info(f"dim_date already has {existing_dates} records. Skipping population.")
            return

        logger.info(f"Populating dim_date from {start_date} to {end_date}...")
        current_date = start_date
        while current_date <= end_date:
            dateref = int(current_date.strftime("%Y%m%d"))  # e.g., 20250101
            full_date = current_date.strftime("%Y-%m-%d")
            year = current_date.year
            quarter = (current_date.month - 1) // 3 + 1
            month = current_date.month
            day = current_date.day
            day_of_week = current_date.strftime("%A")
            is_weekend = day_of_week in ["Saturday", "Sunday"]

            date_record = DimDate(
                dateref=dateref,
                full_date=full_date,
                year=year,
                quarter=quarter,
                month=month,
                day=day,
                day_of_week=day_of_week,
                is_weekend=is_weekend,
            )
            self.context.database_manager.session.add(date_record)
            current_date += timedelta(days=1)

        self.context.database_manager.session.commit()
        logger.info("dim_date table populated successfully.")

    def populate_summary_az_subscription_table(self, tenant_dim_rowid):
        """Populate summary table with the count of active subscriptions."""
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            active_count = (
                self.context.database_manager.session.query(FactAzSubscription)
                .filter(FactAzSubscription.isactive == 1, FactAzSubscription.end_dateref.is_(None))
                .count()
            )

            summary_az_entry = SummaryAzSubscription(
                tenant_dim_rowid=tenant_dim_rowid,
                report_dateref=dateref,
                subscription_count=active_count,
                create_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_az_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active subscription count: {active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())