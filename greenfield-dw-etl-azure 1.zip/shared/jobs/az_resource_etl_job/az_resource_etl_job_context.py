from typing import Optional

import pandas as pd

from shared.repositores.date_repo import DateRepo
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="AZResourceETLJobContext")

class AZResourceETLJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.database_manager: Optional[DatabaseManager] = None
        self.date_repo: Optional[DateRepo] = None
        self.extracted_data_frame: Optional[pd.DataFrame] = None
        self.transformed_data_frame: Optional[pd.DataFrame] = None