from datetime import datetime
from pathlib import Path

from shared.config_loader.config_loader import AzETLJobConfig
from shared.jobs.az_subscription_etl_job.az_subscription_etl_job_context import AZSubscriptionETLJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ArchiveStep")

@measure_time
class ArchiveResourceStep:
    def __init__(self, config: AzETLJobConfig, context: AZSubscriptionETLJobContext):
        self.config = config
        self.context = context

    async def execute(self):
        """Move files from source_dir to archive_base_dir/yyyy/mm/dd/."""
        try:
            source_dir = f"{self.config.dw_azure_home_directory}/resources"
            archive_base_dir = "archived_data/resource"
            files = self.context.azure_blob_manager.list_files(directory_name=source_dir)
            if not files:
                logger.info(f"No files found in {source_dir} to archive.")
                return
            current_date = datetime.now()
            # Construct Azure Blob Storage-compatible archive path
            archive_dir = "/".join([
                archive_base_dir,
                current_date.strftime("%Y"),
                current_date.strftime("%m"),
                current_date.strftime("%d"),
            ])

            for file in files:
                sanitized_file = Path(file).name
                logger.info(f" sanitised file {sanitized_file}")
                source_path = f"{source_dir}/{sanitized_file}"
                destination_path = f"{archive_dir}/{sanitized_file}"
                # Validate paths
                if not source_path or not destination_path:
                    raise ValueError(f"Invalid path: {source_path}, {destination_path}")
                if len(source_path) > 1024 or len(destination_path) > 1024:
                    raise ValueError(f"Path exceeds maximum length: {source_path}, {destination_path}")
                self.context.azure_blob_manager.move_blob(
                    source_directory=source_dir,
                    source_path=source_path,
                    destination_directory=archive_dir,
                    destination_path=destination_path,
                )
                logger.info(f"Archived file {sanitized_file} to {destination_path}")

            logger.info(f"Deleted source blob")
            # Delete all blobs in the folder
            self.context.azure_blob_manager.delete_directory(source_dir)

        except Exception as e:
            logger.error(f"Error during file archival: {e}", exc_info=True)