from datetime import datetime

from shared.config_loader.config_loader import AzETLJobConfig
from shared.jobs.az_resource_etl_job.az_resource_etl_job_context import AZResourceETLJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="TransformResourceStep")

class TransformResourceStep:
    def __init__(self, config: AzETLJobConfig, context: AZResourceETLJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        try:
            if self.context.extracted_data_frame is not None and len(self.context.extracted_data_frame)>0:
                # Log the structure of the extracted DataFrame
                logger.info(f"Extracted DataFrame columns: {self.context.extracted_data_frame.columns}")
                logger.info(f"First few rows of extracted data:\n{self.context.extracted_data_frame.head()}")

                # Select and rename relevant fields from the extracted data frame
                transformed_resources = self.context.extracted_data_frame[
                    ["id", "name", "type", "kind", "subscriptionId", "tags"]
                ].rename(
                    columns={
                        "id": "resource_id",
                        "name": "resource_name",
                        "type": "resource_type",
                        "kind": "resource_kind",
                        "subscriptionId": "subscription_id",
                        "tags": "tags"
                    }
                )

                # Ensure that the column is converted to datetime without timezone information
                # Assign today's date for `start_date`
                transformed_resources["create_date"] = datetime.today().date()
                transformed_resources["start_date"] = datetime.today().date()

                # Store the transformed data frame in the context for loading
                self.context.transformed_data_frame = transformed_resources
                logger.info("Transformation step completed successfully.")
                logger.info(f"Transformation step data: {self.context.transformed_data_frame}.")
            else:
                logger.warn("Data frame is not extracted, hence skipping the transformation.")
        except Exception as e:
            logger.error(f"Error in transforming resources data: {e}")