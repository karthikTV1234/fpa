from shared.config_loader.config_loader import AzETLJobConfig
from shared.jobs.az_resource_etl_job.az_resource_etl_job_context import AZResourceETLJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="ExtractFromBlobStep")


class ExtractFromBlobResourceStep:
    def __init__(self, config: AzETLJobConfig, context: AZResourceETLJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        directory_path = f"{self.config.dw_azure_home_directory}/resource"
        try:
            data = self.context.azure_blob_manager.extract_data(
                directory_path=directory_path
            )
            self.context.extracted_data_frame = data
        except Exception as e:
            logger.error(f"Error in extracting workspace: {e}")