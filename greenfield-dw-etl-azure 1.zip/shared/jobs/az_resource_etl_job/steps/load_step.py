import traceback
from datetime import datetime
from typing import Any

import pandas as pd

from shared.config_loader.config_loader import ConfigLoader
from shared.jobs.az_resource_etl_job.az_resource_etl_job_context import AZResourceETLJobContext
from shared.models.resources import DimAzSubscriptionResources, FactAzSubscriptionResources, \
    SummaryAzSubscriptionResources, DimAzSubscriptionResourcesTags
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="LoadResourceStep")

class LoadResourceStep:
    def __init__(self,config: ConfigLoader, context: AZResourceETLJobContext):
        self.config = config
        self.context = context

    def build_new_dim_az_sub_resources(self, row, sub_dim_rowid, start_date, create_date):
        return DimAzSubscriptionResources(
            resource_id=row["resource_id"],
            subscription_dim_rowid=sub_dim_rowid,
            resource_name=row["resource_name"],
            resource_kind=row["resource_type"],
            resource_type=row["resource_type"],
            start_date=start_date,
            end_date=None,
            create_date=create_date,
            isactive=1
        )

    def build_new_fact_az_sub_resources(self, subscription_dim_rowid, start_date, create_date):
        return FactAzSubscriptionResources(
            sub_resources_dim_rowid=subscription_dim_rowid,
            start_dateref=start_date,
            end_dateref=None,
            create_date=create_date,
            isactive=1,
        )

    async def execute(self):
        try:
            # Validate transformed data frame
            if self.context.transformed_data_frame is None:
                logger.error("No transformed data to load.")
                return

            fact_bulk_records = []
            self.dim_az_subs_resources_record:Any
            self.sub_dim_rowid:Any
            current_date = datetime.now().date()
            logger.info(f"DB Session Check: {self.context.database_manager.session}")

            if not self.context.database_manager.session:
                logger.error("Database session is None. Ensure session is initialized correctly.")
                return
            self.context.transformed_data_frame = self.context.transformed_data_frame.head(5000)
            for index, row in self.context.transformed_data_frame.iterrows():
                try:
                    # Convert dates
                    start_date = pd.to_datetime(row.get("start_date"), errors="coerce").date() if row.get(
                        "start_date") else None
                    end_date = pd.to_datetime(row.get("end_date"), errors="coerce").date() if row.get(
                        "end_date") else None
                    create_date = pd.to_datetime(row.get("create_date"), errors="coerce")  # Keep as datetime

                    #Process dimension Az table
                    self.dim_az_subs_resources_record = (
                        self.context.database_manager.session.query(DimAzSubscriptionResources)
                        .filter_by(resource_id=row["resource_id"], isactive=1)
                        .one_or_none()
                    )

                    # Find subscription row id
                    existing_sub_record = self.context.database_manager.dim_subscription_repo.get_by_subscription_id(
                        row["subscription_id"])
                    if existing_sub_record:
                        self.sub_dim_rowid = existing_sub_record.subscription_dim_rowid

                    if not self.dim_az_subs_resources_record:
                        logger.debug(
                            f"No matching dim_entry found for resourceId: {row['resource_id']}. Inserting new record.")

                        new_dim_az_entry = self.build_new_dim_az_sub_resources(row, self.sub_dim_rowid, start_date, create_date)
                        self.context.database_manager.session.add(new_dim_az_entry)
                        self.context.database_manager.session.commit()
                        self.dim_az_subs_resources_record = new_dim_az_entry
                    else:
                        logger.info(f"Found existing dim_entry for resource_id: {row['resource_id']}.")
                        # Check if subscription Name is changed then do soft delete by setting 'isactive' 0
                        if self.dim_az_subs_resources_record.resource_name != row["resource_name"]:
                            self.dim_az_subs_resources_record.resource_name = row["resource_name"]
                            self.dim_az_subs_resources_record.end_date = current_date
                            self.dim_az_subs_resources_record.isactive = 0
                            self.context.database_manager.session.add(self.dim_az_subs_resources_record)
                            self.context.database_manager.session.commit()

                            # insert new record after soft delete
                            new_dim_az_entry = self.build_new_dim_az_sub_resources(row, self.sub_dim_rowid, start_date, create_date)
                            self.context.database_manager.session.add(new_dim_az_entry)
                            self.context.database_manager.session.commit()
                            self.dim_az_subs_resources_record = new_dim_az_entry

                    # Process tags
                    # Insert or update records in the tags table
                    line_no = 1
                    tags = row['tags']
                    if tags:
                        bulk_tags_record = []
                        for key, value in tags.items():
                            # Check if the record exists for the given field_name
                            existing_record = (
                                self.context.database_manager.session.query(DimAzSubscriptionResourcesTags)
                                .filter_by(
                                    sub_resources_dim_rowid=self.dim_az_subs_resources_record.sub_resources_dim_rowid,
                                    field_name=key, isactive=1)
                                .first()
                            )

                            if existing_record:
                                # If the value has changed, perform a soft delete
                                if existing_record.field_value != value:
                                    existing_record.isactive = 0
                                    existing_record.end_date = datetime.now().date()  # Set end_date to today's date
                                    bulk_tags_record.append(existing_record)
                                    # self.context.database_manager.session.add(existing_record)

                            # Insert the new record
                            new_record = DimAzSubscriptionResourcesTags(
                                sub_resources_dim_rowid=self.dim_az_subs_resources_record.sub_resources_dim_rowid,
                                line_no=line_no,
                                field_name=key,
                                field_value=value,
                                start_date=datetime.now().date(),  # Set start_date as today's date
                                end_date=None,  # New record, end_date is NULL
                                create_date=datetime.now(),  # Set create_date as current datetime
                                update_date=datetime.now(),  # Set create_date as current datetime
                                isactive=1  # Active record
                            )
                            bulk_tags_record.append(new_record)
                            # self.context.database_manager.session.add(new_record)
                            line_no += 1
                        if bulk_tags_record:
                            self.context.database_manager.session.bulk_save_objects(bulk_tags_record)
                            self.context.database_manager.session.commit()

                    # Process fact table
                    fact_az_subscription_resources_record = (
                        self.context.database_manager.session.query(FactAzSubscriptionResources)
                        .filter_by(sub_resources_dim_rowid=self.dim_az_subs_resources_record.sub_resources_dim_rowid, isactive=1)
                        .one_or_none()
                    )

                    if fact_az_subscription_resources_record:
                        # Soft delete existing record
                        fact_az_subscription_resources_record.isactive = 0
                        fact_az_subscription_resources_record.end_dateref = current_date
                        self.context.database_manager.session.add(fact_az_subscription_resources_record)
                        self.context.database_manager.session.commit()

                        # Insert updated record
                        new_fact_az_subscription = self.build_new_fact_az_sub_resources(self.dim_az_subs_resources_record.sub_resources_dim_rowid, start_date, create_date)
                        fact_bulk_records.append(new_fact_az_subscription)
                    else:
                        # Insert updated record
                        new_fact_az_subscription = self.build_new_fact_az_sub_resources(
                            self.dim_az_subs_resources_record.sub_resources_dim_rowid, start_date, create_date)
                        fact_bulk_records.append(new_fact_az_subscription)
                except Exception as row_error:
                    logger.error(
                        f"Error processing row {index} (resource_id={row.get('resource_id', 'Unknown')}): {row_error}")
                    logger.error(traceback.format_exc())

            # Bulk insert into the fact Az Subscription table
            if fact_bulk_records:
                try:
                    self.context.database_manager.session.bulk_save_objects(fact_bulk_records)
                    self.context.database_manager.session.commit()
                    logger.info(f"Inserted {len(fact_bulk_records)} records into fact_az_subscription_resources.")
                except Exception as bulk_error:
                    logger.error(f"Error during bulk insert: {bulk_error}")
                    logger.error(traceback.format_exc())

            # Populate the summary table
            self.populate_summary_az_sub_resources_table(self.sub_dim_rowid)

        except Exception as e:
            logger.error(f"General error in LoadStep: {e}")
            logger.error(traceback.format_exc())

    def populate_summary_az_sub_resources_table(self, sub_dim_rowid):
        """Populate summary table with the count of active subscriptions."""
        try:
            logger.info("Populating summary table...")
            today_date = datetime.now().date()
            dateref = int(today_date.strftime("%Y%m%d"))  # Generate `dateref` for today

            active_count = (
                self.context.database_manager.session.query(FactAzSubscriptionResources)
                .filter(FactAzSubscriptionResources.isactive == 1, FactAzSubscriptionResources.end_dateref.is_(None))
                .count()
            )

            summary_az_entry = SummaryAzSubscriptionResources(
                subscription_dim_rowid=sub_dim_rowid,
                resource_count=active_count,
                report_dateref=dateref,
                create_date=datetime.now(),
            )
            self.context.database_manager.session.add(summary_az_entry)
            self.context.database_manager.session.commit()
            logger.info(f"Summary table updated with active subscription count: {active_count}")
        except Exception as summary_error:
            logger.error(f"Error populating summary table: {summary_error}")
            logger.error(traceback.format_exc())