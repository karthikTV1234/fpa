import os

from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="ConstantConfig")

class ConstantConfig:
    def __init__(self):
        self.az_subscription_watermark_key = 'subscription_last_execution'


class EnvironmentConfig:
    """To load the configuration from the environment variables"""
    def __init__(self):
        self.azure_blob_account_name = os.getenv('AZURE_BLOB_ACCOUNT_NAME')
        self.azure_blob_account_key = os.getenv('AZURE_BLOB_ACCOUNT_KEY')
        self.azure_blob_endpoint = os.getenv('AZURE_BLOB_ENDPOINT')
        self.dw_container_name = os.getenv('DW_CONTAINER_NAME')
        self.dw_azure_home_directory = os.getenv('DW_AZURE_HOME_DIRECTORY')
        self.dw_sql_db_connection_string = os.getenv('DW_SQL_DB_CONNECTION_STRING')

class AzETLJobConfig:
    def __init__(self, azure_blob_account_name: str, azure_blob_account_key: str, azure_blob_endpoint: str, dw_container_name: str, dw_azure_home_directory: str, dw_sql_db_connection_string:str):
        self.azure_blob_account_name = azure_blob_account_name
        self.azure_blob_account_key = azure_blob_account_key
        self.azure_blob_endpoint = azure_blob_endpoint
        self.dw_container_name = dw_container_name
        self.dw_azure_home_directory = dw_azure_home_directory
        self.dw_sql_db_connection_string = dw_sql_db_connection_string
        self.azure_connection_str = f"DefaultEndpointsProtocol=http;AccountName={self.azure_blob_account_name};AccountKey={self.azure_blob_account_key};BlobEndpoint={self.azure_blob_endpoint}"


class ConfigLoader:
    def __init__(self):
        self.env_config = EnvironmentConfig()
        self.constant = ConstantConfig()
        self.az_etl_job_config = AzETLJobConfig(
            azure_blob_account_name=self.env_config.azure_blob_account_name,
            azure_blob_account_key=self.env_config.azure_blob_account_key,
            azure_blob_endpoint=self.env_config.azure_blob_endpoint,
            dw_container_name=self.env_config.dw_container_name,
            dw_azure_home_directory=self.env_config.dw_azure_home_directory,
            dw_sql_db_connection_string=self.env_config.dw_sql_db_connection_string
        )

    def __str__(self):
        return f"ConfigLoader"

    def __get_pydantic_core_schema__(self, handler):
        # Custom schema generation logic here
        return handler.generate_schema(ConfigLoader)