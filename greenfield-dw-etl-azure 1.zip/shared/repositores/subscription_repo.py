from datetime import datetime

from requests import Session
from sqlalchemy import insert

from shared.models.subscription import DimAzSubscription, FactAzSubscription, SummaryAzSubscription
from shared.repositores.base_repo import BaseRepo


class DimAzSubscriptionRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimAzSubscription)

    def get_by_subscription_name(self, subscription_name):
        """Get subscription by name"""
        return self.session.query(DimAzSubscription).filter_by(subscription_name=subscription_name).first()

    def get_by_subscription_id(self, subscription_id):
        """Get subscription by name"""
        return self.session.query(DimAzSubscription).filter_by(subscription_id=subscription_id, isactive=1).first()

    def update_subscription(self, subscription_dim_rowid, **kwargs):
        """Update a dashboard record in dim_az_subscription"""
        filter_criteria = DimAzSubscription.subscription_dim_rowid == subscription_dim_rowid
        return super().update(filter_criteria, kwargs)


class FactAzSubscriptionRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactAzSubscription)

    def get_by_subscription_name(self, subscription_name):
        """Get fact record by dashboard name"""
        result = (
            self.session.query(FactAzSubscription)
            .join(DimAzSubscription, FactAzSubscription.subscription_dim_rowid == DimAzSubscription.subscription_dim_rowid)
            .filter(DimAzSubscription.subscription_name == subscription_name)
            .all()
        )
        return result

    def update_fact_subscription(self, subscription_fact_rowid, **kwargs):
        """Update a fact dashboard record"""
        filter_criteria = FactAzSubscription.subscription_fact_rowid == subscription_fact_rowid
        return super().update(filter_criteria, kwargs)

    def add_fact_subscription(self, subscription_dim_rowid, subscription_name, **kwargs):
        """Add a new fact dashboard record"""
        fact_subscription = FactAzSubscription(
            subscription_dim_rowid=subscription_dim_rowid,
            subscription_name=subscription_name,
            **kwargs,
        )
        self.session.add(fact_subscription)
        self.session.commit()
        return fact_subscription


class SummaryAzSubscriptionRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, SummaryAzSubscription)

    def upsert_summary_subscription(self, report_dateref, subscription_count, create_date=None):
        """Upsert a summary dashboard record."""
        stmt = insert(SummaryAzSubscription).values(
            report_dateref=report_dateref,
            subscription_count=subscription_count,
            create_date=create_date or datetime.now()
        ).on_conflict_do_update(
            index_elements=['report_dateref'],  # Key for conflict resolution
            set_={
                'subscription_count': insert(SummaryAzSubscription).excluded.subscription_count,
                'create_date': insert(SummaryAzSubscription).excluded.create_date
            }
        )
        self.session.execute(stmt)
        self.session.commit()


    # ETL Logic for Loading Summary Table
    def load_summary_data(session, fact_data):
        summary_repo = SummaryAzSubscriptionRepo(session)
        for record in fact_data:
            # Calculate report_dateref
            report_dateref = record['report_dateref']
            subscription_count = record['subscription_count']
            summary_repo.upsert_summary_subscription(
                report_dateref=report_dateref,
                subscription_count=subscription_count
            )