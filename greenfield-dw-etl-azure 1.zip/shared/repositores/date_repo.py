import pytz
from sqlalchemy.orm import Session

from shared.models.dimdate import DimDate
from shared.repositores.base_repo import BaseRepo
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="DateRepo")


class DateRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimDate)

    def get_or_create_date(self, date):
        """
        Check if a date record exists, and if not, create it.
        :param date: A `datetime` object.
        :return: UUID of the `Date` record.
        """

        # Ensure the date is timezone-aware and in UTC
        if date.tzinfo is None:
            # If the datetime is naive (no timezone info), convert it to UTC
            date = pytz.utc.localize(date)
        else:
            # Convert to UTC if it's in another timezone
            date = date.astimezone(pytz.utc)

        # Convert to epoch time (seconds since 1970-01-01)
        epoch_time = int(date.timestamp())  # Convert to epoch time (integer)

        # Extract date components
        year = date.year
        quarter = (date.month - 1) // 3 + 1
        month = date.month
        day = date.day
        day_of_week = date.strftime("%A")
        is_weekend = day_of_week in ["Saturday", "Sunday"]
        hour = date.hour
        minute = date.minute
        second = date.second

        # Check if the date already exists
        existing_date = self.session.query(DimDate).filter_by(full_date=epoch_time).first()
        if existing_date:
            return existing_date.id

        # Create a new date record
        new_date = DimDate(
            full_date=epoch_time,
            year=year,
            quarter=quarter,
            month=month,
            day=day,
            day_of_week=day_of_week,
            is_weekend=is_weekend,
            hour=hour,
            minute=minute,
            second=second,
        )

        self.session.add(new_date)
        self.session.commit()  # Commit to get the `id`
        return new_date.id

