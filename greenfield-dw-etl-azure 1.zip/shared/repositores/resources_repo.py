from datetime import datetime

from requests import Session
from sqlalchemy import insert

from shared.models.resources import DimAzSubscriptionResources, FactAzSubscriptionResources, \
    SummaryAzSubscriptionResources
from shared.repositores.base_repo import BaseRepo


class DimAzSubscriptionResourcesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, DimAzSubscriptionResources)

    def get_by_resource_name(self, resource_name):
        """Get resource by name"""
        return self.session.query(DimAzSubscriptionResources).filter_by(resource_name=resource_name).first()

    def get_by_resource_id(self, resource_id):
        """Get resource by name"""
        return self.session.query(DimAzSubscriptionResources).filter_by(resource_id=resource_id, isactive=1).first()

    def update_resource(self, sub_resources_dim_rowid, **kwargs):
        """Update a resource record in dim_az_resource"""
        filter_criteria = DimAzSubscriptionResources.subscription_dim_rowid == sub_resources_dim_rowid
        return super().update(filter_criteria, kwargs)


class FactAzSubscriptionResourcesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, FactAzSubscriptionResources)

    def get_by_resource_name(self, resource_name):
        """Get fact record by resource name"""
        result = (
            self.session.query(FactAzSubscriptionResources)
            .join(FactAzSubscriptionResources, FactAzSubscriptionResources.sub_resources_fact_rowid == DimAzSubscriptionResources.sub_resources_dim_rowid)
            .filter(FactAzSubscriptionResources.resource_name == resource_name)
            .all()
        )
        return result

    def update_fact_resource(self, resource_fact_rowid, **kwargs):
        """Update a fact resource record"""
        filter_criteria = FactAzSubscriptionResources.sub_resources_fact_rowid == resource_fact_rowid
        return super().update(filter_criteria, kwargs)


class SummaryAzSubscriptionResourcesRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, SummaryAzSubscriptionResources)

    def upsert_summary_subscription(self, report_dateref, resources_count, create_date=None):
        """Upsert a summary resource record."""
        stmt = insert(SummaryAzSubscriptionResources).values(
            report_dateref=report_dateref,
            resources_count=resources_count,
            create_date=create_date or datetime.now()
        ).on_conflict_do_update(
            index_elements=['report_dateref'],  # Key for conflict resolution
            set_={
                'resources_count': insert(SummaryAzSubscriptionResources).excluded.resources_count,
                'create_date': insert(SummaryAzSubscriptionResources).excluded.create_date
            }
        )
        self.session.execute(stmt)
        self.session.commit()


    # ETL Logic for Loading Summary Table
    def load_summary_data(session, fact_data):
        summary_repo = SummaryAzSubscriptionResources(session)
        for record in fact_data:
            # Calculate report_dateref
            report_dateref = record['report_dateref']
            resources_count = record['resources_count']
            summary_repo.upsert_summary_subscription(
                report_dateref=report_dateref,
                resources_count=resources_count
            )