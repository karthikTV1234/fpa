from sqlalchemy import Column, String, Date, DateTime, Integer, ForeignKey

from shared.models.base import Base
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="DimAzSubscription")


class DimAzTenant(Base):
    __tablename__ = 'dim_az_tenant'
    tenant_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String, nullable=False)
    tenant_name = Column(String, nullable=False)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

class DimAzSubscriptionTags(Base):
    __tablename__ = 'dim_az_subscription_tags'
    subscription_tag_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    subscription_dim_rowid = Column(Integer, ForeignKey("dim_az_subscription.subscription_dim_rowid"), nullable=False)
    line_no = Column(Integer, nullable=True)
    field_name = Column(String, nullable=True)
    field_value = Column(String, nullable=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    update_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

class DimAzSubscription(Base):
    __tablename__ = 'dim_az_subscription'

    subscription_dim_rowid = Column(Integer, primary_key=True, autoincrement=True)
    subscription_id = Column(String(255), nullable=False)
    #tenant_dim_rowid = Column(Integer, ForeignKey("dim_az_tenant.tenant_dim_rowid"), nullable=False)
    subscription_name = Column(String, nullable=False, default="")
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True, default=None)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

class FactAzSubscription(Base):
    __tablename__ = 'fact_az_subscription'

    subscription_fact_rowid = Column(Integer, primary_key=True, autoincrement=True)
    subscription_dim_rowid = Column(Integer, ForeignKey("dim_az_subscription.subscription_dim_rowid"), nullable=False)
    tenant_dim_rowid = Column(Integer, ForeignKey("dim_az_tenant.tenant_dim_rowid"), nullable=False)
    start_dateref = Column(Date, nullable=True)  # Date format (YYYY-MM-DD)
    end_dateref = Column(Date, nullable=True, default=None)  # Date format (YYYY-MM-DD)
    create_date = Column(DateTime, nullable=True)
    isactive = Column(Integer, nullable=True)

class SummaryAzSubscription(Base):
    __tablename__ = 'summary_az_subscription'
    subs_summary_rowid = Column(Integer, primary_key=True, autoincrement=True)
    tenant_dim_rowid = Column(Integer, nullable=False)
    report_dateref = Column(Integer, ForeignKey("dim_date.dateref"), nullable=False)
    subscription_count = Column(Integer, nullable=False)
    create_date = Column(DateTime, nullable=True)