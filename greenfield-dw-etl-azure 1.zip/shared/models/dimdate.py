import uuid

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    UUID, Date
)

from shared.models.base import Base


class DimDate(Base):
    __tablename__ = "dim_date"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, nullable=False)
    full_date = Column(Date, unique=True, nullable=False)
    year = Column(Integer, nullable=False)
    quarter = Column(Integer, nullable=False)
    month = Column(Integer, nullable=False)
    day = Column(Integer, nullable=False)
    day_of_week = Column(String, nullable=False)
    is_weekend = Column(Boolean, nullable=False)
    hour = Column(Integer, nullable=False,default=0)
    minute = Column(Integer, nullable=False,default=0)
    second = Column(Integer, nullable=False,default=0)

    # New column for ForeignKey reference
    dateref = Column(Integer, unique=True, nullable=False)