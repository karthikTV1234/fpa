-- PostgreSQL database schema
-- Name: dim_az_subs_resource_tags; Type: TABLE
CREATE TABLE public.dim_az_subs_resource_tags (
    sub_resources_tags_dim_rowid integer NOT NULL,
    sub_resources_dim_rowid integer NOT NULL,
    line_no integer,
    field_name character varying,
    field_value character varying,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    update_date timestamp without time zone,
    isactive integer
);

-- Name: dim_az_subscription; Type: TABLE
CREATE TABLE public.dim_az_subscription (
    subscription_dim_rowid integer NOT NULL,
    subscription_id character varying(255) NOT NULL,
    subscription_name character varying NOT NULL,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: dim_az_subscription_resources; Type: TABLE
CREATE TABLE public.dim_az_subscription_resources (
    sub_resources_dim_rowid integer NOT NULL,
    resource_id character varying(255) NOT NULL,
    subscription_dim_rowid integer NOT NULL,
    resource_name character varying NOT NULL,
    resource_kind character varying NOT NULL,
    resource_type character varying NOT NULL,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: dim_az_subscription_tags; Type: TABLE
CREATE TABLE public.dim_az_subscription_tags (
    subscription_tag_dim_rowid integer NOT NULL,
    subscription_dim_rowid integer NOT NULL,
    line_no integer,
    field_name character varying,
    field_value character varying,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    update_date timestamp without time zone,
    isactive integer
);

-- Name: dim_az_tenant; Type: TABLE

CREATE TABLE public.dim_az_tenant (
    tenant_dim_rowid integer NOT NULL,
    tenant_id character varying NOT NULL,
    tenant_name character varying NOT NULL,
    start_date date,
    end_date date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: fact_az_subscription; Type: TABLE
CREATE TABLE public.fact_az_subscription (
    subscription_fact_rowid integer NOT NULL,
    subscription_dim_rowid integer NOT NULL,
    tenant_dim_rowid integer NOT NULL,
    start_dateref date,
    end_dateref date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: fact_az_subscription_resources; Type: TABLE
CREATE TABLE public.fact_az_subscription_resources (
    sub_resources_fact_rowid integer NOT NULL,
    sub_resources_dim_rowid integer NOT NULL,
    start_dateref date,
    end_dateref date,
    create_date timestamp without time zone,
    isactive integer
);

-- Name: summary_az_subscription; Type: TABLE
CREATE TABLE public.summary_az_subscription (
    subs_summary_rowid integer NOT NULL,
    tenant_dim_rowid integer NOT NULL,
    report_dateref integer NOT NULL,
    subscription_count integer NOT NULL,
    create_date timestamp without time zone
);

-- Name: summary_az_subscription_resources; Type: TABLE
CREATE TABLE public.summary_az_subscription_resources (
    subs_resources_summary_rowid integer NOT NULL,
    subscription_dim_rowid integer NOT NULL,
    resource_count integer NOT NULL,
    report_dateref integer NOT NULL,
    create_date timestamp without time zone
);
-- database schema end
