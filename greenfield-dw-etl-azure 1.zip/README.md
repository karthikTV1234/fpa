# greenfield-dw-etl-azure

This repository contains the code for an Azure Function written in Python. These functions extract subscription and resource data from Azure Greenfield using APIs and process it using the Pandas library to store the data in a structured format for analysis and visualization. The data is then loaded into PostgreSQL, organized into dimension, fact, and summary tables.

## Table of Contents

- [Project Overview](#project-overview)
- [Prerequisites](#prerequisites)
- [Setup Instructions](#setup-instructions)
- [Configuration](#configuration)
- [Local Development](#local-development)
- [Docker Setup](#docker-setup)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [References](#references)

## Project Overview

This Azure Function is designed to efficiently process and manage data by leveraging Azure Blob Storage as an intermediate storage layer for API responses. The workflow involves the following steps:

- API Response Storage in Blob: The raw API responses stored in blob storage act as the source of truth for all data processing.
- The Azure Function extracts data from blob storage, focusing on the Subscription API and Resource API responses to retrieve detailed information, including subscription details, resource types, and resource counts.
- Loading Data for Analysis:
   The extracted and transformed data is loaded into PostgreSQL for structured storage and analysis. This allows for generating key operational insights related to infrastructure usage, configuration, and performance metrics.

By specifically targeting the Subscription API and Resource API, this process ensures efficient data handling while maintaining flexibility for additional use cases in the future.
###  Data Extraction from Blob storage
- Blob Path: raw_data/subscriptions
   Fetches JSON files containing API responses for subscriptions, which provide detailed metadata about subscriptions.

- Blob Path: raw_data/resources
Fetches JSON files containing API responses for resources, which include information on resources.

The extracted JSON files serve as the foundation for efficient data collection. They are then transformed using Pandas, where the data is cleaned, normalized, and enriched to ensure compatibility for downstream analysis. Finally, the transformed data is loaded into a PostgreSQL database, enabling structured storage, relational querying, and seamless integration for reporting and analytics workflows.
## Data Transformation and Loading

1. **Data Transformation**:
   - The extracted raw JSON data is processed using the Pandas library to standardize the structure.
   - Irrelevant fields are removed, and necessary fields are reformatted for consistency.
   - Data is aggregated where applicable (e.g., summarizing resource counts and subscription statistics).
   - The transformed data is converted into structured formats suitable for database insertion.

2. **Data Loading**:
   - The transformed data is stored in PostgreSQL.
   - Data is partitioned into dimension, fact, and summary tables for optimized retrieval and analysis.
   - The Azure Function directly loads data into PostgreSQL .

## Prerequisites

- Python 3.8+ installed on your local machine.
- [Azure Functions Core Tools](https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local#install-the-azure-functions-core-tools) installed.
- An active Azure subscription.
- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) installed for deploying to Azure.
- [Docker](https://docs.docker.com/get-docker/) installed for containerized execution.

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/azure-function-python.git
   cd azure-function-python
   ```

2. Set up a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows, use `.venv\Scripts\activate`
   pip install -r requirements.txt
   ```

## Configuration

1. Create a `local.settings.json` file in the root directory with the following structure:
   ```json
      {
        "IsEncrypted": false,
        "Values": {
          "FUNCTIONS_WORKER_RUNTIME": "python",
          "AzureWebJobsFeatureFlags": "EnableWorkerIndexing",
          "AzureWebJobsStorage": "UseDevelopmentStorage=true",
      
          "AZURE_CLIENT_ID": "<AZURE_CLIENT_ID>",
          "AZURE_CLIENT_SECRET": "<AZURE_CLIENT_SECRET>",
          "AZURE_TENANT_ID": "<AZURE_TENANT_ID>",
      
          "AZURE_BLOB_ACCOUNT_NAME": "<AZURE_BLOB_ACCOUNT_NAME>",
          "AZURE_BLOB_ACCOUNT_KEY": "<AZURE_BLOB_ACCOUNT_KEY>",
          "AZURE_BLOB_ENDPOINT": "<AZURE_BLOB_ENDPOINT>",
          "AZURE_RESOURCE_MAX_PAGE_SIZE": "<AZURE_RESOURCE_MAX_PAGE_SIZE>",
          "DW_CONTAINER_NAME": "<DW_CONTAINER_NAME>",
          "DW_AZURE_HOME_DIRECTORY": "<DW_AZURE_HOME_DIRECTORY>",
          "AZURE_RESOURCE_WATERMARK_BLOB_NAME": "<AZURE_RESOURCE_WATERMARK_BLOB_NAME>"
      
        }
      }
   ```

Replace the placeholder values with your actual Azure credentials and PostgreSQL connection string.

## Local Development

To run the function locally:

1. Start the Azure Functions runtime:
   ```bash
   func start
   ```

2. Navigate to `http://localhost:7071/api/[FunctionName]` to trigger the function.

## Docker Setup

To run the function inside a Docker container:

1. Build the Docker image:
   ```bash
   docker build -t azure-function-app .
   ```

2. Run the container:
   ```bash
   docker run -p 7071:7071 -v $(pwd)/local.settings.json:/app/local.settings.json azure-function-app
   ```

### Using Docker Compose

For easier setup, use Docker Compose:

1. Create a `docker-compose.yml` file with the following content:
   ```yaml
   version: '3.8'
   services:
     azure-function:
       build: .
       ports:
         - "7071:7071"
       volumes:
         - ./local.settings.json:/app/local.settings.json
   ```

2. Start the container:
   ```bash
   docker-compose up --build
   ```

This will set up and run the function in a containerized environment.

## Testing

You can use tools like Postman or `curl` to test the function locally or after deployment.

For example:
   ```bash
   curl -X GET http://localhost:7071/api/[FunctionName]
   ```

Replace `[FunctionName]` with the name of your function.

## Troubleshooting

1. Check the Azure Functions logs:
   ```bash
   func azure functionapp logstream [FunctionAppName]
   ```

2. Ensure all environment variables are correctly set in `local.settings.json` and in the Azure Portal (under "Configuration" for the Function App).

3. Check the Docker logs if running in a container:
   ```bash
   docker logs [container_id]
   ```

## References

1. [Azure Functions Documentation](https://docs.microsoft.com/en-us/azure/azure-functions/)
2. [Azure Python SDK](https://docs.microsoft.com/en-us/python/azure/)
3. [Docker Documentation](https://docs.docker.com/)

