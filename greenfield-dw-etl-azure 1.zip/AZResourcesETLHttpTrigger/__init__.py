import azure.functions as func

from shared.az_subscription_workflow import AzSubscriptionWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="az_etl_resource_http_trigger")


async def main(req: func.HttpRequest) -> func.HttpResponse:
    job = 'etl_resource'
    logger.info(f'Az {job} HTTP trigger function processed a request.')
    wf = AzSubscriptionWorkflow()
    await wf.execute_job(job)
    return func.HttpResponse(f"{job} has been triggerred successfully")