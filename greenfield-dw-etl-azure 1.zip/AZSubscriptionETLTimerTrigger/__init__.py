import logging
from datetime import datetime, timezone

from azure.functions import TimerRequest

from shared.az_subscription_workflow import AzSubscriptionWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="subscription_etl_timer_trigger")

async def main(mytimer: TimerRequest) -> None:
    utc_timestamp = datetime.utcnow().replace(tzinfo=timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    azw = AzSubscriptionWorkflow()
    await azw.execute_job('etl_subscription')
