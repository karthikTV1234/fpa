import azure.functions as func

from shared.tfc_workflow import TFCWorkflow
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="tfc_provider_http_trigger")


async def main(req: func.HttpRequest) -> func.HttpResponse:
    job = 'provider'
    logger.info(f'Provider {job} HTTP trigger function processed a request.')
    tfc = TFCWorkflow()
    await tfc.execute_job(job_name=job)
    return func.HttpResponse(f"{job} has been triggered successfully")
