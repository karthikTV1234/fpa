import os
from unittest import mock

import pytest

from shared.jobs.tfc_cv_job.tfc_cv_job import TFCCVJob


# Fixture to mock environment variables
@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        "FUNCTIONS_WORKER_RUNTIME": "python",
        "AzureWebJobsFeatureFlags": "EnableWorkerIndexing",
        "AzureWebJobsStorage": "UseDevelopmentStorage=true",
        "AZURE_BLOB_ACCOUNT_NAME": "devstoreaccount1",
        "AZURE_BLOB_ACCOUNT_KEY": "testkey",
        "AZURE_BLOB_ENDPOINT": "http://127.0.0.1:10000/test",
        "DW_CONTAINER_NAME": "terraform-container",
        "DW_TFC_HOME_DIRECTORY": "raw_data"
    }):
        yield


# Fixture to mock dependencies
@pytest.fixture
def mock_dependencies(mock_env_vars):
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.cv_job_config = mock_job_config

    mock_cv_service = mock.Mock()

    mock_extract_run_from_blob_step = mock.Mock()
    mock_download_extract_store_cv_step = mock.Mock()
    mock_teardown_step = mock.Mock()

    mock_extract_run_from_blob_step.execute = mock.AsyncMock()
    mock_download_extract_store_cv_step.execute = mock.AsyncMock()
    mock_teardown_step.execute = mock.AsyncMock()

    mock_context = mock.Mock()
    mock_context.cv_service = mock_cv_service

    job = TFCCVJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context

    job._extract_run_from_blob_step = mock_extract_run_from_blob_step
    job._download_extract_store_cv_step = mock_download_extract_store_cv_step
    job._teardown_step = mock_teardown_step

    return job, mock_extract_run_from_blob_step, mock_download_extract_store_cv_step, mock_teardown_step


@pytest.mark.asyncio
async def test_cv_job_flow(mock_dependencies):
    job, mock_extract_run_from_blob_step, mock_download_extract_store_cv_step, mock_teardown_step = mock_dependencies

    await job._extract_run_from_blob_step.execute()
    await job._download_extract_store_cv_step.execute()
    await job._teardown_step.execute()

    mock_extract_run_from_blob_step.execute.assert_called_once()
    mock_download_extract_store_cv_step.execute.assert_called_once()
    mock_teardown_step.execute.assert_called_once()


@pytest.mark.asyncio
async def test_cv_job_flow_exception_in_extract(mock_dependencies):
    job, mock_extract_run_from_blob_step, mock_download_extract_store_cv_step, mock_teardown_step = mock_dependencies

    mock_extract_run_from_blob_step.execute.side_effect = Exception("Extract run from blob step failed!")

    with pytest.raises(Exception, match="Extract run from blob step failed!"):
        await job._extract_run_from_blob_step.execute()

    mock_download_extract_store_cv_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()


@pytest.mark.asyncio
async def test_cv_job_flow_exception_in_download(mock_dependencies):
    job, mock_extract_run_from_blob_step, mock_download_extract_store_cv_step, mock_teardown_step = mock_dependencies

    await job._extract_run_from_blob_step.execute()

    mock_download_extract_store_cv_step.execute.side_effect = Exception("Download extract store CV step failed!")

    with pytest.raises(Exception, match="Download extract store CV step failed!"):
        await job._download_extract_store_cv_step.execute()

    mock_teardown_step.execute.assert_not_called()
