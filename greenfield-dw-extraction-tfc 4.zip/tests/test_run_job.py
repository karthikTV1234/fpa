import os
from unittest import mock

import pytest

from shared.jobs.tfc_run_job.tfc_run_job import TFCRunJob


# Fixture to mock environment variables
@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        "FUNCTIONS_WORKER_RUNTIME": "python",
        "AzureWebJobsFeatureFlags": "EnableWorkerIndexing",
        "AzureWebJobsStorage": "UseDevelopmentStorage=true",
        "TFC_ENDPOINT_BASE_URL": "https://app.terraform.io/api/v2",
        "AZURE_BLOB_ACCOUNT_NAME": "devstoreaccount1",
        "AZURE_BLOB_ACCOUNT_KEY": "testkey",
        "AZURE_BLOB_ENDPOINT": "http://127.0.0.1:10000/test",
        "TFC_RUN_WATERMARK_BLOB_NAME": "run_watermarks.json",
        "TFC_API_KEY": "test_tfc_api_key",
        "DW_CONTAINER_NAME": "terraform-container",
        "DW_TFC_HOME_DIRECTORY": "raw_data"
    }):
        yield


# Fixture to mock dependencies
@pytest.fixture
def mock_dependencies(mock_env_vars):
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.run_job_config = mock_job_config

    mock_run_service = mock.Mock()

    mock_fetch_pending_run_step = mock.Mock()
    mock_get_workspace_ids_step = mock.Mock()
    mock_get_current_watermark_step = mock.Mock()
    mock_fetch_run_step = mock.Mock()
    mock_store_run_step = mock.Mock()
    mock_update_watermark_step = mock.Mock()
    mock_teardown_step = mock.Mock()

    mock_fetch_pending_run_step.execute = mock.AsyncMock()
    mock_get_workspace_ids_step.execute = mock.AsyncMock()
    mock_get_current_watermark_step.execute = mock.AsyncMock()
    mock_fetch_run_step.execute = mock.AsyncMock()
    mock_store_run_step.execute = mock.AsyncMock()
    mock_update_watermark_step.execute = mock.AsyncMock()
    mock_teardown_step.execute = mock.AsyncMock()

    mock_context = mock.Mock()
    mock_context.run_service = mock_run_service

    job = TFCRunJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context

    job._fetch_pending_run_step = mock_fetch_pending_run_step
    job._get_workspace_ids_step = mock_get_workspace_ids_step
    job._get_current_watermark_step = mock_get_current_watermark_step
    job._fetch_run_step = mock_fetch_run_step
    job._store_run_step = mock_store_run_step
    job._update_watermark_step = mock_update_watermark_step
    job._teardown_step = mock_teardown_step

    return job, mock_fetch_pending_run_step, mock_get_workspace_ids_step, mock_get_current_watermark_step, mock_fetch_run_step, mock_store_run_step, mock_update_watermark_step, mock_teardown_step


@pytest.mark.asyncio
async def test_run_job_flow(mock_dependencies):
    job, mock_fetch_pending_run_step, mock_get_workspace_ids_step, mock_get_current_watermark_step, mock_fetch_run_step, mock_store_run_step, mock_update_watermark_step, mock_teardown_step = mock_dependencies

    await job._fetch_pending_run_step.execute()
    await job._get_workspace_ids_step.execute()
    await job._get_current_watermark_step.execute()
    await job._fetch_run_step.execute()
    await job._store_run_step.execute()
    await job._update_watermark_step.execute()
    await job._teardown_step.execute()

    mock_fetch_pending_run_step.execute.assert_called_once()
    mock_get_workspace_ids_step.execute.assert_called_once()
    mock_get_current_watermark_step.execute.assert_called_once()
    mock_fetch_run_step.execute.assert_called_once()
    mock_store_run_step.execute.assert_called_once()
    mock_update_watermark_step.execute.assert_called_once()
    mock_teardown_step.execute.assert_called_once()


@pytest.mark.asyncio
async def test_run_job_flow_exception_in_fetch(mock_dependencies):
    job, mock_fetch_pending_run_step, mock_get_workspace_ids_step, mock_get_current_watermark_step, mock_fetch_run_step, mock_store_run_step, mock_update_watermark_step, mock_teardown_step = mock_dependencies

    mock_fetch_run_step.execute.side_effect = Exception("Fetch run step failed!")

    with pytest.raises(Exception, match="Fetch run step failed!"):
        await job._fetch_run_step.execute()

    mock_store_run_step.execute.assert_not_called()
    mock_update_watermark_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()


@pytest.mark.asyncio
async def test_run_job_flow_exception_in_store(mock_dependencies):
    job, mock_fetch_pending_run_step, mock_get_workspace_ids_step, mock_get_current_watermark_step, mock_fetch_run_step, mock_store_run_step, mock_update_watermark_step, mock_teardown_step = mock_dependencies

    await job._fetch_run_step.execute()

    mock_store_run_step.execute.side_effect = Exception("Store run step failed!")

    with pytest.raises(Exception, match="Store run step failed!"):
        await job._store_run_step.execute()

    mock_update_watermark_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()
