import os
from unittest import mock

import pytest

from shared.jobs.tfc_project_job.tfc_project_job import TFCProjectJob


# Fixture to mock environment variables
@pytest.fixture
def mock_env_vars():
    with mock.patch.dict(os.environ, {
        "FUNCTIONS_WORKER_RUNTIME": "python",
        "AzureWebJobsFeatureFlags": "EnableWorkerIndexing",
        "AzureWebJobsStorage": "UseDevelopmentStorage=true",
        "TFC_ENDPOINT_BASE_URL": "https://app.terraform.io/api/v2",
        "AZURE_BLOB_ACCOUNT_NAME": "devstoreaccount1",
        "AZURE_BLOB_ACCOUNT_KEY": "testkey",
        "AZURE_BLOB_ENDPOINT": "http://127.0.0.1:10000/test",
        "TFC_PROJECT_WATERMARK_BLOB_NAME": "project_watermarks.json",
        "TFC_API_KEY": "test_tfc_api_key",
        "DW_CONTAINER_NAME": "terraform-container",
        "DW_TFC_HOME_DIRECTORY": "raw_data"
    }):
        yield


# Fixture to mock dependencies
@pytest.fixture
def mock_dependencies(mock_env_vars):
    mock_config_loader = mock.Mock()
    mock_job_config = mock.Mock()
    mock_config_loader.project_job_config = mock_job_config

    mock_project_service = mock.Mock()

    mock_fetch_project_step = mock.Mock()
    mock_store_project_step = mock.Mock()
    mock_teardown_step = mock.Mock()

    mock_fetch_project_step.execute = mock.AsyncMock()
    mock_store_project_step.execute = mock.AsyncMock()
    mock_teardown_step.execute = mock.AsyncMock()

    mock_context = mock.Mock()
    mock_context.project_service = mock_project_service

    job = TFCProjectJob()
    job._config_loader = mock_config_loader
    job._job_config = mock_job_config
    job._context = mock_context

    job._fetch_project_step = mock_fetch_project_step
    job._store_project_step = mock_store_project_step
    job._teardown_step = mock_teardown_step

    return job, mock_fetch_project_step, mock_store_project_step, mock_teardown_step


@pytest.mark.asyncio
async def test_project_job_flow(mock_dependencies):
    job, mock_fetch_project_step, mock_store_project_step, mock_teardown_step = mock_dependencies

    await job._fetch_project_step.execute()
    await job._store_project_step.execute()
    await job._teardown_step.execute()

    mock_fetch_project_step.execute.assert_called_once()
    mock_store_project_step.execute.assert_called_once()
    mock_teardown_step.execute.assert_called_once()


@pytest.mark.asyncio
async def test_project_job_flow_exception_in_fetch(mock_dependencies):
    job, mock_fetch_project_step, mock_store_project_step, mock_teardown_step = mock_dependencies

    mock_fetch_project_step.execute.side_effect = Exception("Fetch project step failed!")

    with pytest.raises(Exception, match="Fetch project step failed!"):
        await job._fetch_project_step.execute()

    mock_store_project_step.execute.assert_not_called()
    mock_teardown_step.execute.assert_not_called()


@pytest.mark.asyncio
async def test_project_job_flow_exception_in_store(mock_dependencies):
    job, mock_fetch_project_step, mock_store_project_step, mock_teardown_step = mock_dependencies

    await job._fetch_project_step.execute()

    mock_store_project_step.execute.side_effect = Exception("Store project step failed!")

    with pytest.raises(Exception, match="Store project step failed!"):
        await job._store_project_step.execute()

    mock_teardown_step.execute.assert_not_called()
