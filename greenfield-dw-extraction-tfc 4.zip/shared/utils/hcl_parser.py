import hcl


def parse_terraform_lock(file_content):
    """
    Parses the .terraform.lock.hcl content and extracts provider details.

    :param file_content: Content of the .terraform.lock.hcl file as bytes or string.
    :return: List of providers with names and versions.
    """
    try:
        hcl_data = hcl.loads(file_content.decode("utf-8"))

        providers = []
        for provider_key, provider_data in hcl_data.get('provider', {}).items():
            provider_name = provider_key.split('/')[-1]  # Extract the provider name
            version = provider_data.get('version', 'unknown')
            providers.append({"provider_name": provider_name, "version": version})

        return providers
    except Exception as e:
        raise RuntimeError(f"Error while parsing the file: {e}")
