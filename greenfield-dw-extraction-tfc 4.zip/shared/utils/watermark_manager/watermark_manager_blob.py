import json
from datetime import datetime

from azure.storage.blob import BlobServiceClient

from shared.utils.logger_setup import setup_logger

logger = setup_logger("WatermarkManagerBlob")


class WatermarkManagerBlob:
    def __init__(self, connection_string, container_name, blob_name="watermarks.json"):
        """
        Initialize the WatermarkManager with Azure Blob Storage.
        :param connection_string: Azure Blob Storage connection string.
        :param container_name: Name of the Azure Blob Storage container.
        :param blob_name: Blob file name to store watermarks.
        """
        self.container_name = container_name
        self.blob_name = blob_name
        self.blob_service_client = BlobServiceClient.from_connection_string(
            connection_string)
        self.container_client = self.blob_service_client.get_container_client(
            container_name)
        self.watermarks = self._load_watermarks()

    def _load_watermarks(self):
        """
        Load watermarks from the blob storage.
        :return: A dictionary of watermarks.
        """
        try:
            blob_client = self.container_client.get_blob_client(self.blob_name)
            # Check if the blob exists
            if not blob_client.exists():
                logger.warning(f"Watermark blob {self.blob_name} does not exist. Defaulting to None.")
                return {}

            # Read the blob data
            blob_data = blob_client.download_blob().readall()
            return json.loads(blob_data).get("resource_last_execution")

        except Exception as e:
            logger.warning(f"Error loading watermark: {e}. Defaulting to None.")
            return {}

    def _save_watermarks(self):
        """
        Save the current watermarks to the blob storage.
        """
        try:
            blob_client = self.container_client.get_blob_client(self.blob_name)
            blob_client.upload_blob(
                json.dumps(self.watermarks, indent=4),
                overwrite=True,
            )
        except Exception as e:
            logger.error(f"Error saving watermarks: {e}")

    def get_watermark(self, source_name):
        """
        Get the current watermark for a specific source.
        If no watermark exists, returns None.
        """
        if self.watermarks is not None:
            return self.watermarks.get(source_name)

    def update_watermark(self, source_name, new_watermark):
        """
        Update the watermark for a specific source and persist it.
        """
        if self.watermarks is None:
            self.watermarks = {}
        self.watermarks[source_name] = new_watermark
        self._save_watermarks()

    def filter_data(self, source_name, data, timestamp_key):
        """
        Filter data based on the current watermark for the given source.
        :param source_name: Name of the data source.
        :param data: List of data items to filter.
        :param timestamp_key: Key in the data item that contains the timestamp.
        :return: Filtered data items.
        """
        watermark = self.get_watermark(source_name)
        if not watermark:
            # If no watermark exists, consider all data.
            return data

        # Convert the watermark to a datetime object.
        watermark_time = datetime.fromisoformat(watermark)

        # Filter data based on the watermark.
        filtered_data = [
            item for item in data
            if datetime.fromisoformat(item[timestamp_key].replace("Z", "")) > watermark_time
        ]
        return filtered_data

    def close(self):
        """
        close the Azure Blob Service Client
        """
        self.blob_service_client.close()
