import functools
import time

from shared.utils.logger_setup import setup_logger

logger = setup_logger("RetryOn429")


def retry_on_429(max_retries=3):
    """
    A decorator to retry an API request if the response status is 429 (Too Many Requests).
    It respects the 'Retry-After' header if present.

    :param max_retries: Maximum number of retries before giving up.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                response = func(*args, **kwargs)
                if response.status_code != 429:
                    # Return the response if it's not a 429 status.
                    return response

                # Handle 429: Too Many Requests
                retry_after = response.headers.get("Retry-After")
                if retry_after:
                    retry_after = int(retry_after)
                else:
                    retry_after = 1  # Default retry delay if no Retry-After header

                logger.warn(
                    f"429 Too Many Requests received. Retrying after {retry_after} seconds...")
                time.sleep(retry_after)
                retries += 1

            raise Exception(
                f"Max retries reached. Last response: {response.status_code}, {response.text}")

        return wrapper

    return decorator
