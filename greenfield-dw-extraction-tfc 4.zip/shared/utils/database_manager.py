from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from shared.models.base import Base
from shared.repositories.workspace_run_control_repo import WorkspaceRunControlRepo
from shared.utils.logger_setup import setup_logger

logger = setup_logger("DatabaseManager")


class DatabaseManager:
    def __init__(self, database_url: str):
        # Initialize the engine and session
        self.engine = create_engine(database_url, echo=False)
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
        # Create tables if they don't exist
        Base.metadata.create_all(self.engine)
        self.workspace_run_control_repo = WorkspaceRunControlRepo(self.session)

    def close_session(self):
        self.session.close_all()
