from shared.jobs.tfc_cv_job.tfc_cv_job import TFCCVJob
from shared.jobs.tfc_module_job.tfc_module_job import TFCModuleJob
from shared.jobs.tfc_project_job.tfc_project_job import TFCProjectJob
from shared.jobs.tfc_provider_job.tfc_provider_job import TFCProviderJob
from shared.jobs.tfc_run_job.tfc_run_job import TFCRunJob
from shared.jobs.tfc_workspace_job.tfc_workspace_job import TFCWorkspaceJob
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="TFCWorkflow")


class TFCWorkflow:
    jobs: dict = {}

    def __init__(self, **kwargs):
        self.jobs['workspace'] = TFCWorkspaceJob()
        self.jobs['workspace'].initialize()

        self.jobs['run'] = TFCRunJob()
        self.jobs['run'].initialize()

        self.jobs['project'] = TFCProjectJob()
        self.jobs['project'].initialize()

        self.jobs['module'] = TFCModuleJob()
        self.jobs['module'].initialize()

        self.jobs['provider'] = TFCProviderJob()
        self.jobs['provider'].initialize()

        self.jobs['configuration_version'] = TFCCVJob()
        self.jobs['configuration_version'].initialize()

    async def execute_job(self, job_name: str) -> bool:
        if not self.jobs.get(job_name):
            logger.critical(
                f"error in job execution, job={job_name} is not registered")
            return False
        else:
            logger.info(f"{job_name} is about to execute")
            job = self.jobs[job_name]
            await job.trigger_event('start')
            return True
