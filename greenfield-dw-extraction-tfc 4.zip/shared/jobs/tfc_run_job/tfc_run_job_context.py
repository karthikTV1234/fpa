from typing import Optional, List

from shared.repositories.workspace_run_control_repo import WorkspaceRunControlRepo
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob


class TFCRunJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.watermark_manager: Optional[WatermarkManagerBlob] = None
        self.run_current_watermark: Optional[str] = None
        self.run_new_watermark: Optional[str] = None
        self.runs: List[any] = []
        self.database_manager: Optional[DatabaseManager] = None
        self.workspace_run_control_repo: Optional[WorkspaceRunControlRepo] = None
        self.workspace_list_ids: List[any] = []
        self.pending_run_list = {}