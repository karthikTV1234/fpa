import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_run_job.steps.fetch_pending_run_step import FetchPendingRunStep
from shared.jobs.tfc_run_job.steps.fetch_run_step import FetchRunStep
from shared.jobs.tfc_run_job.steps.get_run_current_watermark_step import GetRunCurrentWatermarkStep
from shared.jobs.tfc_run_job.steps.get_workspace_ids import GetWorkspaceIdsStep
from shared.jobs.tfc_run_job.steps.store_run_step import StoreRunStep
from shared.jobs.tfc_run_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_run_job.steps.update_run_watermark_step import UpdateRunWatermarkStep
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="TFCRunJob")


class TFCRunJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCRunJobContext = None

    _fetch_pending_run_step: FetchPendingRunStep = None
    _get_workspace_ids_step: GetWorkspaceIdsStep = None
    _get_run_current_watermark_step: GetRunCurrentWatermarkStep = None
    _fetch_run_step: FetchRunStep = None
    _store_run_step: StoreRunStep = None
    _teardown_step: TeardownStep = None
    _update_run_new_watermark_step: UpdateRunWatermarkStep = None

    class States(statesman.StateEnum):
        start = "start"
        fetch_pending_run = "fetch_pending_run"
        get_workspace_ids = "get_workspace_ids"
        get_current_watermark = "get_current_watermark"
        fetch_run = "fetch_run"
        store_run = "store_run"
        update_watermark = "update_watermark"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCRunJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._context.watermark_manager = WatermarkManagerBlob(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name,
            blob_name=self._config_loader.tfc_extraction_job_config.tfc_run_watermark_blob_name
        )

        self._context.database_manager = DatabaseManager(
            database_url=self._job_config.dw_sql_db_connection_string,
        )

        if not self._context.database_manager.session:
            raise ValueError("DatabaseManager session is not initialized. Check the database URL or connectivity.")

        logger.info("DatabaseManager initialized successfully.")

        self._fetch_pending_run_step = FetchPendingRunStep(config=self._job_config, context=self._context)
        self._get_workspace_ids_step = GetWorkspaceIdsStep(config=self._job_config, context=self._context)

        self._get_run_current_watermark_step = GetRunCurrentWatermarkStep(
            config=self._job_config, context=self._context)
        self._fetch_run_step = FetchRunStep(
            config=self._job_config, context=self._context)
        self._store_run_step = StoreRunStep(
            config=self._job_config, context=self._context)
        self._update_run_new_watermark_step = UpdateRunWatermarkStep(
            config=self._job_config, context=self._context)
        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)


    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("fetch_pending_run")

    @statesman.event(States.start, States.fetch_pending_run)
    async def fetch_pending_run(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is fetch pending run")
        await self._fetch_pending_run_step.execute()
        await self.trigger_event("get_workspace_ids")

    @statesman.event(States.fetch_pending_run, States.get_workspace_ids)
    async def get_workspace_ids(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is getting workspace ids")
        await self._get_workspace_ids_step.execute()
        await self.trigger_event("get_current_watermark")

    @statesman.event(States.get_workspace_ids, States.get_current_watermark)
    async def get_current_watermark(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is retrieving current watermark")
        await self._get_run_current_watermark_step.execute()
        await self.trigger_event("fetch_run")

    @statesman.event(States.get_current_watermark, States.fetch_run)
    async def fetch_run(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching runs")
        await self._fetch_run_step.execute()
        await self.trigger_event("store_run")

    @statesman.event(States.fetch_run, States.store_run)
    async def store_run(self) -> None:
        logger.info(f"{self.__class__.__name__} is storing runs")
        await self._store_run_step.execute()
        await self.trigger_event("update_watermark")

    @statesman.event(States.store_run, States.update_watermark)
    async def update_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is updating new watermark")
        await self._update_run_new_watermark_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.update_watermark, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is tearing down")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
