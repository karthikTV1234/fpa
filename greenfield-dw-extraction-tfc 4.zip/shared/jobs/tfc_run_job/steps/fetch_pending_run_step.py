import json

import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.models.control_table import WorkspaceRunControl
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchPendingRunStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchPendingRunStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    def _fetch_run(self, api_url, api_token):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{api_url}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        run_data = data.get("data", {})
        return run_data

    @measure_time
    async def execute(self):
        # Check if any pending workspace need to fetch
        pending_run_list = self.context.database_manager.session.query(WorkspaceRunControl).filter_by(
            run_status=0).all()

        run_map = {}
        try:
            if pending_run_list and len(pending_run_list) > 0:
                for pending_run in pending_run_list:
                    api_url = f"runs/{pending_run.run_id}"
                    # Loop through all organizations and fetch workspaces for each one
                    organizations = json.loads(self.config.organizations)

                    for org in organizations:
                        org_id = org.get('org_id')
                        org_token = org.get('org_token')

                        if not org_id or not org_token:
                            logger.warn(f"Skipping invalid organization: {org}")
                            continue
                        try:
                            run = self._fetch_run(api_url, org_token)
                            if run:
                                run_map[run["id"]] = run
                        except requests.exceptions.RequestException as e:
                            logger.error(f"Error fetching run for id {pending_run.run_id}: {e}")

            self.context.pending_run_list = run_map
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching pending run: {e}")
