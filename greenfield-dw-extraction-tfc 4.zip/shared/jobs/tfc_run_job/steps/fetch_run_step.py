import json

import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchRunStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchRunStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    def _fetch_paginated_runs(self, api_url, api_token, page_size=100, page_number=None):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{api_url}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # API Call parameters
        params = {
            'page[number]': page_number,
            'page[size]': page_size
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        run_data = data.get("data", [])
        runs = [item for item in run_data]
        return runs

    @measure_time
    async def execute(self):
        page_size = self.config.tfc_run_max_page_size
        watermark = self.context.run_current_watermark
        all_runs = []

        # Loop through all organizations and fetch runs for each one
        organizations = json.loads(self.config.organizations)

        for org in organizations:
            org_id = org.get('org_id')
            org_token = org.get('org_token')

            if not org_id or not org_token:
                logger.warn(f"Skipping invalid organization: {org}")
                continue

            # Endpoint to fetch runs
            api_url = f"organizations/{org_id}/runs"
            page_number = 1
            stop_fetching = False
            while not stop_fetching:
                try:
                    runs = self._fetch_paginated_runs(api_url, org_token, page_size, page_number)
                    if not runs:
                        logger.warn(f"No more runs to fetch for organization {org_id}.")
                        break
                    for run in runs:
                        updated_at = run["attributes"]["updated-at"]
                        if watermark and updated_at <= watermark:
                            logger.info(
                                f"Reached previously fetched runs, watermark={watermark}. Stopping.")
                            stop_fetching = True
                            break

                        run_workspace_id = run["relationships"]["workspace"]["data"]["id"]

                        # Check run's workspace id if it is not present in the workspace blob list
                        if run_workspace_id not in self.context.workspace_list_ids:
                            # Create a new control table entry with workspace status = 0 and run_status = 0
                            self.context.database_manager.workspace_run_control_repo.insert_if_not_exists(
                                workspace_id=run_workspace_id,
                                run_id=run["id"],
                                workspace_status=0,
                                run_status=0
                            )
                            # Skip this run record if 'workspace_id' is not in workspace_list_ids
                            continue
                        all_runs.append(run)
                    # Move to the next page
                    page_number += 1

                except requests.exceptions.RequestException as e:
                    logger.error(f"Error fetching runs for org {org_id}, page {page_number}: {e}")
                    break

        # After fetching, store the last watermark for future reference
        if all_runs:
            new_watermark = max(item['attributes']['updated-at']
                                for item in all_runs)
            self.context.run_new_watermark = new_watermark
        self.context.runs = all_runs
