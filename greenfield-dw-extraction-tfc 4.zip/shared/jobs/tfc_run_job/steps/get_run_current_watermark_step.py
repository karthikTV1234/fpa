from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="GetRunCurrentWatermarkStep")


class GetRunCurrentWatermarkStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        source_name = self.config.tfc_run_watermark_key
        watermark = self.context.watermark_manager.get_watermark(source_name)
        if watermark is None:
            # watermark = self.config.tfc_run_initial_watermark
            watermark = None
        self.context.run_current_watermark = watermark
