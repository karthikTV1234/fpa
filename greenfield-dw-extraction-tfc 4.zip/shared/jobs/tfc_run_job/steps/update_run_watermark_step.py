from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="UpdateRunWatermarkStep")


class UpdateRunWatermarkStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        if self.context.run_new_watermark is not None:
            source_name = self.config.tfc_run_watermark_key
            watermark = self.context.run_new_watermark
            self.context.watermark_manager.update_watermark(
                source_name=source_name, new_watermark=watermark)
        else:
            logger.info('no new watermark to update')
