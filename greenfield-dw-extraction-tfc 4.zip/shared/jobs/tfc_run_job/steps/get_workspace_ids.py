from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="GetRunCurrentWatermarkStep")


class GetWorkspaceIdsStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        directory_path = f"{self.config.dw_tfc_home_directory}/workspace"
        existing_workspace_list = self.context.azure_blob_manager.fetch_existing_data(directory_path=directory_path)
        # Extract all workspace IDs
        workspace_ids = [obj["id"] for obj in existing_workspace_list]
        self.context.workspace_list_ids = workspace_ids