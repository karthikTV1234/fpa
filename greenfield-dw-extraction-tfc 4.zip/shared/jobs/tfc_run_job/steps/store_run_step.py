from datetime import datetime

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_run_job.tfc_run_job_context import TFCRunJobContext
from shared.models.control_table import WorkspaceRunControl
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="StoreRunStep")


class StoreRunStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCRunJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        run_list = self.context.runs
        run_pending_map = self.context.pending_run_list
        if len(run_list) == 0 and len(run_pending_map) == 0:
            logger.info(f"zero runs fetched, hence skipping storage")
            return
        if run_pending_map:
            # Add pending run records to run list
            run_pending_map = self.context.pending_run_list

            # Convert run_list to a set of IDs for easy lookup
            run_ids_in_list = {ws["id"] for ws in run_list}

            # Remove existing records from run and add missing records to run_list
            updated_run_map = {
                ws_id: ws_data for ws_id, ws_data in run_pending_map.items() if ws_id not in run_ids_in_list
            }

            # Add missing records to run_list
            for ws_id, ws_data in run_pending_map.items():
                if ws_id not in run_ids_in_list:
                    run_list.append(ws_data)  # Append new run to the list

        current_date_timestamp = datetime.now().strftime('%Y_%m_%d_%H%M%S')
        file = f"run_{current_date_timestamp}.json"
        directory = f"{self.config.dw_tfc_home_directory}/run"
        self.context.azure_blob_manager.upload_object(
            obj=run_list, directory_name=directory, file_path=file)

        # Update run in the control table as it is present now at blob
        for run_id in self.context.pending_run_list.keys():
            record = self.context.database_manager.session.query(WorkspaceRunControl).filter_by(
                run_id=run_id, run_status=0).first()
            if record:
                record.run_status = 1
                self.context.database_manager.session.add(record)
                self.context.database_manager.session.commit()
