import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_project_job.steps.fetch_project_step import FetchProjectStep
from shared.jobs.tfc_project_job.steps.store_project_step import StoreProjectStep
from shared.jobs.tfc_project_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_project_job.tfc_project_job_context import TFCProjectJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="TFCProjectJob")


class TFCProjectJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCProjectJobContext = None

    _fetch_project_step: FetchProjectStep = None
    _store_project_step: StoreProjectStep = None
    _teardown_step: TeardownStep = None

    class States(statesman.StateEnum):
        start = "start"
        fetch_project = "fetch_project"
        store_project = "store_project"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCProjectJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._fetch_project_step = FetchProjectStep(
            config=self._job_config, context=self._context)
        self._store_project_step = StoreProjectStep(
            config=self._job_config, context=self._context)
        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)

    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("fetch_project")

    @statesman.event(States.start, States.fetch_project)
    async def fetch_project(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching project")
        await self._fetch_project_step.execute()
        await self.trigger_event("store_project")

    @statesman.event(States.fetch_project, States.store_project)
    async def store_project(self) -> None:
        logger.info(f"{self.__class__.__name__} is storing project")
        await self._store_project_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.store_project, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is tearing down")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
