from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager


class TFCProjectJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.projects: List[any] = []
