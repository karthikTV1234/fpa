from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_project_job.tfc_project_job_context import TFCProjectJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="StoreProjectStep")


class StoreProjectStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCProjectJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        obj = self.context.projects
        directory = f"{self.config.dw_tfc_home_directory}/project"
        file = 'project.json'

        self.context.azure_blob_manager.upload_object(
            obj=obj, directory_name=directory, file_path=file)
