import json
from datetime import datetime

import pandas as pd
import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_project_job.tfc_project_job_context import TFCProjectJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchProjectStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchProjectStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCProjectJobContext):
        self.config = config
        self.context = context

    """Compare two list of projects for each fields based on primary key field "id" and find any differ or changes, if changes are detected then do soft delete by updating the fields
         end_date to today date and is_active to false, if id not found in the existing record it means the record is new so just add it as a new record,
         if id found in the existing list and no changes are detected then don't do anything, use existing record as it is """

    @staticmethod
    def _scd_type_2_logic(existing_project_data_list, new_project_data_list):
        final_records = []
        current_date = datetime.now().strftime("%Y-%m-%d")
        try:
            existing_pd_dataframe = pd.DataFrame(existing_project_data_list)
            new_pd_dataframe = pd.DataFrame(new_project_data_list)

            for _, new_row in new_pd_dataframe.iterrows():
                project_id = new_row["id"]
                existing_row = existing_pd_dataframe[existing_pd_dataframe["id"] == project_id]
                if existing_row.empty:  # New record
                    final_records.append(new_row.to_dict())
                else:
                    # Check for changes
                    fields_to_check = ["name", "description", "workspace-count", "team-count"]
                    existing_attributes = existing_row.iloc[0]["attributes"]
                    new_attributes = new_row["attributes"]
                    changes_detected = any(
                        existing_attributes.get(field, None) != new_attributes.get(field, None) for field in
                        fields_to_check
                    )

                    if changes_detected:  # Update record with soft delete
                        # Soft delete old record
                        old_record = existing_row.iloc[0].to_dict()
                        old_record["end_date"] = current_date
                        old_record["is_active"] = False
                        final_records.append(old_record)

                        # Add new record
                        new_record = new_row.to_dict()
                        new_record["start_date"] = datetime.now().strftime("%Y-%m-%d")
                        new_record["end_date"] = None
                        new_record["is_active"] = True
                        new_record["version"] = old_record["version"] + 1
                        final_records.append(new_record)
                    else:
                        # No changes
                        final_records.append(existing_row.iloc[0].to_dict())
        except Exception as e:
            logger.error(f"Error during compare old and new projects: {str(e)}")
        return final_records

    @staticmethod
    def _include_extra_fields(project_list):
        subs_dataframe = pd.DataFrame(project_list)
        subs_dataframe["start_date"] = datetime.now().strftime("%Y-%m-%d")
        subs_dataframe["end_date"] = None
        subs_dataframe["is_active"] = True
        subs_dataframe["version"] = 1
        """Convert DataFrame back to JSON array"""
        return subs_dataframe.to_dict(orient='records')

    def _fetch_paginated_project(self, endpoint, api_token, page_size=100, page_number=None):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{endpoint}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # API Call parameters
        params = {
            'page[number]': page_number,
            'page[size]': page_size
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        project_data = data.get("data", [])
        next_page = data.get("links", {}).get("next")
        projects = [item for item in project_data]
        return projects, next_page

    @measure_time
    async def execute(self):
        all_data = []
        projects_data = []
        # Loop through all organizations and fetch projects for each one
        organizations = json.loads(self.config.organizations)

        for org in organizations:
            org_id = org.get('org_id')
            org_token = org.get('org_token')

            if not org_id or not org_token:
                logger.warn(f"Skipping invalid organization: {org}")
                continue
            endpoint = f"organizations/{org_id}/projects"
            page_number = 1
            page_size = self.config.tfc_project_max_page_size
            stop_fetching = False
            while not stop_fetching:
                try:
                    logger.info(f"Fetching project for {org_id} for page {page_number}")
                    projects,next_page = self._fetch_paginated_project(endpoint, org_token, page_size, page_number)
                    if not projects:
                        logger.warn(f"No more projects to fetch for organization {org_id}.")
                        break
                    all_data.extend(projects)
                    # Move to the next page
                    if next_page is not None:
                        page_number += 1
                    else:
                        break

                except requests.exceptions.RequestException as e:
                    logger.error(
                        f"Error fetching projects on page {page_number}: {e}")
                    break

        if all_data:
            directory_path = f"{self.config.dw_tfc_home_directory}/project"
            existing_project_data_list = self.context.azure_blob_manager.fetch_existing_data(directory_path=directory_path)
            if existing_project_data_list:
                projects_data = self._scd_type_2_logic(existing_project_data_list, all_data)
            else:
                projects_data = self._include_extra_fields(all_data)
        self.context.projects = projects_data
