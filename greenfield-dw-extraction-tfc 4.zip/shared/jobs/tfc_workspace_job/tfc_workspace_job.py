import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_workspace_job.steps.fetch_pending_workspace_step import FetchPendingWorkspaceStep
from shared.jobs.tfc_workspace_job.steps.fetch_workspace_step import FetchWorkspaceStep
from shared.jobs.tfc_workspace_job.steps.get_workspace_current_watermark_step import GetWorkspaceCurrentWatermarkStep
from shared.jobs.tfc_workspace_job.steps.store_workspace_step import StoreWorkspaceStep
from shared.jobs.tfc_workspace_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_workspace_job.steps.update_workspace_watermark_step import UpdateWorkspaceWatermarkStep
from shared.jobs.tfc_workspace_job.tfc_workspace_job_context import TFCWorkspaceJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="TFCWorkspaceJob")


class TFCWorkspaceJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCWorkspaceJobContext = None

    _fetch_pending_workspace_step: FetchPendingWorkspaceStep = None
    _get_workspace_current_watermark_step: GetWorkspaceCurrentWatermarkStep = None
    _fetch_step: FetchWorkspaceStep = None
    _store_step: StoreWorkspaceStep = None
    _teardown_step: TeardownStep = None
    _update_workspace_new_watermark_step: UpdateWorkspaceWatermarkStep = None

    class States(statesman.StateEnum):
        start = "start"
        fetch_pending_workspace = "fetch_pending_workspace"
        get_current_watermark = "get_current_watermark"
        fetch_workspace = "fetch_workspace"
        store_workspace = "store_workspace"
        update_watermark = "update_watermark"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCWorkspaceJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._context.watermark_manager = WatermarkManagerBlob(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name,
            blob_name=self._config_loader.tfc_extraction_job_config.tfc_workspace_watermark_blob_name
        )

        self._context.database_manager = DatabaseManager(
            database_url=self._job_config.dw_sql_db_connection_string,
        )

        if not self._context.database_manager.session:
            raise ValueError("DatabaseManager session is not initialized. Check the database URL or connectivity.")

        logger.info("DatabaseManager initialized successfully.")

        self._fetch_pending_workspace_step = FetchPendingWorkspaceStep(
            config=self._job_config, context=self._context)

        self._get_workspace_current_watermark_step = GetWorkspaceCurrentWatermarkStep(
            config=self._job_config, context=self._context)
        self._fetch_step = FetchWorkspaceStep(
            config=self._job_config, context=self._context)
        self._store_step = StoreWorkspaceStep(
            config=self._job_config, context=self._context)
        self._update_workspace_new_watermark_step = UpdateWorkspaceWatermarkStep(
            config=self._job_config, context=self._context)
        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)

    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("fetch_pending_workspace")

    @statesman.event(States.start, States.fetch_pending_workspace)
    async def fetch_pending_workspace(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is fetch pending workspace")
        await self._fetch_pending_workspace_step.execute()
        await self.trigger_event("get_current_watermark")

    @statesman.event(States.fetch_pending_workspace, States.get_current_watermark)
    async def get_current_watermark(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is retrieving current watermark")
        await self._get_workspace_current_watermark_step.execute()
        await self.trigger_event("fetch_workspace")

    @statesman.event(States.get_current_watermark, States.fetch_workspace)
    async def fetch_workspace(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching workspace")
        await self._fetch_step.execute()
        await self.trigger_event("store_workspace")

    @statesman.event(States.fetch_workspace, States.store_workspace)
    async def store_workspace(self) -> None:
        logger.info(f"{self.__class__.__name__} is storing workspace")
        await self._store_step.execute()
        await self.trigger_event("update_watermark")

    @statesman.event(States.store_workspace, States.update_watermark)
    async def update_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is updating new watermark")
        await self._update_workspace_new_watermark_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.update_watermark, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is tearing down")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
