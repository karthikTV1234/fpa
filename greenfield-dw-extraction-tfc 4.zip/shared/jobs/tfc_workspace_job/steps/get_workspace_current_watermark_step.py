from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_workspace_job.tfc_workspace_job_context import TFCWorkspaceJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="GetWorkspaceCurrentWatermarkStep")


class GetWorkspaceCurrentWatermarkStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCWorkspaceJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        source_name = self.config.tfc_workspace_watermark_key
        watermark = self.context.watermark_manager.get_watermark(source_name)
        if watermark is None:
            watermark = None
        self.context.workspace_current_watermark = watermark
