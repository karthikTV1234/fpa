from datetime import datetime

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_workspace_job.tfc_workspace_job_context import TFCWorkspaceJobContext
from shared.models.control_table import WorkspaceRunControl
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="StoreWorkspaceStep")


class StoreWorkspaceStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCWorkspaceJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        workspace_list = self.context.workspaces
        workspace_pending_map = self.context.pending_workspaces_list
        if len(workspace_list) == 0 and len(workspace_pending_map) == 0:
            logger.info(f"zero workspaces fetched, hence skipping storage")
            return

        if workspace_pending_map:
            # Add pending workspace records to workspace list
            # Convert workspace_list to a set of IDs for easy lookup
            workspace_ids_in_list = {ws["id"] for ws in workspace_list}

            # Remove existing records from workspace_pending_map and add missing records to workspace_list
            updated_workspace_map = {
                ws_id: ws_data for ws_id, ws_data in workspace_pending_map.items() if ws_id not in workspace_ids_in_list
            }

            # Add missing records to workspace_list
            for ws_id, ws_data in workspace_pending_map.items():
                if ws_id not in workspace_ids_in_list:
                    workspace_list.append(ws_data)  # Append new workspace to the list


        current_date_timestamp = datetime.now().strftime('%Y_%m_%d_%H%M%S')
        directory = f"{self.config.dw_tfc_home_directory}/workspace"
        file = f"workspace_{current_date_timestamp}.json"

        self.context.azure_blob_manager.upload_object(
            obj=workspace_list, directory_name=directory, file_path=file)

        if workspace_pending_map:
            # Update workspace_status in the control table as it is present now at blob
            for workspace_id in workspace_pending_map.keys():
                pending_records = self.context.database_manager.session.query(WorkspaceRunControl).filter_by(
                    workspace_id=workspace_id, workspace_status=0).all()
                for record in pending_records:
                    if record:
                        record.workspace_status = 1
                        self.context.database_manager.session.add(record)
                        self.context.database_manager.session.commit()
