import json

import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_workspace_job.tfc_workspace_job_context import TFCWorkspaceJobContext
from shared.models.control_table import WorkspaceRunControl
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchPendingWorkspaceStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchPendingWorkspaceStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCWorkspaceJobContext):
        self.config = config
        self.context = context

    def _fetch_workspace(self, api_url, api_token):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{api_url}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        workspace_data = data.get("data", {})
        return workspace_data

    @measure_time
    async def execute(self):
        # Check if any pending workspace need to fetch
        pending_workspaces_list = self.context.database_manager.session.query(WorkspaceRunControl).filter_by(workspace_status=0).all()
        workspace_map = {}
        try:
            for pending_workspace in pending_workspaces_list:
                logger.info(pending_workspace.workspace_id, pending_workspace.run_id, pending_workspace.workspace_status)
                api_url = f"workspaces/{pending_workspace.workspace_id}"
                # Loop through all organizations and fetch workspaces for each one
                organizations = json.loads(self.config.organizations)

                for org in organizations:
                    org_id = org.get('org_id')
                    org_token = org.get('org_token')

                    if not org_id or not org_token:
                        logger.warn(f"Skipping invalid organization: {org}")
                        continue
                    try:
                        workspace = self._fetch_workspace(api_url, org_token)
                        if workspace:
                            workspace_map[workspace["id"]] = workspace
                    except requests.exceptions.RequestException as e:
                        logger.error(f"Error fetching workspace for id {pending_workspace.workspace_id}: {e}")

            self. context.pending_workspaces_list = workspace_map
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching pending workspace: {e}")