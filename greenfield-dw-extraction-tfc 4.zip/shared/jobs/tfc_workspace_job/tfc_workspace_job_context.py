from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.database_manager import DatabaseManager
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob


class TFCWorkspaceJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.watermark_manager: Optional[WatermarkManagerBlob] = None
        self.workspace_current_watermark: Optional[str] = None
        self.workspace_new_watermark: Optional[str] = None
        self.workspaces: List[any] = []
        self.pending_workspaces_list = {}
        self.database_manager: Optional[DatabaseManager] = None