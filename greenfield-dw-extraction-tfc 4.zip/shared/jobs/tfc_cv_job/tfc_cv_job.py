import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_cv_job.steps.download_extract_store_step import DownloadExtractStoreCVStep
from shared.jobs.tfc_cv_job.steps.extract_run_from_blob_step import ExtractRunFromBlobStep
from shared.jobs.tfc_cv_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_cv_job.tfc_cv_job_context import TFCCVJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="TFCConfigurationVersionJob")


class TFCCVJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCCVJobContext = None

    _extract_run_from_blob_step: ExtractRunFromBlobStep = None
    _download_extract_store_cv_step: DownloadExtractStoreCVStep = None
    _teardown_step: TeardownStep = None

    class States(statesman.StateEnum):
        start = "start"
        extract_run_from_blob = "extract_run_from_blob"
        download_extract_store_cv = "download_extract_store_cv"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCCVJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._extract_run_from_blob_step = ExtractRunFromBlobStep(
            config=self._job_config, context=self._context)
        self._download_extract_store_cv_step = DownloadExtractStoreCVStep(
            config=self._job_config, context=self._context)
        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)

    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("extract_run_from_blob")

    @statesman.event(States.start, States.extract_run_from_blob)
    async def extract_run_from_blob(self) -> None:
        logger.info(f"{self.__class__.__name__} is extracting run from blob")
        await self._extract_run_from_blob_step.execute()
        await self.trigger_event("download_extract_store_cv")

    @statesman.event(States.extract_run_from_blob, States.download_extract_store_cv)
    async def download_extract_store_cv(self) -> None:
        logger.info(f"{self.__class__.__name__} is started to download,extract and store")
        await self._download_extract_store_cv_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.download_extract_store_cv, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is tearing down")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
