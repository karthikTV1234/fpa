from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager


class TFCCVJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.configuration_versions: List[str] = []
