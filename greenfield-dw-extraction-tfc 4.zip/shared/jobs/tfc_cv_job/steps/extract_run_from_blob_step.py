from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_cv_job.tfc_cv_job_context import TFCCVJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time


logger = setup_logger(name="ExtractRunFromBlobStep")


class ExtractRunFromBlobStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCCVJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        directory = "raw_data/run"
        all_data = []
        unique_cv_ids = set()  # Use a set to eliminate duplicates automatically
        try:
            # Get a list of all JSON files in the directory
            json_files = self.context.azure_blob_manager.list_files(directory_name=directory)
            json_files = [f for f in json_files if f.endswith(".json")]
            for filename in json_files:
                # Extract JSON data from each file
                data = self.context.azure_blob_manager.read_json_from_blob(
                    directory_name=directory,
                    file_path=filename
                )
                if isinstance(data, list):  # If the file contains a list of dictionaries
                    all_data.extend(data)
                elif isinstance(data, dict):  # If the file contains a single dictionary
                    all_data.append(data)
                else:
                    logger.warning(f"Unexpected data format in file: {filename}")

            if all_data:
                # Extract unique configuration version IDs
                for run in all_data:
                    cv_id = (
                        run.get("relationships", {})
                        .get("configuration-version", {})
                        .get("data", {})
                        .get("id")
                    )
                    if cv_id:
                        unique_cv_ids.add(cv_id)  # Add to the set to ensure uniqueness

                # Convert the set to a list
                unique_cv_ids_list = list(unique_cv_ids)
                self.context.configuration_versions = unique_cv_ids_list
                logger.info(f"Extracted {len(unique_cv_ids_list)} unique configuration version IDs.")
            else:
                logger.info(f"Read data from {len(json_files)} JSON files in {directory}. Unique CV IDs extracted.")
        except Exception as e:
            logger.error(f"Error in extracting runs: {e}")
            self.context.configuration_versions = []
