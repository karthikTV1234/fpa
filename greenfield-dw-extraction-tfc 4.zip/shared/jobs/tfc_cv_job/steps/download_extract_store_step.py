import json
import tarfile
from datetime import datetime
from io import BytesIO

import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_cv_job.tfc_cv_job_context import TFCCVJobContext
from shared.utils.hcl_parser import parse_terraform_lock
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="DownloadExtractStoreCVStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None):
    """
    Makes an API request. Retries on receiving specific errors.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, allow_redirects=True, stream=True)
    return response


class DownloadExtractStoreCVStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCCVJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        """
        Fetches the .tar.gz file from the API, extracts its content, and processes required files.

        """
        base_url = self.config.tfc_endpoint_base_url
        headers = {
            'Authorization': f'Bearer  {self.config.tfc_api_key}'
        }
        for cv_id in self.context.configuration_versions:
            url = f"{base_url}/configuration-versions/{cv_id}/download"
            logger.info("Starting file download.")
            response = make_api_request(url, headers=headers)
            logger.info("File downloaded successfully.")

            tar_gz_memory_file = BytesIO(response.content)

            modules_data = {}
            providers_data = {}

            # Extract and process the file content
            logger.info("Extracting file contents.")
            with tarfile.open(fileobj=tar_gz_memory_file, mode='r:gz') as archive:
                file_list = archive.getnames()

                # Process .terraform.lock.hcl if present
                if ".terraform.lock.hcl" in file_list:
                    logger.info(".terraform.lock.hcl file found!")

                    # Extract the specific file to memory
                    lock_file_content = archive.extractfile(".terraform.lock.hcl").read()

                    # Parse the file and write the JSON
                    providers_data = parse_terraform_lock(lock_file_content)
                    if providers_data:
                        for provider in providers_data:
                            provider["cv_id"] = cv_id
                else:
                    logger.warning(".terraform.lock.hcl file not found.")

                # Check for .terraform folder and modules.json
                terraform_folder = ".terraform"
                if any(name.startswith(terraform_folder) for name in file_list):
                    logger.info(".terraform folder found!")

                    modules_file_path = f"{terraform_folder}/modules/modules.json"
                    if modules_file_path in file_list:
                        logger.info(f"modules.json file found inside {terraform_folder} folder!")

                        # Extract the modules.json file to memory
                        modules_file_content = archive.extractfile(modules_file_path).read().decode("utf-8")
                        # Parse JSON and write to context
                        modules_data = json.loads(modules_file_content)
                        if modules_data:
                            for module in modules_data["Modules"]:
                                module["cv_id"] = cv_id
                    else:
                        logger.warning("modules.json file not found inside .terraform folder.")
                else:
                    logger.warning(".terraform folder not found.")

            # Store extracted data if either modules_data or providers_data is not empty
            if modules_data or providers_data:
                self.store_data(modules_data, providers_data, cv_id)
            else:
                logger.info("No data to store for configuration version: %s", cv_id)

    def store_data(self, modules, providers, cv_id):
        """
        Stores the extracted modules and providers data to Azure Blob Storage.
        """
        current_date_timestamp = datetime.now().strftime('%Y_%m_%d_%H%M%S')
        directory_module = f"{self.config.dw_tfc_home_directory}/cv/module"
        directory_provider = f"{self.config.dw_tfc_home_directory}/cv/provider"
        file_module = f"module_{cv_id}_{current_date_timestamp}.json"
        file_provider = f"provider_{cv_id}_{current_date_timestamp}.json"

        if modules:
            self.context.azure_blob_manager.upload_object(
                obj=modules, directory_name=directory_module, file_path=file_module)
        else:
            logger.info("No module data to store for configuration version: %s", cv_id)

        if providers:
            self.context.azure_blob_manager.upload_object(
                obj=providers, directory_name=directory_provider, file_path=file_provider)
        else:
            logger.info("No provider data to store for configuration version: %s", cv_id)
