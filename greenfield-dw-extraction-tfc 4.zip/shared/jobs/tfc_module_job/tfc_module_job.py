import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_module_job.steps.fetch_module_step import FetchModuleStep
from shared.jobs.tfc_module_job.steps.get_module_current_watermark_step import GetModuleCurrentWatermarkStep
from shared.jobs.tfc_module_job.steps.store_module_step import StoreModuleStep
from shared.jobs.tfc_module_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_module_job.steps.update_module_watermark_step import UpdateModuleWatermarkStep
from shared.jobs.tfc_module_job.tfc_module_job_context import TFCModuleJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="TFCModuleJob")


class TFCModuleJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCModuleJobContext = None

    _get_module_current_watermark_step: GetModuleCurrentWatermarkStep = None
    _fetch_step: FetchModuleStep = None
    _store_step: StoreModuleStep = None
    _teardown_step: TeardownStep = None
    _update_module_new_watermark_step: UpdateModuleWatermarkStep = None

    class States(statesman.StateEnum):
        start = "start"
        get_current_watermark = "get_current_watermark"
        fetch_module = "fetch_module"
        store_module = "store_module"
        update_watermark = "update_watermark"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCModuleJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._context.watermark_manager = WatermarkManagerBlob(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name,
            blob_name=self._config_loader.tfc_extraction_job_config.tfc_module_watermark_blob_name
        )

        self._get_module_current_watermark_step = GetModuleCurrentWatermarkStep(
            config=self._job_config, context=self._context)
        self._fetch_step = FetchModuleStep(
            config=self._job_config, context=self._context)
        self._store_step = StoreModuleStep(
            config=self._job_config, context=self._context)
        self._update_module_new_watermark_step = UpdateModuleWatermarkStep(
            config=self._job_config, context=self._context)
        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)

    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("get_current_watermark")

    @statesman.event(States.start, States.get_current_watermark)
    async def get_current_watermark(self) -> None:
        logger.info(
            f"{self.__class__.__name__} is retrieving current watermark")
        await self._get_module_current_watermark_step.execute()
        await self.trigger_event("fetch_module")

    @statesman.event(States.get_current_watermark, States.fetch_module)
    async def fetch_module(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching module")
        await self._fetch_step.execute()
        await self.trigger_event("store_module")

    @statesman.event(States.fetch_module, States.store_module)
    async def store_module(self) -> None:
        logger.info(f"{self.__class__.__name__} is storing module")
        await self._store_step.execute()
        await self.trigger_event("update_watermark")

    @statesman.event(States.store_module, States.update_watermark)
    async def update_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is updating new watermark")
        await self._update_module_new_watermark_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.update_watermark, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is tearing down")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
