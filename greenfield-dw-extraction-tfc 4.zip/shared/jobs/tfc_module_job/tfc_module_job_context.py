from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob


class TFCModuleJobContext:
    def __init__(self):
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.watermark_manager: Optional[WatermarkManagerBlob] = None
        self.module_current_watermark: Optional[str] = None
        self.module_new_watermark: Optional[str] = None
        self.modules: List[any] = []
