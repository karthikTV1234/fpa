import json

import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_module_job.tfc_module_job_context import TFCModuleJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchModuleStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchModuleStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCModuleJobContext):
        self.config = config
        self.context = context

    def _fetch_paginated_module(self, api_url, api_token, page_size=100, page_number=None):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{api_url}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # API Call parameters
        params = {
            'page[number]': page_number,
            'page[size]': page_size
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        module_data = data.get("data", [])
        modules = [item for item in module_data]
        return modules

    @measure_time
    async def execute(self):
        watermark = self.context.module_current_watermark
        all_data = []
        # Loop through all organizations and fetch modules for each one
        organizations = json.loads(self.config.organizations)

        for org in organizations:
            org_id = org.get('org_id')
            org_token = org.get('org_token')

            if not org_id or not org_token:
                logger.warn(f"Skipping invalid organization: {org}")
                continue

            api_url = f"organizations/{org_id}/registry-modules"
            page_number = 1
            page_size = self.config.tfc_module_max_page_size
            stop_fetching = False
            while not stop_fetching:
                try:
                    modules = self._fetch_paginated_module(api_url, org_token, page_size, page_number)
                    if not modules:
                        logger.warn(f"No more modules to fetch for organization {org_id}.")
                        break
                    for module in modules:
                        updated_at = module["attributes"]["updated-at"]
                        if watermark and updated_at <= watermark:
                            logger.info(
                                f"Reached previously fetched module, watermark={watermark}. Stopping.")
                            stop_fetching = True
                            break
                        all_data.append(module)

                    # Move to the next page
                    page_number += 1

                except requests.exceptions.RequestException as e:
                    logger.error(f"Error fetching modules for org {org_id}, page {page_number}: {e}")
                    break
        # After fetching, store the last watermark for future reference
        if all_data:
            new_watermark = max(item['attributes']['updated-at']
                                for item in all_data)
            self.context.module_new_watermark = new_watermark
        self.context.modules = all_data
