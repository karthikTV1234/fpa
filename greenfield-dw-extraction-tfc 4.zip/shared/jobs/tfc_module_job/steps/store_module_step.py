from datetime import datetime

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_module_job.tfc_module_job_context import TFCModuleJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time

logger = setup_logger(name="StoreModuleStep")


class StoreModuleStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCModuleJobContext):
        self.config = config
        self.context = context

    @measure_time
    async def execute(self):
        obj = self.context.modules
        if len(obj) == 0:
            logger.info(f"zero modules fetched, hence skipping storage")
            return
        current_date_timestamp = datetime.now().strftime('%Y_%m_%d_%H%M%S')
        directory = f"{self.config.dw_tfc_home_directory}/module"
        file = f"module_{current_date_timestamp}.json"
        obj = self.context.modules

        self.context.azure_blob_manager.upload_object(
            obj=obj, directory_name=directory, file_path=file)
