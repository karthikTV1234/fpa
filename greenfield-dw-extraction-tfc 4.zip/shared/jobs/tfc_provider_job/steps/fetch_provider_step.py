import requests

from shared.config_loader.config_loader import TFCExtractionJobConfig
from shared.jobs.tfc_provider_job.tfc_provider_job_context import TFCProviderJobContext
from shared.utils.logger_setup import setup_logger
from shared.utils.measure_time_decorator import measure_time
from shared.utils.retry_too_many_request_decorator import retry_on_429

logger = setup_logger(name="FetchProviderStep")


@retry_on_429(max_retries=5)
def make_api_request(url, headers=None, params=None):
    """
    Makes an API request with optional headers and query parameters.
    Retries on receiving a 429 status code.

    :param url: API endpoint URL.
    :param headers: Dictionary of HTTP headers.
    :param params: Dictionary of query parameters.
    :return: HTTP response object.
    """
    response = requests.get(url, headers=headers, params=params)
    return response


class FetchProviderStep:
    def __init__(self, config: TFCExtractionJobConfig, context: TFCProviderJobContext):
        self.config = config
        self.context = context

    def _fetch_paginated_provider(self, api_url, api_token, page_size=100, page_number=None):
        base_url = self.config.tfc_endpoint_base_url
        url = f"{base_url}/{api_url}"
        headers = {
            'Authorization': f'Bearer {api_token}'
        }
        # API Call parameters
        params = {
            'page[number]': page_number,
            'page[size]': page_size
        }
        # Assuming 'make_api_request' is a helper function for making the request
        response = make_api_request(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        providers_data = data.get("data", [])
        providers = [item for item in providers_data]
        return providers

    @measure_time
    async def execute(self):
        watermark = self.context.provider_new_watermark
        all_data = []
        api_url = "organizations/AssurantOrg1/registry-providers"
        provider_token = "XiUPqzrKnSNsGA.atlasv1.luyEGVwQ3L0RWFSJbHcqm6OjzrZ46yxpY2y3xs9crTcukUGaWJFpwDF1KnXTQoNUoAo"
        page_number = 1
        page_size = self.config.tfc_provider_max_page_size
        stop_fetching = False
        while not stop_fetching:
            try:
                providers = self._fetch_paginated_provider(api_url, provider_token, page_size, page_number)
                if not providers:
                    logger.warn(f"No more provider to fetch")
                    break
                for provider in providers:
                    updated_at = provider["attributes"]["updated-at"]
                    if watermark and updated_at <= watermark:
                        logger.info(
                            f"Reached previously fetched provider, watermark={watermark}. Stopping.")
                        stop_fetching = True
                        break
                    all_data.append(provider)

                # Move to the next page
                page_number += 1

            except requests.exceptions.RequestException as e:
                logger.error(f"Error fetching provider, page {page_number}: {e}")
                break

        # After fetching, store the last watermark for future reference
        if all_data:
            new_watermark = max(item['attributes']['updated-at']
                                for item in all_data)
            self.context.provider_new_watermark = new_watermark
        self.context.providers = all_data
