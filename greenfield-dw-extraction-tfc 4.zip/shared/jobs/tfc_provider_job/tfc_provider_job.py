import statesman

from shared.config_loader.config_loader import ConfigLoader, TFCExtractionJobConfig
from shared.jobs.tfc_provider_job.steps.fetch_provider_step import FetchProviderStep
from shared.jobs.tfc_provider_job.steps.get_provider_current_watermark_step import GetProviderCurrentWatermarkStep
from shared.jobs.tfc_provider_job.steps.store_provider_step import StoreProviderStep
from shared.jobs.tfc_provider_job.steps.teardown_step import TeardownStep
from shared.jobs.tfc_provider_job.steps.update_provider_watermark_step import UpdateProviderWatermarkStep
from shared.jobs.tfc_provider_job.tfc_provider_job_context import TFCProviderJobContext
from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="TFCProviderJob")


class TFCProviderJob(statesman.StateMachine):
    _config_loader: ConfigLoader = None
    _job_config: TFCExtractionJobConfig = None
    _context: TFCProviderJobContext = None

    _fetch_provider_step: FetchProviderStep = None
    _store_provider_step: StoreProviderStep = None
    _fetch_watermark_step: GetProviderCurrentWatermarkStep = None
    _update_watermark_step: UpdateProviderWatermarkStep = None
    _teardown_step: TeardownStep = None

    class States(statesman.StateEnum):
        start = "start"
        get_current_watermark = "get_current_watermark"
        fetch_provider = "fetch_provider"
        store_provider = 'store_provider'
        update_watermark = "update_watermark"
        teardown = "teardown"
        end = "end"

    def initialize(self):
        self._config_loader = ConfigLoader()
        self._context = TFCProviderJobContext()
        self._job_config = self._config_loader.tfc_extraction_job_config

        self._context.azure_blob_manager = AzureBlobContainerManager(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name)

        self._context.watermark_manager = WatermarkManagerBlob(
            connection_string=self._config_loader.tfc_extraction_job_config.azure_connection_str,
            container_name=self._config_loader.tfc_extraction_job_config.dw_container_name,
            blob_name=self._config_loader.tfc_extraction_job_config.tfc_provider_watermark_blob_name
        )

        self._fetch_watermark_step = GetProviderCurrentWatermarkStep(config=self._job_config, context=self._context)
        self._update_watermark_step = UpdateProviderWatermarkStep(config=self._job_config, context=self._context)

        self._fetch_provider_step = FetchProviderStep(
            config=self._job_config, context=self._context)

        self._store_provider_step = StoreProviderStep(
            config=self._job_config, context=self._context)

        self._teardown_step = TeardownStep(
            config=self._job_config, context=self._context)

    @statesman.event(None, States.start)
    async def start(self) -> None:
        logger.info(f"{self.__class__.__name__} has started")
        await self.trigger_event("get_current_watermark")

    @statesman.event(States.start, States.get_current_watermark)
    async def get_current_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is retrieving current watermark")
        await self._fetch_watermark_step.execute()
        await self.trigger_event("fetch_provider")

    @statesman.event(States.get_current_watermark, States.fetch_provider)
    async def fetch_provider(self) -> None:
        logger.info(f"{self.__class__.__name__} is fetching fetch_provider")
        await self._fetch_provider_step.execute()
        await self.trigger_event("store_provider")

    @statesman.event(States.fetch_provider, States.store_provider)
    async def store_provider(self) -> None:
        logger.info(f"{self.__class__.__name__} is store store_provider")
        await self._store_provider_step.execute()
        await self.trigger_event("update_watermark")

    @statesman.event(States.store_provider, States.update_watermark)
    async def update_watermark(self) -> None:
        logger.info(f"{self.__class__.__name__} is update_watermark")
        await self._update_watermark_step.execute()
        await self.trigger_event("teardown")

    @statesman.event(States.update_watermark, States.teardown)
    async def teardown(self) -> None:
        logger.info(f"{self.__class__.__name__} is teardown")
        await self._teardown_step.execute()
        await self.trigger_event("end")

    @statesman.event(States.teardown, States.end)
    async def end(self) -> None:
        logger.info(f"{self.__class__.__name__} has ended")
