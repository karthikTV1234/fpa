from typing import Optional, List

from shared.utils.azure_blob_container import AzureBlobContainerManager
from shared.utils.logger_setup import setup_logger
from shared.utils.watermark_manager.watermark_manager_blob import WatermarkManagerBlob

logger = setup_logger(name="TFCProviderJobContext")


class TFCProviderJobContext:
    def __init__(self):
        logger.info("Class TFCProviderJobContext init")
        self.azure_blob_manager: Optional[AzureBlobContainerManager] = None
        self.watermark_manager: Optional[WatermarkManagerBlob] = None
        self.provider_current_watermark: Optional[str] = None
        self.provider_new_watermark: Optional[str] = None
        self.providers: List[any] = []
