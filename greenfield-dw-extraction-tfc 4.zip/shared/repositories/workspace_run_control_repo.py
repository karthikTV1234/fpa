from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from shared.models.control_table import WorkspaceRunControl
from shared.repositories.base_repo import BaseRepo
from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="WorkspaceRunControlRepo")

class WorkspaceRunControlRepo(BaseRepo):
    def __init__(self, session: Session):
        super().__init__(session, WorkspaceRunControl)

    def insert_workspace_run(self, workspace_id, run_id, workspace_status, run_status):
        new_record = WorkspaceRunControl(
            workspace_id=workspace_id,
            run_id=run_id,
            workspace_status=workspace_status,
            run_status=run_status
        )

        try:
            self.session.add(new_record)
            self.session.commit()
            print("Record inserted successfully!")

        except IntegrityError:
            self.session.rollback()  # Rollback transaction to prevent corruption
            print(f"Duplicate entry found for (workspace_id={workspace_id}, run_id={run_id})")

    def insert_if_not_exists(self, workspace_id, run_id, workspace_status, run_status):
        existing_record = self.session.query(WorkspaceRunControl).filter_by(
            workspace_id=workspace_id, run_id=run_id
        ).first()

        if existing_record:
            print(f"Record already exists: (workspace_id={workspace_id}, run_id={run_id})")
            return

        # Insert new record if it doesn't exist
        new_record = WorkspaceRunControl(
            workspace_id=workspace_id,
            run_id=run_id,
            workspace_status=workspace_status,
            run_status=run_status
        )
        self.session.add(new_record)
        self.session.commit()
        logger.log("New record inserted to control table!")
