from sqlalchemy import inspect
from sqlalchemy.orm import Session


class BaseRepo:
    def __init__(self, session: Session, model_class):
        self.session = session
        self.model_class = model_class

    def add(self, instance):
        """Add an instance to the session"""
        self.session.add(instance)
        self.session.commit()

    def get_by_id(self, model, id_):
        """Fetch an instance by its ID"""
        return self.session.query(model).filter_by(id=id_).first()

    def get_all(self, model):
        """Fetch all instances of a model"""
        return self.session.query(model).all()

    def delete(self, instance):
        """Delete an instance from the session"""
        self.session.delete(instance)
        self.session.commit()

    def update(self, filter_criteria, update_data):
        """
        Generic update method for any model.

        :param filter_criteria: A condition to filter the records to update.
        :param update_data: A dictionary containing the field names and their new values.
        :return: The number of records updated.
        """
        # Get the model class's columns to ensure only valid fields are updated
        valid_columns = {column.name for column in inspect(self.model_class).columns}

        # Filter out any invalid keys from the update data
        update_data = {key: value for key, value in update_data.items() if key in valid_columns}

        if not update_data:
            return 0  # No valid fields to update

        # Perform the update
        updated_count = self.session.query(self.model_class).filter(filter_criteria).update(update_data,
                                                                                            synchronize_session="fetch")
        self.session.commit()
        return updated_count

    def close(self):
        self.session.close()

