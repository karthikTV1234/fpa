import os

from shared.utils.logger_setup import setup_logger

logger = setup_logger(name="config_loader")


class ConstantConfig:
    def __init__(self):
        self.tfc_run_watermark_key = 'tfc_runs'
        self.tfc_workspace_watermark_key = 'tfc_workspace'
        self.tfc_module_watermark_key = 'tfc_module'
        self.tfc_provider_watermark_key = 'tfc_provider'


class EnvironmentConfig:
    """To load the configuration from the environment variables"""

    def __init__(self):
        self.greet_prefix = os.getenv('GREET_PREFIX')
        self.tfc_endpoint_base_url = os.getenv('TFC_ENDPOINT_BASE_URL')
        self.tfc_api_key = os.getenv('TFC_API_KEY')
        self.tfc_organizations = str(os.getenv('TFC_ORGANIZATIONS'))
        self.dw_container_name = os.getenv('DW_CONTAINER_NAME')
        self.dw_tfc_home_directory = os.getenv('DW_TFC_HOME_DIRECTORY')
        self.azure_blob_account_name = os.getenv('AZURE_BLOB_ACCOUNT_NAME')
        self.azure_blob_account_key = str(os.getenv('AZURE_BLOB_ACCOUNT_KEY'))
        self.azure_blob_endpoint = os.getenv('AZURE_BLOB_ENDPOINT')
        self.tfc_workspace_max_page_size = int(os.getenv('TFC_WORKSPACE_MAX_PAGE_SIZE'))
        self.tfc_project_max_page_size = int(os.getenv('TFC_PROJECTS_MAX_PAGE_SIZE'))
        self.tfc_team_max_page_size = int(os.getenv('TFC_TEAM_MAX_PAGE_SIZE'))
        self.tfc_run_max_page_size = int(os.getenv('TFC_RUN_MAX_PAGE_SIZE'))
        self.tfc_module_max_page_size = int(os.getenv('TFC_MODULE_MAX_PAGE_SIZE'))
        self.tfc_provider_max_page_size = int(os.getenv('TFC_PROVIDER_MAX_PAGE_SIZE'))
        self.tfc_organization_max_page_size = int(os.getenv('TFC_ORGANIZATION_MAX_PAGE_SIZE'))
        self.tfc_run_watermark_blob_name = os.getenv('TFC_RUN_WATERMARK_BLOB_NAME')
        self.tfc_workspace_watermark_blob_name = os.getenv('TFC_WORKSPACE_WATERMARK_BLOB_NAME')
        self.tfc_module_watermark_blob_name = os.getenv('TFC_MODULE_WATERMARK_BLOB_NAME')
        self.tfc_provider_watermark_blob_name = os.getenv('TFC_PROVIDER_WATERMARK_BLOB_NAME')
        self.dw_sql_db_connection_string = os.getenv('DW_SQL_DB_CONNECTION_STRING')


class TFCExtractionJobConfig:
    def __init__(self, tfc_endpoint_base_url: str, tfc_api_key: str,
                 organizations: str, dw_container_name: str, dw_tfc_home_directory: str,
                 azure_blob_account_name: str, azure_blob_account_key: str, azure_blob_endpoint: str,
                 tfc_workspace_max_page_size: int,
                 tfc_run_max_page_size: int,
                 tfc_module_max_page_size: int,
                 tfc_provider_max_page_size: int,
                 tfc_project_max_page_size: int,
                 tfc_organization_max_page_size,
                 tfc_run_watermark_blob_name: str,
                 tfc_workspace_watermark_blob_name: str,
                 tfc_module_watermark_blob_name: str,
                 tfc_provider_watermark_blob_name: str,
                 tfc_run_watermark_key: str,
                 tfc_module_watermark_key: str,
                 tfc_provider_watermark_key: str,
                 tfc_workspace_watermark_key: str,
                 dw_sql_db_connection_string:str):
        self.tfc_endpoint_base_url = tfc_endpoint_base_url
        self.tfc_api_key = tfc_api_key
        self.organizations = organizations
        self.dw_container_name = dw_container_name
        self.dw_tfc_home_directory = dw_tfc_home_directory
        self.azure_blob_account_name = azure_blob_account_name
        self.azure_blob_account_key = azure_blob_account_key
        self.azure_blob_endpoint = azure_blob_endpoint
        self.azure_connection_str = f"DefaultEndpointsProtocol=http;AccountName={self.azure_blob_account_name};AccountKey={self.azure_blob_account_key};BlobEndpoint={self.azure_blob_endpoint}"
        self.tfc_workspace_min_page_size = 20
        self.tfc_workspace_max_page_size = tfc_workspace_max_page_size
        self.tfc_run_max_page_size = tfc_run_max_page_size
        self.tfc_module_max_page_size = tfc_module_max_page_size
        self.tfc_provider_max_page_size = tfc_provider_max_page_size
        self.tfc_project_max_page_size = tfc_project_max_page_size
        self.tfc_organization_max_page_size = tfc_organization_max_page_size
        self.tfc_run_watermark_blob_name = tfc_run_watermark_blob_name
        self.tfc_workspace_watermark_blob_name = tfc_workspace_watermark_blob_name
        self.tfc_module_watermark_blob_name = tfc_module_watermark_blob_name
        self.tfc_provider_watermark_blob_name = tfc_provider_watermark_blob_name
        self.tfc_run_watermark_key = tfc_run_watermark_key
        self.tfc_module_watermark_key = tfc_module_watermark_key
        self.tfc_provider_watermark_key = tfc_provider_watermark_key
        self.tfc_workspace_watermark_key = tfc_workspace_watermark_key
        self.dw_sql_db_connection_string = dw_sql_db_connection_string


class ConfigLoader:
    def __init__(self):
        self.env_config = EnvironmentConfig()
        self.constant = ConstantConfig()
        self.tfc_extraction_job_config = TFCExtractionJobConfig(
            tfc_endpoint_base_url=self.env_config.tfc_endpoint_base_url,
            tfc_api_key=self.env_config.tfc_api_key,
            organizations=self.env_config.tfc_organizations,
            dw_container_name=self.env_config.dw_container_name,
            dw_tfc_home_directory=self.env_config.dw_tfc_home_directory,
            azure_blob_account_name=self.env_config.azure_blob_account_name,
            azure_blob_account_key=self.env_config.azure_blob_account_key,
            azure_blob_endpoint=self.env_config.azure_blob_endpoint,
            tfc_workspace_max_page_size=self.env_config.tfc_workspace_max_page_size,
            tfc_run_max_page_size=self.env_config.tfc_run_max_page_size,
            tfc_module_max_page_size=self.env_config.tfc_module_max_page_size,
            tfc_provider_max_page_size=self.env_config.tfc_provider_max_page_size,
            tfc_project_max_page_size=self.env_config.tfc_project_max_page_size,
            tfc_organization_max_page_size=self.env_config.tfc_organization_max_page_size,
            tfc_run_watermark_blob_name=self.env_config.tfc_run_watermark_blob_name,
            tfc_workspace_watermark_blob_name=self.env_config.tfc_workspace_watermark_blob_name,
            tfc_module_watermark_blob_name=self.env_config.tfc_module_watermark_blob_name,
            tfc_provider_watermark_blob_name=self.env_config.tfc_provider_watermark_blob_name,
            tfc_run_watermark_key=self.constant.tfc_run_watermark_key,
            tfc_module_watermark_key=self.constant.tfc_module_watermark_key,
            tfc_provider_watermark_key=self.constant.tfc_provider_watermark_key,
            tfc_workspace_watermark_key=self.constant.tfc_workspace_watermark_key,
            dw_sql_db_connection_string=self.env_config.dw_sql_db_connection_string
        )

    def __str__(self):
        return f"ConfigLoader"
