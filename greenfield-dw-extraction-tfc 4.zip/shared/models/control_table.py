from sqlalchemy import Column, Integer, String, UniqueConstraint

from shared.models.base import Base


class WorkspaceRunControl(Base):
    __tablename__ = 'workspace_run_control'

    id = Column(Integer, primary_key=True, autoincrement=True)
    workspace_id = Column(String(255), nullable=False)
    run_id = Column(String(255), nullable=False)
    workspace_status = Column(Integer, nullable=False)
    run_status = Column(Integer, nullable=False)

    # Unique constraint to prevent duplicate (workspace_id, run_id) pairs
    __table_args__ = (UniqueConstraint('workspace_id', 'run_id', name='uq_workspace_run'),)
