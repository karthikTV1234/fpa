#greenfield-dw-extraction-tfc

This repository contains the code for an Azure Function written in Python. The function is designed to systematically fetch and analyze Terraform operational data to gain insights and enhance decision-making. It extracts workspace, plan, apply, module, and provider data from Terraform APIs and processes it through Azure services to store the data in a structured format for analysis and visualization.

## Table of Contents

- [Project Overview](#project-overview)
- [Prerequisites](#prerequisites)
- [Setup Instructions](#setup-instructions)
- [Configuration](#configuration)
- [Local Development](#local-development)
- [Docker Setup](#docker-setup)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [References](#references)

## Project Overview

This Azure Function fetches data from Terraform APIs to extract information about workspaces, plans, applies, modules, and providers. APIs for each data source provide relevant information about infrastructure usage, configuration, and performance metrics. Each source has distinct API endpoints to retrieve specific data, such as workspace count, module usage, and provider versions.

### List of API Endpoints for Data Extraction
- `GET /organizations/:organization_name/workspaces` - Retrieves the count of workspaces.
- `GET /api/v2/organizations/:organization_name/run` - Fetches the count of plans/applies.
- `GET /api/v2/organizations/:organization_name/project` - Fetches the count of projects.
- `GET /api/v2/configuration-versions/configuration-versions-id/download` - Retrieves Terraform module and provider usage with versions.
- `GET /organizations/:organization_name/registry-providers` - Fetches the list of providers.
- `GET /organizations/:organization_name/registry-modules` - Fetches the list of modules.

These API endpoints enable efficient data collection, which is further processed, stored, and visualized using Azure services.

## Prerequisites

- Python 3.8+ installed on your local machine.
- [Azure Functions Core Tools](https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local#install-the-azure-functions-core-tools) installed.
- An active Azure subscription.
- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) installed for deploying to Azure.
- [Docker](https://docs.docker.com/get-docker/) installed for containerized execution.

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/azure-function-python.git
   cd azure-function-python
   ```

2. Set up a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows, use `.venv\Scripts\activate`
   pip install -r requirements.txt
   ```

## Configuration

1. Create a `local.settings.json` file in the root directory with the following structure:
   ```json
    {
    "IsEncrypted": false,
    "Values": {
        "FUNCTIONS_WORKER_RUNTIME": "<Enter Functions Worker Runtime>",
        "AzureWebJobsFeatureFlags": "<Enter Azure Web Jobs Feature Flags>",
        "AzureWebJobsStorage": "<Enter Azure Web Jobs Storage Connection String>",
        "TFC_ENDPOINT_BASE_URL": "<Enter Terraform Cloud Endpoint Base URL>",
        "AZURE_BLOB_ACCOUNT_NAME": "<Enter Azure Blob Account Name>",
        "AZURE_BLOB_ACCOUNT_KEY": "<Enter Azure Blob Account Key>",
        "AZURE_BLOB_ENDPOINT": "<Enter Azure Blob Endpoint>",
        "TFC_ORGANIZATIONS": "<Enter Terraform Cloud Organizations (JSON Array)>",
        "TFC_API_KEY": "<Enter Terraform Cloud API Key>",
        "TFC_PROJECTS_MAX_PAGE_SIZE": "<Enter Terraform Cloud Projects Max Page Size>",
        "TFC_TEAM_MAX_PAGE_SIZE": "<Enter Terraform Cloud Team Max Page Size>",
        "TFC_RUN_MAX_PAGE_SIZE": "<Enter Terraform Cloud Run Max Page Size>",
        "TFC_MODULE_MAX_PAGE_SIZE": "<Enter Terraform Cloud Module Max Page Size>",
        "TFC_WORKSPACE_MAX_PAGE_SIZE": "<Enter Terraform Cloud Workspace Max Page Size>",
        "TFC_ORGANIZATION_MAX_PAGE_SIZE": "<Enter Terraform Cloud Organization Max Page Size>",
        "DW_CONTAINER_NAME": "<Enter Data Warehouse Container Name>",
        "DW_TFC_HOME_DIRECTORY": "<Enter Data Warehouse Terraform Cloud Home Directory>",
        "TFC_RUN_WATERMARK_BLOB_NAME": "<Enter Terraform Cloud Run Watermark Blob Name>",
        "TFC_WORKSPACE_WATERMARK_BLOB_NAME": "<Enter Terraform Cloud Workspace Watermark Blob Name>",
        "TFC_MODULE_WATERMARK_BLOB_NAME": "<Enter Terraform Cloud Module Watermark Blob Name>",
        "TFC_PROVIDER_WATERMARK_BLOB_NAME": "<Enter Terraform Cloud Provider Watermark Blob Name>"
    }
    }
   ```

Replace the placeholder values with your actual Terraform credentials.

## Local Development

To run the function locally:

1. Start the Azure Functions runtime:
   ```bash
   func start
   ```

2. Navigate to `http://localhost:7071/api/[FunctionName]` to trigger the function.

## Docker Setup

To run the function inside a Docker container:

1. Build the Docker image:
   ```bash
   docker build -t azure-function-app .
   ```

2. Run the container:
   ```bash
   docker run -p 7071:7071 -v $(pwd)/local.settings.json:/app/local.settings.json azure-function-app
   ```

### Using Docker Compose

For easier setup, use Docker Compose:

1. Create a `docker-compose.yml` file with the following content:
   ```yaml
   version: '3.8'
   services:
     azure-function:
       build: .
       ports:
         - "7071:7071"
       volumes:
         - ./local.settings.json:/app/local.settings.json
   ```

2. Start the container:
   ```bash
   docker-compose up --build
   ```

This will set up and run the function in a containerized environment.

## Testing

You can use tools like Postman or `curl` to test the function locally or after deployment.

For example:
   ```bash
   curl -X GET http://localhost:7071/api/[FunctionName]
   ```

Replace `[FunctionName]` with the name of your function.

## Troubleshooting

1. Check the Azure Functions logs:
   ```bash
   func azure functionapp logstream [FunctionAppName] 
   ```

2. Ensure all environment variables are correctly set in `local.settings.json` and in the Azure Portal (under "Configuration" for the Function App).

3. Check the Docker logs if running in a container:
   ```bash
   docker logs [container_id]
   ```

## References

1. [Azure Functions Documentation](https://docs.microsoft.com/en-us/azure/azure-functions/)
2. [Azure Python SDK](https://docs.microsoft.com/en-us/python/azure/)
3. [Docker Documentation](https://docs.docker.com/)
4. [Terraform API Documentation](https://developer.hashicorp.com/terraform/cloud-docs/api)

