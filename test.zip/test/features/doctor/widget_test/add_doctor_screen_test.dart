import 'package:child_health_story/features/doctor/data/model/response/doctor_speciality_list_res_model.dart';
import 'package:child_health_story/features/doctor/presentation/add_doctor_screen.dart';
import 'package:child_health_story/features/hospital/data/model/hospital_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';


class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockDoctorBloc = MockDoctorBloc();
    mockHospitalBloc = MockHospitalBloc();

    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockDoctorBloc.isUIUpdated).thenReturn(true);
    when(() => mockDoctorBloc.hospitalList).thenReturn([]);
    when(() => mockDoctorBloc.doctorSpecialtyList).thenReturn([]);
    when(() => mockDoctorBloc.selectedCountryCode).thenReturn('+91');

  });


  Future<void> pumpAddDoctorDialog(WidgetTester tester, {
    DoctorBloc? doctorBloc,
    HospitalBloc? hospitalBloc,
  }) async {
    final usedDoctorBloc = doctorBloc ?? mockDoctorBloc;
    final usedHospitalBloc = hospitalBloc ?? mockHospitalBloc;

    when(() => usedDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => usedHospitalBloc.state).thenReturn(HospitalInitial());
    when(() => usedDoctorBloc.isUIUpdated).thenReturn(true);
    when(() => usedDoctorBloc.hospitalList).thenReturn([]);
    when(() => usedDoctorBloc.doctorSpecialtyList).thenReturn([]);
    when(() => usedDoctorBloc.selectedCountryCode).thenReturn('+91');

    await tester.pumpWidget(
      MultiBlocProvider(
        providers: [
          BlocProvider<DoctorBloc>.value(value: usedDoctorBloc),
          BlocProvider<HospitalBloc>.value(value: usedHospitalBloc),
        ],
        child: MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(size: Size(1080, 1920)),
            child: Scaffold(
              body: SizedBox(
                width: 600,
                child: const AddDoctorDialog(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  testWidgets(
    'renders AddDoctorDialog with Add Doctor button',
        (tester) async {
          await pumpAddDoctorDialog(tester);

          expect(find.text(AppStrings.addNewDoctor), findsOneWidget);
          expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
          expect(find.text(AppStrings.doctorNameLabel), findsOneWidget);
          expect(find.text(AppStrings.specialityLabel), findsOneWidget);
          expect(find.text(AppStrings.phoneLabelWithOutAsterisk), findsOneWidget);
          expect(find.text(AppStrings.emailLabel), findsOneWidget);
          expect(find.text(AppStrings.notesLabelWithOutAsterisk), findsOneWidget);
          expect(find.text(AppStrings.addDoctorBtnText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await pumpAddDoctorDialog(tester);
    await tester.tap(find.text(AppStrings.addDoctorBtnText));
    await tester.pumpAndSettle();
    expect(find.textContaining('required'), findsWidgets);
  });

  testWidgets('shows snackbar when doctor add fails', (tester) async {
    whenListen(
      mockDoctorBloc,
      Stream.fromIterable([
        DoctorLoading(),
        DoctorFailure('Failed to save doctor'),
      ]),
      initialState: DoctorInitial(),
    );

    await pumpAddDoctorDialog(tester);
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to save doctor'), findsOneWidget);
  });

  testWidgets('dispatches AddDoctorEvent when valid form is submitted', (tester) async {
    when(() => mockDoctorBloc.selectedHospitalId).thenReturn('hospital_1');
    when(() => mockDoctorBloc.hospitalList).thenReturn([
      HospitalListData(id: 'hospital_1', hospitalName: 'Hospital Name'),
    ]);
    when(() => mockDoctorBloc.doctorSpecialtyList).thenReturn([
      DoctorSpecialtyListData(id: 'spec_1', specialtyName: 'Cardiology'),
    ]);
    when(() => mockDoctorBloc.selectedCountryCode).thenReturn('+91');
    when(() => mockDoctorBloc.isUIUpdated).thenReturn(true);

    whenListen(mockDoctorBloc, Stream<DoctorState>.empty(), initialState: DoctorInitial());

    await pumpAddDoctorDialog(tester);

    final doctorNameField = find.widgetWithText(TextFormField, AppStrings.doctorNameLabel);
    expect(doctorNameField, findsOneWidget);
    await tester.enterText(doctorNameField, 'Dr. John');

    final addButton = find.text(AppStrings.addDoctorBtnText);
    expect(addButton, findsOneWidget);
    await tester.tap(addButton);
    await tester.pump();
  });





}
