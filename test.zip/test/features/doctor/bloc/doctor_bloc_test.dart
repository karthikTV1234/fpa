import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/doctor/data/model/request/add_doctor_req_model.dart';
import 'package:child_health_story/features/doctor/data/model/response/add_doctor_res_model.dart';
import 'package:child_health_story/features/doctor/data/model/response/doctor_list_res_model.dart';
import 'package:child_health_story/features/doctor/data/model/response/doctor_speciality_list_res_model.dart';
import 'package:child_health_story/features/doctor/data/repository/doctor_repository.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockDoctorRepository extends Mock implements DoctorRepository {}

void main() {
  late DoctorBloc bloc;
  late MockDoctorRepository mockRepository;

  setUp(() {
    mockRepository = MockDoctorRepository();
    bloc = DoctorBloc(doctorRepository: mockRepository);
  });

  const childId = 'child_123';

  final addReqModel = AddDoctorReqModel(
    childId: childId,
    doctorName: 'Dr. John',
    specialty: ['Cardiology', 'Pediatrics'],
    hospitalId: 'hospital_123',
    phone: '9876543210',
    email: 'dr.john@example.com',
    notes: 'Highly experienced',
  );

  final addDoctorRes = AddDoctorResModel(
    message: 'Doctor added successfully',
    statusCode: 200,
    data: DoctorAddData(
      id: 'doc_001',
      doctorName: 'Dr. John',
      hospitalId: 'hospital_123',
      specialty: ['Cardiology', 'Pediatrics'],
      phone: '9876543210',
      email: 'dr.john@example.com',
      notes: 'Highly experienced',
      isFavorite: false,
      createdBy: 'admin',
      childId: childId,
      userId: 'user_001',
    ),
  );

  final doctorListRes = DoctorListResModel(
    statusCode: 200,
    message: 'Success',
    data: [],
  );
  final doctorListNonEmptyRes = DoctorListResModel(
    statusCode: 200,
    message: 'Fetched successfully',
    data: [
      DoctorListData(
        id: 'doc123',
        doctorName: 'Dr. Smith',
      ),
      DoctorListData(
        id: 'doc456',
        doctorName: 'Dr. Alice',
      ),
    ],
  );

  final specialtyListEmptyRes = DoctorSpecialtyListResModel(
    message: 'Fetched successfully',
    statusCode: 200,
    data: [],
  );
  final specialtyListRes = DoctorSpecialtyListResModel(
    message: 'Fetched successfully',
    statusCode: 200,
    data: [
      DoctorSpecialtyListData(id: 'spec_1', specialtyName: 'Pediatrician'),
      DoctorSpecialtyListData(id: 'spec_2', specialtyName: 'Dermatologist'),
    ],
  );

  group('AddDoctorEvent', () {
    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addDoctor(addReqModel))
            .thenAnswer((_) async => Result.success(addDoctorRes));
        return bloc;
      },
      act: (bloc) => bloc.add(AddDoctorEvent(addDoctorReqModel: addReqModel)),
      expect: () => [
        DoctorLoading(),
        DoctorSuccess(message: 'Doctor added successfully'),
      ],
      verify: (_) {
        verify(() => mockRepository.addDoctor(addReqModel)).called(1);
      },
    );

    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addDoctor(addReqModel))
            .thenAnswer((_) async => Result.failure('Add failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(AddDoctorEvent(addDoctorReqModel: addReqModel)),
      expect: () => [
        DoctorLoading(),
        DoctorFailure('Add failed'),
      ],
    );
  });

  group('FetchDoctorListEvent', () {
    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorListSuccess] on success',
      build: () {
        when(() => mockRepository.getDoctorList())
            .thenAnswer((_) async => Result.success(doctorListRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorListEvent()),
      expect: () =>  [
        DoctorLoading(),
        DoctorListSuccess([]),
      ],
      verify: (_)  {
        verify(() => mockRepository.getDoctorList()).called(1);
      },
    );

    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorListSuccess] on success with non-empty list',
      build: () {
        when(() => mockRepository.getDoctorList())
            .thenAnswer((_) async => Result.success(doctorListNonEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorListEvent()),
      expect: () => [
        DoctorLoading(),
        isA<DoctorListSuccess>().having(
              (s) => s.doctors,
          'doctors',
          isNotEmpty,
        ),
      ],
      verify: (_) {
        verify(() => mockRepository.getDoctorList()).called(1);
      },
    );

    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorFailure] on failure',
      build: () {
        when(() => mockRepository.getDoctorList())
            .thenAnswer((_) async => Result.failure('Fetch failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorListEvent()),
      expect: () => [
        DoctorLoading(),
        DoctorFailure('Fetch failed'),
      ],
    );
  });

  group('FetchDoctorSpecialityListEvent', () {
    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorSpecialityListSuccess] on success',
      build: () {
        when(() => mockRepository.getDoctorSpecialtyList())
            .thenAnswer((_) async => Result.success(specialtyListEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorSpecialityListEvent()),
      expect: () => [
        DoctorLoading(),
        DoctorSpecialityListSuccess([]),
      ],
      verify: (_) {
        verify(() => mockRepository.getDoctorSpecialtyList()).called(1);
      },
    );

    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorSpecialityListSuccess] on success with non-empty list',
      build: () {
        when(() => mockRepository.getDoctorSpecialtyList())
            .thenAnswer((_) async => Result.success(specialtyListRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorSpecialityListEvent()),
      expect: () => [
        DoctorLoading(),
        isA<DoctorSpecialityListSuccess>().having(
              (s) => s.doctorsSpecialities,
          'specialities',
          isNotEmpty,
        ),
      ],
      verify: (_) {
        verify(() => mockRepository.getDoctorSpecialtyList()).called(1);
      },
    );


    blocTest<DoctorBloc, DoctorState>(
      'emits [DoctorLoading, DoctorFailure] on failure',
      build: () {
        when(() => mockRepository.getDoctorSpecialtyList())
            .thenAnswer((_) async => Result.failure('Failed to fetch specialties'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorSpecialityListEvent()),
      expect: () => [
        DoctorLoading(),
        DoctorFailure('Failed to fetch specialties'),
      ],
    );
  });
}
