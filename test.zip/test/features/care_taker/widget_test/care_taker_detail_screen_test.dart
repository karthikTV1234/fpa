import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_detail_res_model.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_state.dart';
import 'package:child_health_story/features/care_taker/presentation/caretaker_details_screen.dart';
import 'package:child_health_story/shared/widgets/custom_radio_list_tile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mocktail/mocktail.dart';

// Mocks and Fakes

class MockCareTakerBloc extends Mock implements CareTakerBloc {}
class MockNavigatorObserver extends Mock implements NavigatorObserver {}
class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockCareTakerBloc mockBloc;
  const careTakerId = 'care123';

  setUpAll(() {
    registerFallbackValue(DeleteCareTakerEvent(careTakerId: careTakerId));
    registerFallbackValue(FetchCareTakerByIdEvent(careTakerId: careTakerId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockCareTakerBloc();

    final testState = CareTakerByIdSuccess(
      CaretakerDetailData(name: 'Test'),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
  });

  final mockData = CaretakerDetailData(
    id: 'ct001',
    name: 'John Doe',
    email: 'johndoe@example.com',
    phoneNumber: '9876543210',
    countryCode: '+91',
    address: '123, MG Road, Bangalore, India',
    isPrimary: true,
    relationshipId: 'R001',
    relationshipName: 'Father',
  );

  testWidgets('renders care taker details when CareTakerByIdSuccess is emitted', (tester) async {
    when(() => mockBloc.state).thenReturn(CareTakerByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(CareTakerByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.careTakerDetailData).thenReturn(mockData);
    when(() => mockBloc.add(any())).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<CareTakerBloc>.value(
          value: mockBloc,
          child: const CareTakerDetailScreen(careTakerId: careTakerId),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Verify that care taker details are rendered
    expect(find.text('John Doe'), findsOneWidget);
    expect(find.text('9876543210'), findsOneWidget);
    expect(find.text('johndoe@example.com'), findsOneWidget);
    expect(find.text('Father'), findsOneWidget);
    expect(find.text('123, MG Road, Bangalore, India'), findsOneWidget);

    final radioFinder = find.byType(CustomRadioListTile);
    final radioWidget = tester.widget<CustomRadioListTile>(radioFinder);
    expect(radioWidget.groupValue, 0);
  });


  testWidgets('should show loading indicator when state is CareTakerLoading', (tester) async {
    when(() => mockBloc.state).thenReturn(CareTakerLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(CareTakerLoading()));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.careTakerDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<CareTakerBloc>.value(
          value: mockBloc,
          child: const CareTakerDetailScreen(careTakerId: careTakerId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('should show error message when state is failure', (tester) async {
    const errorMessage = 'Error loading care taker';

    when(() => mockBloc.state).thenReturn(CareTakerFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(CareTakerFailure(errorMessage)));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.careTakerDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<CareTakerBloc>.value(
              value: mockBloc,
              child: const CareTakerDetailScreen(careTakerId: careTakerId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('delete care taker and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.careTakersScreen: (_) => const Scaffold(body: Text('Care Taker List')),
            },
            home: BlocProvider<CareTakerBloc>.value(
              value: mockBloc,
              child: const CareTakerDetailScreen(careTakerId: careTakerId),
            ),
          ),
        );


        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteCareTakerTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteCareTakerConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteCareTakerEvent(careTakerId: careTakerId))).called(1);

        final successState = CareTakerSuccess(message: 'Care Taker deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });

}
