import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/care_taker/presentation/add_care_taker_screen.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockCareTakerBloc extends MockBloc<CareTakerEvent, CareTakerState> implements CareTakerBloc {}
class FakeCareTakerEvent extends Fake implements CareTakerEvent {}
class FakeCareTakerState extends Fake implements CareTakerState {}

void main() {
  late MockCareTakerBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeCareTakerEvent());
    registerFallbackValue(FakeCareTakerState());
  });

  setUp(() {
    mockBloc = MockCareTakerBloc();

    when(() => mockBloc.state).thenReturn(CareTakerInitial());
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.selectedCountryCode).thenReturn('+91');
    when(() => mockBloc.relationshipLabelList).thenReturn([]);
    when(() => mockBloc.relationshipList).thenReturn([]);
    when(() => mockBloc.isPrimarySelected).thenReturn(0);
  });

  tearDown(() {
    mockBloc.close();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: BlocProvider<CareTakerBloc>.value(
        value: mockBloc,
        child: const AddCareTakerScreen(),
      ),
      routes: {
        PathConstants.careTakersScreen: (_) =>
        const Scaffold(body: Text('CareTaker List')),
      },
    );
  }


  testWidgets(
    'renders all essential form fields and Save button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.careTakerNameLabel), findsOneWidget);
      expect(find.text(AppStrings.phoneLabelWithOutAsterisk), findsOneWidget);
      expect(find.text(AppStrings.emailLabel), findsOneWidget);
      expect(find.text(AppStrings.addressText), findsOneWidget);
      expect(find.text(AppStrings.relationshipText), findsOneWidget);
      },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    final saveButton = find.widgetWithText(ElevatedButton, AppStrings.addCareTakerBtnText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.careTakerNameReq), findsOneWidget);
    expect(find.text(ValidationMessages.plsEnterPhoneNumber), findsOneWidget);
    expect(find.text(ValidationMessages.addressReq), findsOneWidget);
    expect(find.text(ValidationMessages.relationShip), findsOneWidget);

  });

  testWidgets('shows snackbar when care taker add fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        CareTakerLoading(),
        CareTakerFailure('Failed to save care taker'),
      ]),
      initialState: CareTakerInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to save care taker'), findsOneWidget);
  });

  testWidgets('navigates to care taker list screen on success', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        CareTakerLoading(),
        CareTakerSuccess(message: "Added"),
      ]),
      initialState: CareTakerInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.enterText(find.byType(TextFormField).at(0), 'John Doe');           // CareTaker Name
    await tester.enterText(find.byType(TextFormField).at(1), '9876543210');         // Phone
    await tester.enterText(find.byType(TextFormField).at(2), 'johndoe@example.com'); // Email
    await tester.enterText(find.byType(TextFormField).at(3), '123, MG Road, Bangalore'); // Address

    final saveButton = find.widgetWithText(ElevatedButton, AppStrings.addCareTakerBtnText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton, warnIfMissed: false);
    await tester.pumpAndSettle();
  });

}
