import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_list_res_model.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_state.dart';
import 'package:child_health_story/features/care_taker/presentation/care_takers_screen.dart';
import 'package:child_health_story/shared/widgets/custom_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockCareTakerBloc extends MockBloc<CareTakerEvent, CareTakerState>
    implements CareTakerBloc {}

class FakeCareTakerEvent extends Fake implements CareTakerEvent {}

class FakeCareTakerState extends Fake implements CareTakerState {}

void main() {
  late MockCareTakerBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeCareTakerEvent());
    registerFallbackValue(FakeCareTakerState());
  });

  setUp(() {
    mockBloc = MockCareTakerBloc();
  });

  final mockList = [
    CaretakerListData(
      id: 'ct001',
      name: 'John Doe',
      phoneNumber: '9876543210',
      countryCode: '+91',
      address: '123, MG Road, Bangalore, India',
      isPrimary: true,
    ),
    CaretakerListData(
      id: 'ct002',
      name: 'Jane Smith',
      phoneNumber: '9123456780',
      countryCode: '+91',
      address: '456, Park Street, Kolkata, India',
      isPrimary: false,
    ),
  ];
  final mappedList = [
    {
      "id": "ct001",
      "badge": "Primary Care Taker",
      "category": "Child Care Taker",
      "name": "John Doe",
      "subtitle1": "Phone: 9876543210",
      "subtitle2": "Address: 123, MG Road, Bangalore, India",
      "isPrimary": true,
    },
    {
      "id": "ct002",
      "badge": "",
      "category": "Child Care Taker",
      "name": "Jane Smith",
      "subtitle1": "Phone: 9123456780",
      "subtitle2": "Address: 456, Park Street, Kolkata, India",
      "isPrimary": false,
    },
  ];

  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addCareTakerScreen: (_) =>
          const Scaffold(body: Text('Add Care Taker')),
          PathConstants.careTakerDetailsScreen: (_) =>
          const Scaffold(body: Text('Care Taker Detail')),
        },
        home: BlocProvider<CareTakerBloc>.value(
          value: mockBloc,
          child: const CareTakerListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is CareTakerLoading', (WidgetTester tester) async {
    mockBloc = MockCareTakerBloc();

    when(() => mockBloc.state).thenReturn(CareTakerLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(CareTakerLoading()));

    when(() => mockBloc.filteredCareTakerList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<CareTakerBloc>.value(
          value: mockBloc,
          child: const CareTakerListScreen(),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows snackbar on CareTakerFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([CareTakerFailure(errorMessage)]),
      initialState: CareTakerInitial(),
    );

    when(() => mockBloc.filteredCareTakerList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<CareTakerBloc>.value(
          value: mockBloc,
          child: const CareTakerListScreen(),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list of care taker on CareTakerListSuccess', (tester) async {
    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(CareTakerListSuccess(mockList));
    when(() => mockBloc.filteredCareTakerList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    expect(find.text('John Doe'), findsOneWidget);
    expect(find.text('Jane Smith'), findsOneWidget);
  });

  testWidgets('FAB navigates to Add Care Taker Screen', (tester) async {
    when(() => mockBloc.state).thenReturn(CareTakerListSuccess(mockList));
    when(() => mockBloc.filteredCareTakerList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    final fabFinder = find.byType(FloatingActionButton);
    expect(fabFinder, findsOneWidget);

    await tester.tap(fabFinder);
    await tester.pumpAndSettle();

    expect(find.text('Add Care Taker'), findsOneWidget);
  });

  testWidgets('tapping on care taker navigates to Care Taker Detail screen', (tester) async {
    when(() => mockBloc.state).thenReturn(CareTakerListSuccess(mockList));
    when(() => mockBloc.filteredCareTakerList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();
    final firstItem = find.text('John Doe');
    expect(firstItem, findsOneWidget);

    await tester.tap(firstItem);
    await tester.pumpAndSettle();

    expect(find.text('Care Taker Detail'), findsOneWidget);
  });

  testWidgets('tapping radio button shows dialog and triggers UpdateCareTakerEvent', (tester) async {
    when(() => mockBloc.state).thenReturn(CareTakerListSuccess(mockList));
    when(() => mockBloc.filteredCareTakerList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    final radioButton = find.descendant(
      of: find.widgetWithText(CustomCardView, 'Jane Smith'),
      matching: find.byIcon(Icons.radio_button_unchecked),
    );
    expect(radioButton, findsOneWidget);

    await tester.tap(radioButton);
    await tester.pumpAndSettle();

    expect(find.byType(AlertDialog), findsOneWidget);

    final yesButton = find.descendant(
      of: find.byType(AlertDialog),
      matching: find.byType(ElevatedButton),
    ).last;

    await tester.tap(yesButton);
    await tester.pumpAndSettle();

    verify(() => mockBloc.add(UpdateCareTakerEvent(careTakerId: 'ct002'))).called(1);
  });







}
