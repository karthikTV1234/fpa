import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/care_taker/data/model/request/add_care_taker_req_model.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_detail_res_model.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_list_res_model.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_relationship_list_res_model.dart';
import 'package:child_health_story/features/care_taker/data/repository/care_taker_repository.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockCareTakerRepository extends Mock implements CareTakerRepository {}
class FakeAddCareTakerReqModel extends Fake implements AddCaretakerReqModel {}

void main() {
  late CareTakerBloc bloc;
  late MockCareTakerRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddCareTakerReqModel());
  });
  setUp(() {
    mockRepository = MockCareTakerRepository();
    bloc = CareTakerBloc(careTakerRepository: mockRepository);
  });
  const childId = 'child123';
  const careTakerId = 'care123';
  final addReq = AddCaretakerReqModel(
    childId: 'child456',
    name: 'Jane Smith',
    email: 'janesmith@example.com',
    phoneNumber: '9876543210',
    countryCode: '+91',
    address: '456, Park Street, Kolkata, India',
    isPrimary: true,
    relationship: 'R002',
  );
  final listResModel = GetCaretakersListResModel(
    statusCode: 200,
    message: 'Caretakers fetched successfully',
    data: [
      CaretakerListData(
        id: 'ct001',
        name: 'John Doe',
        phoneNumber: '9876543210',
        countryCode: '+91',
        address: '123, MG Road, Bangalore, India',
        isPrimary: true,
      ),
      CaretakerListData(
        id: 'ct002',
        name: 'Jane Smith',
        phoneNumber: '9123456780',
        countryCode: '+91',
        address: '456, Park Street, Kolkata, India',
        isPrimary: false,
      ),
    ],
  );
  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful',
  );
  final detailRes = GetCaretakerDetailResModel(
    statusCode: 200,
    message: 'Caretaker details fetched successfully',
    data: CaretakerDetailData(
      id: 'ct001',
      name: 'John Doe',
      email: 'johndoe@example.com',
      phoneNumber: '9876543210',
      countryCode: '+91',
      address: '123, MG Road, Bangalore, India',
      isPrimary: true,
      relationshipId: 'R001',
      relationshipName: 'Father',
    ),
  );
  final listEmptyRes = GetCaretakersListResModel(
    statusCode: 200,
    message: 'No records found',
    data: [],
  );
  final listRelationshipEmptyRes = GetRelationshipTypesListResModel(
    statusCode: 200,
    message: 'No records found',
    data: [],
  );
  final relationshipListResModel = GetRelationshipTypesListResModel(
    statusCode: 200,
    message: 'Relationship types fetched successfully',
    data: [
      RelationshipTypeListData(
        id: 'R001',
        relationshipName: 'Father',
      ),
      RelationshipTypeListData(
        id: 'R002',
        relationshipName: 'Mother',
      ),
      RelationshipTypeListData(
        id: 'R003',
        relationshipName: 'Sibling',
      ),
      RelationshipTypeListData(
        id: 'R004',
        relationshipName: 'Grandparent',
      ),
      RelationshipTypeListData(
        id: 'R005',
        relationshipName: 'Guardian',
      ),
    ],
  );


  group('AddCareTakerEvent', () {
    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addCareTaker(addReq))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddCareTakerEvent(addCaretakerReqModel: addReq)),
      expect: () => [
        CareTakerLoading(),
        CareTakerSuccess(message: 'Operation successful'),
      ],
      verify: (_) {
        verify(() => mockRepository.addCareTaker(addReq)).called(1);
      },
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addCareTaker(addReq))
            .thenAnswer((_) async => Result.failure('Failed to add care taker'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddCareTakerEvent(addCaretakerReqModel: addReq)),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Failed to add care taker'),
      ],
      verify: (_) {
        verify(() => mockRepository.addCareTaker(addReq)).called(1);
      },
    );
  });

  group('FetchCareTakerListEvent', () {
    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerListSuccess] on success',
      build: () {
        when(() => mockRepository.getCareTakerList(childId))
            .thenAnswer((_) async => Result.success(listEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerListEvent(childId: childId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getCareTakerList(childId)).called(1),
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getCareTakerList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerListEvent(childId: childId)),
      expect: () => [
        CareTakerLoading(),
        isA<CareTakerListSuccess>().having(
              (s) => s.careTakerList,
          'care taker',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getCareTakerList(childId)).called(1),
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] on failure',
      build: () {
        when(() => mockRepository.getCareTakerList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerListEvent(childId: childId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchCareTakerRelationshipListEvent', () {
    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerRelationshipListSuccess] on success',
      build: () {
        when(() => mockRepository.getCareTakerRelationshipList())
            .thenAnswer((_) async => Result.success(listRelationshipEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerRelationshipListEvent()),
      expect: () => [
        CareTakerLoading(),
        CareTakerRelationshipListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getCareTakerRelationshipList()).called(1),
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerRelationshipListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getCareTakerRelationshipList())
            .thenAnswer((_) async => Result.success(relationshipListResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerRelationshipListEvent()),
      expect: () => [
        CareTakerLoading(),
        isA<CareTakerRelationshipListSuccess>().having(
              (s) => s.careTakerRelationshipList,
          'care taker',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getCareTakerRelationshipList()).called(1),
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] on failure',
      build: () {
        when(() => mockRepository.getCareTakerRelationshipList())
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerRelationshipListEvent()),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchCareTakerByIdEvent', () {

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getCareTakerDetails(careTakerId))
            .thenAnswer((_) async => Result.success(detailRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerByIdEvent(careTakerId: careTakerId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerByIdSuccess(detailRes.data),
      ],
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] on failure',
      build: () {
        when(() => mockRepository.getCareTakerDetails(careTakerId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchCareTakerByIdEvent(careTakerId: careTakerId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Not found'),
      ],
    );
  });

  group('UpdateCareTakerEvent', () {
    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerSuccess] on update success',
      build: () {
        when(() => mockRepository.updateCareTaker(careTakerId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateCareTakerEvent(
          careTakerId: careTakerId)
      ),
      expect: () => [
        CareTakerLoading(),
        CareTakerUpdateSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] on update failure',
      build: () {
        when(() => mockRepository.updateCareTaker(careTakerId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateCareTakerEvent(
          careTakerId: careTakerId)
      ),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Update failed'),
      ],
    );
  });

  group('DeleteCareTakerEvent', () {
    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteCareTaker(careTakerId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteCareTakerEvent(careTakerId: careTakerId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<CareTakerBloc, CareTakerState>(
      'emits [CareTakerLoading, CareTakerFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteCareTaker(careTakerId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteCareTakerEvent(careTakerId: careTakerId)),
      expect: () => [
        CareTakerLoading(),
        CareTakerFailure('Delete failed'),
      ],
    );
  });



}
