import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/add_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/update_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/add_medical_cond_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_status_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/repository/medical_condition_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late MedicalConditionRepository repository;

  setUp(() {
    mockDio = MockDio();
    repository = MedicalConditionRepository(dio: mockDio);
  });

  const childId = 'child123';
  const medicalConditionId = 'cond23';
  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };
  final addReq = AddMedicalCondReqModel(
    childId: 'child_001',
    conditionName: 'Asthma',
    diagnosedDate: '2025-07-15',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    dateOfAdmission: '2025-07-16',
    dateOfDischarge: '2025-07-20',
    severity: 'High',
    currentStatus: 'Under Treatment',
    treatmentPlan: 'Inhaler twice daily and avoid allergens',
    attachments: [],
  );
  final addRes = {
    "statusCode": 201,
    "message": "Medical condition added successfully",
    "data": {
      "id": "cond_001",
      "childId": "child_001",
      "conditionName": "Asthma",
      "diagnosedDate": "2025-07-15",
      "hospitalId": "hospital_123",
      "doctorId": "doctor_456",
      "dateOfAdmission": "2025-07-16",
      "dateOfDischarge": "2025-07-20",
      "severity": "High",
      "currentStatus": "UnderTreatment",
      "treatmentPlan": "Use inhaler twice daily, avoid allergens",
      "attachments": [
        "https://example.com/attachments/scan1.png",
        "https://example.com/attachments/report1.pdf"
      ],
      "createdAt": "2025-07-15T10:30:00Z",
      "updatedAt": "2025-07-15T10:30:00Z",
      "isDeleted": false
    }
  };
  final updateReq = UpdateMedicalCondReqModel(
    childId: 'child_001',
    diagnosedDate: '2025-07-15',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    dateOfAdmission: '2025-07-16',
    dateOfDischarge: '2025-07-20',
    severity: 'Medium',
    currentStatus: 'Recovered',
    treatmentPlan: 'Continue monitoring and yearly check-up',
    attachments: [],
  );

  final detailRes = {
    "statusCode": 200,
    "message": "Medical condition retrieved successfully",
    "data": {
      "id": "cond_001",
      "childId": "child_001",
      "conditionName": "Asthma",
      "diagnosedDate": "2025-07-15",
      "hospitalId": "hospital_123",
      "doctorId": "doctor_456",
      "dateOfAdmission": "2025-07-16",
      "dateOfDischarge": "2025-07-20",
      "severity": "High",
      "currentStatus": "UnderTreatment",
      "treatmentPlan": "Use inhaler twice daily, avoid allergens",
      "attachments": [
        "https://example.com/attachments/scan1.png",
        "https://example.com/attachments/report1.pdf"
      ],
      "createdAt": "2025-07-15T10:30:00Z",
      "updatedAt": "2025-07-21T15:45:00Z",
      "isDeleted": false,
      "doctorName": "Dr. John Smith",
      "hospitalName": "City General Hospital",
      "currentStatusName": "Under Treatment"
    }
  };

  final listRes  = {
    "statusCode": 200,
    "message": "Fetched successfully",
    "data": [
      {
        "id": "cond_001",
        "childId": "child_001",
        "conditionName": "Asthma",
        "diagnosedDate": "2025-07-15",
        "doctorId": "doctor_456",
        "severity": "High",
        "currentStatus": "UnderTreatment",
        "doctorName": "Dr. John Smith"
      },
      {
        "id": "cond_002",
        "childId": "child_001",
        "conditionName": "Fracture",
        "diagnosedDate": "2025-05-10",
        "doctorId": "doctor_789",
        "severity": "Medium",
        "currentStatus": "Recovered",
        "doctorName": "Dr. Emily Clark"
      },
      {
        "id": "cond_003",
        "childId": "child_002",
        "conditionName": "Diabetes Type 1",
        "diagnosedDate": "2024-12-01",
        "doctorId": "doctor_321",
        "severity": "Low",
        "currentStatus": "Ongoing",
        "doctorName": "Dr. Raj Patel"
      }
    ]
  };

  group('addMedicalCondition', () {
      test('returns success on 200 response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
                  requestOptions: RequestOptions(path: ''), statusCode: 200,
                  data: addRes
              ),
        );

        final result = await repository.addMedicalCondition(addReq);

        expect(result.isSuccess, true);
        expect(result.data, isA<AddMedicalCondResModel>());
        expect(result.data!.message, 'Medical condition added successfully');
      });

      test('returns failure on non-200 with message', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Invalid request'}),
        );

        final result = await repository.addMedicalCondition(addReq);

        expect(result.isError, true);
        expect(result.error, 'Invalid request');
      });

      test('returns connection timeout error on timeout', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            type: DioExceptionType.connectionTimeout,
          ),
        );

        final result = await repository.addMedicalCondition(addReq);
        expect(result.isError, true);
        expect(result.error, ErrorMessages.connectionTimeOutError);
      });

      test('returns failure on DioException with response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            response: Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Server error'},
            ),
          ),
        );

        final result = await repository.addMedicalCondition(addReq);

        expect(result.isError, true);
        expect(result.error, 'Server error');
      });

      test('returns something went wrong on generic exception', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(Exception('Unexpected error'));

        final result = await repository.addMedicalCondition(addReq);

        expect(result.isError, true);
        expect(result.error, ErrorMessages.somethingWentWrongError);
      });
    });

  group('getMedicalConditionList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: listRes,
      ));

      final result = await repository.getMedicalConditionList(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<MedicalConditionListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch medical conditions'},
      ));

      final result = await repository.getMedicalConditionList(childId);

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch medical conditions');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getMedicalConditionList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getMedicalConditionList(childId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getMedicalConditionList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('getStatusList', () {
    final mockStatusListJson = {
      "statusCode": 200,
      "message": "Fetched successfully",
      "data": [
        {
          "id": "status_1",
          "conditionStatus": "Observation"
        },
        {
          "id": "status_2",
          "conditionStatus": "Treatment"
        },
        {
          "id": "status_3",
          "conditionStatus": "Disease"
        },
        {
          "id": "status_4",
          "conditionStatus": "Recovered"
        },
        {
          "id": "status_5",
          "conditionStatus": "Chronic"
        }
      ]
    };

    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: mockStatusListJson,
      ));

      final result = await repository.getMedicalConditionStatusList();

      expect(result.isSuccess, true);
      expect(result.data, isA<MedicalConditionStatusListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch status list'},
      ));

      final result = await repository.getMedicalConditionStatusList();

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch status list');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getMedicalConditionStatusList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Internal Server Error'},
        ),
      ));

      final result = await repository.getMedicalConditionStatusList();

      expect(result.isError, true);
      expect(result.error, 'Internal Server Error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getMedicalConditionStatusList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('getMedicalConditionDetails', () {

    test('should return MedicalConditionDetails model when response is 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: detailRes,
      ));

      final result = await repository.getMedicalConditionDetails(medicalConditionId);

      expect(result.isSuccess, true);
      final data = result.data!;
      expect(data.statusCode, 200);
      expect(data.message, 'Medical condition retrieved successfully');
    });

    test('should return error message when response is not 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 404,
          data: {"message": "Medical Condition not found"},
        ),
      );

      final result = await repository.getMedicalConditionDetails(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, "Medical Condition not found");
    });

    test('should return connection timeout error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getMedicalConditionDetails(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('should return error from DioException with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getMedicalConditionDetails(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('should return something went wrong on unknown error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Some unexpected error'));

      final result = await repository.getMedicalConditionDetails(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateMedicalConditionDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Update failed'},
      ));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(Exception('Unexpected error'));

      final result = await repository.updateMedicalConditionDetails(
          updateReq, medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });


  });

  group('deleteMedicalCondition', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: commonRes,
      ));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Delete failed'},
      ));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, 'Delete failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteMedicalCondition(medicalConditionId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });




}
