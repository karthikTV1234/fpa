import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/features/medical_conditions/presentation/medical_condition_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mocktail/mocktail.dart';

class MockMedicalConditionBloc extends Mock implements MedicalConditionBloc {}
class MockNavigatorObserver extends Mock implements NavigatorObserver {}
class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockMedicalConditionBloc mockBloc;
  const childId = 'child123';
  const medicalConditionId = 'cond23';
  setUpAll(() {
    registerFallbackValue(DeleteMedicalConditionEvent(medicalConditionId: medicalConditionId));
    registerFallbackValue(FetchMedicalConditionByIdEvent(medicalConditionId: medicalConditionId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockMedicalConditionBloc();
    when(() => mockBloc.isUIUpdated).thenReturn(true);

    final testState = MedicalConditionByIdSuccess(
      MedicalConditionDetailData(conditionName: 'Fever'),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
  });

  final mockData = MedicalConditionDetailData(
    id: "cond_001",
    childId: "child_001",
    conditionName: "Asthma",
    diagnosedDate: "2025-07-15",
    hospitalId: "hospital_123",
    doctorId: "doctor_456",
    dateOfAdmission: "2025-07-16",
    dateOfDischarge: "2025-07-20",
    severity: "High",
    currentStatus: "UnderTreatment",
    treatmentPlan: "Use inhaler twice daily, avoid allergens",
    attachments: [
      "https://example.com/attachments/scan1.png",
      "https://example.com/attachments/report1.pdf"
    ],
    doctorName: "Dr. John Smith",
    hospitalName: "City General Hospital",
    currentStatusName: "Under Treatment",
  );

  testWidgets(
    'renders medical condition details when MedicalConditionByIdSuccess is emitted',
        (WidgetTester tester) async {
      mockBloc = MockMedicalConditionBloc();

      final testState = MedicalConditionByIdSuccess(mockData);

      // Stub the state and stream
      when(() => mockBloc.state).thenReturn(testState);
      when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));

      // Stub the extra fields used by the widget
      when(() => mockBloc.isUIUpdated).thenReturn(true);
      when(() => mockBloc.medicalConditionDetailData).thenReturn(mockData);
      when(() => mockBloc.add(any())).thenReturn(null);

      await tester.pumpWidget(
        MaterialApp(
          home: BlocProvider<MedicalConditionBloc>.value(
            value: mockBloc,
            child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
          ),
        ),
      );

      await tester.pumpAndSettle();

      expect(find.text('Asthma'), findsOneWidget);
      expect(find.text('Dr. John Smith'), findsOneWidget);
      expect(find.text('City General Hospital'), findsOneWidget);
      expect(find.text('Use inhaler twice daily, avoid allergens'), findsOneWidget);
      expect(find.text('High'), findsOneWidget);
      expect(find.text('Under Treatment'), findsOneWidget);
    },
  );

  testWidgets('should show loading indicator when state is MedicalConditionLoading', (WidgetTester tester) async {
    mockBloc = MockMedicalConditionBloc();

    when(() => mockBloc.state).thenReturn(MedicalConditionLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicalConditionLoading()));

    // Stub required getters to avoid null errors
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.medicalConditionDetailData).thenReturn(null);
    when(() => mockBloc.filteredMedicalConditionList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicalConditionBloc>.value(
          value: mockBloc,
          child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });


  testWidgets('should show error message when state is failure', (WidgetTester tester) async {
    mockBloc = MockMedicalConditionBloc();

    const errorMessage = 'Something went wrong';

    when(() => mockBloc.state).thenReturn(MedicalConditionFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicalConditionFailure(errorMessage)));

    // Mock the additional getters used by the widget
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.medicalConditionDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<MedicalConditionBloc>.value(
              value: mockBloc,
              child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();  // start frame
    await tester.pump(const Duration(seconds: 1));  // allow snackbar animation

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });


  testWidgets('navigates to edit MedicalCondition screen on edit button tap', (WidgetTester tester) async {
    mockBloc = MockMedicalConditionBloc();

    final testState = MedicalConditionByIdSuccess(mockData);

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.medicalConditionDetailData).thenReturn(mockData);

    final mockObserver = MockNavigatorObserver();

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.editMedicalConditionScreen) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit MedicalCondition Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<MedicalConditionBloc>.value(
          value: mockBloc,
          child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
        ),
        navigatorObservers: [mockObserver],
      ),
    );

    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);

    reset(mockObserver);

    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);
  });


  testWidgets('should display file attachments if available', (tester) async {
    final mockBloc = MockMedicalConditionBloc();

    final medicalConditionDetail = MedicalConditionDetailData(
      conditionName: 'Fever',
      attachments: ['https://example.com/uploads/report1.pdf'],
    );

    final testState = MedicalConditionByIdSuccess(medicalConditionDetail);

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.medicalConditionDetailData).thenReturn(medicalConditionDetail); // <-- IMPORTANT

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: BlocProvider<MedicalConditionBloc>.value(
            value: mockBloc,
            child: SizedBox(
              height: 200,  // fixed height for ListView to render attachments
              child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.textContaining('pdf'), findsOneWidget);
  });

  testWidgets('delete medical condition and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.medicalConditionsListScreen: (_) => const Scaffold(body: Text('Medical Condition List')),
            },
            home: BlocProvider<MedicalConditionBloc>.value(
              value: mockBloc,
              child: const MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
            ),
          ),
        );

        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteMedicalConditionTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteMedicalConditionConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteMedicalConditionEvent(medicalConditionId: medicalConditionId))).called(1);

        final successState = MedicalConditionSuccess(message: 'Medical Condition deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });


}
