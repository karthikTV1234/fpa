import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/medical_conditions/presentation/add_medical_condition_screen.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockMedicalConditionBloc extends MockBloc<MedicalConditionEvent, MedicalConditionState> implements MedicalConditionBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeMedicalConditionEvent extends Fake implements MedicalConditionEvent {}
class FakeMedicalConditionState extends Fake implements MedicalConditionState {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockMedicalConditionBloc mockBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeMedicalConditionEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeMedicalConditionState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockBloc = MockMedicalConditionBloc();

    when(() => mockBloc.state).thenReturn(MedicalConditionInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.statusLabelList).thenReturn([]);
    when(() => mockBloc.statusList).thenReturn([]);
    when(() => mockBloc.hospitalList).thenReturn([]);
    when(() => mockBloc.doctorList).thenReturn([]);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<MedicalConditionBloc>.value(value: mockBloc),
        ],
        child: const AddMedicalConditionScreen(),
      ),
    );
  }

  testWidgets(
    'renders all essential form fields and Save button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.conditionNameLabel), findsOneWidget);
      expect(find.text(AppStrings.diagnosedDateLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.admissionDateLabel), findsOneWidget);
      expect(find.text(AppStrings.currentStatusLabel), findsOneWidget);
      expect(find.text(AppStrings.dischargeDateLabel), findsOneWidget);
      expect(find.text(AppStrings.severityLabel), findsOneWidget);
      expect(find.text(AppStrings.treatmentNotesLabel), findsOneWidget);
      expect(find.text(AppStrings.saveText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.conditionNameRequired), findsOneWidget);
    expect(find.text(ValidationMessages.diagnosedDateRequired), findsOneWidget);
    expect(find.text(ValidationMessages.hospitalRequired), findsOneWidget);
    expect(find.text(ValidationMessages.doctorRequired), findsOneWidget);
    expect(find.text(ValidationMessages.admissionDateRequired), findsOneWidget);
    expect(find.text(ValidationMessages.statusRequired), findsOneWidget);
  });

  testWidgets('shows snackbar when medical condition add fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        MedicalConditionLoading(),
        MedicalConditionFailure('Failed to save medical condition'),
      ]),
      initialState: MedicalConditionInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // begin listening
    await tester.pump(); // show snackbar

    expect(find.text('Failed to save medical condition'), findsOneWidget);
  });

  testWidgets('navigates to medical condition list screen on success', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        MedicalConditionLoading(),
        MedicalConditionSuccess(message: "Added"),
      ]),
      initialState: MedicalConditionInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    // Fill form fields
    await tester.enterText(find.byType(TextFormField).at(0), 'Fever');
    await tester.enterText(find.byType(TextFormField).at(1), '20-07-2025');
    await tester.enterText(find.byType(TextFormField).at(4), '21-07-2025');
    await tester.enterText(find.byType(TextFormField).at(5), 'Under Treatment');
    await tester.enterText(find.byType(TextFormField).at(6), '25-07-2025');

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton, warnIfMissed: false);
    await tester.pumpAndSettle();

  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
