import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/features/medical_conditions/presentation/medical_conditions_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockMedicalConditionBloc extends MockBloc<MedicalConditionEvent, MedicalConditionState> implements MedicalConditionBloc {}
class FakeMedicalConditionEvent extends Fake implements MedicalConditionEvent {}
class FakeMedicalConditionState extends Fake implements MedicalConditionState {}

void main() {
  late MockMedicalConditionBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeMedicalConditionEvent());
    registerFallbackValue(FakeMedicalConditionState());
  });

  setUp(() {
    mockBloc = MockMedicalConditionBloc();
  });

  final mockList = [
    MedicalConditionListData(
      id: "cond_001",
      childId: "child_001",
      conditionName: "Asthma",
      diagnosedDate: "2025-07-15",
      doctorId: "doctor_456",
      severity: "High",
      currentStatus: "UnderTreatment",
      doctorName: "Dr. John Smith",
    ),
    MedicalConditionListData(
      id: "cond_002",
      childId: "child_001",
      conditionName: "Fracture",
      diagnosedDate: "2025-05-10",
      doctorId: "doctor_789",
      severity: "Medium",
      currentStatus: "Recovered",
      doctorName: "Dr. Emily Clark",
    ),
  ];
  final mappedList = [
    {
      "id": "1",
      "category": "Daily",
      "status": "Next Dosage: 05 Jan 2023 08:00 AM",
      "statusColor": const Color(0xFFFFF3E0),
      "title": "Paracetamol",
      "subtitle": "Start Date: 01 Jan 2023\nEnd Date: 10 Jan 2023",
    },
    {
      "id": "2",
      "category": "Twice a day",
      "status": "Next Dosage: 16 Jan 2023 08:00 AM",
      "statusColor": const Color(0xFFFFF3E0),
      "title": "Amoxicillin",
      "subtitle": "Start Date: 15 Jan 2023\nEnd Date: 25 Jan 2023",
    },
  ];

  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addMedicalConditionScreen: (_) =>
          const Scaffold(body: Text('Add Medical Condition')),
          PathConstants.medicalConditionDetailScreen: (_) =>
          const Scaffold(body: Text('Medical Condition Detail')),
        },
        home: BlocProvider<MedicalConditionBloc>.value(
          value: mockBloc,
          child: const MedicalConditionsListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is MedicalConditionLoading', (WidgetTester tester) async {
    mockBloc = MockMedicalConditionBloc();

    when(() => mockBloc.state).thenReturn(MedicalConditionLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicalConditionLoading()));

    when(() => mockBloc.filteredMedicalConditionList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicalConditionBloc>.value(
          value: mockBloc,
          child: const MedicalConditionsListScreen(),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows snackbar on MedicalConditionFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([MedicalConditionFailure(errorMessage)]),
      initialState: MedicalConditionInitial(),
    );

    when(() => mockBloc.filteredMedicalConditionList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicalConditionBloc>.value(
          value: mockBloc,
          child: const MedicalConditionsListScreen(),
        ),
      ),
    );

    await tester.pump(); // Trigger the bloc listener
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list on MedicalConditionListSuccess', (tester) async {

    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(MedicalConditionListSuccess(mockList));

    // Filtered list returned by the bloc's getter (must match what UI expects)
    when(() => mockBloc.filteredMedicalConditionList).thenReturn([
      {
        "id": "1",
        "category": "Daily",
        "status": "Next Dosage: 05 Jan 2023 08:00 AM",
        "statusColor": const Color(0xFFFFF3E0),
        "title": "Paracetamol",
        "subtitle": "Start Date: 01 Jan 2023\nEnd Date: 10 Jan 2023",
      },
      {
        "id": "2",
        "category": "Twice a day",
        "status": "Next Dosage: 16 Jan 2023 08:00 AM",
        "statusColor": const Color(0xFFFFF3E0),
        "title": "Amoxicillin",
        "subtitle": "Start Date: 15 Jan 2023\nEnd Date: 25 Jan 2023",
      },
    ]);

    await pumpScreen(tester);
    await tester.pumpAndSettle(); // Wait for UI rendering

    expect(find.text('Paracetamol'), findsOneWidget);
    expect(find.text('Amoxicillin'), findsOneWidget);
  });


  testWidgets('filters list when search query is entered', (tester) async {
    when(() => mockBloc.state).thenReturn(MedicalConditionListSuccess(mockList));
    when(() => mockBloc.filteredMedicalConditionList).thenReturn(mappedList);

    await pumpScreen(tester);

    await tester.pumpAndSettle();
    expect(find.text('Paracetamol'), findsOneWidget);
    expect(find.text('Amoxicillin'), findsOneWidget);

    await tester.enterText(find.byType(TextField), 'Para');

    when(() => mockBloc.state).thenReturn(
      MedicalConditionListSearchSuccess([mappedList.first]),
    );
    when(() => mockBloc.filteredMedicalConditionList).thenReturn([mappedList.first]);

    await tester.pumpAndSettle();

    // Only Paracetamol should be visible
    expect(find.text('Paracetamol'), findsOneWidget);
  });


}
