import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/add_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/update_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/add_medical_cond_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_status_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/repository/medical_condition_repository.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockMedicalConditionRepository extends Mock implements MedicalConditionRepository {}
class FakeAddMedicalCondReqModel extends Fake implements AddMedicalCondReqModel {}
class FakeUpdateMedicalCondReqModel extends Fake implements UpdateMedicalCondReqModel {}

void main() {
  late MedicalConditionBloc bloc;
  late MockMedicalConditionRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddMedicalCondReqModel());
    registerFallbackValue(FakeUpdateMedicalCondReqModel());
  });
  setUp(() {
    mockRepository = MockMedicalConditionRepository();
    bloc = MedicalConditionBloc(medicalConditionRepository: mockRepository);
  });
  const childId = 'child123';
  const medicalConditionId = 'cond23';
  final addReq = AddMedicalCondReqModel(
    childId: 'child_001',
    conditionName: 'Asthma',
    diagnosedDate: '2025-07-15',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    dateOfAdmission: '2025-07-16',
    dateOfDischarge: '2025-07-20',
    severity: 'High',
    currentStatus: 'Under Treatment',
    treatmentPlan: 'Inhaler twice daily and avoid allergens',
    attachments: [],
  );
  final addRes = AddMedicalCondResModel(
    statusCode: 201,
    message: "Medical condition added successfully",
    data: MedicalCondAddResData(
      id: "cond_001",
      childId: "child_001",
      conditionName: "Asthma",
      diagnosedDate: "2025-07-15",
      hospitalId: "hospital_123",
      doctorId: "doctor_456",
      dateOfAdmission: "2025-07-16",
      dateOfDischarge: "2025-07-20",
      severity: "High",
      currentStatus: "UnderTreatment",
      treatmentPlan: "Use inhaler twice daily, avoid allergens",
      attachments: [
        "https://example.com/attachments/scan1.png",
        "https://example.com/attachments/report1.pdf"
      ],
      createdAt: "2025-07-15T10:30:00Z",
      updatedAt: "2025-07-15T10:30:00Z",
      isDeleted: false,
    ),
  );

  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful',
  );
  final updateReq = UpdateMedicalCondReqModel(
    childId: 'child_001',
    diagnosedDate: '2025-07-15',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    dateOfAdmission: '2025-07-16',
    dateOfDischarge: '2025-07-20',
    severity: 'Medium',
    currentStatus: 'Recovered',
    treatmentPlan: 'Continue monitoring and yearly check-up',
    attachments: [],
  );

  final detailRes = GetMedicalConditionDetailResModel(
    statusCode: 200,
    message: "Medical condition retrieved successfully",
    data: MedicalConditionDetailData(
      id: "cond_001",
      childId: "child_001",
      conditionName: "Asthma",
      diagnosedDate: "2025-07-15",
      hospitalId: "hospital_123",
      doctorId: "doctor_456",
      dateOfAdmission: "2025-07-16",
      dateOfDischarge: "2025-07-20",
      severity: "High",
      currentStatus: "UnderTreatment",
      treatmentPlan: "Use inhaler twice daily, avoid allergens",
      attachments: [
        "https://example.com/attachments/scan1.png",
        "https://example.com/attachments/report1.pdf"
      ],
      createdAt: "2025-07-15T10:30:00Z",
      updatedAt: "2025-07-21T15:45:00Z",
      isDeleted: false,
      doctorName: "Dr. John Smith",
      hospitalName: "City General Hospital",
      currentStatusName: "Under Treatment",
    ),
  );

  final listResModel = MedicalConditionListResModel(
    statusCode: 200,
    message: "Medical conditions retrieved successfully",
    data: [
      MedicalConditionListData(
        id: "cond_001",
        childId: "child_001",
        conditionName: "Asthma",
        diagnosedDate: "2025-07-15",
        doctorId: "doctor_456",
        severity: "High",
        currentStatus: "UnderTreatment",
        doctorName: "Dr. John Smith",
      ),
      MedicalConditionListData(
        id: "cond_002",
        childId: "child_001",
        conditionName: "Fracture",
        diagnosedDate: "2025-05-10",
        doctorId: "doctor_789",
        severity: "Medium",
        currentStatus: "Recovered",
        doctorName: "Dr. Emily Clark",
      ),
    ],
  );

  final listEmptyRes = MedicalConditionListResModel(
    statusCode: 200,
    message: 'No Medical Conditions found',
    data: [],
  );

  group('AddMedicalConditionEvent', () {
    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addMedicalCondition(addReq))
            .thenAnswer((_) async => Result.success(addRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddMedicalConditionEvent(addMedicalCondReqModel: addReq)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionSuccess(message: 'Medical condition added successfully')
      ],
      verify: (_) {
        verify(() => mockRepository.addMedicalCondition(addReq)).called(1);
      },
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addMedicalCondition(addReq))
            .thenAnswer((_) async => Result.failure('Failed to add condition'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddMedicalConditionEvent(addMedicalCondReqModel: addReq)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Failed to add condition'),
      ],
      verify: (_) {
        verify(() => mockRepository.addMedicalCondition(addReq)).called(1);
      },
    );
  });

  group('FetchMedicalConditionListEvent', () {
    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionListSuccess] on success',
      build: () {
        when(() => mockRepository.getMedicalConditionList(childId))
            .thenAnswer((_) async => Result.success(listEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicalConditionListEvent(childId: childId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getMedicalConditionList(childId)).called(1),
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getMedicalConditionList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicalConditionListEvent(childId: childId)),
      expect: () => [
        MedicalConditionLoading(),
        isA<MedicalConditionListSuccess>().having(
              (s) => s.medicalConditions,
          'MedicalConditions',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getMedicalConditionList(childId)).called(1),
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] on failure',
      build: () {
        when(() => mockRepository.getMedicalConditionList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicalConditionListEvent(childId: childId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchMedicalConditionStatusListEvent', () {
    final statusResModel = MedicalConditionStatusListResModel(
      statusCode: 200,
      message: 'Fetched successfully',
      data: [],
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, StatusListSuccess] on success',
      build: () {
        when(() => mockRepository.getMedicalConditionStatusList())
            .thenAnswer((_) async => Result.success(statusResModel));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchStatusListEvent()),
      expect: () => [
        MedicalConditionLoading(),
        StatusListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getMedicalConditionStatusList()).called(1),
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, StatusListSuccess] with non-empty list',
      build: () {
        final statusList = [
          MedicalConditionStatusData(id: 'status_1', conditionStatus: 'Observation'),
          MedicalConditionStatusData(id: 'status_2', conditionStatus: 'Treatment'),
          MedicalConditionStatusData(id: 'status_3', conditionStatus: 'Disease'),
          MedicalConditionStatusData(id: 'status_4', conditionStatus: 'Recovered'),
          MedicalConditionStatusData(id: 'status_5', conditionStatus: 'Chronic'),
        ];

        final freqResModel = MedicalConditionStatusListResModel(
          statusCode: 200,
          message: 'Fetched successfully',
          data: statusList,
        );

        when(() => mockRepository.getMedicalConditionStatusList())
            .thenAnswer((_) async => Result.success(freqResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchStatusListEvent()),
      expect: () => [
        MedicalConditionLoading(),
        isA<StatusListSuccess>().having(
              (s) => s.statusList,
          'frequencies',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getMedicalConditionStatusList()).called(1),
    );


    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] on failure',
      build: () {
        when(() => mockRepository.getMedicalConditionStatusList())
            .thenAnswer((_) async => Result.failure('Error occurred'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchStatusListEvent()),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Error occurred'),
      ],
    );
  });

  group('FetchMedicalConditionByIdEvent', () {

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getMedicalConditionDetails(medicalConditionId))
            .thenAnswer((_) async => Result.success(detailRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicalConditionByIdEvent(medicalConditionId: medicalConditionId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionByIdSuccess(detailRes.data),
      ],
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] on failure',
      build: () {
        when(() => mockRepository.getMedicalConditionDetails(medicalConditionId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicalConditionByIdEvent(medicalConditionId: medicalConditionId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Not found'),
      ],
    );
  });

  group('UpdateMedicalConditionEvent', () {
    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionSuccess] on update success',
      build: () {
        when(() => mockRepository.updateMedicalConditionDetails(updateReq, medicalConditionId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateMedicalConditionEvent(
          medicalConditionId: medicalConditionId,updateMedicalCondReqModel: updateReq)
      ),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] on update failure',
      build: () {
        when(() => mockRepository.updateMedicalConditionDetails(updateReq, medicalConditionId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateMedicalConditionEvent(
          medicalConditionId: medicalConditionId,updateMedicalCondReqModel: updateReq)
      ),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Update failed'),
      ],
    );
  });

  group('DeleteMedicalConditionEvent', () {
    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteMedicalCondition(medicalConditionId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteMedicalConditionEvent(medicalConditionId: medicalConditionId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<MedicalConditionBloc, MedicalConditionState>(
      'emits [MedicalConditionLoading, MedicalConditionFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteMedicalCondition(medicalConditionId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteMedicalConditionEvent(medicalConditionId: medicalConditionId)),
      expect: () => [
        MedicalConditionLoading(),
        MedicalConditionFailure('Delete failed'),
      ],
    );
  });



}
