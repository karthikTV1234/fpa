import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/data/model/child_detail_model.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/child_profile/presentation/screens/child_profile_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockChildBloc extends Mock implements ChildBloc {}

void main() {
  late MockChildBloc mockChildBloc;

  setUp(() {
    mockChildBloc = MockChildBloc();
  });

  Widget createTestWidget(Widget child) {
    return MaterialApp(
      home: BlocProvider<ChildBloc>.value(
        value: mockChildBloc,
        child: child,
      ),
    );
  }

  testWidgets('displays loader dialog on ChildLoading state', (tester) async {
    final mockBloc = MockChildBloc();

    whenListen(
      mockBloc,
      Stream.fromIterable([ChildLoading()]),
      initialState: ChildInitial(),
    );

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<ChildBloc>.value(
          value: mockBloc,
          child: const ChildProfileDetailScreen(),
        ),
      ),
    );

    await tester.pump(); // Trigger bloc listener

    expect(find.text(AppStrings.loading), findsOneWidget);
  });

  testWidgets('renders child details when ChildByIdSuccess is emitted', (WidgetTester tester) async {
    final child = GetChildData(
      name: 'Baby Test',
      birthDate: '2022-01-01',
      timeOfBirth: '2022-01-01T10:00:00.000Z',
      gender: 'Female',
      height: 75,
      weight: 10.5,
      headCircumference: 42.0,
      bloodType: 'A+',
      description: 'Test baby',
      profilePictureUrl: null,
      coverPhotoUrl: null,
    );

    when(() => mockChildBloc.state).thenReturn(ChildByIdSuccess(child));
    when(() => mockChildBloc.stream).thenAnswer((_) => Stream.value(ChildByIdSuccess(child)));

    await tester.pumpWidget(createTestWidget(const ChildProfileDetailScreen()));
    await tester.pumpAndSettle();

    expect(find.text('Baby Test'), findsOneWidget);
    expect(find.text('Test baby'), findsOneWidget);
    expect(find.text('A+'), findsOneWidget);
  });

  testWidgets('shows snackbar when ChildFailure is emitted', (tester) async {
    when(() => mockChildBloc.state).thenReturn(ChildFailure('Something went wrong'));
    when(() => mockChildBloc.stream).thenAnswer((_) => Stream.value(ChildFailure('Something went wrong')));

    await tester.pumpWidget(createTestWidget(const ChildProfileDetailScreen()));
    await tester.pump(const Duration(seconds: 1)); // Allow snackbar to show

    expect(find.text('Something went wrong'), findsOneWidget);
  });

  testWidgets('navigates to edit screen on edit button tap', (tester) async {
    final child = GetChildData(
      name: 'Baby Test',
      birthDate: '2022-01-01',
      timeOfBirth: '2022-01-01T10:00:00.000Z',
      gender: 'Female',
      height: 75,
      weight: 10.5,
      headCircumference: 42.0,
      bloodType: 'A+',
      description: 'Test baby',
      profilePictureUrl: null,
      coverPhotoUrl: null,
    );

    when(() => mockChildBloc.state).thenReturn(ChildByIdSuccess(child));
    when(() => mockChildBloc.stream).thenAnswer((_) => Stream.value(ChildByIdSuccess(child)));

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.editChildProfile) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<ChildBloc>.value(
          value: mockChildBloc,
          child: const ChildProfileDetailScreen(),
        ),
      ),
    );

    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    expect(find.text('Edit Screen'), findsOneWidget);
  });

}
