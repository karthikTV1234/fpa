import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/child_profile/presentation/screens/add_child.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockChildBloc extends MockBloc<ChildEvent, ChildState> implements ChildBloc {}
class FakeChildEvent extends Fake implements ChildEvent {}


void main() {
  late MockChildBloc mockChildBloc;

  setUpAll(() {
    registerFallbackValue(FakeChildEvent());
  });

  setUp(() {
    mockChildBloc = MockChildBloc();
    when(() => mockChildBloc.state).thenReturn(ChildInitial());
    whenListen(mockChildBloc, Stream<ChildState>.fromIterable([]));

  });

  tearDown(() {
    mockChildBloc.close();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: BlocProvider<ChildBloc>.value(
        value: mockChildBloc,
        child: AddChild(),
      ),
      routes: {
        '/home': (_) => const Scaffold(body: Text('Home')),
      },
    );
  }


  testWidgets('renders all essential form fields and button', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());

    expect(find.text(AppStrings.addaChildText), findsOneWidget);
    expect(find.text(AppStrings.babyNameLabel), findsOneWidget);
    expect(find.text(AppStrings.genderLabel), findsOneWidget);
    expect(find.text(AppStrings.dobLabel), findsOneWidget);
    expect(find.text(AppStrings.heightLabel), findsOneWidget);
    expect(find.text(AppStrings.weightLabel), findsOneWidget);
    expect(find.text(AppStrings.headCircumferenceLabel), findsOneWidget);
    expect(find.text(AppStrings.bloodGroupLabel), findsOneWidget);
    expect(find.text(AppStrings.aboutyourChildLabel), findsOneWidget);
    expect(find.text(AppStrings.nextText), findsOneWidget);
  });

  testWidgets('shows validation errors when fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle(); // wait for UI to settle

    final nextButton = find.text(AppStrings.nextText);
    await tester.ensureVisible(nextButton);

    // Tap the button
    await tester.tap(nextButton);
    await tester.pumpAndSettle();

    // Expect all validation messages
    expect(find.text(ValidationMessages.babyNameReq), findsOneWidget);
    expect(find.text(ValidationMessages.genderReq), findsOneWidget);
    expect(find.text(ValidationMessages.dobReq), findsOneWidget);
    expect(find.text(ValidationMessages.babyHeightReq), findsOneWidget);
    expect(find.text(ValidationMessages.babyWeightReq), findsOneWidget);
    expect(find.text(ValidationMessages.babyHeadCircumfranceReq), findsOneWidget);
    expect(find.text(ValidationMessages.babyBloodGroupReq), findsOneWidget);
  });

  testWidgets('navigates to home screen on success', (tester) async {
    whenListen(
      mockChildBloc,
      Stream.fromIterable([
        ChildLoading(),
        ChildSuccess(message: 'Added'),
      ]),
      initialState: ChildInitial(),
    );
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.enterText(find.byType(TextFormField).at(0), 'Test Baby'); // Name
    await tester.enterText(find.byType(TextFormField).at(1), '2025-01-01 10:00'); // DOB
    await tester.enterText(find.byType(TextFormField).at(2), '50'); // Height
    await tester.enterText(find.byType(TextFormField).at(3), '3.5'); // Weight
    await tester.enterText(find.byType(TextFormField).at(4), '34'); // Head Circumference
    await tester.enterText(find.byType(TextFormField).at(5), 'O+'); // Blood Group

    final nextButton = find.text(AppStrings.nextText);
    await tester.ensureVisible(nextButton);
    await tester.tap(nextButton, warnIfMissed: false);
    await tester.pumpAndSettle();

    await tester.pumpAndSettle();
    expect(find.text('Home'), findsOneWidget);
  });


  testWidgets('shows snackbar on ChildFailure state', (tester) async {
    whenListen(
        mockChildBloc,
        Stream.fromIterable([
          ChildLoading(),
          ChildFailure('Failed to add')]));

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to add'), findsOneWidget);
  });
}
