import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/data/model/child_detail_model.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/child_profile/presentation/screens/edit_child_profile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockChildBloc extends MockBloc<ChildEvent, ChildState> implements ChildBloc {}

void main() {
  late MockChildBloc mockChildBloc;

  setUp(() {
    mockChildBloc = MockChildBloc();
    when(() => mockChildBloc.state).thenReturn(ChildInitial());
  });

  setUpAll(() {
    registerFallbackValue(UpdateChildEvent(
      updateChildReqModel: UpdateChildReqModel(
        userId: '',
        name: '',
        gender: '',
        birthDate: '',
        timeOfBirth: '',
        height: 0,
        weight: 0,
        weightUnit: '',
        headCircumference: 0,
        bloodType: '',
        description: '',
        profilePicture: null,
        coverPhoto: null,
      ),
    ));
  });


  final GetChildData testChildData = GetChildData(
    id: '123',
    name: 'Test Baby',
    gender: 'Male',
    birthDate: '2025-01-01',
    timeOfBirth: '2025-01-01 10:00:00',
    height: 50,
    weight: 3.5,
    headCircumference: 34,
    bloodType: 'O+',
    description: 'Test description',
    profilePictureUrl: '',
    coverPhotoUrl: '',
  );

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: BlocProvider<ChildBloc>.value(
        value: mockChildBloc,
        child: EditChildProfile(childData: testChildData),
      ),
      routes: {
        PathConstants.viewChildProfile: (_) => const Scaffold(body: Text('viewchildprofile')), // dummy screen
      },
    );
  }

  testWidgets('renders all essential form fields and button', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());

    expect(find.text(AppStrings.babyNameLabel), findsOneWidget);
    expect(find.text(AppStrings.genderLabel), findsOneWidget);
    expect(find.text(AppStrings.dobLabel), findsOneWidget);
    expect(find.text(AppStrings.heightLabel), findsOneWidget);
    expect(find.text(AppStrings.weightLabel), findsOneWidget);
    expect(find.text(AppStrings.headCircumferenceLabel), findsOneWidget);
    expect(find.text(AppStrings.bloodGroupLabel), findsOneWidget);
    expect(find.text(AppStrings.aboutyourChildLabel), findsOneWidget);
    expect(find.text(AppStrings.updateTxt), findsOneWidget);
  });

  testWidgets('pops with true on ChildSuccess', (tester) async {
    whenListen(
      mockChildBloc,
      Stream.fromIterable([
        ChildLoading(),
        ChildSuccess(message: 'Updated successfully'),
      ]),
      initialState: ChildInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    // Let the BlocListener process the success state
    await tester.pumpAndSettle();

    // Expect screen popped (no longer in widget tree)
    expect(find.byType(EditChildProfile), findsNothing);
  });

  testWidgets('shows snackbar on ChildFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockChildBloc,
      Stream.fromIterable([
        ChildLoading(),
        ChildFailure(errorMessage),
      ]),
      initialState: ChildInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    // Let the BlocListener process the failure state and show snackbar
    await tester.pump(); // for loading
    await tester.pump(const Duration(seconds: 1)); // for snackbar to appear

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('shows loader when ChildLoading state is emitted', (tester) async {
    whenListen(
      mockChildBloc,
      Stream.fromIterable([ChildLoading()]),
      initialState: ChildInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // Start frame

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });


}
