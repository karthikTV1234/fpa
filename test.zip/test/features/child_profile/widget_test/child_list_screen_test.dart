import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/child_profile/presentation/screens/child_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockChildBloc extends MockBloc<ChildEvent, ChildState>
    implements ChildBloc {}

class FakeChildEvent extends Fake implements ChildEvent {}
class FakeChildState extends Fake implements ChildState {}

void main() {
  late MockChildBloc mockChildBloc;

  setUpAll(() {
    registerFallbackValue(FakeChildEvent());
    registerFallbackValue(FakeChildState());
  });

  setUp(() {
    mockChildBloc = MockChildBloc();
  });

  Future<void> pumpWidget(WidgetTester tester, Widget widget) async {
    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<ChildBloc>.value(
          value: mockChildBloc,
          child: widget,
        ),
      ),
    );
  }

  testWidgets('renders essential UI elements', (tester) async {
    when(() => mockChildBloc.state).thenReturn(ChildInitial());

    await pumpWidget(tester, const ChildListScreen(children: []));
    expect(find.text(AppStrings.chooseYourChildText), findsOneWidget);
    expect(find.text(AppStrings.selectChildDetailsText), findsOneWidget);
  });

  testWidgets('shows loader when ChildLoading state is emitted', (tester) async {
    whenListen(
      mockChildBloc,
      Stream.fromIterable([ChildLoading()]),
      initialState: ChildInitial(),
    );

    await pumpWidget(tester, const ChildListScreen(children: []));
    await tester.pump();

    expect(find.text(AppStrings.loading), findsOneWidget);
  });

  testWidgets('shows snackbar on ChildFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockChildBloc,
      Stream.fromIterable([ChildFailure(errorMessage)]),
      initialState: ChildInitial(),
    );

    await pumpWidget(tester, const ChildListScreen(children: []));
    await tester.pump(); // let the listener respond

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('navigates to add child screen on Add button press', (tester) async {
    when(() => mockChildBloc.state).thenReturn(ChildInitial());

    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addChild: (_) => const Scaffold(body: Text('Add Child Screen')),
        },
        home: BlocProvider<ChildBloc>.value(
          value: mockChildBloc,
          child: const ChildListScreen(children: []),
        ),
      ),
    );

    // Ensure the add button is found and tapped
    final addButton = find.byIcon(Icons.add);
    expect(addButton, findsOneWidget);

    await tester.tap(addButton);
    await tester.pumpAndSettle();

    expect(find.text('Add Child Screen'), findsOneWidget);
  });

  testWidgets('renders list of children on ChildSuccess', (tester) async {
    final mockChildren = [
      ChildProfile(id: "1", name: 'Baby One', birthDate: '2022-01-01'),
      ChildProfile(id: "2", name: 'Baby Two', birthDate: '2023-02-02'),
    ];

    when(() => mockChildBloc.state).thenReturn(ChildSuccess(
      message: 'Loaded'
    ));

    await pumpWidget(tester, ChildListScreen(children: mockChildren));
    await tester.pump();

    // Assert that each child's name is displayed
    for (var child in mockChildren) {
      expect(find.text(child.name ?? ''), findsOneWidget);
    }
  });



}
