import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/child_profile/data/model/add_child_model.dart';
import 'package:child_health_story/features/child_profile/data/model/child_detail_model.dart';
import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/data/model/delete_child_model.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/features/child_profile/data/repository/child_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late ChildRepository repository;

  setUpAll(() {
    registerFallbackValue(AddChildReqModel(
      name: '',
      birthDate: '',
      timeOfBirth: '',
      weight: 0,
      weightUnit: '',
      height: 0,
      headCircumference: 0,
      gender: '',
      bloodType: '',
      description: '',
    ));

    registerFallbackValue(UpdateChildReqModel(
      userId: '',
      name: '',
      birthDate: '',
      timeOfBirth: '',
      weight: 0,
      weightUnit: '',
      height: 0,
      headCircumference: 0,
      gender: '',
      bloodType: '',
      description: '',
    ));
  });


  setUp(() {
    mockDio = MockDio();
    repository = ChildRepository(dio: mockDio);
  });

  final addChildReq = AddChildReqModel(
    name: 'John',
    birthDate: '2023-01-01',
    timeOfBirth: '10:00',
    weight: 3.2,
    weightUnit: 'kg',
    height: 50,
    headCircumference: 35,
    gender: 'Male',
    bloodType: 'O+',
    description: 'Healthy baby',
  );

  final updateChildReq = UpdateChildReqModel(
    userId: 'child123',
    name: 'John Updated',
    birthDate: '2023-01-01',
    timeOfBirth: '10:30',
    weight: 3.5,
    weightUnit: 'kg',
    height: 52,
    headCircumference: 36,
    gender: 'Male',
    bloodType: 'O+',
    description: 'Updated details',
  );

  final childListResJson = {
    'statusCode': 200,
    'message': 'Fetched successfully',
    'data': [
      {
        'id': 'child1',
        'userId': 'user1',
        'name': 'John',
        'age': '1 year',
        'birthDate': '2023-01-01',
        'timeOfBirth': '10:00',
        'weight': 3.2,
        'weightUnit': 'kg',
        'height': 50,
        'headCircumference': 35,
        'gender': 'Male',
        'bloodType': 'O+',
        'profilePictureUrl': 'http://example.com/profile.jpg',
        'coverPhotoUrl': 'http://example.com/cover.jpg',
        'description': 'Healthy baby',
        'createdAt': '2023-01-01T00:00:00Z',
        'updatedAt': '2023-01-01T00:00:00Z',
      },
    ]
  };

  final getChildDetailResJson = {
    'statusCode': 200,
    'message': 'Fetched successfully',
    'data': {
      'id': 'child1',
      'userId': 'user1',
      'name': 'John',
      'birthDate': '2023-01-01',
      'timeOfBirth': '10:00',
      'weight': 3.2,
      'weightUnit': 'kg',
      'height': 50,
      'headCircumference': 35,
      'gender': 'Male',
      'bloodType': 'O+',
      'profilePictureUrl': 'http://example.com/profile.jpg',
      'coverPhotoUrl': 'http://example.com/cover.jpg',
      'description': 'Healthy baby',
    },
  };
  const childId = 'child123';
  final deleteChildResJson = {
    'statusCode': 200,
    'message': 'Deleted successfully',
  };

  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };

  void testRepositoryFunction(
      String description,
      Future Function() call,
      void Function(dynamic) assertions,
      ) {
    test(description, () async {
      final result = await call();
      assertions(result);
    });
  }

  group('addChild', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.addChild(addChildReq);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Invalid data'},
      ));

      final result = await repository.addChild(addChildReq);

      expect(result.isError, true);
      expect(result.error, 'Invalid data');
    });


    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.addChild(addChildReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });


    test('returns failure on DioException', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(DioException(requestOptions: RequestOptions(path: ''), response: Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Error occurred'})));

      final result = await repository.addChild(addChildReq);

      expect(result.isError, true);
      expect(result.error, 'Error occurred');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.addChild(addChildReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });

  });

  group('getChildList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: childListResJson));

      final result = await repository.getChildList();

      expect(result.isSuccess, true);
      expect(result.data, isA<ChildListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
      expect(result.data!.data!.first.name, 'John');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Fetch failed'}));

      final result = await repository.getChildList();

      expect(result.isError, true);
      expect(result.error, 'Fetch failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(requestOptions: RequestOptions(path: ''), type: DioExceptionType.connectionTimeout));

      final result = await repository.getChildList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(requestOptions: RequestOptions(path: ''), response: Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Server error'})));

      final result = await repository.getChildList();

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getChildList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('getChildDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 200,
              data: getChildDetailResJson));

      final result = await repository.getChildDetails('child1');

      expect(result.isSuccess, true);
      expect(result.data, isA<GetChildProfileResModel>());
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Child not found'}));

      final result = await repository.getChildDetails('child1');

      expect(result.isError, true);
      expect(result.error, 'Child not found');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenThrow(
          DioException(
              requestOptions: RequestOptions(path: ''),
              type: DioExceptionType.connectionTimeout));

      final result = await repository.getChildDetails('child1');

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenThrow(
          DioException(
              requestOptions: RequestOptions(path: ''),
              type: DioExceptionType.connectionError));

      final result = await repository.getChildDetails('child1');

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenThrow(
          DioException(
              requestOptions: RequestOptions(path: ''),
              response: Response(
                  requestOptions: RequestOptions(path: ''),
                  statusCode: 400,
                  data: {'message': 'Server error'})));

      final result = await repository.getChildDetails('child1');

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });
    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getChildDetails('child1');

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateChildDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.updateChildDetails(updateChildReq);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Invalid data'},
      ));

      final result = await repository.updateChildDetails(updateChildReq);

      expect(result.isError, true);
      expect(result.error, 'Invalid data');
    });


    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateChildDetails(updateChildReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(DioException(requestOptions: RequestOptions(path: ''), response: Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Update failed'})));

      final result = await repository.updateChildDetails(updateChildReq);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.updateChildDetails(updateChildReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('deleteChild', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: deleteChildResJson,
      ));

      final result = await repository.deleteChild(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<DeleteChildResModel>());
      expect(result.data!.message, 'Deleted successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Deletion failed'},
      ));

      final result = await repository.deleteChild(childId);

      expect(result.isError, true);
      expect(result.error, 'Deletion failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteChild(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteChild(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Child not found'},
        ),
      ));

      final result = await repository.deleteChild(childId);

      expect(result.isError, true);
      expect(result.error, 'Child not found');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteChild(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });
}
