import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/child_profile/data/model/add_child_model.dart';
import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/data/model/child_detail_model.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/features/child_profile/data/model/delete_child_model.dart';
import 'package:child_health_story/features/child_profile/data/repository/child_repository.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockChildRepository extends Mock implements ChildRepository {}
class FakeAddChildReqModel extends Fake implements AddChildReqModel {}
class FakeUpdateChildReqModel extends Fake implements UpdateChildReqModel {}

void main() {
  late MockChildRepository mockChildRepository;
  late ChildBloc childBloc;

  setUpAll(() {
    registerFallbackValue(FakeAddChildReqModel());
    registerFallbackValue(FakeUpdateChildReqModel());
  });

  setUp(() {
    mockChildRepository = MockChildRepository();
    childBloc = ChildBloc(childRepository: mockChildRepository);
  });

  final addChildReq = AddChildReqModel(
    name: 'Test Baby',
    birthDate: '2025-01-01',
    timeOfBirth: '10:00',
    weight: 3.5,
    weightUnit: 'kg',
    height: 50,
    headCircumference: 34,
    gender: 'Male',
    bloodType: 'O+',
    description: 'Healthy baby',
  );
  final addChildData = AddChildData(
    id: 'child123',
    name: 'Test Baby',
    birthDate: '2025-01-01',
    profilePictureUrl: 'https://example.com/photo.jpg',
    coverPhotoUrl: 'https://example.com/cover.jpg',
  );

  final addChildRes = AddChildResModel(
    statusCode: 200,
    message: AppStrings.childAddedSuccessMessage,
    data: addChildData,
  );

  final updateChildReq = UpdateChildReqModel(
    userId: 'child123',
    name: 'Updated Baby',
    birthDate: '2025-01-02',
    timeOfBirth: '11:00',
    weight: 3.8,
    weightUnit: 'kg',
    height: 52,
    headCircumference: 35,
    gender: 'Male',
    bloodType: 'A+',
    description: 'Updated description',
  );

  final commonRes = CommonResModel(
    statusCode: 200,
    message: AppStrings.childAddedSuccessMessage,
  );

  final childListRes = ChildListResModel(
    statusCode: 200,
    data: [],
  );

  final getChildProfileRes = GetChildProfileResModel(
    statusCode: 200,
    data: GetChildData(name: 'Test Baby'),
  );

  final deleteChildRes = DeleteChildResModel(
    statusCode: 200,
    message: AppStrings.childDeleteSuccessMessage,
  );

  group('ChildBloc AddChildEvent', () {
    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildSuccess] on successful add',
      build: () {
        when(() => mockChildRepository.addChild(any()))
            .thenAnswer((_) async => Result.success(addChildRes));
        return childBloc;
      },
      act: (bloc) => bloc.add(AddChildEvent(addChildReqModel: addChildReq)),
      expect: () => [
        ChildLoading(),
        ChildSuccess(message: AppStrings.childAddedSuccessMessage),
      ],
    );

    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildFailure] on failed add',
      build: () {
        when(() => mockChildRepository.addChild(any()))
            .thenAnswer((_) async => Result.failure('Failed to add child'));
        return childBloc;
      },
      act: (bloc) => bloc.add(AddChildEvent(addChildReqModel: addChildReq)),
      expect: () => [
        ChildLoading(),
        ChildFailure('Failed to add child'),
      ],
    );
  });

  group('ChildBloc FetchChildListEvent', () {
    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildListSuccess] on successful fetch',
      build: () {
        when(() => mockChildRepository.getChildList())
            .thenAnswer((_) async => Result.success(childListRes));
        return childBloc;
      },
      act: (bloc) => bloc.add(FetchChildListEvent()),
      expect: () => [
        ChildLoading(),
        ChildListSuccess(childListRes.data ?? []),
      ],
    );

    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildFailure] on failed fetch',
      build: () {
        when(() => mockChildRepository.getChildList())
            .thenAnswer((_) async => Result.failure('Failed to fetch list'));
        return childBloc;
      },
      act: (bloc) => bloc.add(FetchChildListEvent()),
      expect: () => [
        ChildLoading(),
        ChildFailure('Failed to fetch list'),
      ],
    );
  });

  group('ChildBloc FetchChildByIdEvent', () {
    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildByIdSuccess] on successful fetch',
      build: () {
        when(() => mockChildRepository.getChildDetails(any()))
            .thenAnswer((_) async => Result.success(getChildProfileRes));
        return childBloc;
      },
      act: (bloc) => bloc.add(FetchChildByIdEvent(childId: 'child123')),
      expect: () => [
        ChildLoading(),
        ChildByIdSuccess(getChildProfileRes.data),
      ],
    );

    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildFailure] on failed fetch',
      build: () {
        when(() => mockChildRepository.getChildDetails(any()))
            .thenAnswer((_) async => Result.failure('Failed to fetch child'));
        return childBloc;
      },
      act: (bloc) => bloc.add(FetchChildByIdEvent(childId: 'child123')),
      expect: () => [
        ChildLoading(),
        ChildFailure('Failed to fetch child'),
      ],
    );
  });

  group('ChildBloc UpdateChildEvent', () {
    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildSuccess] on successful update',
      build: () {
        when(() => mockChildRepository.updateChildDetails(any()))
            .thenAnswer((_) async => Result.success(commonRes));
        return childBloc;
      },
      act: (bloc) => bloc.add(UpdateChildEvent(updateChildReqModel: updateChildReq)),
      expect: () => [
        ChildLoading(),
        ChildSuccess(message: AppStrings.childAddedSuccessMessage),
      ],
    );

    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildFailure] on failed update',
      build: () {
        when(() => mockChildRepository.updateChildDetails(any()))
            .thenAnswer((_) async => Result.failure('Failed to update child'));
        return childBloc;
      },
      act: (bloc) => bloc.add(UpdateChildEvent(updateChildReqModel: updateChildReq)),
      expect: () => [
        ChildLoading(),
        ChildFailure('Failed to update child'),
      ],
    );
  });

  group('ChildBloc DeleteChildEvent', () {
    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildSuccess] on successful delete',
      build: () {
        when(() => mockChildRepository.deleteChild(any()))
            .thenAnswer((_) async => Result.success(commonRes));
        return childBloc;
      },
      act: (bloc) => bloc.add(DeleteChildEvent(childId: 'child123')),
      expect: () => [
        ChildLoading(),
        ChildSuccess(message: AppStrings.childDeleteSuccessMessage),
      ],
    );

    blocTest<ChildBloc, ChildState>(
      'emits [ChildLoading, ChildFailure] on failed delete',
      build: () {
        when(() => mockChildRepository.deleteChild(any()))
            .thenAnswer((_) async => Result.failure('Failed to delete child'));
        return childBloc;
      },
      act: (bloc) => bloc.add(DeleteChildEvent(childId: 'child123')),
      expect: () => [
        ChildLoading(),
        ChildFailure('Failed to delete child'),
      ],
    );
  });
}
