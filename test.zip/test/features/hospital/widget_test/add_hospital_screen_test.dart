import 'package:child_health_story/features/hospital/presentation/add_hospital_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';

class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockHospitalBloc.selectedCountryCode).thenReturn('+91');
  });

  Future<void> pumpAddHospitalDialog(WidgetTester tester, {
    HospitalBloc? hospitalBloc,
  }) async {
    final mockHospitalBloc = hospitalBloc ?? MockHospitalBloc();
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());
    when(() => mockHospitalBloc.addressSearchList).thenReturn([]);
    when(() => mockHospitalBloc.selectedCountryCode).thenReturn('+91');

    await tester.pumpWidget(
      BlocProvider<HospitalBloc>.value(
        value: mockHospitalBloc,
        child: MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(size: Size(1080, 1920)),
            child: Scaffold(
              body: SizedBox(
                width: 600,
                child: const AddHospitalDialog(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  testWidgets(
    'renders AddHospitalDialog with Add Hospital button',
        (tester) async {
      await pumpAddHospitalDialog(tester);

      expect(find.text(AppStrings.addNewHospital), findsOneWidget);
      expect(find.text(AppStrings.hospitalNameLabel), findsOneWidget);
      expect(find.text(AppStrings.searchAddressLabel), findsOneWidget);
      expect(find.text(AppStrings.phoneLabelWithOutAsterisk), findsOneWidget);
      expect(find.text(AppStrings.emailLabel), findsOneWidget);
      expect(find.text(AppStrings.notesLabelWithOutAsterisk), findsOneWidget);
      expect(find.text(AppStrings.addHospitalBtnText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await pumpAddHospitalDialog(tester);
    await tester.tap(find.text(AppStrings.addHospitalBtnText));
    await tester.pumpAndSettle();
    expect(find.textContaining('required'), findsWidgets);
  });

  testWidgets('shows snackbar when hospital add fails', (tester) async {
    whenListen(
      mockHospitalBloc,
      Stream.fromIterable([
        HospitalLoading(),
        HospitalFailure('Failed to save hospital'),
      ]),
      initialState: HospitalInitial(),
    );

    await pumpAddHospitalDialog(tester, hospitalBloc: mockHospitalBloc);
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();

    expect(find.text('Failed to save hospital'), findsOneWidget);
  });

  testWidgets('dispatches AddHospitalEvent when valid form is submitted', (tester) async {
    whenListen(
      mockHospitalBloc,
      Stream<HospitalState>.fromIterable([
        HospitalInitial(),
        HospitalSuccess(message: 'Successfully added hospital'),
      ]),
      initialState: HospitalInitial(),
    );

    whenListen(
      mockHospitalBloc,
      Stream<HospitalState>.fromIterable([
        HospitalInitial(),
      ]),
      initialState: HospitalInitial(),
    );

    await pumpAddHospitalDialog(tester,
      hospitalBloc: mockHospitalBloc,
    );

    await tester.pumpAndSettle();

    final textFields = find.byType(TextFormField);
    expect(textFields, findsWidgets);
    await tester.enterText(textFields.at(0), 'Apex Hospital');

    // Tap Add button
    final addButton = find.text(AppStrings.addHospitalBtnText);
    await tester.tap(addButton);
    await tester.pump();
  });
}
