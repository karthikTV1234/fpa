import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/hospital/data/model/hospital_model.dart';
import 'package:child_health_story/features/hospital/data/repository/hospital_repository.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late HospitalRepository repository;
  late MockDio mockDio;

  setUp(() {
    mockDio = MockDio();
    repository = HospitalRepository(dio: mockDio);
  });
  const childId = 'child_123';
  final addHospitalReqModel = AddHospitalReqModel(
    childId: 'child_123',
    hospitalName: 'City Care Hospital',
    address: '123 Main Street, Downtown',
    latitude: 12.9716,
    longitude: 77.5946,
    email: 'info@citycare.com',
    phone: '9876543210',
    notes: '24/7 Emergency services',
  );
  final addHospitalResJson = {
    "statusCode": 200,
    "message": "Hospital added successfully",
    "data": {
      "id": "hosp_001",
      "childId": "child_001",
      "hospitalName": "Sunshine Children Hospital",
      "phone": "9876543210",
      "email": "info@sunshine.com",
      "address": "123 Pediatric Lane, City Center",
      "notes": "Excellent pediatric care.",
      "latitude": 12.9716,
      "longitude": 77.5946
    }
  };



  final hospitalListJson = {
    'statusCode': 200,
    'message': 'Fetched successfully',
    'data': [
      {
        'id': 'hosp_001',
        'hospitalName': 'City Hospital',
        'address': '123 Main St',
        'phone': '9876543210',
      }
    ],
  };

  group('addHospital', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
          requestOptions: RequestOptions(path: ''), statusCode: 200,
          data: addHospitalResJson
      ),
      );

      final result = await repository.addHospital(addHospitalReqModel);
      expect(result.isSuccess, true);
      expect(result.data, isA<AddHospitalResModel>());
      expect(result.data!.message, 'Hospital added successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Invalid request'},
        ),
      );

      final result = await repository.addHospital(addHospitalReqModel);

      expect(result.isError, true);
      expect(result.error, 'Invalid request');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionTimeout,
        ),
      );

      final result = await repository.addHospital(addHospitalReqModel);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          response: Response(
            requestOptions: RequestOptions(path: ''),
            statusCode: 400,
            data: {'message': 'Server error'},
          ),
        ),
      );

      final result = await repository.addHospital(addHospitalReqModel);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
        Exception('Unexpected error'),
      );

      final result = await repository.addHospital(addHospitalReqModel);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });

  });

  group('getHospitalList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: hospitalListJson,
      ));

      final result = await repository.getHospitalList();
      expect(result.isSuccess, true);
      expect(result.data!.message, 'Fetched successfully');
      expect(result.data!.data.first.hospitalName, 'City Hospital');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch hospitals'},
      ));

      final result = await repository.getHospitalList();

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch hospitals');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getHospitalList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getHospitalList();

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getHospitalList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });

  });

}
