import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/hospital/data/model/hospital_model.dart';
import 'package:child_health_story/features/hospital/data/repository/hospital_repository.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';

class MockHospitalRepository extends Mock implements HospitalRepository {}

void main() {
  late HospitalBloc bloc;
  late MockHospitalRepository mockRepository;

  setUp(() {
    mockRepository = MockHospitalRepository();
    bloc = HospitalBloc(hospitalRepository: mockRepository);
  });

  const childId = 'child_123';

  final addHospitalReq = AddHospitalReqModel(
    childId: childId,
    hospitalName: 'Apollo',
    address: 'Bangalore',
    latitude: 12.97,
    longitude: 77.59,
    email: 'apollo@hosp.com',
    phone: '1234567890',
    notes: '24x7 available',
  );

  final addHospitalRes = AddHospitalResModel(
    statusCode: 200,
    message: "Hospital added successfully",
    data: HospitalAddData(
      id: 'hos_001',
      childId: childId,
      hospitalName: 'Apollo',
      phone: '1234567890',
      email: 'apollo@hosp.com',
      address: 'Bangalore',
      notes: '24x7 available',
      isFavorite: true,
      latitude: 12.97,
      longitude: 77.59,
      userId: 'user_1',
    ),
  );

  final hospitalListRes = HospitalListResModel(
    statusCode: 200,
    message: 'Hospitals fetched successfully',
    data: [
      HospitalListData(id: 'hos_001', hospitalName: 'Apollo'),
      HospitalListData(id: 'hos_002', hospitalName: 'Fortis'),
    ],
  );
  final hospitalListEmptyRes = HospitalListResModel(
    statusCode: 200,
    message: 'Hospitals fetched successfully',
    data: [],
  );

  group('AddHospitalEvent', () {
    blocTest<HospitalBloc, HospitalState>(
      'emits [HospitalLoading, HospitalSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addHospital(addHospitalReq))
            .thenAnswer((_) async => Result.success(addHospitalRes));
        return bloc;
      },
      act: (bloc) => bloc.add(AddHospitalEvent(addHospitalReqModel: addHospitalReq)),
      expect: () => [
        HospitalLoading(),
        HospitalSuccess(message: 'Hospital added successfully'),
      ],
      verify: (_) {
        verify(() => mockRepository.addHospital(addHospitalReq)).called(1);
      },
    );

    blocTest<HospitalBloc, HospitalState>(
      'emits [HospitalLoading, HospitalFailure]  when repository returns failure',
      build: () {
        when(() => mockRepository.addHospital(addHospitalReq))
            .thenAnswer((_) async => Result.failure('Add failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(AddHospitalEvent(addHospitalReqModel: addHospitalReq)),
      expect: () => [
        HospitalLoading(),
        HospitalFailure('Add failed'),
      ],
    );
  });

  group('FetchHospitalListEvent', () {
    blocTest<HospitalBloc, HospitalState>(
      'emits [HospitalLoading, HospitalListSuccess] on success',
      build: () {
        when(() => mockRepository.getHospitalList())
            .thenAnswer((_) async => Result.success(hospitalListEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHospitalListEvent()),
      expect: () =>  [
        HospitalLoading(),
        HospitalListSuccess([]),
      ],
      verify: (_)  {
        verify(() => mockRepository.getHospitalList()).called(1);
      },
    );

    blocTest<HospitalBloc, HospitalState>(
      'emits [HospitalLoading, HospitalListSuccess] on success with non-empty list',
      build: () {
        when(() => mockRepository.getHospitalList())
            .thenAnswer((_) async => Result.success(hospitalListRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHospitalListEvent()),
      expect: () => [
        HospitalLoading(),
        isA<HospitalListSuccess>().having(
              (s) => s.hospitals,
          'hospitals',
          isNotEmpty,
        ),
      ],
      verify: (_) {
        verify(() => mockRepository.getHospitalList()).called(1);
      },
    );

    blocTest<HospitalBloc, HospitalState>(
      'emits [HospitalLoading, HospitalFailure] on failure',
      build: () {
        when(() => mockRepository.getHospitalList())
            .thenAnswer((_) async => Result.failure('Fetch failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHospitalListEvent()),
      expect: () => [
        HospitalLoading(),
        HospitalFailure('Fetch failed'),
      ],
    );
  });

}
