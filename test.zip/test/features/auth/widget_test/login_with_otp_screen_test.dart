import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:child_health_story/features/auth/data/repository/firebase_auth_repository.dart';
import 'package:child_health_story/features/auth/presentation/bloc/login_otp_bloc.dart';
import 'package:child_health_story/features/auth/presentation/login_with_otp.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockFirebaseAuthRepository extends Mock implements FirebaseAuthRepository {}
class MockAuthRepository extends Mock implements AuthRepository {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockFirebaseAuthRepository mockFirebaseAuthRepository;
  late MockAuthRepository mockAuthRepository;

  setUpAll(() {
    registerFallbackValue("");
  });

  setUp(() {
    mockFirebaseAuthRepository = MockFirebaseAuthRepository();
    mockAuthRepository = MockAuthRepository();
  });

  Future<void> pumpLoginOTPScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.otpScreen: (_) => const Placeholder(), // dummy widget for test
        },
        home: BlocProvider(
          create: (_) => LoginOtpBloc(
              firebaseAuthRepository: mockFirebaseAuthRepository,
              authRepository: mockAuthRepository
          ),
          child:  LoginWithOtp(),
        ),
      ),
    );
  }

  group('LoginWithOtpScreen Validation Tests', () {
    testWidgets('shows validation errors when fields are empty', (tester) async {
      await pumpLoginOTPScreen(tester);

      await tester.tap(find.text(AppStrings.continueText));
      await tester.pumpAndSettle();

      expect(find.text(ValidationMessages.plsEnterPhoneNumber), findsOneWidget);
    });

    testWidgets('shows validation error for invalid phone number', (tester) async {
      await pumpLoginOTPScreen(tester);

      await tester.enterText(find.byType(TextFormField).at(0), '1234');
      await tester.tap(find.text(AppStrings.continueText));
      await tester.pumpAndSettle();

      expect(find.text(ValidationMessages.plsEnterValidPhoneNumber), findsOneWidget);
    });

    testWidgets('Requests OTP on valid phone number', (tester) async {
      const testPhoneNumber = '9876543210';
      const testVerificationId = 'test_verification_id';

      when(() => mockFirebaseAuthRepository.requestOtp(
        phoneNumber: any(named: 'phoneNumber'),
      )).thenAnswer((_) async => Result.success(testVerificationId));

      await pumpLoginOTPScreen(tester);
      await tester.enterText(find.byType(TextFormField), testPhoneNumber);

      await tester.tap(find.text(AppStrings.continueText));
      await tester.pump();
      await tester.pump();
      await tester.pumpAndSettle();
      verify(() => mockFirebaseAuthRepository.requestOtp(phoneNumber: testPhoneNumber)).called(1);

    });
  });
}
