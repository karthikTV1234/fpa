import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/auth/data/model/login_model.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:child_health_story/features/auth/presentation/login_screen.dart';
import 'package:child_health_story/features/auth/presentation/bloc/login_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockAuthRepository extends Mock implements AuthRepository {}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockAuthRepository mockAuthRepository;

  setUpAll(() {
    registerFallbackValue(LoginReqModel(
      email: '',
      password: '',
      deviceId: '',
    ));
  });

  setUp(() {
    mockAuthRepository = MockAuthRepository();
  });

  Future<void> pumpLoginScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          '/addchild': (context) => const Placeholder(key: Key('addChildScreen')),
          '/forgotPassword': (context) => const Placeholder(key: Key('forgotPasswordScreen')),
        },
        home: BlocProvider(
          create: (_) => LoginBloc(authRepository: mockAuthRepository),
          child: const LoginScreen(),
        ),
      ),
    );
  }

  testWidgets('shows validation errors when fields are empty', (tester) async {
    await pumpLoginScreen(tester);

    await tester.tap(find.text(AppStrings.continueText));
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.emailReq), findsOneWidget);
    expect(find.text(ValidationMessages.passwordReq), findsOneWidget);
  });

  testWidgets('shows validation error for invalid email', (tester) async {
    await pumpLoginScreen(tester);

    await tester.enterText(find.byType(TextFormField).at(0), 'invalidemail');
    await tester.enterText(find.byType(TextFormField).at(1), 'Password@123');

    await tester.tap(find.text(AppStrings.continueText));
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.invalidEmail), findsOneWidget);
  });

  testWidgets('shows validation error for weak password', (tester) async {
    await pumpLoginScreen(tester);

    await tester.enterText(find.byType(TextFormField).at(1), 'weak');
    await tester.tap(find.text(AppStrings.continueText));
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.passwordPolicy), findsOneWidget);
  });

  testWidgets('Login successfully', (tester) async {
    when(() => mockAuthRepository.login(any())).thenAnswer(
          (_) async => Result.success(
              LoginResModel(
              accessToken: 'mock_token_123',
              firstName: 'Test',
              lastName: 'User',
              )
          ),
    );

    await pumpLoginScreen(tester);

    final emailField = find.byType(TextFormField).at(0);
    final passwordField = find.byType(TextFormField).at(1);

    await tester.enterText(emailField, 'test@example.com');
    await tester.enterText(passwordField, 'StrongPass@123');

    await tester.tap(find.text(AppStrings.continueText));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();

  });
}
