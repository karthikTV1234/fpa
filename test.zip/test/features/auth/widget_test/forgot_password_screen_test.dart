import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/auth/presentation/bloc/forgot_password_bloc.dart';
import 'package:child_health_story/features/auth/presentation/forgot_password.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MockForgotPasswordBloc extends MockBloc<ForgotPasswordEvent, ForgotPasswordState> implements ForgotPasswordBloc {}

void main() {
  late MockForgotPasswordBloc mockBloc;

  setUp(() {
    mockBloc = MockForgotPasswordBloc();
  });

  tearDown(() {
    mockBloc.close();
  });

  Future<void> pumpForgotPasswordScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<ForgotPasswordBloc>.value(
          value: mockBloc,
          child: const ForgotPasswordScreen(),
        ),
        routes: {
          PathConstants.otpScreen: (context) => const Placeholder(key: Key('otpScreen')),
        },
      ),
    );
  }

  group('ForgotPasswordScreen Widget Tests', () {
    testWidgets('shows validation error if email is not entered', (tester) async {
      when(() => mockBloc.state).thenReturn(ForgotPasswordInitial());

      await pumpForgotPasswordScreen(tester);

      final shareOTPButton = find.text(AppStrings.shareOTPText);
      await tester.tap(shareOTPButton);
      await tester.pump();

      expect(find.text(ValidationMessages.emailReq), findsOneWidget);
    });

    testWidgets('shows validation error for invalid email format', (tester) async {
      when(() => mockBloc.state).thenReturn(ForgotPasswordInitial());

      await pumpForgotPasswordScreen(tester);

      final emailField = find.byType(TextFormField);
      await tester.enterText(emailField, 'invalidemail');

      final shareOTPButton = find.text(AppStrings.shareOTPText);
      await tester.tap(shareOTPButton);
      await tester.pump();

      expect(find.text(ValidationMessages.invalidEmail), findsOneWidget);
    });

    testWidgets('shows error snackbar on API failure', (tester) async {
      whenListen(
        mockBloc,
        Stream.fromIterable([
          ForgotPasswordInitial(),
          ForgotPasswordLoading(),
          ForgotPasswordFailure('Failed to send reset email'),
        ]),
        initialState: ForgotPasswordInitial(),
      );

      await pumpForgotPasswordScreen(tester);

      final emailField = find.byType(TextFormField);
      await tester.enterText(emailField, 'test@example.com');

      final shareOTPButton = find.text(AppStrings.shareOTPText);
      await tester.tap(shareOTPButton);
      await tester.pump(); // loader
      await tester.pump(); // error snackbar

      expect(find.text('Failed to send reset email'), findsOneWidget);
    });

    testWidgets('navigates to OTP screen on success', (tester) async {
      whenListen(
        mockBloc,
        Stream.fromIterable([
          ForgotPasswordInitial(),
          ForgotPasswordLoading(),
          ForgotPasswordSuccess(message: 'Email sent successfully'),
        ]),
        initialState: ForgotPasswordInitial(),
      );

      await pumpForgotPasswordScreen(tester);

      final emailField = find.byType(TextFormField);
      await tester.enterText(emailField, 'test@example.com');

      final shareOTPButton = find.text(AppStrings.shareOTPText);
      await tester.tap(shareOTPButton, warnIfMissed: false);
      await tester.pump(); // loader
      await tester.pump(); // success snackbar
      await tester.pumpAndSettle(); // navigation
      
      // Verify navigation
      expect(find.byKey(const Key('otpScreen')), findsOneWidget);
    });
  });
}
