import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/auth/data/model/forgot_password_model.dart';
import 'package:child_health_story/features/auth/data/model/reset_password_model.dart';
import 'package:child_health_story/features/auth/data/model/validate_reset_code_model.dart';
import 'package:child_health_story/features/auth/data/repository/forgot_password_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late ForgotPasswordRepository forgotPasswordRepository;

  setUp(() {
    mockDio = MockDio();
    forgotPasswordRepository = ForgotPasswordRepository(dio: mockDio);
  });

  final forgotPasswordReq = ForgotPasswordReqModel(email: 'john@example.com');
  final validateResetCodeReq = ValidateResetCodeReqModel(email: 'john@example.com', code: '123456');
  final setNewPasswordReq = SetNewPasswordReqModel(email: 'john@example.com', newPassword: 'newPassword123');

  final commonSuccessRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };

  test('resetPassword returns success on 200 response', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 200,
      data: commonSuccessRes,
    ));

    final result = await forgotPasswordRepository.resetPassword(forgotPasswordReq);

    expect(result.isSuccess, true);
    expect(result.data, isNotNull);
    expect(result.data!.message, 'Operation successful');
  });

  test('resetPassword returns failure on non-200 with message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 400,
      data: {'message': 'Invalid email'},
    ));

    final result = await forgotPasswordRepository.resetPassword(forgotPasswordReq);

    expect(result.isError, true);
    expect(result.error, 'Invalid email');
  });

  test('resetPassword returns failure on DioException with response message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      response: Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Email not registered'},
      ),
    ));

    final result = await forgotPasswordRepository.resetPassword(forgotPasswordReq);

    expect(result.isError, true);
    expect(result.error, 'Email not registered');
  });

  test('validateResetCode returns success on 200 response', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 200,
      data: commonSuccessRes,
    ));

    final result = await forgotPasswordRepository.validateResetCode(validateResetCodeReq);

    expect(result.isSuccess, true);
    expect(result.data, isNotNull);
    expect(result.data!.message, 'Operation successful');
  });

  test('validateResetCode returns failure on non-200 with message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 400,
      data: {'message': 'Invalid code'},
    ));

    final result = await forgotPasswordRepository.validateResetCode(validateResetCodeReq);

    expect(result.isError, true);
    expect(result.error, 'Invalid code');
  });

  test('validateResetCode returns failure on DioException with response message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      response: Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Code expired'},
      ),
    ));

    final result = await forgotPasswordRepository.validateResetCode(validateResetCodeReq);

    expect(result.isError, true);
    expect(result.error, 'Code expired');
  });

  test('setNewPassword returns success on 200 response', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 200,
      data: commonSuccessRes,
    ));

    final result = await forgotPasswordRepository.setNewPassword(setNewPasswordReq);

    expect(result.isSuccess, true);
    expect(result.data, isNotNull);
    expect(result.data!.message, 'Operation successful');
  });

  test('setNewPassword returns failure on non-200 with message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 400,
      data: {'message': 'Weak password'},
    ));

    final result = await forgotPasswordRepository.setNewPassword(setNewPasswordReq);

    expect(result.isError, true);
    expect(result.error, 'Weak password');
  });

  test('setNewPassword returns failure on DioException with response message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      response: Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Password does not meet criteria'},
      ),
    ));

    final result = await forgotPasswordRepository.setNewPassword(setNewPasswordReq);

    expect(result.isError, true);
    expect(result.error, 'Password does not meet criteria');
  });

  test('returns something went wrong on generic exception', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(Exception('unknown error'));

    final result = await forgotPasswordRepository.resetPassword(forgotPasswordReq);

    expect(result.isError, true);
    expect(result.error, ErrorMessages.somethingWentWrongError);
  });

  test('returns connection timeout error on timeout', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      type: DioExceptionType.connectionTimeout,
    ));

    final result = await forgotPasswordRepository.resetPassword(forgotPasswordReq);

    expect(result.isError, true);
    expect(result.error, ErrorMessages.connectionTimeOutError);
  });
}
