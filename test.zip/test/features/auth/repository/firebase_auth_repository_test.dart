import 'package:child_health_story/features/auth/data/repository/firebase_auth_repository.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockFirebaseAuth extends Mock implements FirebaseAuth {}
class MockUserCredential extends Mock implements UserCredential {}
class FakeAuthCredential extends Fake implements AuthCredential {}
class MockUser extends Mock implements User {}


void main() {
  late MockFirebaseAuth mockFirebaseAuth;
  late MockUserCredential mockUserCredential;
  late FirebaseAuthRepository firebaseAuthRepository;
  setUpAll(() {
    registerFallbackValue(FakeAuthCredential());
  });
  setUp(() {
    mockFirebaseAuth = MockFirebaseAuth();
    mockUserCredential = MockUserCredential();
    firebaseAuthRepository = FirebaseAuthRepository(firebaseAuth: mockFirebaseAuth);
  });

  test('requestOtp returns success with verificationId', () async {
    final phoneNumber = '1234567890';
    final verificationId = 'test-verification-id';

    when(() => mockFirebaseAuth.verifyPhoneNumber(
      phoneNumber: '+91${phoneNumber.trim()}',
      verificationCompleted: any(named: 'verificationCompleted'),
      verificationFailed: any(named: 'verificationFailed'),
      codeSent: any(named: 'codeSent'),
      codeAutoRetrievalTimeout: any(named: 'codeAutoRetrievalTimeout'),
    )).thenAnswer((invocation) async {
      final codeSent = invocation.namedArguments[#codeSent] as PhoneCodeSent;
      codeSent(verificationId, 123456);
      return Future.value();
    });

    final result = await firebaseAuthRepository.requestOtp(phoneNumber: phoneNumber);

    expect(result.isSuccess, true);
    expect(result.data, verificationId);
  });

  test('requestOtp returns failure for invalid phone number', () async {
    final phoneNumber = 'invalid-number';

    when(() => mockFirebaseAuth.verifyPhoneNumber(
      phoneNumber: '+91${phoneNumber.trim()}',
      verificationCompleted: any(named: 'verificationCompleted'),
      verificationFailed: any(named: 'verificationFailed'),
      codeSent: any(named: 'codeSent'),
      codeAutoRetrievalTimeout: any(named: 'codeAutoRetrievalTimeout'),
    )).thenAnswer((invocation) async {
      final verificationFailed = invocation.namedArguments[#verificationFailed] as PhoneVerificationFailed;
      verificationFailed(FirebaseAuthException(code: 'invalid-phone-number'));
      return Future.value();
    });

    final result = await firebaseAuthRepository.requestOtp(phoneNumber: phoneNumber);

    expect(result.isError, true);
    expect(result.error, "Invalid phone number. Please check and try again.");
  });

  test('requestOtp returns failure for too many requests', () async {
    final phoneNumber = '1234567890';

    when(() => mockFirebaseAuth.verifyPhoneNumber(
      phoneNumber: '+91${phoneNumber.trim()}',
      verificationCompleted: any(named: 'verificationCompleted'),
      verificationFailed: any(named: 'verificationFailed'),
      codeSent: any(named: 'codeSent'),
      codeAutoRetrievalTimeout: any(named: 'codeAutoRetrievalTimeout'),
    )).thenAnswer((invocation) async {
      final verificationFailed = invocation.namedArguments[#verificationFailed] as PhoneVerificationFailed;
      verificationFailed(FirebaseAuthException(code: 'too-many-requests'));
      return Future.value();
    });

    final result = await firebaseAuthRepository.requestOtp(phoneNumber: phoneNumber);

    expect(result.isError, true);
    expect(result.error, "Too many attempts. Please try again later.");
  });

  test('requestOtp returns generic failure for other errors', () async {
    final phoneNumber = '1234567890';

    when(() => mockFirebaseAuth.verifyPhoneNumber(
      phoneNumber: '+91${phoneNumber.trim()}',
      verificationCompleted: any(named: 'verificationCompleted'),
      verificationFailed: any(named: 'verificationFailed'),
      codeSent: any(named: 'codeSent'),
      codeAutoRetrievalTimeout: any(named: 'codeAutoRetrievalTimeout'),
    )).thenAnswer((invocation) async {
      final verificationFailed = invocation.namedArguments[#verificationFailed] as PhoneVerificationFailed;
      verificationFailed(FirebaseAuthException(code: 'unknown-error'));
      return Future.value();
    });

    final result = await firebaseAuthRepository.requestOtp(phoneNumber: phoneNumber);

    expect(result.isError, true);
    expect(result.error, "OTP verification failed. Please try again.");
  });

  test('submitOtp returns success with token when OTP is valid', () async {
    final otp = '123456';
    final verificationId = 'test-verification-id';
    const mockToken = 'mock_id_token';

    // Arrange: mock signInWithCredential to succeed
    when(() => mockFirebaseAuth.signInWithCredential(any()))
        .thenAnswer((_) async => mockUserCredential);

    // Arrange: mock currentUser and getIdToken
    final mockUser = MockUser();
    when(() => mockFirebaseAuth.currentUser).thenReturn(mockUser);
    when(() => mockUser.getIdToken()).thenAnswer((_) async => mockToken);

    // Act
    final result = await firebaseAuthRepository.submitOtp(
      otp: otp,
      verificationId: verificationId,
    );

    // Assert
    expect(result.isSuccess, true);
    expect(result.data, mockToken);
  });


  test('submitOtp returns failure when OTP is invalid', () async {
    final otp = '123456';
    final verificationId = 'test-verification-id';

    when(() => mockFirebaseAuth.signInWithCredential(any()))
        .thenThrow(FirebaseAuthException(code: 'invalid-verification-code', message: 'Invalid OTP'));

    final result = await firebaseAuthRepository.submitOtp(
      otp: otp,
      verificationId: verificationId,
    );

    expect(result.isError, true);
    expect(result.error, 'Invalid OTP');
  });


  test('submitOtp returns generic failure for other errors', () async {
    final otp = '123456';
    final verificationId = 'test-verification-id';

    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: otp.trim(),
    );

    when(() => mockFirebaseAuth.signInWithCredential(credential))
        .thenThrow(Exception('Something went wrong'));

    final result = await firebaseAuthRepository.submitOtp(
      otp: otp,
      verificationId: verificationId,
    );

    expect(result.isError, true);
    expect(result.error, 'Something went wrong. Please try again.');
  });
}
