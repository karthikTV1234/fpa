import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/auth/data/model/login_model.dart';
import 'package:child_health_story/features/auth/data/model/login_with_otp.dart';
import 'package:child_health_story/features/auth/data/model/sing_up_model.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late AuthRepository authRepository;

  setUp(() {
    mockDio = MockDio();
    authRepository = AuthRepository(dio: mockDio);
  });

  final signUpReq = SignUpReqModel(
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    phone: '1234567890',
    password: 'password',
    deviceId: '',
    countryCode: '+91',
  );

  final signUpRes = {
    "message": "Registration successful",
    "id": "123",
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "token": "",
  };

  final loginWithOtpReq = LoginWithOtpReqModel(idToken: 'firebase_id_token');

  final loginRes = {
    "access_token": "access_123",
    "message": "Login successful",
    "firstName": "John",
    "lastName": "Doe",
  };

  test('register returns success on 200 response', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 200,
      data: signUpRes,
    ));

    final result = await authRepository.register(signUpReq);

    expect(result.isSuccess, true);
    expect(result.data, isNotNull);
    expect(result.data!.id, '123');
    expect(result.data!.message, 'Registration successful');
  });

  test('register returns failure on non-200 with message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenAnswer((_) async => Response(
      requestOptions: RequestOptions(path: ''),
      statusCode: 400,
      data: {'message': 'Invalid data'},
    ));

    final result = await authRepository.register(signUpReq);

    expect(result.isError, true);
    expect(result.error, 'Invalid data');
  });

  test('register returns failure on DioException with response message', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      response: Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Email already exists'},
      ),
    ));

    final result = await authRepository.register(signUpReq);

    expect(result.isError, true);
    expect(result.error, 'Email already exists');
  });

  test('register returns connection timeout error on timeout', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(DioException(
      requestOptions: RequestOptions(path: ''),
      type: DioExceptionType.connectionTimeout,
    ));

    final result = await authRepository.register(signUpReq);

    expect(result.isError, true);
    expect(result.error, ErrorMessages.connectionTimeOutError);
  });

  test('register returns something went wrong on generic exception', () async {
    when(() => mockDio.post(
      any(),
      data: any(named: 'data'),
    )).thenThrow(Exception('unknown error'));

    final result = await authRepository.register(signUpReq);

    expect(result.isError, true);
    expect(result.error, ErrorMessages.somethingWentWrongError);
  });

  group('loginWithOTP', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.post(
        any(),
        data: any(named: 'data'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: loginRes,
      ));

      final result = await authRepository.loginWithOTP(loginWithOtpReq);

      expect(result.isSuccess, true);
      expect(result.data, isA<LoginResModel>());
      expect(result.data!.accessToken, 'access_123');
    });

    test('returns failure on non-200 response with message', () async {
      when(() => mockDio.post(
        any(),
        data: any(named: 'data'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Invalid token'},
      ));

      final result = await authRepository.loginWithOTP(loginWithOtpReq);

      expect(result.isError, true);
      expect(result.error, 'Invalid token');
    });

    test('returns failure on DioException with server message', () async {
      when(() => mockDio.post(
        any(),
        data: any(named: 'data'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 401,
          data: {'message': 'Token expired'},
        ),
      ));

      final result = await authRepository.loginWithOTP(loginWithOtpReq);

      expect(result.isError, true);
      expect(result.error, 'Token expired');
    });

    test('returns connection timeout error', () async {
      when(() => mockDio.post(
        any(),
        data: any(named: 'data'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await authRepository.loginWithOTP(loginWithOtpReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns something went wrong on generic error', () async {
      when(() => mockDio.post(
        any(),
        data: any(named: 'data'),
      )).thenThrow(Exception('unexpected error'));

      final result = await authRepository.loginWithOTP(loginWithOtpReq);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });
}
