import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/auth/data/model/sing_up_model.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_bloc.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_events.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_state.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class FakeSignUpReqModel extends Fake implements SignUpReqModel {}
// Mock Repository
class MockAuthRepository extends Mock implements AuthRepository {}

void main() {
  late SignUpBloc signUpBloc;
  late MockAuthRepository mockAuthRepository;

  setUpAll(() {
    registerFallbackValue(FakeSignUpReqModel());
  });

  setUp(() {
    mockAuthRepository = MockAuthRepository();
    signUpBloc = SignUpBloc(authRepository: mockAuthRepository);
  });

  tearDown(() {
    signUpBloc.close();
  });

  final signUpReq = SignUpReqModel(
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    phone: '1234567890',
    password: 'password',
    deviceId: '',
    countryCode: '+91',
  );

  group('SignUpBloc Tests', () {
    const successMessage = 'Registration successful';

    test('initial state is RegisterInitial', () {
      expect(signUpBloc.state, RegisterInitial());
    });

    blocTest<SignUpBloc, SignUpState>(
      'emits [RegisterLoading, RegisterSuccess] when RegisterSubmitted succeeds',
      build: () {
        when(() => mockAuthRepository.register(any()))
            .thenAnswer((_) async => Result.success(SignUpResModel(
          message: 'Registration successful',
          id: 'user123',
          firstName: 'John',
          lastName: 'Doe',
          email: 'john@example.com',
          phone: '1234567890',
          token: 'token_abc123',
        )));
        return signUpBloc;
      },
      act: (bloc) =>
          bloc.add(RegisterSubmitEvent(signUpReqModel: signUpReq)),
      expect: () => [
        RegisterLoading(),
        RegisterSuccess(message: successMessage),
      ],
      verify: (_) {
        verify(() => mockAuthRepository.register(any())).called(1);
      },
    );

    blocTest<SignUpBloc, SignUpState>(
      'emits [RegisterLoading, RegisterFailure] when RegisterSubmitted fails',
      build: () {
        when(() => mockAuthRepository.register(any()))
            .thenAnswer((_) async => Result.failure('Email already in use'));
        return signUpBloc;
      },
      act: (bloc) =>
          bloc.add(RegisterSubmitEvent(signUpReqModel: signUpReq)),
      expect: () => [
        RegisterLoading(),
        RegisterFailure('Email already in use'),
      ],
      verify: (_) {
        verify(() => mockAuthRepository.register(any())).called(1);

      },
    );
  });
}
