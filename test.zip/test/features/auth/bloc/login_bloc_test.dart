import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/auth/data/model/login_model.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:child_health_story/features/auth/presentation/bloc/login_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class FakeLoginReqModel extends Fake implements LoginReqModel {}
// Mock Repository
class MockAuthRepository extends Mock implements AuthRepository {}

void main() {
  late LoginBloc loginBloc;
  late MockAuthRepository mockAuthRepository;

  setUpAll(() {
    registerFallbackValue(FakeLoginReqModel());
  });

  setUp(() {
    mockAuthRepository = MockAuthRepository();
    loginBloc = LoginBloc(authRepository: mockAuthRepository);
  });

  tearDown(() {
    loginBloc.close();
  });

  group('LoginBloc Tests', () {
    const testEmail = 'john@example.com';
    const testPassword = 'Password@123';
    const testDeviceId = 'device123';
    const successMessage = 'Registration successful';

    test('initial state is LoginInitial', () {
      expect(loginBloc.state, LoginInitial());
    });

    blocTest<LoginBloc, LoginState>(
      'emits [LoginLoading, LoginSuccess] when LoginSubmitted succeeds',
      build: () {
        when(() => mockAuthRepository.login(any()))
            .thenAnswer((_) async => Result.success(
          LoginResModel(
              accessToken: 'token_abc123',
              firstName: 'first',
              lastName: 'last',
          ),
        ));
        return loginBloc;
      },
      act: (bloc) => bloc.add(
        LoginSubmitted(
          email: testEmail,
          password: testPassword,
          deviceId: testDeviceId,
        ),
      ),
      expect: () => [
        LoginLoading(),
        LoginSuccess(message: successMessage),
      ],
      verify: (_) {
        verify(() => mockAuthRepository.login(any())).called(1);
      },
    );

    blocTest<LoginBloc, LoginState>(
      'emits [LoginLoading, LoginFailure] when LoginSubmitted fails',
      build: () {
        when(() => mockAuthRepository.login(any()))
            .thenAnswer((_) async => Result.failure('Invalid credentials'));
        return loginBloc;
      },
      act: (bloc) => bloc.add(
        LoginSubmitted(
          email: testEmail,
          password: testPassword,
          deviceId: testDeviceId,
        ),
      ),
      expect: () => [
        LoginLoading(),
        LoginFailure('Invalid credentials'),
      ],
      verify: (_) {
        verify(() => mockAuthRepository.login(any())).called(1);
      },
    );
  });
}