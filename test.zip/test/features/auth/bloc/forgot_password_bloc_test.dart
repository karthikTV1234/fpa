import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/auth/data/model/reset_password_model.dart';
import 'package:child_health_story/features/auth/data/model/validate_reset_code_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:child_health_story/features/auth/data/model/forgot_password_model.dart';
import 'package:child_health_story/features/auth/data/repository/forgot_password_repository.dart';
import 'package:child_health_story/features/auth/presentation/bloc/forgot_password_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class FakeForgotPasswordReqModel extends Fake implements ForgotPasswordReqModel {}
class MockForgotPasswordRepository extends Mock implements ForgotPasswordRepository {}

void main() {
  late ForgotPasswordBloc forgotPasswordBloc;
  late MockForgotPasswordRepository mockForgotPasswordRepository;

  setUpAll(() {
    registerFallbackValue(FakeForgotPasswordReqModel());
    registerFallbackValue(ValidateResetCodeReqModel(
      email: 'test@example.com',
      code: '123456',
    ));
    registerFallbackValue(SetNewPasswordReqModel(
      email: 'test@example.com',
      newPassword: 'NewPassword@123',
    ));
  });

  setUp(() {
    mockForgotPasswordRepository = MockForgotPasswordRepository();
    forgotPasswordBloc = ForgotPasswordBloc(
      forgotPasswordRepository: mockForgotPasswordRepository,
    );
  });

  tearDown(() {
    forgotPasswordBloc.close();
  });

  group('ForgotPasswordBloc Tests', () {
    const testEmail = 'test@example.com';
    const testCode = '123456';
    const testNewPassword = 'NewPassword@123';
    const successMessage = 'Operation successful';
    const successStatusCode = 200;

    test('initial state is ForgotPasswordInitial', () {
      expect(forgotPasswordBloc.state, ForgotPasswordInitial());
    });

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordSuccess] when EmailSubmitted succeeds',
      build: () {
        when(() => mockForgotPasswordRepository.resetPassword(any()))
            .thenAnswer((_) async => Result.success(
          CommonResModel(
            statusCode: successStatusCode,
            message: successMessage,
          ),
        ));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        EmailSubmitted(
          email: testEmail,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordSuccess(message: successMessage),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.resetPassword(any())).called(1);
      },
    );

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordFailure] when EmailSubmitted fails',
      build: () {
        when(() => mockForgotPasswordRepository.resetPassword(any()))
            .thenAnswer((_) async => Result.failure('Invalid email'));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        EmailSubmitted(
          email: testEmail,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordFailure('Invalid email'),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.resetPassword(any())).called(1);
      },
    );

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordSuccess] when EmailSubmitOtp succeeds',
      build: () {
        when(() => mockForgotPasswordRepository.validateResetCode(any()))
            .thenAnswer((_) async => Result.success(
          CommonResModel(
            statusCode: successStatusCode,
            message: successMessage,
          ),
        ));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        EmailOTPSubmit(
          email: testEmail,
          code: testCode,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordSuccess(message: successMessage),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.validateResetCode(any())).called(1);
      },
    );

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordFailure] when EmailSubmitOtp fails',
      build: () {
        when(() => mockForgotPasswordRepository.validateResetCode(any()))
            .thenAnswer((_) async => Result.failure('Invalid OTP'));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        EmailOTPSubmit(
          email: testEmail,
          code: testCode,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordFailure('Invalid OTP'),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.validateResetCode(any())).called(1);
      },
    );

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordSuccess] when SetNewPassword succeeds',
      build: () {
        when(() => mockForgotPasswordRepository.setNewPassword(any()))
            .thenAnswer((_) async => Result.success(
          CommonResModel(
            statusCode: successStatusCode,
            message: successMessage,
          ),
        ));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        SetNewPassword(
          email: testEmail,
          newPassword: testNewPassword,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordSuccess(message: successMessage),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.setNewPassword(any())).called(1);
      },
    );

    blocTest<ForgotPasswordBloc, ForgotPasswordState>(
      'emits [ForgotPasswordLoading, ForgotPasswordFailure] when SetNewPassword fails',
      build: () {
        when(() => mockForgotPasswordRepository.setNewPassword(any()))
            .thenAnswer((_) async => Result.failure('Password reset failed'));
        return forgotPasswordBloc;
      },
      act: (bloc) => bloc.add(
        SetNewPassword(
          email: testEmail,
          newPassword: testNewPassword,
        ),
      ),
      expect: () => [
        ForgotPasswordLoading(),
        ForgotPasswordFailure('Password reset failed'),
      ],
      verify: (_) {
        verify(() => mockForgotPasswordRepository.setNewPassword(any())).called(1);
      },
    );
  });
}