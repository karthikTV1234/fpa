import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/doctor_visits/data/models/request/add_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/request/edit_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_list_res_model.dart';
import 'package:child_health_story/features/doctor_visits/data/repository/doctor_visit_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late DoctorVisitRepository repository;

  setUp(() {
    mockDio = MockDio();
    repository = DoctorVisitRepository(dio: mockDio);
  });

  const childId = 'child123';
  const doctorVisitId = 'doc123';
  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };
  final addReq = AddDoctorVisitReqModel(
    childId: 'child_001',
    dateOfVisit: '2025-08-20',
    purpose: 'Routine Checkup',
    followUpDate: '2025-09-20',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    treatmentNotes: 'Child is healthy. Advised balanced diet and vitamins.',
    attachments: [],
  );
  final updateReq = UpdateDoctorVisitReqModel(
    childId: 'child_001',
    followUpDate: '2025-09-20',
    treatmentNotes: 'Child is healthy. Advised balanced diet and vitamins.',
    attachments: [],
  );
  final detailRes = {
    "statusCode": 200,
    "message": "Doctor visit details fetched successfully",
    "data": {
      "id": "visit_12345",
      "childId": "child_987",
      "dateOfVisit": "2025-08-15",
      "doctorId": "doc_456",
      "purpose": "Routine Checkup",
      "treatmentNotes": "Child is healthy. Recommended vitamins.",
      "followUpDate": "2025-09-15",
      "attachments": [
        "https://example.com/reports/report1.pdf",
        "https://example.com/reports/xray.png"
      ],
      "doctorName": "Dr. Priya Sharma",
      "hospitalName": "Sunrise Children Hospital"
    }
  };
  final listRes  = {
    "statusCode": 200,
    "message": "Doctor visit list fetched successfully",
    "data": [
      {
        "id": "visit_101",
        "childId": "child_001",
        "dateOfVisit": "2025-08-15",
        "doctorId": "doc_456",
        "purpose": "Routine Checkup",
        "treatmentNotes": "Child is healthy. Recommended vitamins.",
        "doctorName": "Dr. Priya Sharma"
      },
      {
        "id": "visit_102",
        "childId": "child_001",
        "dateOfVisit": "2025-07-10",
        "doctorId": "doc_789",
        "purpose": "Fever and Cold",
        "treatmentNotes": "Prescribed paracetamol for 5 days.",
        "doctorName": "Dr. Anil Kumar"
      },
    ]
  };

  group('addDoctorVisit', () {
      test('returns success on 200 response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
                  requestOptions: RequestOptions(path: ''), statusCode: 200,
                  data: commonRes
              ),
        );

        final result = await repository.addDoctorVisit(addReq);

        expect(result.isSuccess, true);
        expect(result.data, isA<CommonResModel>());
        expect(result.data!.message, 'Operation successful');
      });

      test('returns failure on non-200 with message', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Invalid request'}),
        );

        final result = await repository.addDoctorVisit(addReq);

        expect(result.isError, true);
        expect(result.error, 'Invalid request');
      });

      test('returns connection timeout error on timeout', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            type: DioExceptionType.connectionTimeout,
          ),
        );

        final result = await repository.addDoctorVisit(addReq);
        expect(result.isError, true);
        expect(result.error, ErrorMessages.connectionTimeOutError);
      });

      test('returns failure on DioException with response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            response: Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Server error'},
            ),
          ),
        );

        final result = await repository.addDoctorVisit(addReq);

        expect(result.isError, true);
        expect(result.error, 'Server error');
      });

      test('returns something went wrong on generic exception', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(Exception('Unexpected error'));

        final result = await repository.addDoctorVisit(addReq);

        expect(result.isError, true);
        expect(result.error, ErrorMessages.somethingWentWrongError);
      });
    });

  group('getDoctorVisitList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: listRes,
      ));

      final result = await repository.getDoctorVisitList(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<GetDoctorVisitListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Doctor visit list fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch vaccinations'},
      ));

      final result = await repository.getDoctorVisitList(childId);

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch vaccinations');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getDoctorVisitList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getDoctorVisitList(childId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getDoctorVisitList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('getDoctorVisitDetails', () {

    test('should return DoctorVisitDetails model when response is 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: detailRes,
      ));

      final result = await repository.getDoctorVisitDetails(doctorVisitId);

      expect(result.isSuccess, true);
      final data = result.data!;
      expect(data.statusCode, 200);
      expect(data.message, 'Doctor visit details fetched successfully');
    });

    test('should return error message when response is not 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 404,
          data: {"message": "Doctor Visit not found"},
        ),
      );

      final result = await repository.getDoctorVisitDetails(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, "Doctor Visit not found");
    });

    test('should return connection timeout error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getDoctorVisitDetails(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('should return error from DioException with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getDoctorVisitDetails(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('should return something went wrong on unknown error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Some unexpected error'));

      final result = await repository.getDoctorVisitDetails(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateDoctorVisitDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Update failed'},
      ));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(Exception('Unexpected error'));

      final result = await repository.updateDoctorVisitDetails(
          updateReq, doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });


  });

  group('deleteDoctorVisit', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: commonRes,
      ));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Delete failed'},
      ));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, 'Delete failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteDoctorVisit(doctorVisitId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });




}
