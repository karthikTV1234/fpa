import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/doctor_visits/data/models/request/add_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/request/edit_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_detail_res_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_list_res_model.dart';
import 'package:child_health_story/features/doctor_visits/data/repository/doctor_visit_repository.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_events.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDoctorVisitRepository extends Mock implements DoctorVisitRepository {}
class FakeAddDoctorVisitReqModel extends Fake implements AddDoctorVisitReqModel {}
class FakeUpdateDoctorVisitReqModel extends Fake implements UpdateDoctorVisitReqModel {}

void main() {
  late DoctorVisitBloc bloc;
  late MockDoctorVisitRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddDoctorVisitReqModel());
    registerFallbackValue(FakeUpdateDoctorVisitReqModel());
  });
  setUp(() {
    mockRepository = MockDoctorVisitRepository();
    bloc = DoctorVisitBloc(doctorVisitRepository: mockRepository);
  });
  const childId = 'child123';
  const doctorVisitId = 'doc123';
  final addReq = AddDoctorVisitReqModel(
    childId: 'child_001',
    dateOfVisit: '2025-08-20',
    purpose: 'Routine Checkup',
    followUpDate: '2025-09-20',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    treatmentNotes: 'Child is healthy. Advised balanced diet and vitamins.',
    attachments: [],
  );
  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful',
  );
  final updateReq = UpdateDoctorVisitReqModel(
    childId: 'child_001',
    followUpDate: '2025-09-20',
    treatmentNotes: 'Child is healthy. Advised balanced diet and vitamins.',
    attachments: [],
  );
  final detailRes = GetDoctorVisitDetailResModel(
    statusCode: 200,
    message: 'Doctor visit details fetched successfully',
    data: DoctorVisitDetailData(
      id: 'visit_123',
      childId: 'child_001',
      dateOfVisit: '2025-08-15',
      doctorId: 'doctor_456',
      purpose: 'Routine Checkup',
      treatmentNotes: 'Child is healthy. Advised to continue balanced diet and vitamins.',
      followUpDate: '2025-09-15',
      attachments: [
        'https://dummy.cdn.com/report1.pdf',
        'https://dummy.cdn.com/xray1.png',
      ],
      createdAt: '2025-08-15T10:00:00Z',
      updatedAt: '2025-08-15T11:30:00Z',
      hospitalId: 'hospital_123',
      isDeleted: false,
      doctorName: 'Dr. Priya Sharma',
      hospitalName: 'Sunshine Children Hospital',
    ),
  );
  final listResModel = GetDoctorVisitListResModel(
    statusCode: 200,
    message: 'Doctor visit list fetched successfully',
    data: [
      DoctorVisitListData(
        id: 'visit_101',
        childId: 'child_001',
        dateOfVisit: '2025-08-15',
        doctorId: 'doc_456',
        purpose: 'Routine Checkup',
        treatmentNotes: 'Child is healthy. Recommended vitamins.',
        doctorName: 'Dr. Priya Sharma',
      ),
      DoctorVisitListData(
        id: 'visit_102',
        childId: 'child_001',
        dateOfVisit: '2025-07-10',
        doctorId: 'doc_789',
        purpose: 'Fever and Cold',
        treatmentNotes: 'Prescribed paracetamol for 5 days.',
        doctorName: 'Dr. Anil Kumar',
      ),
      DoctorVisitListData(
        id: 'visit_103',
        childId: 'child_001',
        dateOfVisit: '2025-06-05',
        doctorId: 'doc_321',
        purpose: 'Vaccination Follow-up',
        treatmentNotes: 'No adverse reactions observed.',
        doctorName: 'Dr. Seema Reddy',
      ),
    ],
  );
  final listEmptyRes = GetDoctorVisitListResModel(
    statusCode: 200,
    message: 'No doctor visit found',
    data: [],
  );

  group('AddDoctorVisitEvent', () {
    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addDoctorVisit(addReq))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddDoctorVisitEvent(addDoctorVisitReqModel: addReq)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitSuccess(message: 'Operation successful')
      ],
      verify: (_) {
        verify(() => mockRepository.addDoctorVisit(addReq)).called(1);
      },
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addDoctorVisit(addReq))
            .thenAnswer((_) async => Result.failure('Failed to add doctor visit'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddDoctorVisitEvent(addDoctorVisitReqModel: addReq)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitFailure('Failed to add doctor visit'),
      ],
      verify: (_) {
        verify(() => mockRepository.addDoctorVisit(addReq)).called(1);
      },
    );
  });

  group('FetchDoctorVisitListEvent', () {
    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitListSuccess] on success',
      build: () {
        when(() => mockRepository.getDoctorVisitList(childId))
            .thenAnswer((_) async => Result.success(listEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorVisitListEvent(childId: childId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getDoctorVisitList(childId)).called(1),
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getDoctorVisitList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorVisitListEvent(childId: childId)),
      expect: () => [
        DoctorVisitLoading(),
        isA<DoctorVisitListSuccess>().having(
              (s) => s.doctorVisitList,
          'DoctorVisitList',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getDoctorVisitList(childId)).called(1),
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitFailure] on failure',
      build: () {
        when(() => mockRepository.getDoctorVisitList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorVisitListEvent(childId: childId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchDoctorVisitByIdEvent', () {

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getDoctorVisitDetails(doctorVisitId))
            .thenAnswer((_) async => Result.success(detailRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorVisitByIdEvent(doctorVisitId: doctorVisitId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitByIdSuccess(detailRes.data),
      ],
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitFailure] on failure',
      build: () {
        when(() => mockRepository.getDoctorVisitDetails(doctorVisitId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchDoctorVisitByIdEvent(doctorVisitId: doctorVisitId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitFailure('Not found'),
      ],
    );
  });

  group('UpdateDoctorVisitEvent', () {
    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitSuccess] on update success',
      build: () {
        when(() => mockRepository.updateDoctorVisitDetails(updateReq, doctorVisitId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateDoctorVisitEvent(
          doctorVisitId: doctorVisitId,updateDoctorVisitReqModel: updateReq)
      ),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitFailure] on update failure',
      build: () {
        when(() => mockRepository.updateDoctorVisitDetails(updateReq, doctorVisitId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateDoctorVisitEvent(
          doctorVisitId: doctorVisitId,updateDoctorVisitReqModel: updateReq)
      ),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitFailure('Update failed'),
      ],
    );
  });

  group('DeleteDoctorVisitEvent', () {
    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteDoctorVisit(doctorVisitId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteDoctorVisitEvent(doctorVisitId: doctorVisitId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<DoctorVisitBloc, DoctorVisitState>(
      'emits [DoctorVisitLoading, DoctorVisitFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteDoctorVisit(doctorVisitId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteDoctorVisitEvent(doctorVisitId: doctorVisitId)),
      expect: () => [
        DoctorVisitLoading(),
        DoctorVisitFailure('Delete failed'),
      ],
    );
  });



}
