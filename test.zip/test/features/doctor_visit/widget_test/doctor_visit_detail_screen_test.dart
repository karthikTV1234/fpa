import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_detail_res_model.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_events.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_state.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mocktail/mocktail.dart';

// Mocks and Fakes

class MockDoctorVisitBloc extends Mock implements DoctorVisitBloc {}
class MockNavigatorObserver extends Mock implements NavigatorObserver {}
class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockDoctorVisitBloc mockBloc;
  const doctorVisitId = 'doc123';

  setUpAll(() {
    registerFallbackValue(DeleteDoctorVisitEvent(doctorVisitId: doctorVisitId));
    registerFallbackValue(FetchDoctorVisitByIdEvent(doctorVisitId: doctorVisitId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockDoctorVisitBloc();

    final testState = DoctorVisitByIdSuccess(
      DoctorVisitDetailData(purpose: 'Routine Checkup'),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
  });

  final mockData = DoctorVisitDetailData(
    id: 'visit_123',
    childId: 'child_001',
    dateOfVisit: '2025-08-15',
    doctorId: 'doctor_456',
    purpose: 'Routine Checkup',
    treatmentNotes: 'Child is healthy. Advised to continue balanced diet and vitamins.',
    followUpDate: '2025-09-15',
    attachments: [
      'https://dummy.cdn.com/report1.pdf',
      'https://dummy.cdn.com/xray1.png',
    ],
    doctorName: 'Dr. Priya Sharma',
    hospitalName: 'Sunshine Children Hospital',
  );

  testWidgets('renders doctor visit details when DoctorVisitByIdSuccess is emitted', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(mockData);
    when(() => mockBloc.add(any())).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<DoctorVisitBloc>.value(
          value: mockBloc,
          child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
        ),
      ),
    );

    await tester.pumpAndSettle();
    final formattedVisitDate = (mockData.dateOfVisit).formatAsDateTime();
    final formattedFollowUpDate = (mockData.followUpDate).formatAsDateTime();
    expect(find.text('Routine Checkup'), findsOneWidget);
    expect(find.text(formattedVisitDate), findsOneWidget);
    expect(find.text('Sunshine Children Hospital'), findsOneWidget);
    expect(find.text('Dr. Priya Sharma'), findsOneWidget);
    expect(find.text(formattedFollowUpDate), findsOneWidget);
    expect(find.text('Child is healthy. Advised to continue balanced diet and vitamins.'), findsOneWidget); // notes
  });

  testWidgets('should show loading indicator when state is DoctorVisitLoading', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitLoading()));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<DoctorVisitBloc>.value(
          value: mockBloc,
          child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('should show error message when state is failure', (tester) async {
    const errorMessage = 'Error loading doctor visit';

    when(() => mockBloc.state).thenReturn(DoctorVisitFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitFailure(errorMessage)));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<DoctorVisitBloc>.value(
              value: mockBloc,
              child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('navigates to edit doctor visit screen on edit button tap', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(mockData);

    final mockObserver = MockNavigatorObserver();

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.doctorVisitFormScreen) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit DoctorVisit Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<DoctorVisitBloc>.value(
          value: mockBloc,
          child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
        ),
        navigatorObservers: [mockObserver],
      ),
    );

    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);

    reset(mockObserver);

    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);
  });

  testWidgets('should display file attachments if available', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(mockData);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: BlocProvider<DoctorVisitBloc>.value(
            value: mockBloc,
            child: SizedBox(
              height: 200,
              child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.textContaining('pdf'), findsOneWidget);
  });

  testWidgets('delete doctor visit and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.doctorVisitListScreen: (_) => const Scaffold(body: Text('Doctor Visit List')),
            },
            home: BlocProvider<DoctorVisitBloc>.value(
              value: mockBloc,
              child: const DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
            ),
          ),
        );


        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteDoctorVisitTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteDoctorVisitConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteDoctorVisitEvent(doctorVisitId: doctorVisitId))).called(1);

        final successState = DoctorVisitSuccess(message: 'Doctor Visit deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });

}
