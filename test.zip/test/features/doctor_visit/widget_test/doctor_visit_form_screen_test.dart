import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_detail_res_model.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_form_screen.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_events.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_state.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockDoctorVisitBloc extends MockBloc<DoctorVisitEvent, DoctorVisitState> implements DoctorVisitBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeDoctorVisitEvent extends Fake implements DoctorVisitEvent {}
class FakeDoctorVisitState extends Fake implements DoctorVisitState {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockDoctorVisitBloc mockBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeDoctorVisitEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeDoctorVisitState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockBloc = MockDoctorVisitBloc();

    when(() => mockBloc.state).thenReturn(DoctorVisitInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.hospitalList).thenReturn([]);
    when(() => mockBloc.doctorList).thenReturn([]);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  final mockDoctorVisitDetail = DoctorVisitDetailData(
    id: 'visit_123',
    childId: 'child_001',
    dateOfVisit: '2025-08-15',
    doctorId: 'doctor_456',
    purpose: 'Routine Checkup',
    treatmentNotes: 'Child is healthy. Advised to continue balanced diet and vitamins.',
    followUpDate: '2025-09-15',
    attachments: [
      'https://dummy.cdn.com/report1.pdf',
      'https://dummy.cdn.com/xray1.png',
    ],
    createdAt: '2025-08-15T10:00:00Z',
    updatedAt: '2025-08-15T11:30:00Z',
    hospitalId: 'hospital_123',
    isDeleted: false,
    doctorName: 'Dr. Priya Sharma',
    hospitalName: 'Sunshine Children Hospital',
  );

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<DoctorVisitBloc>.value(value: mockBloc),
        ],
        child: const DoctorVisitFormScreen(),
      ),
    );
  }

  Widget createEditWidgetUnderTest(DoctorVisitDetailData detailData) {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<DoctorVisitBloc>.value(value: mockBloc),
        ],
        child: DoctorVisitFormScreen(doctorVisitDetailData: detailData),
      ),
    );
  }


  testWidgets(
    'renders all essential form fields and Save button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.purposeLabel), findsOneWidget);
      expect(find.text(AppStrings.dateOfVisitLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.followUpDateLabel), findsOneWidget);
      expect(find.text(AppStrings.saveText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.purposeRequired), findsOneWidget);
    expect(find.text(ValidationMessages.dateOfVisitRequired), findsOneWidget);
    expect(find.text(ValidationMessages.hospitalRequired), findsOneWidget);
    expect(find.text(ValidationMessages.doctorRequired), findsOneWidget);
  });

  testWidgets('prepopulates fields with existing data', (WidgetTester tester) async {
    await tester.pumpWidget(createEditWidgetUnderTest(mockDoctorVisitDetail));
    await tester.pumpAndSettle();

    expect(find.widgetWithText(TextFormField, 'Routine Checkup'), findsOneWidget); // Purpose
    expect(find.widgetWithText(TextFormField, '2025-08-15 00:00'), findsOneWidget); // formatted date of visit
    expect(find.widgetWithText(TextFormField, 'Sunshine Children Hospital'), findsOneWidget); // Hospital
    expect(find.widgetWithText(TextFormField, 'Dr. Priya Sharma'), findsOneWidget); // Doctor
    expect(find.widgetWithText(TextFormField, '2025-09-15 00:00'), findsOneWidget);
    expect(
      find.widgetWithText(TextFormField, 'Child is healthy. Advised to continue balanced diet and vitamins.'),
      findsOneWidget,
    ); // Notes
  });

  testWidgets('shows snackbar when doctor visit add fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        DoctorVisitLoading(),
        DoctorVisitFailure('Failed to save doctor visit'),
      ]),
      initialState: DoctorVisitInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to save doctor visit'), findsOneWidget);
  });

  testWidgets('shows snackbar when doctor visit update fails', (WidgetTester tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        DoctorVisitLoading(),
        DoctorVisitFailure('Failed to update doctor visit'),
      ]),
      initialState: DoctorVisitInitial(),
    );

    await tester.pumpWidget(createEditWidgetUnderTest(mockDoctorVisitDetail));
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to update doctor visit'), findsOneWidget);
  });

  testWidgets('navigates to doctor visit list screen on success', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        DoctorVisitLoading(),
        DoctorVisitSuccess(message: "Added"),
      ]),
      initialState: DoctorVisitInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.enterText(find.byType(TextFormField).at(0), 'Routine Checkup'); // Purpose
    await tester.enterText(find.byType(TextFormField).at(1), '2025-08-15');      // Date of Visit
    await tester.enterText(find.byType(TextFormField).at(2), 'Sunshine Hospital'); // Hospital Name
    await tester.enterText(find.byType(TextFormField).at(3), 'Dr. Priya Sharma'); // Doctor Name
    await tester.enterText(find.byType(TextFormField).at(4), '2025-09-15');      // Follow-up Date
    await tester.enterText(find.byType(TextFormField).at(5), 'Child is healthy. Advised to continue vitamins.'); // Notes

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton, warnIfMissed: false);
    await tester.pumpAndSettle();
  });

  testWidgets('navigates back on successful update', (WidgetTester tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        DoctorVisitLoading(),
        DoctorVisitSuccess(message: "Updated"),
      ]),
      initialState: DoctorVisitInitial(),
    );

    await tester.pumpWidget(createEditWidgetUnderTest(mockDoctorVisitDetail));

    final updateButton = find.text(AppStrings.updateTxt);
    await tester.ensureVisible(updateButton);
    await tester.tap(updateButton, warnIfMissed: false);
    await tester.pumpAndSettle();

    expect(find.byType(DoctorVisitFormScreen), findsNothing); // screen popped
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
