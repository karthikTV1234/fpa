import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_list_res_model.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_events.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_state.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDoctorVisitBloc extends MockBloc<DoctorVisitEvent, DoctorVisitState>
    implements DoctorVisitBloc {}

class FakeDoctorVisitEvent extends Fake implements DoctorVisitEvent {}
class FakeDoctorVisitState extends Fake implements DoctorVisitState {}

void main() {
  late MockDoctorVisitBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeDoctorVisitEvent());
    registerFallbackValue(FakeDoctorVisitState());
  });

  setUp(() {
    mockBloc = MockDoctorVisitBloc();
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.doctorVisitDetailData).thenReturn(null);
    when(() => mockBloc.selectedChildName).thenReturn("");
    when(() => mockBloc.selectedChildProfileImage).thenReturn("");

  });

  final mockList = [
    DoctorVisitListData(
      id: 'visit_101',
      childId: 'child_001',
      dateOfVisit: '2025-08-15',
      doctorId: 'doc_456',
      purpose: 'Routine Checkup',
      treatmentNotes: 'Child is healthy. Recommended vitamins.',
      doctorName: 'Dr. Priya Sharma',
    ),
    DoctorVisitListData(
      id: 'visit_102',
      childId: 'child_001',
      dateOfVisit: '2025-07-10',
      doctorId: 'doc_789',
      purpose: 'Fever and Cold',
      treatmentNotes: 'Prescribed paracetamol for 5 days.',
      doctorName: 'Dr. Anil Kumar',
    ),
  ];
  final mappedList = [
    {
      "id": "vac_001",
      "category": "Liver Infection",
      "title": "Hepatitis B",
      "subtitle": "Vaccinated Date: 02 Aug 2025",
    },
    {
      "id": "vac_002",
      "category": "Poliomyelitis",
      "status": "Pending", // Not vaccinated
      "statusColor": AppColors.vLightOrangeColor,
      "title": "Polio",
      "subtitle": "Scheduled Date: 10 Aug 2025",
    },
  ];


  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.doctorVisitFormScreen: (_) =>
          const Scaffold(body: Text('Add Doctor Visit')),
          PathConstants.doctorVisitDetailScreen: (_) =>
          const Scaffold(body: Text('Doctor Visit Detail')),
        },
        home: BlocProvider<DoctorVisitBloc>.value(
          value: mockBloc,
          child: const DoctorVisitListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is DoctorVisitLoading', (tester) async {
    // state + stream
    when(() => mockBloc.state).thenReturn(DoctorVisitLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(DoctorVisitLoading()));

    // required properties
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.filteredDoctorVisitList).thenReturn([]);

    await pumpScreen(tester);
    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });


  testWidgets('shows snackbar on DoctorVisitFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([DoctorVisitFailure(errorMessage)]),
      initialState: DoctorVisitInitial(),
    );

    when(() => mockBloc.filteredDoctorVisitList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<DoctorVisitBloc>.value(
          value: mockBloc,
          child: const DoctorVisitListScreen(),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list of vaccinations on DoctorVisitListSuccess', (tester) async {

    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(DoctorVisitListSuccess(mockList));

    when(() => mockBloc.filteredDoctorVisitList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    expect(find.text('Hepatitis B'), findsOneWidget);
    expect(find.text('Polio'), findsOneWidget);

  });


  testWidgets('filters list when search query is entered', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitListSuccess(mockList));
    when(() => mockBloc.filteredDoctorVisitList).thenReturn(mappedList);

    await pumpScreen(tester);

    await tester.pumpAndSettle();
    expect(find.text('Hepatitis B'), findsOneWidget);
    expect(find.text('Polio'), findsOneWidget);


    await tester.enterText(find.byType(TextField), 'Hepa');

    when(() => mockBloc.state).thenReturn(
      DoctorVisitListSearchSuccess([mappedList.first]),
    );
    when(() => mockBloc.filteredDoctorVisitList).thenReturn([mappedList.first]);

    await tester.pumpAndSettle();

    expect(find.text('Hepatitis B'), findsOneWidget);
  });

  testWidgets('FAB navigates to Add Doctor Visit Screen', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitListSuccess(mockList));
    when(() => mockBloc.filteredDoctorVisitList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    final fabFinder = find.byType(FloatingActionButton);
    expect(fabFinder, findsOneWidget);

    await tester.tap(fabFinder);
    await tester.pumpAndSettle();

    expect(find.text('Add Doctor Visit'), findsOneWidget);
  });

  testWidgets('tapping on care taker navigates to  Detail screen', (tester) async {
    when(() => mockBloc.state).thenReturn(DoctorVisitListSuccess(mockList));
    when(() => mockBloc.filteredDoctorVisitList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();
    final firstItem = find.text('Hepatitis B');
    expect(firstItem, findsOneWidget);

    await tester.tap(firstItem);
    await tester.pumpAndSettle();

    expect(find.text('Doctor Visit Detail'), findsOneWidget);
  });


}
