import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/vaccination/data/models/request/add_vaccination_req_model.dart';
import 'package:child_health_story/features/vaccination/data/models/request/edit_vaccination_req_model.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_list_res_model.dart';
import 'package:child_health_story/features/vaccination/data/repository/vaccinations_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late VaccinationsRepository repository;

  setUp(() {
    mockDio = MockDio();
    repository = VaccinationsRepository(dio: mockDio);
  });

  const childId = 'child123';
  const vaccinationId = 'vac123';
  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };
  final addReq = AddVaccinationReqModel(
    childId: 'child_001',
    vaccineName: 'MMR',
    disease: 'Measles, Mumps, Rubella',
    scheduledDate: '2025-08-10',
    vaccinatedDate: '2025-08-08',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    vaccineNumber: 'MMR-001',
    reactions: 'Mild fever for 2 days',
    attachments: [], // Can mock File objects here if needed
  );
  final updateReq = UpdateVaccinationReqModel(
    childId: 'child_001',
    scheduledDate: '2025-08-05',
    vaccinatedDate: '2025-08-06',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    vaccineNumber: 'DTP-2025-01',
    reactions: 'Mild swelling at injection site',
    attachments: [], // Optional: you can mock File if needed
  );
  final detailRes = {
    "statusCode": 200,
    "message": "Fetched successfully",
    "data": {
      "id": "vac_123",
      "childId": "child_001",
      "vaccineName": "MMR",
      "scheduledDate": "2025-08-10",
      "vaccinatedDate": "2025-08-08",
      "vaccineNumber": "MMR-2025-001",
      "hospitalId": "hospital_123",
      "doctorId": "doctor_456",
      "disease": "Measles, Mumps, Rubella",
      "reactions": "Mild fever and rash",
      "isVaccinated": true,
      "attachments": [
        "https://dummy.cdn.com/file1.jpg",
        "https://dummy.cdn.com/file2.jpg"
      ],
      "createdAt": "2025-08-08T10:00:00Z",
      "updatedAt": "2025-08-08T12:00:00Z",
      "isDeleted": false,
      "doctorName": "Dr. John Smith",
      "hospitalName": "Sunshine Hospital"
    }
  };
  final listRes  = {
    "statusCode": 200,
    "message": "Fetched successfully",
    "data": [
      {
        "id": "vac_001",
        "vaccineName": "Hepatitis B",
        "scheduledDate": "2025-08-01",
        "vaccinatedDate": "2025-08-02",
        "disease": "Hepatitis B",
        "isVaccinated": true
      },
      {
        "id": "vac_002",
        "vaccineName": "Polio",
        "scheduledDate": "2025-08-10",
        "vaccinatedDate": "",
        "disease": "Poliomyelitis",
        "isVaccinated": false
      }
    ]
  };


  group('addVaccination', () {
      test('returns success on 200 response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
                  requestOptions: RequestOptions(path: ''), statusCode: 200,
                  data: commonRes
              ),
        );

        final result = await repository.addVaccination(addReq);

        expect(result.isSuccess, true);
        expect(result.data, isA<CommonResModel>());
        expect(result.data!.message, 'Operation successful');
      });

      test('returns failure on non-200 with message', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Invalid request'}),
        );

        final result = await repository.addVaccination(addReq);

        expect(result.isError, true);
        expect(result.error, 'Invalid request');
      });

      test('returns connection timeout error on timeout', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            type: DioExceptionType.connectionTimeout,
          ),
        );

        final result = await repository.addVaccination(addReq);
        expect(result.isError, true);
        expect(result.error, ErrorMessages.connectionTimeOutError);
      });

      test('returns failure on DioException with response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            response: Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Server error'},
            ),
          ),
        );

        final result = await repository.addVaccination(addReq);

        expect(result.isError, true);
        expect(result.error, 'Server error');
      });

      test('returns something went wrong on generic exception', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(Exception('Unexpected error'));

        final result = await repository.addVaccination(addReq);

        expect(result.isError, true);
        expect(result.error, ErrorMessages.somethingWentWrongError);
      });
    });

  group('getVaccinationList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: listRes,
      ));

      final result = await repository.getVaccinationList(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<GetVaccinationsListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch vaccinations'},
      ));

      final result = await repository.getVaccinationList(childId);

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch vaccinations');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getVaccinationList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getVaccinationList(childId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getVaccinationList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });


  group('getVaccinationDetails', () {

    test('should return VaccinationDetails model when response is 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: detailRes,
      ));

      final result = await repository.getVaccinationDetails(vaccinationId);

      expect(result.isSuccess, true);
      final data = result.data!;
      expect(data.statusCode, 200);
      expect(data.message, 'Fetched successfully');
    });

    test('should return error message when response is not 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 404,
          data: {"message": "Vaccination not found"},
        ),
      );

      final result = await repository.getVaccinationDetails(vaccinationId);

      expect(result.isError, true);
      expect(result.error, "Vaccination not found");
    });

    test('should return connection timeout error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getVaccinationDetails(vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('should return error from DioException with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getVaccinationDetails(vaccinationId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('should return something went wrong on unknown error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Some unexpected error'));

      final result = await repository.getVaccinationDetails(vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateVaccinationDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Update failed'},
      ));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(Exception('Unexpected error'));

      final result = await repository.updateVaccinationDetails(
          updateReq, vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });


  });

  group('deleteVaccination', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: commonRes,
      ));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Delete failed'},
      ));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isError, true);
      expect(result.error, 'Delete failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteVaccination(vaccinationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });




}
