import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/vaccination/data/models/request/add_vaccination_req_model.dart';
import 'package:child_health_story/features/vaccination/data/models/request/edit_vaccination_req_model.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_detail_res_model.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_list_res_model.dart';
import 'package:child_health_story/features/vaccination/data/repository/vaccinations_repository.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockVaccinationsRepository extends Mock implements VaccinationsRepository {}
class FakeAddVaccinationReqModel extends Fake implements AddVaccinationReqModel {}
class FakeUpdateVaccinationReqModel extends Fake implements UpdateVaccinationReqModel {}

void main() {
  late VaccinationsBloc bloc;
  late MockVaccinationsRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddVaccinationReqModel());
    registerFallbackValue(FakeUpdateVaccinationReqModel());
  });
  setUp(() {
    mockRepository = MockVaccinationsRepository();
    bloc = VaccinationsBloc(vaccinationsRepository: mockRepository);
  });
  const childId = 'child123';
  const vaccinationId = 'vac123';
  final addVaccinationReq = AddVaccinationReqModel(
    childId: 'child_001',
    vaccineName: 'MMR',
    disease: 'Measles, Mumps, Rubella',
    scheduledDate: '2025-08-10',
    vaccinatedDate: '2025-08-08',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    vaccineNumber: 'MMR-001',
    reactions: 'Mild fever for 2 days',
    attachments: [], // Can mock File objects here if needed
  );
  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful',
  );
  final updateReq = UpdateVaccinationReqModel(
    childId: 'child_001',
    scheduledDate: '2025-08-05',
    vaccinatedDate: '2025-08-06',
    hospitalId: 'hospital_123',
    doctorId: 'doctor_456',
    vaccineNumber: 'DTP-2025-01',
    reactions: 'Mild swelling at injection site',
    attachments: [], // Optional: you can mock File if needed
  );
  final  detailRes = GetVaccinationsDetailResModel(
    statusCode: 200,
    message: 'Vaccination details fetched successfully',
    data: VaccinationDetailData(
      id: 'vac_123',
      childId: 'child_001',
      vaccineName: 'MMR',
      scheduledDate: '2025-08-10',
      vaccinatedDate: '2025-08-08',
      vaccineNumber: 'MMR-2025-001',
      hospitalId: 'hospital_123',
      doctorId: 'doctor_456',
      disease: 'Measles, Mumps, Rubella',
      reactions: 'Mild fever and rash',
      isVaccinated: true,
      attachments: ['https://dummy.cdn.com/file1.jpg', 'https://dummy.cdn.com/file2.jpg'],
      createdAt: '2025-08-08T10:00:00Z',
      updatedAt: '2025-08-08T12:00:00Z',
      isDeleted: false,
      doctorName: 'Dr. John Smith',
      hospitalName: 'Sunshine Hospital',
    ),
  );
  final listResModel = GetVaccinationsListResModel(
    statusCode: 200,
    message: 'Vaccinations fetched successfully',
    data: [
      VaccinationListData(
        id: 'vac_001',
        vaccineName: 'Hepatitis B',
        scheduledDate: '2025-08-01',
        vaccinatedDate: '2025-08-02',
        disease: 'Hepatitis B',
        isVaccinated: true,
      ),
      VaccinationListData(
        id: 'vac_002',
        vaccineName: 'Polio',
        scheduledDate: '2025-08-10',
        vaccinatedDate: '',
        disease: 'Poliomyelitis',
        isVaccinated: false,
      ),
    ],
  );
  final listEmptyRes = GetVaccinationsListResModel(
    statusCode: 200,
    message: 'No vaccinations found',
    data: [],
  );

  group('AddVaccinationEvent', () {
    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addVaccination(addVaccinationReq))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddVaccinationEvent(addVaccinationReqModel: addVaccinationReq)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsSuccess(message: 'Operation successful')
      ],
      verify: (_) {
        verify(() => mockRepository.addVaccination(addVaccinationReq)).called(1);
      },
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addVaccination(addVaccinationReq))
            .thenAnswer((_) async => Result.failure('Failed to add vaccination'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddVaccinationEvent(addVaccinationReqModel: addVaccinationReq)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsFailure('Failed to add vaccination'),
      ],
      verify: (_) {
        verify(() => mockRepository.addVaccination(addVaccinationReq)).called(1);
      },
    );
  });

  group('FetchVaccinationsListEvent', () {
    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationListSuccess] on success',
      build: () {
        when(() => mockRepository.getVaccinationList(childId))
            .thenAnswer((_) async => Result.success(listEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchVaccinationsListEvent(childId: childId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getVaccinationList(childId)).called(1),
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getVaccinationList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchVaccinationsListEvent(childId: childId)),
      expect: () => [
        VaccinationsLoading(),
        isA<VaccinationListSuccess>().having(
              (s) => s.vaccinationsList,
          'vaccinations',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getVaccinationList(childId)).called(1),
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsFailure] on failure',
      build: () {
        when(() => mockRepository.getVaccinationList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchVaccinationsListEvent(childId: childId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchVaccinationByIdEvent', () {

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getVaccinationDetails(vaccinationId))
            .thenAnswer((_) async => Result.success(detailRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchVaccinationByIdEvent(vaccinationId: vaccinationId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationByIdSuccess(detailRes.data),
      ],
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsFailure] on failure',
      build: () {
        when(() => mockRepository.getVaccinationDetails(vaccinationId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchVaccinationByIdEvent(vaccinationId: vaccinationId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsFailure('Not found'),
      ],
    );
  });

  group('UpdateVaccinationEvent', () {
    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsSuccess] on update success',
      build: () {
        when(() => mockRepository.updateVaccinationDetails(updateReq, vaccinationId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateVaccinationEvent(
          vaccinationId: vaccinationId,updateVaccinationReqModel: updateReq)
      ),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsFailure] on update failure',
      build: () {
        when(() => mockRepository.updateVaccinationDetails(updateReq, vaccinationId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateVaccinationEvent(
          vaccinationId: vaccinationId,updateVaccinationReqModel: updateReq)
      ),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsFailure('Update failed'),
      ],
    );
  });

  group('DeleteVaccinationEvent', () {
    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteVaccination(vaccinationId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteVaccinationEvent(vaccinationId: vaccinationId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<VaccinationsBloc, VaccinationState>(
      'emits [VaccinationsLoading, VaccinationsFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteVaccination(vaccinationId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteVaccinationEvent(vaccinationId: vaccinationId)),
      expect: () => [
        VaccinationsLoading(),
        VaccinationsFailure('Delete failed'),
      ],
    );
  });



}
