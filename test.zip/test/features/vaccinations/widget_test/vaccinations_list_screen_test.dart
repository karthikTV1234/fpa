import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_list_res_model.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/features/vaccination/presentation/vaccination_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockVaccinationsBloc extends MockBloc<VaccinationsEvent, VaccinationState>
    implements VaccinationsBloc {}

class FakeVaccinationsEvent extends Fake implements VaccinationsEvent {}

class FakeVaccinationsState extends Fake implements VaccinationState {}

void main() {
  late MockVaccinationsBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeVaccinationsEvent());
    registerFallbackValue(FakeVaccinationsState());
  });

  setUp(() {
    mockBloc = MockVaccinationsBloc();
  });

  final mockList = [
    VaccinationListData(
      id: 'vac_001',
      vaccineName: 'Hepatitis B',
      scheduledDate: '2025-08-01',
      vaccinatedDate: '2025-08-02',
      disease: 'Liver Infection',
      isVaccinated: true,
    ),
    VaccinationListData(
      id: 'vac_002',
      vaccineName: 'Polio',
      scheduledDate: '2025-08-10',
      vaccinatedDate: '',
      disease: 'Poliomyelitis',
      isVaccinated: false,
    ),
  ];
  final mappedList = [
    {
      "id": "vac_001",
      "category": "Liver Infection",
      "title": "Hepatitis B",
      "subtitle": "Vaccinated Date: 02 Aug 2025",
    },
    {
      "id": "vac_002",
      "category": "Poliomyelitis",
      "status": "Pending", // Not vaccinated
      "statusColor": AppColors.vLightOrangeColor,
      "title": "Polio",
      "subtitle": "Scheduled Date: 10 Aug 2025",
    },
  ];


  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addVaccinationScreen: (_) =>
          const Scaffold(body: Text('Add Vaccination')),
          PathConstants.vaccinationDetailScreen: (_) =>
          const Scaffold(body: Text('Vaccination Detail')),
        },
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is VaccinationsLoading', (WidgetTester tester) async {
    mockBloc = MockVaccinationsBloc();

    when(() => mockBloc.state).thenReturn(VaccinationsLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationsLoading()));

    when(() => mockBloc.filteredVaccinationsList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationListScreen(),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows snackbar on VaccinationsFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([VaccinationsFailure(errorMessage)]),
      initialState: VaccinationsInitial(),
    );

    when(() => mockBloc.filteredVaccinationsList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationListScreen(),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list of vaccinations on VaccinationListSuccess', (tester) async {

    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(VaccinationListSuccess(mockList));

    when(() => mockBloc.filteredVaccinationsList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    expect(find.text('Hepatitis B'), findsOneWidget);
    expect(find.text('Polio'), findsOneWidget);

  });


  testWidgets('filters list when search query is entered', (tester) async {
    when(() => mockBloc.state).thenReturn(VaccinationListSuccess(mockList));
    when(() => mockBloc.filteredVaccinationsList).thenReturn(mappedList);

    await pumpScreen(tester);

    await tester.pumpAndSettle();
    expect(find.text('Hepatitis B'), findsOneWidget);
    expect(find.text('Polio'), findsOneWidget);


    await tester.enterText(find.byType(TextField), 'Hepa');

    when(() => mockBloc.state).thenReturn(
      VaccinationListSearchSuccess([mappedList.first]),
    );
    when(() => mockBloc.filteredVaccinationsList).thenReturn([mappedList.first]);

    await tester.pumpAndSettle();

    expect(find.text('Hepatitis B'), findsOneWidget);
  });


}
