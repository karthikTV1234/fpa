import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_detail_res_model.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/features/vaccination/presentation/edit_vaccination.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockVaccinationsBloc extends MockBloc<VaccinationsEvent, VaccinationState> implements VaccinationsBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeVaccinationsEvent extends Fake implements VaccinationsEvent {}
class FakeVaccinationState extends Fake implements VaccinationState {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockVaccinationsBloc mockBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeVaccinationsEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeVaccinationState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockBloc = MockVaccinationsBloc();

    when(() => mockBloc.state).thenReturn(VaccinationsInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.hospitalList).thenReturn([]);
    when(() => mockBloc.doctorList).thenReturn([]);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  final detailData = VaccinationDetailData(
    vaccineName: 'Hepatitis B',
    disease: 'Hepatitis',
    scheduledDate: '2025-08-01',
    vaccinatedDate: '2025-08-02',
    hospitalName: 'City Hospital',
    doctorName: 'Dr. Who',
    vaccineNumber: '1',
    reactions: 'Mild fever',
    attachments: ['https://example.com/uploads/vaccine_report.pdf'],
  );

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<VaccinationsBloc>.value(value: mockBloc),
        ],
        child:  EditVaccinationScreen(vaccinationDetailData: detailData),
      ),
      routes: {
        PathConstants.vaccinationDetailScreen: (_) =>
        const Scaffold(body: Text('Vaccination Detail')),
      },
    );
  }

  testWidgets(
    'renders all essential form fields and Update button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.vaccineNameLabel), findsOneWidget);
      expect(find.text(AppStrings.diseaseLabel), findsOneWidget);
      expect(find.text(AppStrings.scheduledDateLabel), findsOneWidget);
      expect(find.text(AppStrings.vaccinatedDateLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.vaccineNumberLabel), findsOneWidget);
      expect(find.text(AppStrings.reactionsLabel), findsOneWidget);
      expect(find.text(AppStrings.updateTxt), findsOneWidget);
    },
  );

  testWidgets('prepopulates fields with existing data',
          (WidgetTester tester) async {
        await tester.pumpWidget(createWidgetUnderTest());
        await tester.pumpAndSettle();

        expect(find.widgetWithText(TextFormField, 'Hepatitis B'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, 'Hepatitis'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '1'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '2025-08-01'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '2025-08-02'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, 'Mild fever'), findsOneWidget);
 });

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), '');
    await tester.enterText(find.byType(TextFormField).at(1), '');

    final saveButton = find.text(AppStrings.updateTxt);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.vaccineNameRequired), findsOneWidget);
    expect(find.text(ValidationMessages.diseaseRequired), findsOneWidget);
  });

  testWidgets('shows snackbar when vaccination update fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        VaccinationsLoading(),
        VaccinationsFailure('Failed to update vaccination')
      ]),
      initialState: VaccinationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // begin listening
    await tester.pump(); // show snackbar

    expect(find.text('Failed to update vaccination'), findsOneWidget);
  });

  testWidgets('pops with true on VaccinationsSuccess', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        VaccinationsLoading(),
        VaccinationsSuccess(message: 'Updated successfully'),
      ]),
      initialState: VaccinationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();

    expect(find.byType(EditVaccinationScreen), findsNothing);
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
