import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/add_vaccination.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockVaccinationsBloc extends MockBloc<VaccinationsEvent, VaccinationState> implements VaccinationsBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeVaccinationsEvent extends Fake implements VaccinationsEvent {}
class FakeVaccinationState extends Fake implements VaccinationState {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockVaccinationsBloc mockBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeVaccinationsEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeVaccinationState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockBloc = MockVaccinationsBloc();

    when(() => mockBloc.state).thenReturn(VaccinationsInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.hospitalList).thenReturn([]);
    when(() => mockBloc.doctorList).thenReturn([]);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<VaccinationsBloc>.value(value: mockBloc),
        ],
        child: const AddVaccinationScreen(),
      ),
      routes: {
        PathConstants.vaccinationListScreen: (_) =>
        const Scaffold(body: Text('Vaccination List')),
      },
    );
  }

  testWidgets(
    'renders all essential form fields and Save button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.vaccineNameLabel), findsOneWidget);
      expect(find.text(AppStrings.diseaseLabel), findsOneWidget);
      expect(find.text(AppStrings.scheduledDateLabel), findsOneWidget);
      expect(find.text(AppStrings.vaccinatedDateLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.vaccineNumberLabel), findsOneWidget);
      expect(find.text(AppStrings.reactionsLabel), findsOneWidget);
      expect(find.text(AppStrings.saveText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.vaccineNameRequired), findsOneWidget);
    expect(find.text(ValidationMessages.diseaseRequired), findsOneWidget);
    expect(find.text(ValidationMessages.vaccineNumberRequired), findsOneWidget);
  });

  testWidgets('shows snackbar when vaccination add fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        VaccinationsLoading(),
        VaccinationsFailure('Failed to save vaccination'),
      ]),
      initialState: VaccinationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump();
    await tester.pump();

    expect(find.text('Failed to save vaccination'), findsOneWidget);
  });

  testWidgets('navigates to vaccination list screen on success', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        VaccinationsLoading(),
        VaccinationsSuccess(message: "Added"),
      ]),
      initialState: VaccinationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.enterText(find.byType(TextFormField).at(0), 'Hepatitis B'); // Vaccine Name
    await tester.enterText(find.byType(TextFormField).at(1), 'Hepatitis B Virus'); // Disease
    await tester.enterText(find.byType(TextFormField).at(2), '02-08-2025'); // Scheduled Date
    await tester.enterText(find.byType(TextFormField).at(3), '05-08-2025'); // Vaccinated Date
    await tester.enterText(find.byType(TextFormField).at(4), 'Apollo Hospital'); // Hospital
    await tester.enterText(find.byType(TextFormField).at(5), 'Dr. Smith'); // Doctor
    await tester.enterText(find.byType(TextFormField).at(6), 'VAC1234'); // Vaccine Number
    await tester.enterText(find.byType(TextFormField).at(7), 'No side effects'); // Notes

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton, warnIfMissed: false);
    await tester.pumpAndSettle();

    expect(find.text('Vaccination List'), findsOneWidget);
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
