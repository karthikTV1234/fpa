import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/vaccination/data/models/response/vaccination_detail_res_model.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/features/vaccination/presentation/vaccination_detail.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mocktail/mocktail.dart';

// Mocks and Fakes

class MockVaccinationsBloc extends Mock implements VaccinationsBloc {}
class MockNavigatorObserver extends Mock implements NavigatorObserver {}
class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockVaccinationsBloc mockBloc;
  const vaccinationId = 'vac123';

  setUpAll(() {
    registerFallbackValue(DeleteVaccinationEvent(vaccinationId: vaccinationId));
    registerFallbackValue(FetchVaccinationByIdEvent(vaccinationId: vaccinationId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockVaccinationsBloc();

    final testState = VaccinationByIdSuccess(
      VaccinationDetailData(vaccineName: 'Hepatitis B'),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
  });

  final mockData = VaccinationDetailData(
    vaccineName: 'Hepatitis B',
    disease: 'Hepatitis',
    scheduledDate: '2025-08-01',
    vaccinatedDate: '2025-08-02',
    hospitalName: 'City Hospital',
    doctorName: 'Dr. Who',
    vaccineNumber: '1',
    reactions: 'Mild fever',
    attachments: ['https://example.com/uploads/vaccine_report.pdf'],
  );

  testWidgets('renders vaccination details when VaccinationByIdSuccess is emitted', (tester) async {
    when(() => mockBloc.state).thenReturn(VaccinationByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.vaccinationDetailData).thenReturn(mockData);
    when(() => mockBloc.add(any())).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.text('Hepatitis B'), findsOneWidget);
    expect(find.text('Hepatitis'), findsOneWidget);
    expect(find.text('2025-08-01'), findsOneWidget);
    expect(find.text('2025-08-02'), findsOneWidget);
    expect(find.text('City Hospital'), findsOneWidget);
    expect(find.text('Dr. Who'), findsOneWidget);
    expect(find.text('1'), findsOneWidget);
    expect(find.text('Mild fever'), findsOneWidget);
  });

  testWidgets('should show loading indicator when state is VaccinationsLoading', (tester) async {
    when(() => mockBloc.state).thenReturn(VaccinationsLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationsLoading()));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.vaccinationDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('should show error message when state is failure', (tester) async {
    const errorMessage = 'Error loading vaccination';

    when(() => mockBloc.state).thenReturn(VaccinationsFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationsFailure(errorMessage)));
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.vaccinationDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<VaccinationsBloc>.value(
              value: mockBloc,
              child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('navigates to edit vaccination screen on edit button tap', (tester) async {
    when(() => mockBloc.state).thenReturn(VaccinationByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.vaccinationDetailData).thenReturn(mockData);

    final mockObserver = MockNavigatorObserver();

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.editVaccinationScreen) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit Vaccination Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<VaccinationsBloc>.value(
          value: mockBloc,
          child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
        ),
        navigatorObservers: [mockObserver],
      ),
    );

    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);

    reset(mockObserver);

    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);
  });

  testWidgets('should display file attachments if available', (tester) async {
    when(() => mockBloc.state).thenReturn(VaccinationByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(VaccinationByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.vaccinationDetailData).thenReturn(mockData);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: BlocProvider<VaccinationsBloc>.value(
            value: mockBloc,
            child: SizedBox(
              height: 200,
              child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.textContaining('pdf'), findsOneWidget);
  });

  testWidgets('delete vaccination and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.vaccinationListScreen: (_) => const Scaffold(body: Text('Vaccination List')),
            },
            home: BlocProvider<VaccinationsBloc>.value(
              value: mockBloc,
              child: const VaccinationDetailScreen(vaccinationId: vaccinationId),
            ),
          ),
        );


        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteVaccinationTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteVaccinationConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteVaccinationEvent(vaccinationId: vaccinationId))).called(1);

        final successState = VaccinationsSuccess(message: 'Vaccination deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });

}
