import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/health_tracker/data/models/request/add_health_tracker_req_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/request/edit_health_tracker_req_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/add_health_tracker_res_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_list_res_model.dart';
import 'package:child_health_story/features/health_tracker/data/repository/health_tracker_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late HealthTrackerRepository repository;

  setUp(() {
    mockDio = MockDio();
    repository = HealthTrackerRepository(dio: mockDio);
  });

  const childId = 'child123';
  const healthTrackerId = 'health123';
  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };
  final addReq = AddHealthRecordReqModel(
    childId: 'child456',
    dateOfEntry: '2025-08-08',
    temperature: '98.6',
    heartRate: '75',
    respiratoryRate: '16',
    notes: 'Routine checkup, all normal',
    conditionName: 'General Checkup',
    attachments: [],
  );
  final addRes = {
    "statusCode": 200,
    "message": "Health record added successfully",
    "data": {
      "id": "hr123",
      "childId": "child456",
      "dateOfEntry": "2025-08-08",
      "temperature": "98.6",
      "heartRate": "75",
      "respiratoryRate": "16",
      "notes": "Routine checkup, all normal",
      "attachments": [
        "https://example.com/attachment1.jpg",
        "https://example.com/attachment2.pdf"
      ],
      "conditionName": "General Checkup",
      "createdAt": "2025-08-08T12:34:56.000Z",
      "updatedAt": "2025-08-08T12:34:56.000Z",
      "isDeleted": false
    }
  };
  final updateReq = UpdateHealthRecordReqModel(
    childId: 'child456',
    dateOfEntry: '2025-08-08',
    temperature: '99.1',
    heartRate: '80',
    respiratoryRate: '18',
    notes: 'Updated record after follow-up visit',
    conditionName: 'Mild Fever',
    attachments: [],
  );
  final detailRes = {
    "statusCode": 200,
    "message": "Fetched successfully",
    "data": {
      "id": "hr123",
      "childId": "child456",
      "dateOfEntry": "2025-08-08",
      "temperature": "98.7",
      "heartRate": "78",
      "respiratoryRate": "20",
      "notes": "Child had a mild cold and was observed for 2 days.",
      "attachments": [
        "https://example.com/attachments/report1.jpg",
        "https://example.com/attachments/report2.pdf"
      ],
      "conditionName": "Common Cold",
      "createdAt": "2025-08-08T10:30:00Z",
      "updatedAt": "2025-08-08T12:00:00Z",
      "isDeleted": false
    }
  };
  final listRes  = {
    "statusCode": 200,
    "message": "Fetched successfully",
    "data": [
      {
        "id": "hr1",
        "dateOfEntry": "2025-08-01",
        "temperature": "98.4",
        "heartRate": 75,
        "respiratoryRate": 18,
        "conditionName": "Fever"
      },
      {
        "id": "hr2",
        "dateOfEntry": "2025-08-05",
        "temperature": "99.1",
        "heartRate": 80,
        "respiratoryRate": 20,
        "conditionName": "Cold"
      }
    ]
  };

  group('addHealthTracker', () {
      test('returns success on 200 response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
                  requestOptions: RequestOptions(path: ''), statusCode: 200,
                  data: addRes
              ),
        );

        final result = await repository.addHealthRecord(addReq);

        expect(result.isSuccess, true);
        expect(result.data, isA<AddHealthRecordResModel>());
        expect(result.data!.message, 'Health record added successfully');
      });

      test('returns failure on non-200 with message', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Invalid request'}),
        );

        final result = await repository.addHealthRecord(addReq);

        expect(result.isError, true);
        expect(result.error, 'Invalid request');
      });

      test('returns connection timeout error on timeout', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            type: DioExceptionType.connectionTimeout,
          ),
        );

        final result = await repository.addHealthRecord(addReq);
        expect(result.isError, true);
        expect(result.error, ErrorMessages.connectionTimeOutError);
      });

      test('returns failure on DioException with response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            response: Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Server error'},
            ),
          ),
        );

        final result = await repository.addHealthRecord(addReq);

        expect(result.isError, true);
        expect(result.error, 'Server error');
      });

      test('returns something went wrong on generic exception', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(Exception('Unexpected error'));

        final result = await repository.addHealthRecord(addReq);

        expect(result.isError, true);
        expect(result.error, ErrorMessages.somethingWentWrongError);
      });
    });

  group('getHealthTrackerList', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: listRes,
      ));

      final result = await repository.getHealthRecordList(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<GetHealthRecordsListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch health records'},
      ));

      final result = await repository.getHealthRecordList(childId);

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch health records');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getHealthRecordList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getHealthRecordList(childId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getHealthRecordList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });


  group('getHealthTrackerDetails', () {

    test('should return HealthTrackerDetails model when response is 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: detailRes,
      ));

      final result = await repository.getHealthRecordDetails(healthTrackerId);

      expect(result.isSuccess, true);
      final data = result.data!;
      expect(data.statusCode, 200);
      expect(data.message, 'Fetched successfully');
    });

    test('should return error message when response is not 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 404,
          data: {"message": "Health Tracker not found"},
        ),
      );

      final result = await repository.getHealthRecordDetails(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, "Health Tracker not found");
    });

    test('should return connection timeout error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getHealthRecordDetails(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('should return error from DioException with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getHealthRecordDetails(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('should return something went wrong on unknown error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Some unexpected error'));

      final result = await repository.getHealthRecordDetails(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateHealthTrackerDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: commonRes));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Update failed'},
      ));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId
      );

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(Exception('Unexpected error'));

      final result = await repository.updateHealthRecordDetails(
          updateReq, healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });


  });

  group('deleteHealthTracker', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: commonRes,
      ));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Delete failed'},
      ));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, 'Delete failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteHealthRecord(healthTrackerId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });




}
