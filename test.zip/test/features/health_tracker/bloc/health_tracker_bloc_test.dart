import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/health_tracker/data/models/request/add_health_tracker_req_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/request/edit_health_tracker_req_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/add_health_tracker_res_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_detail_res_model.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_list_res_model.dart';
import 'package:child_health_story/features/health_tracker/data/repository/health_tracker_repository.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockHealthTrackerRepository extends Mock implements HealthTrackerRepository {}
class FakeAddHealthRecordReqModel extends Fake implements AddHealthRecordReqModel {}
class FakeUpdateHealthRecordReqModel extends Fake implements UpdateHealthRecordReqModel {}

void main() {
  late HealthTrackerBloc bloc;
  late MockHealthTrackerRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddHealthRecordReqModel());
    registerFallbackValue(FakeUpdateHealthRecordReqModel());
  });
  setUp(() {
    mockRepository = MockHealthTrackerRepository();
    bloc = HealthTrackerBloc(healthTrackerRepository: mockRepository);
  });
  const childId = 'child123';
  const healthTrackerId = 'health123';
  final addReq = AddHealthRecordReqModel(
    childId: 'child456',
    dateOfEntry: '2025-08-08',
    temperature: '98.6',
    heartRate: '75',
    respiratoryRate: '16',
    notes: 'Routine checkup, all normal',
    conditionName: 'General Checkup',
    attachments: [],
  );
  final addRes = AddHealthRecordResModel(
    statusCode: 200,
    message: 'Added successfully',
    data: HealthRecordAddResData(
      id: 'hr123',
      childId: 'child456',
      dateOfEntry: '2025-08-08',
      temperature: '98.6',
      heartRate: '75',
      respiratoryRate: '16',
      notes: 'Routine checkup, all normal',
      attachments: [
        'https://example.com/attachment1.jpg',
        'https://example.com/attachment2.pdf',
      ],
      conditionName: 'General Checkup',
      createdAt: '2025-08-08T12:34:56.000Z',
      updatedAt: '2025-08-08T12:34:56.000Z',
      isDeleted: false,
    ),
  );
  final updateReq = UpdateHealthRecordReqModel(
    childId: 'child456',
    dateOfEntry: '2025-08-08',
    temperature: '99.1',
    heartRate: '80',
    respiratoryRate: '18',
    notes: 'Updated record after follow-up visit',
    conditionName: 'Mild Fever',
    attachments: [],
  );
  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful',
  );
  final detailRes = GetHealthRecordDetailResModel(
    statusCode: 200,
    message: 'Health record fetched successfully',
    data: HealthRecordDetailData(
      id: 'hr123',
      childId: 'child456',
      dateOfEntry: '2025-08-08',
      temperature: '98.7',
      heartRate: '78',
      respiratoryRate: '20',
      notes: 'Child had a mild cold and was observed for 2 days.',
      attachments: [
        'https://example.com/attachments/report1.jpg',
        'https://example.com/attachments/report2.pdf',
      ],
      conditionName: 'Common Cold',
      createdAt: '2025-08-08T10:30:00Z',
      updatedAt: '2025-08-08T12:00:00Z',
      isDeleted: false,
    ),
  );
  final listResModel = GetHealthRecordsListResModel(
    statusCode: 200,
    message: 'Health records fetched successfully',
    data: [
      HealthRecordListData(
        id: 'hr1',
        dateOfEntry: '2025-08-01',
        temperature: '98.4',
        heartRate: 75,
        respiratoryRate: 18,
        conditionName: 'Fever',
      ),
      HealthRecordListData(
        id: 'hr2',
        dateOfEntry: '2025-08-05',
        temperature: '99.1',
        heartRate: 80,
        respiratoryRate: 20,
        conditionName: 'Cold',
      ),
    ],
  );
  final listEmptyRes = GetHealthRecordsListResModel(
    statusCode: 200,
    message: 'No records found',
    data: [],
  );

  group('AddHealthTrackerEvent', () {
    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addHealthRecord(addReq))
            .thenAnswer((_) async => Result.success(addRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddHealthTrackerEvent(addHealthTrackerReqModel: addReq)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerSuccess(message: 'Added successfully'),
      ],
      verify: (_) {
        verify(() => mockRepository.addHealthRecord(addReq)).called(1);
      },
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addHealthRecord(addReq))
            .thenAnswer((_) async => Result.failure('Failed to add health record'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddHealthTrackerEvent(addHealthTrackerReqModel: addReq)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerFailure('Failed to add health record'),
      ],
      verify: (_) {
        verify(() => mockRepository.addHealthRecord(addReq)).called(1);
      },
    );
  });

  group('FetchHealthTrackerListEvent', () {
    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerListSuccess] on success',
      build: () {
        when(() => mockRepository.getHealthRecordList(childId))
            .thenAnswer((_) async => Result.success(listEmptyRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHealthTrackerListEvent(childId: childId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getHealthRecordList(childId)).called(1),
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerListSuccess] with non-empty list',
      build: () {
        when(() => mockRepository.getHealthRecordList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchHealthTrackerListEvent(childId: childId)),
      expect: () => [
        HealthTrackerLoading(),
        isA<HealthTrackerListSuccess>().having(
              (s) => s.healthTrackerList,
          'health record',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getHealthRecordList(childId)).called(1),
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerFailure] on failure',
      build: () {
        when(() => mockRepository.getHealthRecordList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHealthTrackerListEvent(childId: childId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchHealthTrackerByIdEvent', () {

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getHealthRecordDetails(healthTrackerId))
            .thenAnswer((_) async => Result.success(detailRes));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHealthTrackerByIdEvent(healthTrackerId: healthTrackerId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerByIdSuccess(detailRes.data),
      ],
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerFailure] on failure',
      build: () {
        when(() => mockRepository.getHealthRecordDetails(healthTrackerId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchHealthTrackerByIdEvent(healthTrackerId: healthTrackerId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerFailure('Not found'),
      ],
    );
  });

  group('UpdateHealthTrackerEvent', () {
    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerSuccess] on update success',
      build: () {
        when(() => mockRepository.updateHealthRecordDetails(updateReq, healthTrackerId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateHealthTrackerEvent(
          healthTrackerId: healthTrackerId,updateHealthRecordReqModel: updateReq)
      ),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerFailure] on update failure',
      build: () {
        when(() => mockRepository.updateHealthRecordDetails(updateReq, healthTrackerId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateHealthTrackerEvent(
          healthTrackerId: healthTrackerId,updateHealthRecordReqModel: updateReq)
      ),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerFailure('Update failed'),
      ],
    );
  });

  group('DeleteHealthTrackerEvent', () {
    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteHealthRecord(healthTrackerId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteHealthTrackerEvent(healthTrackerId: healthTrackerId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<HealthTrackerBloc, HealthTrackerState>(
      'emits [HealthTrackerLoading, HealthTrackerFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteHealthRecord(healthTrackerId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteHealthTrackerEvent(healthTrackerId: healthTrackerId)),
      expect: () => [
        HealthTrackerLoading(),
        HealthTrackerFailure('Delete failed'),
      ],
    );
  });



}
