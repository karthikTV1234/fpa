import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_detail_res_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/features/health_tracker/presentation/health_tracker_detail_screen.dart';

class MockHealthTrackerBloc extends Mock implements HealthTrackerBloc {}

class MockNavigatorObserver extends Mock implements NavigatorObserver {}

class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockHealthTrackerBloc mockBloc;
  const healthTrackerId = 'ht123';

  setUpAll(() {
    registerFallbackValue(FetchHealthTrackerByIdEvent(healthTrackerId: healthTrackerId));
    registerFallbackValue(DeleteHealthTrackerEvent(healthTrackerId: healthTrackerId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockHealthTrackerBloc();

    final testState = HealthTrackerByIdSuccess(
      HealthRecordDetailData(
        conditionName: 'Fever',
        dateOfEntry: '2025-08-01',
        temperature: '98.6',
        heartRate: '75',
        respiratoryRate: '18',
      ),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
  });

  final mockData = HealthRecordDetailData(
    conditionName: 'Fever',
    dateOfEntry: '2025-08-01',
    temperature: '98.6',
    heartRate: '75',
    respiratoryRate: '18',
    notes: 'Patient is recovering well.',
      attachments: ['https://example.com/uploads/health_report.pdf']
  );

  testWidgets('renders vaccination details when HealthTrackerByIdSuccess is emitted', (tester) async {
    when(() => mockBloc.state).thenReturn(HealthTrackerByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.healthRecordDetailData).thenReturn(mockData);
    when(() => mockBloc.add(any())).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.text('Fever'), findsOneWidget);
    expect(find.text('2025-08-01'), findsOneWidget);
    expect(find.text('98.6'), findsOneWidget);
    expect(find.text('75'), findsOneWidget);
    expect(find.text('18'), findsOneWidget);
    expect(find.text('Patient is recovering well.'), findsOneWidget);
  });

  testWidgets('should show loading indicator when state is HealthTrackerLoading', (WidgetTester tester) async {
    when(() => mockBloc.state).thenReturn(HealthTrackerLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerLoading()));

    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.healthRecordDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('should show error message when state is failure', (WidgetTester tester) async {
    const errorMessage = 'Failed to load health tracker data';

    when(() => mockBloc.state).thenReturn(HealthTrackerFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerFailure(errorMessage)));

    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.healthRecordDetailData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<HealthTrackerBloc>.value(
              value: mockBloc,
              child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();  // start frame
    await tester.pump(const Duration(seconds: 1));  // allow snackbar animation

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('navigates to edit health tracker screen on edit button tap', (tester) async {
    when(() => mockBloc.state).thenReturn(HealthTrackerByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.healthRecordDetailData).thenReturn(mockData);

    final mockObserver = MockNavigatorObserver();

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.editHealthTrackerScreen) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit Health Tracker Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
        ),
        navigatorObservers: [mockObserver],
      ),
    );

    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);

    reset(mockObserver);

    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);
  });

  testWidgets('should display file attachments if available', (tester) async {
    when(() => mockBloc.state).thenReturn(HealthTrackerByIdSuccess(mockData));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerByIdSuccess(mockData)));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.healthRecordDetailData).thenReturn(mockData);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: BlocProvider<HealthTrackerBloc>.value(
            value: mockBloc,
            child: SizedBox(
              height: 200,
              child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.textContaining('pdf'), findsOneWidget);
  });

  testWidgets('delete health tracker and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.healthTrackerListScreen: (_) => const Scaffold(body: Text('Medications List')),
            },
            home: BlocProvider<HealthTrackerBloc>.value(
              value: mockBloc,
              child: const HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
            ),
          ),
        );

        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteHealthTrackerTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteHealthTrackerConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteHealthTrackerEvent(healthTrackerId: healthTrackerId))).called(1);

        final successState = HealthTrackerSuccess(message: 'HealthTracker deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });
}
