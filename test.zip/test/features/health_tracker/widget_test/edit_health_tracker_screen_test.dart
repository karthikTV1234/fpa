import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_detail_res_model.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/features/health_tracker/presentation/edit_health_tracker_screen.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';

class MockHealthTrackerBloc extends MockBloc<HealthTrackerEvent, HealthTrackerState> implements HealthTrackerBloc {}

class FakeHealthTrackerEvent extends Fake implements HealthTrackerEvent {}
class FakeHealthTrackerState extends Fake implements HealthTrackerState {}

void main() {
  late MockHealthTrackerBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeHealthTrackerEvent());
    registerFallbackValue(FakeHealthTrackerState());
  });

  setUp(() {
    mockBloc = MockHealthTrackerBloc();

    when(() => mockBloc.state).thenReturn(HealthTrackerInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
  });

  final detailData = HealthRecordDetailData(
    id: 'hr123',
    childId: 'child456',
    dateOfEntry: '2025-08-08',
    temperature: '98.7',
    heartRate: '78',
    respiratoryRate: '20',
    notes: 'Child had a mild cold and was observed for 2 days.',
    attachments: [
      'https://example.com/attachments/report1.jpg',
      'https://example.com/attachments/report2.pdf',
    ],
    conditionName: 'Common Cold',
  );

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: BlocProvider<HealthTrackerBloc>.value(
        value: mockBloc,
        child:  EditHealthTrackerScreen(healthRecordDetailData: detailData),
      ),
      routes: {
        PathConstants.healthTrackerListScreen: (_) =>
        const Scaffold(body: Text('HealthTracker List')),
      },
    );
  }


  testWidgets(
    'renders all essential form fields and Update button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.conditionNameLabel), findsOneWidget);
      expect(find.text(AppStrings.dateLabel), findsOneWidget);
      expect(find.text(AppStrings.temperatureLabel), findsOneWidget);
      expect(find.text(AppStrings.heartRateLabel), findsOneWidget);
      expect(find.text(AppStrings.respiratoryLabel), findsOneWidget);
      expect(find.text(AppStrings.updateTxt), findsOneWidget);
    },
  );

  testWidgets('prepopulates fields with existing data',
          (WidgetTester tester) async {
        await tester.pumpWidget(createWidgetUnderTest());
        await tester.pumpAndSettle();

        expect(find.widgetWithText(TextFormField, 'Common Cold'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '98.7'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '78'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '20'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, 'Child had a mild cold and was observed for 2 days.'), findsOneWidget);
 });

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), '');
    await tester.enterText(find.byType(TextFormField).at(2), '');
    await tester.enterText(find.byType(TextFormField).at(3), '');
    await tester.enterText(find.byType(TextFormField).at(4), '');

    final saveButton = find.text(AppStrings.updateTxt);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.conditionNameValidation), findsOneWidget);
    expect(find.text(ValidationMessages.temperatureEmptyValidation), findsOneWidget);
    expect(find.text(ValidationMessages.heartRateEmptyValidation), findsOneWidget);
    expect(find.text(ValidationMessages.respiratoryEmptyValidation), findsOneWidget);
  });

  testWidgets('shows snackbar when health tracker update fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        HealthTrackerLoading(),
        HealthTrackerFailure('Failed to update health tracker ')
      ]),
      initialState: HealthTrackerInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // begin listening
    await tester.pump(); // show snackbar

    expect(find.text('Failed to update health tracker '), findsOneWidget);
  });

  testWidgets('pops with true on HealthTrackerSuccess', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        HealthTrackerLoading(),
        HealthTrackerSuccess(message: 'Updated successfully'),
      ]),
      initialState: HealthTrackerInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();

    expect(find.byType(EditHealthTrackerScreen), findsNothing);
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
