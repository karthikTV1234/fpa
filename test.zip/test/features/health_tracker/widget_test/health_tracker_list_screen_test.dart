import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/health_tracker/data/models/response/health_tracker_list_res_model.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/features/health_tracker/presentation/health_tracker_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockHealthTrackerBloc extends MockBloc<HealthTrackerEvent, HealthTrackerState>
    implements HealthTrackerBloc {}

class FakeHealthTrackerEvent extends Fake implements HealthTrackerEvent {}

class FakeHealthTrackerState extends Fake implements HealthTrackerState {}

void main() {
  late MockHealthTrackerBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeHealthTrackerEvent());
    registerFallbackValue(FakeHealthTrackerState());
  });

  setUp(() {
    mockBloc = MockHealthTrackerBloc();
  });

  final mockList = [
    HealthRecordListData(
      id: 'hr1',
      dateOfEntry: '2025-08-01',
      temperature: '98.4',
      heartRate: 75,
      respiratoryRate: 18,
      conditionName: 'Fever',
    ),
    HealthRecordListData(
      id: 'hr2',
      dateOfEntry: '2025-08-05',
      temperature: '99.1',
      heartRate: 80,
      respiratoryRate: 20,
      conditionName: 'Cold',
    ),
  ];
  final mappedList = [
    {
      "id": "hr1",
      "category": "01 Aug 2025",
      "title": "Fever",
      "subtitle": "Temperature: 98.4 °F\nHeart Rate: 75\nRespiratory Rate: 18",
    },
    {
      "id": "hr2",
      "category": "05 Aug 2025",
      "title": "Cold",
      "subtitle": "Temperature: 99.1 °F\nHeart Rate: 80\nRespiratory Rate: 20",
    },
  ];

  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addHealthTrackerScreen: (_) =>
          const Scaffold(body: Text('Add Health Tracker')),
          PathConstants.healthTrackerDetailScreen: (_) =>
          const Scaffold(body: Text('Health Tracker Detail')),
        },
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is HealthTrackerLoading', (WidgetTester tester) async {
    mockBloc = MockHealthTrackerBloc();

    when(() => mockBloc.state).thenReturn(HealthTrackerLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(HealthTrackerLoading()));

    when(() => mockBloc.filteredHealthTrackerList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerListScreen(),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows snackbar on HealthTrackerFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([HealthTrackerFailure(errorMessage)]),
      initialState: HealthTrackerInitial(),
    );

    when(() => mockBloc.filteredHealthTrackerList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<HealthTrackerBloc>.value(
          value: mockBloc,
          child: const HealthTrackerListScreen(),
        ),
      ),
    );

    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list of health tracker on HealthTrackerListSuccess', (tester) async {

    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(HealthTrackerListSuccess(mockList));

    when(() => mockBloc.filteredHealthTrackerList).thenReturn(mappedList);

    await pumpScreen(tester);
    await tester.pumpAndSettle();

    expect(find.text('Fever'), findsOneWidget);
    expect(find.text('Cold'), findsOneWidget);
  });


  testWidgets('filters list when search query is entered', (tester) async {
    when(() => mockBloc.state).thenReturn(HealthTrackerListSuccess(mockList));
    when(() => mockBloc.filteredHealthTrackerList).thenReturn(mappedList);

    await pumpScreen(tester);

    await tester.pumpAndSettle();
    expect(find.text('Fever'), findsOneWidget);
    expect(find.text('Cold'), findsOneWidget);

    await tester.enterText(find.byType(TextField), 'Fev');

    when(() => mockBloc.state).thenReturn(
      HealthTrackerListSearchSuccess([mappedList.first]),
    );
    when(() => mockBloc.filteredHealthTrackerList).thenReturn([mappedList.first]);

    await tester.pumpAndSettle();

    expect(find.text('Fever'), findsOneWidget);
  });


}
