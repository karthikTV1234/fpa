import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/medications/data/model/request/add_medication_req_model.dart';
import 'package:child_health_story/features/medications/data/model/request/edit_medication_req_model.dart';
import 'package:child_health_story/features/medications/data/model/response/add_medication_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/edit_medication_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/frequency_list_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_list_res_model.dart';
import 'package:child_health_story/features/medications/data/repository/medications_repository.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late MockDio mockDio;
  late MedicationsRepository repository;

  setUp(() {
    mockDio = MockDio();
    repository = MedicationsRepository(dio: mockDio);
  });

  const childId = 'child123';
  const medicationId = 'med123';

  final addMedicationReq = AddMedicationReqModel(
    childId: 'child123',
    medicineName: 'Paracetamol',
    dosage: '5ml',
    frequency: 'Twice a day',
    timeOfDay: ['Morning', 'Night'],
    startDate: '2025-07-26',
    endDate: '2025-08-02',
    prescribedBy: 'Dr. Smith',
    reasonOfUse: 'Fever',
    notes: 'Take after food',
    attachments: [],
  );
  final addMedicationSuccessResponse = {
    'statusCode': 200,
    'message': 'Medication added successfully',
    'data': {
      'id': 'med123',
      'child_id': 'child123',
      'medicine_name': 'Paracetamol',
      'dosage': '5ml',
      'frequency': 'Twice a day',
      'time_of_day': ['Morning', 'Night'],
      'start_date': '2025-07-26',
      'end_date': '2025-08-02',
      'prescribed_by': 'Dr. Smith',
      'reason_of_use': 'Fever',
      'notes': 'Take after food',
      'is_active': true,
      'created_at': '2025-07-26T10:00:00Z',
      'updated_at': '2025-07-26T10:00:00Z',
      'attachments': [],
    }
  };

  final updateReqModel = UpdateMedicationReqModel(
    medicineName: 'Paracetamol',
    dosage: '5ml',
    frequency: 'Once a day',
    timeOfDay: ['Morning'],
    startDate: '2023-01-01',
    endDate: '2023-01-10',
    prescribedBy: 'Dr. John',
    reasonOfUse: 'Fever',
    notes: 'No side effects',
  );

  final updateResJson = {
    'statusCode': 200,
    'message': 'Operation successful',
    'data': {
      'id': 'med_123',
      'childId': 'child123',
      'medicineName': 'Paracetamol',
      'dosage': '5ml',
      'frequency': 'Once a day',
      'timeOfDay': ['Morning'],
      'startDate': '2023-01-01',
      'endDate': '2023-01-10',
      'prescribedBy': 'Dr. John',
      'reasonOfUse': 'Fever',
      'notes': 'No side effects',
      'attachments': ['url1', 'url2'],
    },
  };


  final commonRes = {
    'statusCode': 200,
    'message': 'Operation successful',
  };

    group('addMedication', () {
      test('returns success on 200 response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(
                  requestOptions: RequestOptions(path: ''), statusCode: 200,
                  data: addMedicationSuccessResponse
              ),
        );

        final result = await repository.addMedication(addMedicationReq);

        expect(result.isSuccess, true);
        expect(result.data, isA<AddMedicationResModel>());
        expect(result.data!.message, 'Medication added successfully');
      });

      test('returns failure on non-200 with message', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenAnswer(
              (_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 400, data: {'message': 'Invalid request'}),
        );

        final result = await repository.addMedication(addMedicationReq);

        expect(result.isError, true);
        expect(result.error, 'Invalid request');
      });

      test('returns connection timeout error on timeout', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            type: DioExceptionType.connectionTimeout,
          ),
        );

        final result = await repository.addMedication(addMedicationReq);
        expect(result.isError, true);
        expect(result.error, ErrorMessages.connectionTimeOutError);
      });

      test('returns failure on DioException with response', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(
          DioException(
            requestOptions: RequestOptions(path: ''),
            response: Response(
              requestOptions: RequestOptions(path: ''),
              statusCode: 400,
              data: {'message': 'Server error'},
            ),
          ),
        );

        final result = await repository.addMedication(addMedicationReq);

        expect(result.isError, true);
        expect(result.error, 'Server error');
      });

      test('returns something went wrong on generic exception', () async {
        when(() => mockDio.post(any(), data: any(named: 'data'), options: any(named: 'options'))).thenThrow(Exception('Unexpected error'));

        final result = await repository.addMedication(addMedicationReq);

        expect(result.isError, true);
        expect(result.error, ErrorMessages.somethingWentWrongError);
      });
    });

  group('getMedicationList', () {
    final medicationListJson = {
      'statusCode': 200,
      'message': 'Fetched successfully',
      'data': [
        {
          'id': 'med1',
          'child_id': 'child123',
          'medicineName': 'Paracetamol',
          'dosage': '5ml',
          'frequency': 'Twice a day',
          'timeOfDay': ['Morning', 'Evening'],
          'startDate': '2023-01-01',
          'endDate': '2023-01-10',
          'nextDosage': '2023-01-02T08:00:00',
        }
      ]
    };

    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: medicationListJson,
      ));

      final result = await repository.getMedicationList(childId);

      expect(result.isSuccess, true);
      expect(result.data, isA<GetMedicationsListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
      expect(result.data!.data.first.medicineName, 'Paracetamol');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch medications'},
      ));

      final result = await repository.getMedicationList(childId);

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch medications');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getMedicationList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getMedicationList(childId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getMedicationList(childId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('getFrequencyList', () {
    final mockFrequencyListJson = {
      'statusCode': 200,
      'message': 'Fetched successfully',
      'data': [
        {'label': 'Once a day', 'frequencyId': 'freq_1'},
        {'label': 'Twice a day', 'frequencyId': 'freq_2'},
      ],
    };

    test('returns success on 200 response', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: mockFrequencyListJson,
      ));

      final result = await repository.getFrequencyList();

      expect(result.isSuccess, true);
      expect(result.data, isA<FrequencyListResModel>());
      expect(result.data!.statusCode, 200);
      expect(result.data!.message, 'Fetched successfully');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Failed to fetch frequency list'},
      ));

      final result = await repository.getFrequencyList();

      expect(result.isError, true);
      expect(result.error, 'Failed to fetch frequency list');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getFrequencyList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Internal Server Error'},
        ),
      ));

      final result = await repository.getFrequencyList();

      expect(result.isError, true);
      expect(result.error, 'Internal Server Error');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.getFrequencyList();

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });


  group('getMedicationDetails', () {
    final mockResJson = {
      "statusCode": 200,
      "message": "Success",
      "data": {
        "id": "med1",
        "childId": "child123",
        "medicineName": "Paracetamol",
        "dosage": "5ml",
        "frequency": "Twice a day",
        "prescribedBy": "Dr. Smith",
        "reasonOfUse": "Fever",
        "timeOfDay": ["Morning", "Evening"],
        "startDate": "2023-01-01",
        "endDate": "2023-01-10",
        "nextDosage": "2023-01-02T08:00:00",
        "notes": "Take after food",
        "attachments": ["img1.png", "img2.png"]
      }
    };

    const mockMedicationId = 'med1';

    test('should return MedicationDetails model when response is 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: mockResJson,
      ));

      final result = await repository.getMedicationDetails(mockMedicationId);

      expect(result.isSuccess, true);
      final data = result.data!;
      expect(data.statusCode, 200);
      expect(data.message, 'Success');
      expect(data.data.id, 'med1');
      expect(data.data.medicineName, 'Paracetamol');
    });

    test('should return error message when response is not 200', () async {
      when(() => mockDio.get(any(), options: any(named: 'options'))).thenAnswer(
            (_) async => Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 404,
          data: {"message": "Medication not found"},
        ),
      );

      final result = await repository.getMedicationDetails(mockMedicationId);

      expect(result.isError, true);
      expect(result.error, "Medication not found");
    });

    test('should return connection timeout error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.getMedicationDetails(mockMedicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('should return error from DioException with message', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 500,
          data: {'message': 'Server error'},
        ),
      ));

      final result = await repository.getMedicationDetails(mockMedicationId);

      expect(result.isError, true);
      expect(result.error, 'Server error');
    });

    test('should return something went wrong on unknown error', () async {
      when(() => mockDio.get(any(), options: any(named: 'options')))
          .thenThrow(Exception('Some unexpected error'));

      final result = await repository.getMedicationDetails(mockMedicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });

  group('updateMedicationDetails', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.patch(any(), data: any(named: 'data'), options: any(named: 'options')))
          .thenAnswer((_) async => Response(requestOptions: RequestOptions(path: ''), statusCode: 200, data: updateResJson));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isSuccess, true);
      expect(result.data, isA<UpdateMedicationResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Update failed'},
      ));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isError, true);
      expect(result.error, 'Update failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.patch(
        any(),
        data: any(named: 'data'),
        options: any(named: 'options'),
      )).thenThrow(Exception('Unexpected error'));

      final result = await repository.updateMedicationDetails(updateReqModel, medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });


  });

  group('deleteMedication', () {
    test('returns success on 200 response', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
        data: commonRes,
      ));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isSuccess, true);
      expect(result.data, isA<CommonResModel>());
      expect(result.data!.message, 'Operation successful');
    });

    test('returns failure on non-200 with message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenAnswer((_) async => Response(
        requestOptions: RequestOptions(path: ''),
        statusCode: 400,
        data: {'message': 'Delete failed'},
      ));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isError, true);
      expect(result.error, 'Delete failed');
    });

    test('returns connection timeout error on timeout', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionTimeout,
      ));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.connectionTimeOutError);
    });

    test('returns network error on connection error', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
      ));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.networkError);
    });

    test('returns failure on DioException with response message', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(DioException(
        requestOptions: RequestOptions(path: ''),
        response: Response(
          requestOptions: RequestOptions(path: ''),
          statusCode: 400,
          data: {'message': 'Something went wrong'},
        ),
      ));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isError, true);
      expect(result.error, 'Something went wrong');
    });

    test('returns something went wrong on generic exception', () async {
      when(() => mockDio.delete(any(), options: any(named: 'options')))
          .thenThrow(Exception('Unexpected error'));

      final result = await repository.deleteMedication(medicationId);

      expect(result.isError, true);
      expect(result.error, ErrorMessages.somethingWentWrongError);
    });
  });




}
