import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_list_res_model.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_events.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_state.dart';
import 'package:child_health_story/features/medications/presentation/medications_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockMedicationsBloc extends MockBloc<MedicationsEvent, MedicationsState>
    implements MedicationsBloc {}

class FakeMedicationsEvent extends Fake implements MedicationsEvent {}

class FakeMedicationsState extends Fake implements MedicationsState {}

void main() {
  late MockMedicationsBloc mockBloc;

  setUpAll(() {
    registerFallbackValue(FakeMedicationsEvent());
    registerFallbackValue(FakeMedicationsState());
  });

  setUp(() {
    mockBloc = MockMedicationsBloc();
  });

  final mockList = [
    MedicationListData(
      id: "1",
      childId: "child-1",
      medicineName: 'Paracetamol',
      dosage: '5ml',
      frequency: 'Daily',
      timeOfDay: ['Morning'],
      startDate: '2023-01-01',
      endDate: '2023-01-10',
      nextDosage: '2023-01-05T08:00:00Z',
    ),
    MedicationListData(
      id: "2",
      childId: "child-1",
      medicineName: 'Amoxicillin',
      dosage: '10ml',
      frequency: 'Twice a day',
      timeOfDay: ['Morning', 'Evening'],
      startDate: '2023-01-15',
      endDate: '2023-01-25',
      nextDosage: '2023-01-16T08:00:00Z',
    ),
  ];
  final mappedList = [
    {
      "id": "1",
      "category": "Daily",
      "status": "Next Dosage: 05 Jan 2023 08:00 AM",
      "statusColor": const Color(0xFFFFF3E0),
      "title": "Paracetamol",
      "subtitle": "Start Date: 01 Jan 2023\nEnd Date: 10 Jan 2023",
    },
    {
      "id": "2",
      "category": "Twice a day",
      "status": "Next Dosage: 16 Jan 2023 08:00 AM",
      "statusColor": const Color(0xFFFFF3E0),
      "title": "Amoxicillin",
      "subtitle": "Start Date: 15 Jan 2023\nEnd Date: 25 Jan 2023",
    },
  ];

  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        routes: {
          PathConstants.addMedicationScreen: (_) =>
          const Scaffold(body: Text('Add Medication')),
          PathConstants.medicationDetailScreen: (_) =>
          const Scaffold(body: Text('Medication Detail')),
        },
        home: BlocProvider<MedicationsBloc>.value(
          value: mockBloc,
          child: const MedicationsListScreen(),
        ),
      ),
    );
  }

  testWidgets('should show loading indicator when state is MedicationsLoading', (WidgetTester tester) async {
    mockBloc = MockMedicationsBloc();

    when(() => mockBloc.state).thenReturn(MedicationsLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicationsLoading()));

    when(() => mockBloc.filteredMedicationsList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicationsBloc>.value(
          value: mockBloc,
          child: const MedicationsListScreen(),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows snackbar on MedicationsFailure', (tester) async {
    const errorMessage = 'Something went wrong';

    whenListen(
      mockBloc,
      Stream.fromIterable([MedicationsFailure(errorMessage)]),
      initialState: MedicationsInitial(),
    );

    when(() => mockBloc.filteredMedicationsList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicationsBloc>.value(
          value: mockBloc,
          child: const MedicationsListScreen(),
        ),
      ),
    );

    await tester.pump(); // Trigger the bloc listener
    await tester.pump(const Duration(seconds: 1));

    expect(find.text(errorMessage), findsOneWidget);
  });

  testWidgets('renders list of medications on MedicationListSuccess', (tester) async {

    // State returned by the bloc
    when(() => mockBloc.state).thenReturn(MedicationListSuccess(mockList));

    // Filtered list returned by the bloc's getter (must match what UI expects)
    when(() => mockBloc.filteredMedicationsList).thenReturn([
      {
        "id": "1",
        "category": "Daily",
        "status": "Next Dosage: 05 Jan 2023 08:00 AM",
        "statusColor": const Color(0xFFFFF3E0),
        "title": "Paracetamol",
        "subtitle": "Start Date: 01 Jan 2023\nEnd Date: 10 Jan 2023",
      },
      {
        "id": "2",
        "category": "Twice a day",
        "status": "Next Dosage: 16 Jan 2023 08:00 AM",
        "statusColor": const Color(0xFFFFF3E0),
        "title": "Amoxicillin",
        "subtitle": "Start Date: 15 Jan 2023\nEnd Date: 25 Jan 2023",
      },
    ]);

    await pumpScreen(tester);
    await tester.pumpAndSettle(); // Wait for UI rendering

    expect(find.text('Paracetamol'), findsOneWidget);
    expect(find.text('Amoxicillin'), findsOneWidget);
  });


  testWidgets('filters list when search query is entered', (tester) async {
    when(() => mockBloc.state).thenReturn(MedicationListSuccess(mockList));
    when(() => mockBloc.filteredMedicationsList).thenReturn(mappedList);

    await pumpScreen(tester);

    await tester.pumpAndSettle();
    expect(find.text('Paracetamol'), findsOneWidget);
    expect(find.text('Amoxicillin'), findsOneWidget);

    await tester.enterText(find.byType(TextField), 'Para');

    when(() => mockBloc.state).thenReturn(
      MedicationListSearchSuccess([mappedList.first]),
    );
    when(() => mockBloc.filteredMedicationsList).thenReturn([mappedList.first]);

    await tester.pumpAndSettle();

    // Only Paracetamol should be visible
    expect(find.text('Paracetamol'), findsOneWidget);
  });


}
