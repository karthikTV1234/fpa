import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/medications/presentation/add_medication_screen.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_events.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_state.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockMedicationsBloc extends MockBloc<MedicationsEvent, MedicationsState> implements MedicationsBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeMedicationsEvent extends Fake implements MedicationsEvent {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeMedicationsState extends Fake implements MedicationsState {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockMedicationsBloc mockMedicationsBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeMedicationsEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeMedicationsState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockMedicationsBloc = MockMedicationsBloc();

    when(() => mockMedicationsBloc.state).thenReturn(MedicationsInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockMedicationsBloc.isUIUpdated).thenReturn(true);
    when(() => mockMedicationsBloc.frequencyLabelList).thenReturn([]);
    when(() => mockMedicationsBloc.frequencyList).thenReturn([]);
    when(() => mockMedicationsBloc.selectedTimesPerDay).thenReturn([]);
    when(() => mockMedicationsBloc.hospitalList).thenReturn([]);
    when(() => mockMedicationsBloc.doctorList).thenReturn([]);
    when(() => mockMedicationsBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockMedicationsBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<MedicationsBloc>.value(value: mockMedicationsBloc),
        ],
        child: const AddMedicationScreen(),
      ),
      routes: {
        PathConstants.medicationListScreen: (_) =>
        const Scaffold(body: Text('Medications List')),
      },
    );
  }

  testWidgets(
    'renders all essential form fields and Save button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.medicationNameLabel), findsOneWidget);
      expect(find.text(AppStrings.reasonForUsageLabel), findsOneWidget);
      expect(find.text(AppStrings.dosageLabel), findsOneWidget);
      expect(find.text(AppStrings.frequencyLabel), findsOneWidget);
      expect(find.text(AppStrings.startDateLabel), findsOneWidget);
      expect(find.text(AppStrings.endDateLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.notesLabel), findsOneWidget);
      expect(find.text(AppStrings.saveText), findsOneWidget);
    },
  );

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pumpAndSettle();

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.medicationNameRequired), findsOneWidget);
    expect(find.text(ValidationMessages.reasonForUsageRequired), findsOneWidget);
    expect(find.text(ValidationMessages.dosageRequired), findsOneWidget);
    expect(find.text(ValidationMessages.frequencyRequired), findsOneWidget);
    expect(find.text(ValidationMessages.startDateRequired), findsOneWidget);
    expect(find.text(ValidationMessages.endDateRequired), findsOneWidget);
    expect(find.text(ValidationMessages.hospitalRequired), findsOneWidget);
    expect(find.text(ValidationMessages.doctorRequired), findsOneWidget);
  });

  testWidgets('shows snackbar when medication add fails', (tester) async {
    whenListen(
      mockMedicationsBloc,
      Stream.fromIterable([
        MedicationsLoading(),
        MedicationsFailure('Failed to save medication')
      ]),
      initialState: MedicationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // begin listening
    await tester.pump(); // show snackbar

    expect(find.text('Failed to save medication'), findsOneWidget);
  });

  testWidgets('navigates to medication list screen on success', (tester) async {
    whenListen(
      mockMedicationsBloc,
      Stream.fromIterable([
        MedicationsLoading(),
        MedicationsSuccess(message: "Added"),
      ]),
      initialState: MedicationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    // Fill form fields
    await tester.enterText(find.byType(TextFormField).at(0), 'Paracetamol'); // Medication Name
    await tester.enterText(find.byType(TextFormField).at(1), 'fever'); // Reason for Usage
    await tester.enterText(find.byType(TextFormField).at(2), '200mg'); // Dosage
    await tester.enterText(find.byType(TextFormField).at(2), '25-07-2025');
    await tester.enterText(find.byType(TextFormField).at(2), '20-07-2025');

    final saveButton = find.text(AppStrings.saveText);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton, warnIfMissed: false);
    await tester.pumpAndSettle();

    expect(find.text('Medications List'), findsOneWidget);
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
