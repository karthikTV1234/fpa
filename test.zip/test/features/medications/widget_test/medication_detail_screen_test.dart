import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_detail_res_model.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_events.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_state.dart';
import 'package:child_health_story/features/medications/presentation/medication_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';

class MockMedicationsBloc extends Mock implements MedicationsBloc {}
class MockNavigatorObserver extends Mock implements NavigatorObserver {}
class FakeRoute extends Fake implements Route<dynamic> {}

void main() {
  late MockMedicationsBloc mockBloc;
  const childId = 'child123';
  const medicationId = 'med123';
  setUpAll(() {
    registerFallbackValue(DeleteMedicationEvent(medicationId: medicationId));
    registerFallbackValue(FetchMedicationByIdEvent(medicationId: medicationId));
    registerFallbackValue(FakeRoute());
  });

  setUp(() {
    mockBloc = MockMedicationsBloc();
    when(() => mockBloc.isUIUpdated).thenReturn(true);

    final testState = MedicationByIdSuccess(
      MedicationDetailData(medicineName: 'Paracetamol'),
    );

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
  });

  final mockData = MedicationDetailData(
    medicineName: 'Paracetamol',
    dosage: '5ml',
    reasonOfUse: 'Fever',
    frequencyLabel: 'Twice a day',
    doctorName: 'Dr. Smith',
    hospitalName: 'City Hospital',
  );

  testWidgets(
    'renders medication details when MedicationByIdSuccess is emitted',
        (WidgetTester tester) async {
      mockBloc = MockMedicationsBloc();

      final testState = MedicationByIdSuccess(mockData);

      // Stub the state and stream
      when(() => mockBloc.state).thenReturn(testState);
      when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));

      // Stub the extra fields used by the widget
      when(() => mockBloc.isUIUpdated).thenReturn(true);
      when(() => mockBloc.medicationData).thenReturn(mockData);
      when(() => mockBloc.add(any())).thenReturn(null);

      await tester.pumpWidget(
        MaterialApp(
          home: BlocProvider<MedicationsBloc>.value(
            value: mockBloc,
            child: const MedicationDetailScreen(medicationId: medicationId),
          ),
        ),
      );

      await tester.pumpAndSettle();

      expect(find.text('Paracetamol'), findsOneWidget);
      expect(find.text('5ml'), findsOneWidget);
      expect(find.text('Fever'), findsOneWidget);
      expect(find.text('Twice a day'), findsOneWidget);
      expect(find.text('Dr. Smith'), findsOneWidget);
      expect(find.text('City Hospital'), findsOneWidget);
    },
  );

  testWidgets('should show loading indicator when state is MedicationsLoading', (WidgetTester tester) async {
    mockBloc = MockMedicationsBloc();

    when(() => mockBloc.state).thenReturn(MedicationsLoading());
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicationsLoading()));

    // Stub required getters to avoid null errors
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.medicationData).thenReturn(null);
    when(() => mockBloc.filteredMedicationsList).thenReturn([]);

    await tester.pumpWidget(
      MaterialApp(
        home: BlocProvider<MedicationsBloc>.value(
          value: mockBloc,
          child: const MedicationDetailScreen(medicationId: medicationId),
        ),
      ),
    );

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });


  testWidgets('should show error message when state is failure', (WidgetTester tester) async {
    mockBloc = MockMedicationsBloc();

    const errorMessage = 'Something went wrong';

    when(() => mockBloc.state).thenReturn(MedicationsFailure(errorMessage));
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(MedicationsFailure(errorMessage)));

    // Mock the additional getters used by the widget
    when(() => mockBloc.isUIUpdated).thenReturn(false);
    when(() => mockBloc.medicationData).thenReturn(null);

    await tester.pumpWidget(
      MaterialApp(
        home: ScaffoldMessenger(
          child: Scaffold(
            body: BlocProvider<MedicationsBloc>.value(
              value: mockBloc,
              child: const MedicationDetailScreen(medicationId: medicationId),
            ),
          ),
        ),
      ),
    );

    await tester.pump();  // start frame
    await tester.pump(const Duration(seconds: 1));  // allow snackbar animation

    expect(find.byType(SnackBar), findsOneWidget);
    expect(find.text(errorMessage), findsOneWidget);
  });


  testWidgets('navigates to edit medication screen on edit button tap', (WidgetTester tester) async {
    mockBloc = MockMedicationsBloc();

    final testState = MedicationByIdSuccess(mockData);

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));
    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.medicationData).thenReturn(mockData);

    final mockObserver = MockNavigatorObserver();

    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: (settings) {
          if (settings.name == PathConstants.editMedicationScreen) {
            return MaterialPageRoute(
              builder: (_) => const Scaffold(body: Text('Edit Medication Screen')),
            );
          }
          return null;
        },
        home: BlocProvider<MedicationsBloc>.value(
          value: mockBloc,
          child: const MedicationDetailScreen(medicationId: medicationId),
        ),
        navigatorObservers: [mockObserver],
      ),
    );

    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);

    reset(mockObserver);

    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();

    verify(() => mockObserver.didPush(any(), any())).called(1);
  });


  testWidgets('should display file attachments if available', (tester) async {
    final mockBloc = MockMedicationsBloc();

    final medicationDetail = MedicationDetailData(
      medicineName: 'Paracetamol',
      attachments: ['https://example.com/uploads/report1.pdf'],
    );

    final testState = MedicationByIdSuccess(medicationDetail);

    when(() => mockBloc.state).thenReturn(testState);
    when(() => mockBloc.stream).thenAnswer((_) => Stream.value(testState));

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.medicationData).thenReturn(medicationDetail); // <-- IMPORTANT

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: BlocProvider<MedicationsBloc>.value(
            value: mockBloc,
            child: SizedBox(
              height: 200,  // fixed height for ListView to render attachments
              child: MedicationDetailScreen(medicationId: 'med123'),
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.textContaining('pdf'), findsOneWidget);
  });

  testWidgets('delete medications and confirm deletion',
          (WidgetTester tester) async {
        final mockObserver = MockNavigatorObserver();

        await tester.pumpWidget(
          MaterialApp(
            navigatorObservers: [mockObserver],
            routes: {
              PathConstants.medicationListScreen: (_) => const Scaffold(body: Text('Medications List')),
            },
            home: BlocProvider<MedicationsBloc>.value(
              value: mockBloc,
              child: const MedicationDetailScreen(medicationId: medicationId),
            ),
          ),
        );

        final deleteButton = find.text(AppStrings.deleteBtnText);
        await tester.ensureVisible(deleteButton);
        await tester.tap(deleteButton, warnIfMissed: false);
        await tester.pumpAndSettle();

        expect(find.text(AppStrings.deleteMedicationTitle), findsOneWidget);
        expect(find.text(AppStrings.deleteMedicationConfirmationMessage), findsOneWidget);

        // Tap Yes button to confirm delete
        final yesButton = find.text(AppStrings.deleteBtnText);
        expect(yesButton, findsWidgets);
        await tester.tap(yesButton.last);
        await tester.pump();

        verify(() => mockBloc.add(DeleteMedicationEvent(medicationId: medicationId))).called(1);

        final successState = MedicationsSuccess(message: 'Medication deleted successfully');
        when(() => mockBloc.state).thenReturn(successState);
        when(() => mockBloc.stream).thenAnswer((_) => Stream.value(successState));

        mockBloc.emit(successState);
        await tester.pumpAndSettle();
      });


}
