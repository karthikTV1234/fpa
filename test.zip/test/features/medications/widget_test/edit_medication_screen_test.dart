import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_detail_res_model.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_events.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_state.dart';
import 'package:child_health_story/features/medications/presentation/edit_medication_screen.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mocktail/mocktail.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class MockMedicationsBloc extends MockBloc<MedicationsEvent, MedicationsState> implements MedicationsBloc {}
class MockDoctorBloc extends MockBloc<DoctorEvent, DoctorState> implements DoctorBloc {}
class MockHospitalBloc extends MockBloc<HospitalEvent, HospitalState> implements HospitalBloc {}

class FakeMedicationsEvent extends Fake implements MedicationsEvent {}
class FakeDoctorEvent extends Fake implements DoctorEvent {}
class FakeHospitalEvent extends Fake implements HospitalEvent {}
class FakeMedicationsState extends Fake implements MedicationsState {}
class FakeDoctorState extends Fake implements DoctorState {}
class FakeHospitalState extends Fake implements HospitalState {}

void main() {
  late MockMedicationsBloc mockBloc;
  late MockDoctorBloc mockDoctorBloc;
  late MockHospitalBloc mockHospitalBloc;

  setUpAll(() {
    registerFallbackValue(FakeMedicationsEvent());
    registerFallbackValue(FakeDoctorEvent());
    registerFallbackValue(FakeHospitalEvent());
    registerFallbackValue(FakeMedicationsState());
    registerFallbackValue(FakeDoctorState());
    registerFallbackValue(FakeHospitalState());
  });

  setUp(() {
    mockHospitalBloc = MockHospitalBloc();
    mockDoctorBloc = MockDoctorBloc();
    mockBloc = MockMedicationsBloc();

    when(() => mockBloc.state).thenReturn(MedicationsInitial());
    when(() => mockDoctorBloc.state).thenReturn(DoctorInitial());
    when(() => mockHospitalBloc.state).thenReturn(HospitalInitial());

    when(() => mockBloc.isUIUpdated).thenReturn(true);
    when(() => mockBloc.frequencyLabelList).thenReturn([]);
    when(() => mockBloc.frequencyList).thenReturn([]);
    when(() => mockBloc.selectedTimesPerDay).thenReturn([]);
    when(() => mockBloc.hospitalList).thenReturn([]);
    when(() => mockBloc.doctorList).thenReturn([]);
    when(() => mockBloc.newAttachments).thenReturn([]);
  });

  tearDown(() {
    mockBloc.close();
    mockDoctorBloc.close();
    mockHospitalBloc.close();
  });

  final detailData = MedicationDetailData(
      id: 'med_123',
      medicineName: 'Paracetamol',
      dosage: '5ml',
      frequencyLabel: 'Daily Once',
      timeOfDay: ['Morning'],
      startDate: '2023-01-01',
      endDate: '2023-01-10',
      doctorName: 'Dr. John',
      reasonOfUse: 'Fever',
      notes: ''
  );

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: MultiBlocProvider(
        providers: [
          BlocProvider<HospitalBloc>.value(value: mockHospitalBloc),
          BlocProvider<DoctorBloc>.value(value: mockDoctorBloc),
          BlocProvider<MedicationsBloc>.value(value: mockBloc),
        ],
        child:  EditMedicationScreen(medicationDetailData: detailData),
      ),
      routes: {
        PathConstants.medicationDetailScreen: (_) =>
        const Scaffold(body: Text('Medication Detail')),
      },
    );
  }

  testWidgets(
    'renders all essential form fields and Update button',
        (tester) async {
      await tester.pumpWidget(createWidgetUnderTest());

      expect(find.text(AppStrings.medicationNameLabel), findsOneWidget);
      expect(find.text(AppStrings.reasonForUsageLabel), findsOneWidget);
      expect(find.text(AppStrings.dosageLabel), findsOneWidget);
      expect(find.text(AppStrings.frequencyLabel), findsOneWidget);
      expect(find.text(AppStrings.startDateLabel), findsOneWidget);
      expect(find.text(AppStrings.endDateLabel), findsOneWidget);
      expect(find.text(AppStrings.hospitalLabel), findsOneWidget);
      expect(find.text(AppStrings.doctorLabel), findsOneWidget);
      expect(find.text(AppStrings.notesLabel), findsOneWidget);
      expect(find.text(AppStrings.updateTxt), findsOneWidget);
    },
  );

  testWidgets('prepopulates fields with existing data',
          (WidgetTester tester) async {
        await tester.pumpWidget(createWidgetUnderTest());
        await tester.pumpAndSettle();

        expect(find.widgetWithText(TextFormField, 'Paracetamol'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, 'Fever'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '5ml'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '2023-01-01'), findsOneWidget);
        expect(find.widgetWithText(TextFormField, '2023-01-10'), findsOneWidget);
 });

  testWidgets('shows validation errors when required fields are empty', (tester) async {
    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), '');
    await tester.enterText(find.byType(TextFormField).at(1), '');
    await tester.enterText(find.byType(TextFormField).at(2), '');

    final saveButton = find.text(AppStrings.updateTxt);
    await tester.ensureVisible(saveButton);
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(find.text(ValidationMessages.medicationNameRequired), findsOneWidget);
    expect(find.text(ValidationMessages.reasonForUsageRequired), findsOneWidget);
    expect(find.text(ValidationMessages.dosageRequired), findsOneWidget);
    expect(find.text(ValidationMessages.frequencyRequired), findsOneWidget);
    expect(find.text(ValidationMessages.hospitalRequired), findsOneWidget);
    expect(find.text(ValidationMessages.doctorRequired), findsOneWidget);
  });

  testWidgets('shows snackbar when medication update fails', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        MedicationsLoading(),
        MedicationsFailure('Failed to update medication')
      ]),
      initialState: MedicationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());
    await tester.pump(); // begin listening
    await tester.pump(); // show snackbar

    expect(find.text('Failed to update medication'), findsOneWidget);
  });

  testWidgets('pops with true on MedicationsSuccess', (tester) async {
    whenListen(
      mockBloc,
      Stream.fromIterable([
        MedicationsLoading(),
        MedicationsSuccess(message: 'Updated successfully'),
      ]),
      initialState: MedicationsInitial(),
    );

    await tester.pumpWidget(createWidgetUnderTest());

    await tester.pumpAndSettle();

    expect(find.byType(EditMedicationScreen), findsNothing);
  });

  testWidgets('shows error if file size exceeds 10 MB', (tester) async {
    final oversizedXFile = XFile('/dummy/path/big_file.pdf');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [oversizedXFile],
        onBuildCallback: (ctx) async {
          CustomSnackBar(
            context: ctx,
            message: AppStrings.fileSizeLimit(10),
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('File size must be less than 10MB.'), findsWidgets);
  });

  testWidgets('shows file type error when selecting unsupported file', (tester) async {
    final unsupportedFile = XFile('/dummy/path/bad.exe');

    await tester.pumpWidget(
      TestAttachmentWrapper(
        filesToSend: [unsupportedFile],
        onBuildCallback: (ctx) {
          CustomSnackBar(
            context: ctx,
            message: 'Only ${AppStrings.supportedFileTypes.join(', ').toUpperCase()} files are allowed.',
            messageType: AppStrings.failure,
          ).show();
        },
      ),
    );

    await tester.pumpAndSettle();
    expect(find.textContaining('Only'), findsOneWidget);
  });

  testWidgets('FileAttachmentsWidget should display newly selected file', (WidgetTester tester) async {
    final dummyFile = XFile('path/to/file.jpg');

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FileAttachmentsWidget(
            maxFileSizeMB: AppStrings.maxFileSize,
            supportedTypes: AppStrings.supportedFileTypes,
            existingAttachments: const [],
            selectedNewFiles: [dummyFile],
            onFileSelected: (_) {},
            onFileDeleted: (_) {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // Assert that the file name appears in the UI
    expect(find.textContaining('file.jpg'), findsOneWidget);
  });

}

class TestAttachmentWrapper extends StatelessWidget {
  final List<XFile> filesToSend;
  final void Function(BuildContext) onBuildCallback;

  const TestAttachmentWrapper({
    Key? key,
    required this.filesToSend,
    required this.onBuildCallback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              onBuildCallback(ctx);
            });
            return FileAttachmentsWidget(
              maxFileSizeMB: AppStrings.maxFileSize,
              supportedTypes: AppStrings.supportedFileTypes,
              existingAttachments: const [],
              selectedNewFiles: filesToSend,
              onFileSelected: (_) {},
              onFileDeleted: (_) {},
            );
          },
        ),
      ),
    );
  }

}
