import 'package:bloc_test/bloc_test.dart';
import 'package:child_health_story/core/utils/result.dart';
import 'package:child_health_story/features/medications/data/model/request/add_medication_req_model.dart';
import 'package:child_health_story/features/medications/data/model/request/edit_medication_req_model.dart';
import 'package:child_health_story/features/medications/data/model/response/add_medication_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/edit_medication_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/frequency_list_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_detail_res_model.dart';
import 'package:child_health_story/features/medications/data/model/response/medication_list_res_model.dart';
import 'package:child_health_story/features/medications/data/repository/medications_repository.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_events.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_state.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockMedicationsRepository extends Mock implements MedicationsRepository {}
class FakeAddMedicationReqModel extends Fake implements AddMedicationReqModel {}
class FakeUpdateMedicationReqModel extends Fake implements UpdateMedicationReqModel {}

void main() {
  late MedicationsBloc bloc;
  late MockMedicationsRepository mockRepository;
  setUpAll(() {
    registerFallbackValue(FakeAddMedicationReqModel());
    registerFallbackValue(FakeUpdateMedicationReqModel());
  });
  setUp(() {
    mockRepository = MockMedicationsRepository();
    bloc = MedicationsBloc(medicationsRepository: mockRepository);
  });
  const childId = 'child123';
  const medicationId = 'med123';
  final addMedicationReq = AddMedicationReqModel(
    childId: 'child123',
    medicineName: 'Paracetamol',
    dosage: '5ml',
    frequency: 'Twice a day',
    timeOfDay: ['Morning', 'Night'],
    startDate: '2025-07-26',
    endDate: '2025-08-02',
    prescribedBy: 'Dr. Smith',
    reasonOfUse: 'Fever',
    notes: 'Take after food',
    attachments: [],
  );
  final addMedicationRes = AddMedicationResModel(
    statusCode: 200,
    message: "Medication added successfully",
    data: MedicationAddResData(
      id: 'med_123',
      childId: childId,
      medicineName: 'Paracetamol',
      dosage: '5ml',
      frequency: 'Twice a day',
      timeOfDay: ['Morning', 'Night'],
      startDate: '2025-07-26',
      endDate: '2025-08-02',
      prescribedBy: 'Dr. Smith',
      reasonOfUse: 'Fever',
      notes: 'Take after food',
      isActive: true,
      createdAt: '2025-07-26T00:00:00.000Z',
      updatedAt: '2025-07-26T00:00:00.000Z',
      attachments: [],
    ),
  );
  final medDetailModel = GetMedicationsDetailResModel(
    statusCode: 200,
    message: 'Success',
    data: MedicationDetailData(
        id: 'med_123',
        medicineName: 'Paracetamol',
        dosage: '5ml',
        frequencyLabel: 'Once',
        timeOfDay: ['Morning'],
        startDate: '2023-01-01',
        endDate: '2023-01-10',
        doctorName: 'Dr. John',
        reasonOfUse: 'Fever',
        notes: ''
    ),
  );
  final updateReqModel = UpdateMedicationReqModel(
    medicineName: 'Paracetamol',
    dosage: '5ml',
    frequency: 'Once a day',
    timeOfDay: ['Morning'],
    startDate: '2023-01-01',
    endDate: '2023-01-10',
    prescribedBy: 'Dr. John',
    reasonOfUse: 'Fever',
    notes: 'No side effects',
  );

  final updateResModel = UpdateMedicationResModel(
    statusCode: 200,
    message: 'Operation successful',
    data: MedicationUpdateResData(
      id: 'med_123',
      childId: childId,
      medicineName: 'Paracetamol',
      dosage: '5ml',
      frequency: 'Once a day',
      timeOfDay: ['Morning'],
      startDate: '2023-01-01',
      endDate: '2023-01-10',
      prescribedBy: 'Dr. John',
      reasonOfUse: 'Fever',
      notes: 'No side effects',
      isActive: true,
      createdAt: '2023-01-01T00:00:00.000Z',
      updatedAt: '2023-01-01T00:00:00.000Z',
      attachments: ['url1', 'url2'],
    ),
  );

  final commonRes = CommonResModel(
    statusCode: 200,
    message: 'Operation successful'
  );

  group('AddMedicationEvent', () {
    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsSuccess] when repository returns success',
      build: () {
        when(() => mockRepository.addMedication(addMedicationReq))
            .thenAnswer((_) async => Result.success(addMedicationRes));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddMedicationEvent(addMedicationReqModel: addMedicationReq)),
      expect: () => [
        MedicationsLoading(),
        MedicationsSuccess(message: 'Medication added successfully'),
      ],
      verify: (_) {
        verify(() => mockRepository.addMedication(addMedicationReq)).called(1);
      },
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] when repository returns failure',
      build: () {
        when(() => mockRepository.addMedication(addMedicationReq))
            .thenAnswer((_) async => Result.failure('Failed to add medication'));
        return bloc;
      },
      act: (bloc) =>
          bloc.add(AddMedicationEvent(addMedicationReqModel: addMedicationReq)),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Failed to add medication'),
      ],
      verify: (_) {
        verify(() => mockRepository.addMedication(addMedicationReq)).called(1);
      },
    );
  });

  group('FetchMedicationsListEvent', () {
    final listResModel = GetMedicationsListResModel(
      statusCode: 200,
      message: 'Fetched successfully',
      data: [],
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationListSuccess] on success',
      build: () {
        when(() => mockRepository.getMedicationList(childId))
            .thenAnswer((_) async => Result.success(listResModel));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicationsListEvent(childId: childId)),
      expect: () => [
        MedicationsLoading(),
        MedicationListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getMedicationList(childId)).called(1),
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationListSuccess] with non-empty list',
      build: () {
        final medicationList = [
          MedicationListData(
            id: 'med_001',
            childId: childId,
            medicineName: 'Paracetamol',
            dosage: '5ml',
            frequency: 'Twice a day',
            timeOfDay: ['Morning', 'Night'],
            startDate: '2025-08-01',
            endDate: '2025-08-07',
            nextDosage: '2025-08-04T09:00:00Z',
          ),
          MedicationListData(
            id: 'med_002',
            childId: childId,
            medicineName: 'Ibuprofen',
            dosage: '10ml',
            frequency: 'Once a day',
            timeOfDay: ['Evening'],
            startDate: '2025-07-28',
            endDate: '2025-08-05',
            nextDosage: '2025-08-04T18:00:00Z',
          ),
        ];

        final listResModel = GetMedicationsListResModel(
          statusCode: 200,
          message: 'Fetched successfully',
          data: medicationList,
        );

        when(() => mockRepository.getMedicationList(childId))
            .thenAnswer((_) async => Result.success(listResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicationsListEvent(childId: childId)),
      expect: () => [
        MedicationsLoading(),
        isA<MedicationListSuccess>().having(
              (s) => s.medications,
          'medications',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getMedicationList(childId)).called(1),
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] on failure',
      build: () {
        when(() => mockRepository.getMedicationList(childId))
            .thenAnswer((_) async => Result.failure('Failed to fetch'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicationsListEvent(childId: childId)),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Failed to fetch'),
      ],
    );
  });

  group('FetchFrequencyListEvent', () {
    final freqResModel = FrequencyListResModel(
      statusCode: 200,
      message: 'Fetched successfully',
      data: [],
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, FrequencyListSuccess] on success',
      build: () {
        when(() => mockRepository.getFrequencyList())
            .thenAnswer((_) async => Result.success(freqResModel));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchFrequencyListEvent()),
      expect: () => [
        MedicationsLoading(),
        FrequencyListSuccess([]),
      ],
      verify: (_) => verify(() => mockRepository.getFrequencyList()).called(1),
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, FrequencyListSuccess] with non-empty list',
      build: () {
        final frequencyList = [
          FrequencyListData(label: 'Once a day', frequencyId: 'freq_1'),
          FrequencyListData(label: 'Twice a day', frequencyId: 'freq_2'),
          FrequencyListData(label: 'Thrice a day', frequencyId: 'freq_3'),
        ];

        final freqResModel = FrequencyListResModel(
          statusCode: 200,
          message: 'Fetched successfully',
          data: frequencyList,
        );

        when(() => mockRepository.getFrequencyList())
            .thenAnswer((_) async => Result.success(freqResModel));

        return bloc;
      },
      act: (bloc) => bloc.add(FetchFrequencyListEvent()),
      expect: () => [
        MedicationsLoading(),
        isA<FrequencyListSuccess>().having(
              (s) => s.frequencyList,
          'frequencies',
          isNotEmpty,
        ),
      ],
      verify: (_) => verify(() => mockRepository.getFrequencyList()).called(1),
    );


    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] on failure',
      build: () {
        when(() => mockRepository.getFrequencyList())
            .thenAnswer((_) async => Result.failure('Error occurred'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchFrequencyListEvent()),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Error occurred'),
      ],
    );
  });

  group('FetchMedicationByIdEvent', () {

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationByIdSuccess] on success',
      build: () {
        when(() => mockRepository.getMedicationDetails(medicationId))
            .thenAnswer((_) async => Result.success(medDetailModel));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicationByIdEvent(medicationId: medicationId)),
      expect: () => [
        MedicationsLoading(),
        MedicationByIdSuccess(medDetailModel.data),
      ],
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] on failure',
      build: () {
        when(() => mockRepository.getMedicationDetails(medicationId))
            .thenAnswer((_) async => Result.failure('Not found'));
        return bloc;
      },
      act: (bloc) => bloc.add(FetchMedicationByIdEvent(medicationId: medicationId)),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Not found'),
      ],
    );
  });

  group('UpdateMedicationEvent', () {
    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsSuccess] on update success',
      build: () {
        when(() => mockRepository.updateMedicationDetails(updateReqModel, medicationId))
            .thenAnswer((_) async => Result.success(updateResModel));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateMedicationEvent(medicationId: medicationId,updateMedicationReqModel: updateReqModel)),
      expect: () => [
        MedicationsLoading(),
        MedicationsSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] on update failure',
      build: () {
        when(() => mockRepository.updateMedicationDetails(updateReqModel, medicationId))
            .thenAnswer((_) async => Result.failure('Update failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(UpdateMedicationEvent(medicationId: medicationId,updateMedicationReqModel: updateReqModel)),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Update failed'),
      ],
    );
  });

  group('DeleteMedicationEvent', () {
    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsSuccess] on delete success',
      build: () {
        when(() => mockRepository.deleteMedication(medicationId))
            .thenAnswer((_) async => Result.success(commonRes));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteMedicationEvent(medicationId: medicationId)),
      expect: () => [
        MedicationsLoading(),
        MedicationsSuccess(message: 'Operation successful'),
      ],
    );

    blocTest<MedicationsBloc, MedicationsState>(
      'emits [MedicationsLoading, MedicationsFailure] on delete failure',
      build: () {
        when(() => mockRepository.deleteMedication(medicationId))
            .thenAnswer((_) async => Result.failure('Delete failed'));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteMedicationEvent(medicationId: medicationId)),
      expect: () => [
        MedicationsLoading(),
        MedicationsFailure('Delete failed'),
      ],
    );
  });



}
