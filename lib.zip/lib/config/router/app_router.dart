import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/auth/presentation/bloc/login_bloc.dart';
import 'package:child_health_story/features/auth/presentation/bloc/forgot_password_bloc.dart';
import 'package:child_health_story/features/auth/presentation/change_password_screen.dart';
import 'package:child_health_story/features/auth/presentation/forgot_password.dart';
import 'package:child_health_story/features/auth/data/repository/forgot_password_repository.dart';
import 'package:child_health_story/features/auth/presentation/login_screen.dart';
import 'package:child_health_story/features/auth/presentation/login_with_otp.dart';
import 'package:child_health_story/features/auth/presentation/otp_screen.dart';
import 'package:child_health_story/features/care_taker/data/repository/care_taker_repository.dart';
import 'package:child_health_story/features/care_taker/presentation/add_care_taker_screen.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/care_takers_screen.dart';
import 'package:child_health_story/features/care_taker/presentation/caretaker_details_screen.dart';
import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/data/repository/child_repository.dart';
import 'package:child_health_story/features/child_profile/presentation/screens/add_child.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/auth/presentation/sign_up_page.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_detail_res_model.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_detail_screen.dart';
import 'package:child_health_story/features/doctor_visits/data/repository/doctor_visit_repository.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_form_screen.dart';
import 'package:child_health_story/features/doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_list_screen.dart';
import 'package:child_health_story/features/health_tracker/data/repository/health_tracker_repository.dart';
import 'package:child_health_story/features/health_tracker/presentation/add_health_tracker_screen.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/edit_health_tracker_screen.dart';
import 'package:child_health_story/features/health_tracker/presentation/health_tracker_detail_screen.dart';
import 'package:child_health_story/features/health_tracker/presentation/health_tracker_list_screen.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/repository/medical_condition_repository.dart';
import 'package:child_health_story/features/medical_conditions/presentation/add_medical_condition_screen.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/edit_medical_condition_screen.dart';
import 'package:child_health_story/features/medical_conditions/presentation/medical_condition_detail_screen.dart';
import 'package:child_health_story/features/vaccination/data/repository/vaccinations_repository.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/edit_vaccination.dart';
import 'package:child_health_story/features/vaccination/presentation/vaccination_detail.dart';
import 'package:child_health_story/features/vaccination/presentation/vaccination_list_screen.dart';
import '../../features/child_profile/data/model/child_detail_model.dart';
import 'package:child_health_story/features/health_records/health_records.dart';
import 'package:child_health_story/features/home/home_screen.dart';
import 'package:child_health_story/features/init/splash_screen.dart';
import 'package:child_health_story/features/medications/data/repository/medications_repository.dart';
import 'package:child_health_story/features/medications/presentation/add_medication_screen.dart';
import 'package:child_health_story/features/medications/presentation/medication_detail_screen.dart';
import 'package:child_health_story/features/medications/presentation/medications_screen.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/medical_conditions_list_screen.dart';
import 'package:child_health_story/features/vaccination/presentation/add_vaccination.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../features/auth/data/repository/auth_repository.dart';
import '../../features/auth/data/repository/firebase_auth_repository.dart';
import '../../features/auth/presentation/args/otp_screen_args.dart';
import '../../features/auth/presentation/bloc/login_otp_bloc.dart';
import '../../features/auth/presentation/bloc/sign_up/sing_up_bloc.dart';
import '../../features/child_profile/presentation/screens/child_list_screen.dart';
import '../../features/child_profile/presentation/screens/child_profile_detail_screen.dart';
import '../../features/child_profile/presentation/screens/edit_child_profile.dart';
import '../../features/doctor/data/repository/doctor_repository.dart';
import '../../features/doctor/presentation/bloc/doctor_bloc.dart';
import '../../features/health_tracker/data/models/response/health_tracker_detail_res_model.dart';
import '../../features/hospital/data/repository/hospital_repository.dart';
import '../../features/hospital/presentation/bloc/hospital_bloc.dart';
import '../../features/medications/data/model/response/medication_detail_res_model.dart';
import '../../features/medications/presentation/edit_medication_screen.dart';
import '../../features/vaccination/data/models/response/vaccination_detail_res_model.dart';


class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case PathConstants.initScreen:
        return MaterialPageRoute(builder: (_) => SplashScreen());
      case PathConstants.signUpScreen:
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider(
                create: (_) => SignUpBloc(authRepository: AuthRepository()),
              ),
              BlocProvider(
                create: (_) => ChildBloc(childRepository: ChildRepository()),
              ),
            ],
            child: SignUpScreen(),
          ),
        );
      case PathConstants.loginScreen:
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider(
                create: (_) => LoginBloc(authRepository: AuthRepository()),
              ),
              BlocProvider(
                create: (_) => ChildBloc(childRepository: ChildRepository()),
              ),
            ],
            child: LoginScreen(),
          ),
        );
      case PathConstants.forgotPasswordScreen:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => ForgotPasswordBloc(forgotPasswordRepository: ForgotPasswordRepository()),
            child:  ForgotPasswordScreen(),
          ),
        );
      case PathConstants.otpScreen:
        final args = settings.arguments as OtpScreenArgs;
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider<LoginOtpBloc>(
                create: (_) => LoginOtpBloc(
                  firebaseAuthRepository: FirebaseAuthRepository(),
                  authRepository: AuthRepository(),
                ),
              ),
              BlocProvider<ForgotPasswordBloc>(
                create: (_) => ForgotPasswordBloc(
                  forgotPasswordRepository: ForgotPasswordRepository(),
                ),
              ),
            ],
            child: OtpScreen(
              firebaseVerificationId: args.verificationId,
              isFromForgotPassword: args.isFromForgotPassword,
              phoneNumber: args.phoneNumber,
              countryCode: args.countryCode,
              email: args.email,
            ),
          ),
        );
      case PathConstants.loginWithOtp:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => LoginOtpBloc(
                firebaseAuthRepository: FirebaseAuthRepository(),
              authRepository: AuthRepository(),
            ),
            child: const LoginWithOtp(),
          ),
        );
      case PathConstants.changePasswordScreen:
        return MaterialPageRoute(
          settings: settings,
          builder: (context) => BlocProvider<ForgotPasswordBloc>(
            create: (_) => ForgotPasswordBloc(
              forgotPasswordRepository: ForgotPasswordRepository(),
            ),
            child: const ChangePasswordScreen(),
          ),
        );
      case PathConstants.addChild:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) => ChildBloc(
                  childRepository: ChildRepository()
              ),
              child: AddChild(),
            ));
      case PathConstants.childListScreen:
        final args = settings.arguments as List<ChildProfile>?;
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) => ChildBloc(
                  childRepository: ChildRepository()
              ),
              child: ChildListScreen(children: args),
            ));
      case PathConstants.viewChildProfile:
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => ChildBloc(
                  childRepository: ChildRepository()
              ),
              child: ChildProfileDetailScreen(),
            );
          },
        );
      case PathConstants.editChildProfile:
        final childData = settings.arguments as GetChildData;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => ChildBloc(
                  childRepository: ChildRepository()
              ),
              child: EditChildProfile(childData: childData),
            );
          },
        );

    //Medications
      case PathConstants.addMedicationScreen:
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider<HospitalBloc>(
                create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
              ),
              BlocProvider<DoctorBloc>(
                create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
              ),
              BlocProvider<MedicationsBloc>(
                create: (_) => MedicationsBloc(medicationsRepository: MedicationsRepository()),
              ),
            ],
            child:  AddMedicationScreen(),
          ),
        );
      case PathConstants.medicationListScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  MedicationsBloc(
                  medicationsRepository: MedicationsRepository()
              ),
              child: MedicationsListScreen(),
            ));
      case PathConstants.medicationDetailScreen:
        final String medicationId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => MedicationsBloc(
                  medicationsRepository: MedicationsRepository()
              ),
              child: MedicationDetailScreen(medicationId: medicationId),
            );
          },
        );
      case PathConstants.editMedicationScreen:
        final medicationData = settings.arguments as MedicationDetailData;
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
              providers: [
                BlocProvider<HospitalBloc>(
                  create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
                ),
                BlocProvider<DoctorBloc>(
                  create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
                ),
                BlocProvider<MedicationsBloc>(
                  create: (_) => MedicationsBloc(medicationsRepository: MedicationsRepository()),
                ),
              ],
              child:  EditMedicationScreen(medicationDetailData: medicationData)
          ),
        );

    //Vaccinations
      case PathConstants.addVaccinationScreen:
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider<HospitalBloc>(
                create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
              ),
              BlocProvider<DoctorBloc>(
                create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
              ),
              BlocProvider<VaccinationsBloc>(
                create: (_) => VaccinationsBloc(vaccinationsRepository: VaccinationsRepository()),
              ),
            ],
            child:  AddVaccinationScreen(),
          ),
        );
      case PathConstants.vaccinationListScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  VaccinationsBloc(
                  vaccinationsRepository: VaccinationsRepository()
              ),
              child: VaccinationListScreen(),
            ));
      case PathConstants.vaccinationDetailScreen:
        final String vaccinationId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => VaccinationsBloc(
                  vaccinationsRepository: VaccinationsRepository()
              ),
              child: VaccinationDetailScreen(vaccinationId: vaccinationId),
            );
          },
        );
      case PathConstants.editVaccinationScreen:
        final vaccinationData = settings.arguments as VaccinationDetailData;
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
              providers: [
                BlocProvider<HospitalBloc>(
                  create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
                ),
                BlocProvider<DoctorBloc>(
                  create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
                ),
                BlocProvider<VaccinationsBloc>(
                  create: (_) => VaccinationsBloc(vaccinationsRepository: VaccinationsRepository()),
                ),
              ],
              child:  EditVaccinationScreen(vaccinationDetailData: vaccinationData)
          ),
        );


    //Health Tracker
      case PathConstants.addHealthTrackerScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) => HealthTrackerBloc(
                  healthTrackerRepository: HealthTrackerRepository()
              ),
              child: AddHealthTrackerScreen(),
            ));
      case PathConstants.healthTrackerListScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  HealthTrackerBloc(
                  healthTrackerRepository: HealthTrackerRepository()
              ),
              child: HealthTrackerListScreen(),
            ));
      case PathConstants.healthTrackerDetailScreen:
        final String healthTrackerId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => HealthTrackerBloc(
                  healthTrackerRepository: HealthTrackerRepository()
              ),
              child: HealthTrackerDetailScreen(healthTrackerId: healthTrackerId),
            );
          },
        );
      case PathConstants.editHealthTrackerScreen:
        final healthTrackerData = settings.arguments as HealthRecordDetailData;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => HealthTrackerBloc(
                  healthTrackerRepository: HealthTrackerRepository()
              ),
              child: EditHealthTrackerScreen(healthRecordDetailData: healthTrackerData),
            );
          },
        );

    //Medical Conditions
      case PathConstants.addMedicalConditionScreen:
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider<HospitalBloc>(
                create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
              ),
              BlocProvider<DoctorBloc>(
                create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
              ),
              BlocProvider<MedicalConditionBloc>(
                create: (_) => MedicalConditionBloc(medicalConditionRepository: MedicalConditionRepository()),
              ),
            ],
            child:  AddMedicalConditionScreen(),
          ),
        );
      case PathConstants.medicalConditionsListScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  MedicalConditionBloc(
                  medicalConditionRepository: MedicalConditionRepository()
              ),
              child: MedicalConditionsListScreen(),
            ));
      case PathConstants.medicalConditionDetailScreen:
        final String medicalConditionId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => MedicalConditionBloc(
                  medicalConditionRepository: MedicalConditionRepository()
              ),
              child: MedicalConditionDetailScreen(medicalConditionId: medicalConditionId),
            );
          },
        );
      case PathConstants.editMedicalConditionScreen:
        final conditionData = settings.arguments as MedicalConditionDetailData;
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
              providers: [
                BlocProvider<HospitalBloc>(
                  create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
                ),
                BlocProvider<DoctorBloc>(
                  create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
                ),
                BlocProvider<MedicalConditionBloc>(
                  create: (_) => MedicalConditionBloc(medicalConditionRepository: MedicalConditionRepository()),
                ),
              ],
              child:  EditMedicalConditionScreen(medicalConditionDetailData: conditionData)
          ),
        );

    //Doctor Visit
      case PathConstants.doctorVisitFormScreen:
        final args = settings.arguments as DoctorVisitDetailData?;
        return MaterialPageRoute(
          builder: (_) => MultiBlocProvider(
            providers: [
              BlocProvider<HospitalBloc>(
                create: (_) => HospitalBloc(hospitalRepository: HospitalRepository()),
              ),
              BlocProvider<DoctorBloc>(
                create: (_) => DoctorBloc(doctorRepository: DoctorRepository()),
              ),
              BlocProvider<DoctorVisitBloc>(
                create: (_) => DoctorVisitBloc(doctorVisitRepository: DoctorVisitRepository()),
              ),
            ],
            child:  DoctorVisitFormScreen(doctorVisitDetailData : args),
          ),
        );
      case PathConstants.doctorVisitListScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  DoctorVisitBloc(
                  doctorVisitRepository: DoctorVisitRepository()
              ),
              child: DoctorVisitListScreen(),
            ));
      case PathConstants.doctorVisitDetailScreen:
        final String doctorVisitId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => DoctorVisitBloc(
                  doctorVisitRepository: DoctorVisitRepository()
              ),
              child: DoctorVisitDetailScreen(doctorVisitId: doctorVisitId),
            );
          },
        );

    //Care Taker
      case PathConstants.addCareTakerScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) => CareTakerBloc(
                  careTakerRepository: CareTakerRepository()
              ),
              child: AddCareTakerScreen(),
            ));
      case PathConstants.careTakersScreen:
        return MaterialPageRoute(
            builder: (_) => BlocProvider(
              create: (context) =>  CareTakerBloc(
                  careTakerRepository: CareTakerRepository()
              ),
              child: CareTakerListScreen(),
            ));
      case PathConstants.careTakerDetailsScreen:
        final String careTakerId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) {
            return BlocProvider(
              create: (context) => CareTakerBloc(
                  careTakerRepository: CareTakerRepository()
              ),
              child: CareTakerDetailScreen(careTakerId: careTakerId),
            );
          },
        );


      case PathConstants.homeScreen:
        return MaterialPageRoute(builder: (_) => HomeScreen());
      case PathConstants.healthRecords:
        return MaterialPageRoute(builder: (_) => HealthRecords());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: TextWidgets.textWidget(
                  AppStrings.noRouteFoundText, AppColors.cblackColor,
                  fontSize: 14),
            ),
          ),
        );
    }
  }
}
