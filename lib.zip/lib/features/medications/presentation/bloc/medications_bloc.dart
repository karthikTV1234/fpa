import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/response/frequency_list_res_model.dart';
import '../../data/model/response/medication_detail_res_model.dart';
import '../../data/model/response/medication_list_res_model.dart';
import '../../data/repository/medications_repository.dart';
import 'medications_events.dart';
import 'medications_state.dart';

/// BLOC
class MedicationsBloc extends Bloc<MedicationsEvent, MedicationsState> {
  List<Map<String, dynamic>> filteredMedicationsList = [];
  final MedicationsRepository medicationsRepository;
  bool isUIUpdated = false;
  String? selectedHospitalId;
  List<HospitalListData> hospitalList = [];
  String? selectedDoctorId;
  List<DoctorListData> doctorList = [];
  List<FrequencyListData> frequencyList = [];
  List<String> frequencyLabelList = [];
  String? selectedFrequency;
  String? selectedFrequencyId;
  List<String> selectedTimesPerDay = [];
  List<XFile> newAttachments = [];
   MedicationDetailData? medicationData;

  MedicationsBloc({required this.medicationsRepository}) : super(MedicationsInitial()) {
    on<SetHospitalListEvent>((event, emit) {
      hospitalList = event.hospitals;
      emit(HospitalListSet(event.hospitals));
    });
    on<SelectHospitalEvent>((event, emit) {
      isUIUpdated = true;
      selectedHospitalId = event.hospitalId;
      emit(HospitalSelected(event.hospitalId));
    });
    on<SetDoctorListEvent>((event, emit) {
      doctorList = event.doctors;
      emit(DoctorListSet(event.doctors));
    });
    on<SelectDoctorEvent>((event, emit) {
      isUIUpdated = true;
      selectedDoctorId = event.doctorId;
      emit(DoctorSelected(event.doctorId));
    });
    on<SelectFrequencyEvent>((event, emit) {
      isUIUpdated = true;
      selectedFrequency = event.frequencyValue;
      final selectedModel = frequencyList.firstWhere(
            (element) => element.label == selectedFrequency,
        orElse: () => FrequencyListData(),
      );
      selectedFrequencyId = selectedModel.frequencyId;
      emit(FrequencySelected(event.frequencyValue));
    });
    on<PreselectFrequencyEvent>((event, emit) {
      final matched = frequencyList.firstWhere(
            (element) => element.frequencyId == event.frequencyId,
        orElse: () => FrequencyListData(),
      );
      selectedFrequencyId = matched.frequencyId;
      selectedFrequency = matched.label;
      isUIUpdated = true;
      emit(FrequencySelected(matched.label));
    });
    on<SelectTimesPerDayEvent>((event, emit) {
      isUIUpdated = true;
      selectedTimesPerDay = event.selectedTimes;
      isUIUpdated = true;
      emit(TimesPerDaySelected(selectedTimesPerDay));
    });
    on<PreselectTimesPerDayEvent>((event, emit) {
      selectedTimesPerDay = event.selectedTimes;
      isUIUpdated = true;
      emit(TimesPerDaySelected(selectedTimesPerDay));
    });

    on<MedicationAddNewAttachmentEvent>((event, emit) {
      newAttachments.add(event.file);
      isUIUpdated = true;
      emit(MedicationsAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<MedicationRemoveNewAttachmentEvent>((event, emit) {
      newAttachments.removeWhere((f) => f.path == event.file.path);
      isUIUpdated = true;
      newAttachments = List<XFile>.from(newAttachments);
      emit(MedicationsAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<SearchMedicationsListEvent>((event, emit) {
      if (event.textSearch.trim().isEmpty) {
        filteredMedicationsList = event.list;
      } else {
        filteredMedicationsList = event.list.where((element) {
          final title = (element["title"] ?? "").toLowerCase();
          return title.contains(event.textSearch.toLowerCase());
        }).toList();
      }
      emit(MedicationListSearchSuccess(filteredMedicationsList));
    });
    on<AddMedicationEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.addMedication(
          event.addMedicationReqModel
      );
      if (result.isSuccess) {
        emit(MedicationsSuccess(message: result.data?.message ?? AppStrings.medicationAddedSuccessMessage));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchMedicationsListEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.getMedicationList(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetMedicationsListResModel resModel = result.data!;
        emit(MedicationListSuccess(resModel.data));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchFrequencyListEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.getFrequencyList();
      if (result.isSuccess && result.data != null) {
        final FrequencyListResModel resModel = result.data!;
        frequencyList = resModel.data;
        frequencyLabelList.addAll(
          frequencyList.map((e) => e.label).where((e) => e.isNotEmpty),
        );
        isUIUpdated = true;
        emit(FrequencyListSuccess(resModel.data));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchMedicationByIdEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.getMedicationDetails(event.medicationId);
      if (result.isSuccess && result.data != null) {
        final GetMedicationsDetailResModel resModel = result.data!;
        medicationData = resModel.data;
         isUIUpdated = true;
        emit(MedicationByIdSuccess(resModel.data));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateMedicationEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.updateMedicationDetails(
          event.updateMedicationReqModel,
        event.medicationId
      );
      if (result.isSuccess) {
        emit(MedicationsSuccess(message: result.data?.message ?? AppStrings.medicationUpdateSuccessMessage));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteMedicationEvent>((event, emit) async {
      emit(MedicationsLoading());
      final result = await medicationsRepository.deleteMedication(event.medicationId);
      if (result.isSuccess && result.data != null) {
        emit(MedicationsSuccess(message: result.data?.message ??  AppStrings.medicationDeleteSuccessMessage));
      } else {
        emit(MedicationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearMedicationFormEvent>((event, emit) {
      frequencyList.clear();
      frequencyLabelList.clear();
      selectedFrequencyId = null;
      selectedFrequency = null;
      selectedTimesPerDay.clear();
      hospitalList.clear();
      selectedHospitalId = null;
      doctorList.clear();
      selectedDoctorId = null;
      newAttachments.clear();
      isUIUpdated = false;
      emit(MedicationsInitial());
    });
  }
}
