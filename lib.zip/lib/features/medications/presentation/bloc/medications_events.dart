import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/request/add_medication_req_model.dart';
import '../../data/model/request/edit_medication_req_model.dart';

/// EVENTS
abstract class MedicationsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddMedicationEvent extends MedicationsEvent with EquatableMixin {
  final AddMedicationReqModel addMedicationReqModel;
  AddMedicationEvent({
    required this.addMedicationReqModel
  });
  @override
  List<Object?> get props => [addMedicationReqModel];
}
class FetchMedicationsListEvent extends MedicationsEvent {
  final String childId;
  FetchMedicationsListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class FetchFrequencyListEvent extends MedicationsEvent {}
class SearchMedicationsListEvent extends MedicationsEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchMedicationsListEvent({required this.textSearch, required this.list});
}
class FetchMedicationByIdEvent extends MedicationsEvent {
  final String medicationId;
  FetchMedicationByIdEvent({required this.medicationId});
  @override
  List<Object?> get props => [medicationId];
}
class UpdateMedicationEvent extends MedicationsEvent {
  final String medicationId;
  final UpdateMedicationReqModel updateMedicationReqModel;
  UpdateMedicationEvent({
    required this.medicationId,
    required this.updateMedicationReqModel,
  });
  @override
  List<Object?> get props => [medicationId, updateMedicationReqModel];
}
class DeleteMedicationEvent extends MedicationsEvent {
  final String medicationId;
  DeleteMedicationEvent({required this.medicationId});
  @override
  List<Object?> get props => [medicationId];
}
class SetHospitalListEvent extends MedicationsEvent {
  final List<HospitalListData> hospitals;
  SetHospitalListEvent(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class SelectHospitalEvent extends MedicationsEvent {
  final String hospitalId;
  SelectHospitalEvent(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class SetDoctorListEvent extends MedicationsEvent {
  final List<DoctorListData> doctors;
  SetDoctorListEvent(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class SelectDoctorEvent extends MedicationsEvent {
  final String doctorId;
  SelectDoctorEvent(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class SelectFrequencyEvent extends MedicationsEvent {
  final String frequencyValue;
  SelectFrequencyEvent(this.frequencyValue);
  @override
  List<Object?> get props => [frequencyValue];
}
class PreselectFrequencyEvent extends MedicationsEvent {
  final String frequencyId;
  PreselectFrequencyEvent(this.frequencyId);
  @override
  List<Object?> get props => [frequencyId];
}
class SelectTimesPerDayEvent extends MedicationsEvent {
  final List<String> selectedTimes;
  SelectTimesPerDayEvent(this.selectedTimes);
  @override
  List<Object?> get props => [selectedTimes];
}
class PreselectTimesPerDayEvent extends MedicationsEvent {
  final List<String> selectedTimes;
  PreselectTimesPerDayEvent(this.selectedTimes);
  @override
  List<Object?> get props => [selectedTimes];
}
class MedicationAddNewAttachmentEvent extends MedicationsEvent {
  final XFile file;
  MedicationAddNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class MedicationRemoveNewAttachmentEvent extends MedicationsEvent {
  final XFile file;
  MedicationRemoveNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class ClearMedicationFormEvent extends MedicationsEvent {}


