import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/response/frequency_list_res_model.dart';
import '../../data/model/response/medication_detail_res_model.dart';
import '../../data/model/response/medication_list_res_model.dart';

/// STATES
abstract class MedicationsState extends Equatable {
  @override
  List<Object?> get props => [];
}
class MedicationsInitial extends MedicationsState {}
class MedicationsLoading extends MedicationsState {}
class MedicationsSuccess extends MedicationsState {
  final String message;
  MedicationsSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class MedicationListSuccess extends MedicationsState {
  final List<MedicationListData> medications;
  MedicationListSuccess(this.medications);
  @override
  List<Object?> get props => [medications];
}
class MedicationListSearchSuccess extends MedicationsState {
  final List<Map<String, dynamic>> filteredList;
  MedicationListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class FrequencyListSuccess extends MedicationsState {
  final List<FrequencyListData> frequencyList;
  FrequencyListSuccess(this.frequencyList);
  @override
  List<Object?> get props => [frequencyList];
}
class MedicationByIdSuccess extends MedicationsState {
  final MedicationDetailData? medicationData;
  MedicationByIdSuccess(this.medicationData);
  @override
  List<Object?> get props => [medicationData];
}
class MedicationsFailure extends MedicationsState {
  final String error;
  MedicationsFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class HospitalListSet extends MedicationsState {
  final List<HospitalListData> hospitals;
  HospitalListSet(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class HospitalSelected extends MedicationsState {
  final String hospitalId;
  HospitalSelected(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DoctorListSet extends MedicationsState {
  final List<DoctorListData> doctors;
  DoctorListSet(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class DoctorSelected extends MedicationsState {
  final String doctorId;
  DoctorSelected(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class FrequencySelected extends MedicationsState {
  final String frequency;
  FrequencySelected(this.frequency);
  @override
  List<Object?> get props => [frequency];
}
class TimesPerDaySelected extends MedicationsState {
  final List<String> selectedTimes;
  TimesPerDaySelected(this.selectedTimes);
  @override
  List<Object?> get props => [selectedTimes];
}
class MedicationsAttachmentsUpdated extends MedicationsState with EquatableMixin {
  final List<XFile> attachments;
  MedicationsAttachmentsUpdated(this.attachments);
  @override
  List<Object?> get props => [attachments];
}
class MedicationFormReset extends MedicationsState {}
