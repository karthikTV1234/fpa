import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/common_card_item.dart';
import 'package:child_health_story/shared/widgets/common_list_view.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../data/model/response/medication_list_res_model.dart';
import 'bloc/medications_events.dart';
import 'bloc/medications_state.dart';

class MedicationsListScreen extends StatefulWidget {
  const MedicationsListScreen({super.key});

  @override
  State<MedicationsListScreen> createState() => _MedicationsListScreenState();
}

class _MedicationsListScreenState extends State<MedicationsListScreen> {
  final TextEditingController _searchController = TextEditingController();
  late final MedicationsBloc _medicationsBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _medicationsBloc = context.read<MedicationsBloc>();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      _medicationsBloc.add(FetchMedicationsListEvent(childId: childId));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _mapMedicationsToUI(List<MedicationListData> meds) {
    return meds.map((med) {
      final formattedNextDosage = AppUtils.formatBackendDateTimeReadable(med.nextDosage ?? "");
      final formattedStartDate = AppUtils.formatDateOnly(med.startDate);
      final formattedEndDate = AppUtils.formatDateOnly(med.endDate);
      final statusText = formattedNextDosage.isNotEmpty
          ? "${AppStrings.nextDosagePrefix}$formattedNextDosage"
          : "";
      final subtitleText = formattedStartDate.isNotEmpty
          ? "${AppStrings.startDatePrefix}$formattedStartDate"
          : "";

      final subtitle2Text = formattedEndDate.isNotEmpty
          ? "${AppStrings.endDatePrefix}$formattedEndDate"
          : "";
      return {
        "id": med.id,
        "category": med.frequency,
        "status": statusText,
        "statusColor": AppColors.vLightOrangeColor,
        "title": med.medicineName,
        "subtitle": subtitleText,
        "subtitle2": subtitle2Text,
      };
    }).toList();
  }


  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MedicationsBloc, MedicationsState>(
        listener: (context, state) {
          if (state is MedicationListSuccess) {
             mappedList = _mapMedicationsToUI(state.medications);
             _medicationsBloc.filteredMedicationsList = mappedList;
          }else if (state is MedicationListSearchSuccess) {
            _medicationsBloc.filteredMedicationsList = state.filteredList;
          }

          if (state is MedicationsFailure) {
            CustomSnackBar(
              context: context,
              message: state.error,
              messageType: AppStrings.failure,
            ).show();
          }
        },
    builder: (context, state) {
      return  Stack(
        children:[
       ParentWidget(
        appbarTitle: AppStrings.medicationText,
        appbarTitleColor: AppColors.cblackColor,
        appbarColor: AppColors.clightGrayColor,
        appbarSubtitle: AppStrings.medicationDetailsText(
            SharedPreferencesHelper.instance.getSelectedChildName()
        ),
        leadingWidget: IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: Icon(
              Icons.arrow_back,
              color: AppColors.cblackColor,
            )),
        context: context,
        hasHeader: true,
        childWidget: ConstrainedBox(
          constraints:
          BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
          child: IntrinsicHeight(
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Column(
                spacing: 8,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextWidgets.textWidget(
                        AppStrings.historyText, AppColors.cblackColor,
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextInputWidgets.getTextField(
                      fillColor: AppColors.clightGrayColor,
                      textColor: AppColors.cblackColor,
                      hintText: AppStrings.searchMedicationText,
                      prefixIcon: Icon(Icons.search, color: Colors.grey,
                          size: 15),
                      controller: _searchController,
                        keyboardType: TextInputType.text,
                        onChanged: (value) {
                          _medicationsBloc.add(SearchMedicationsListEvent(
                          textSearch: value,
                          list: mappedList,
                        ));
                      },
                    ),
                  ),
                  Expanded(
                    child: CommonListView<Map<String, dynamic>>(
                      data: _medicationsBloc.filteredMedicationsList,
                      padding: const EdgeInsets.all(16),
                      itemBuilder: (item) =>
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: CommonCardItem(
                              id: item["id"],
                              category: item["category"] ?? "",
                              status: item["status"] ?? "",
                              statusColor: item["statusColor"],
                              title: item["title"] ?? "",
                              subtitle: item["subtitle"] ?? "",
                              subtitle2: item["subtitle2"] ?? "",
                              onTap: (selectedId)  {
                                _navigateToDetailScreen(context, selectedId);
                              },
                            ),
                          ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
           floatingActionButton: ButtonWidgets.floatingActionButton(
             Icons.add,
             AppColors.cwhiteColor,
             AppColors.cprimaryColor,
                 () async {
               final result = await Navigator.pushNamed(
                 context,
                 PathConstants.addMedicationScreen,
               );
               if (result == true) {
                 final childId = SharedPreferencesHelper.instance.getSelectedChildId();
                 if (childId.isNotEmpty) {
                   _medicationsBloc.add(FetchMedicationsListEvent(childId: childId));
                 }
               }
             },
           ),
      ),
       Visibility(visible: state is MedicationsLoading, child:Loader.showLoader(AppStrings.loading))
     ]
      );
    },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.medicationDetailScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _medicationsBloc.add(FetchMedicationsListEvent(childId: childId));
      }
    }
  }

}
