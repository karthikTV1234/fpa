import 'dart:io';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/features/medications/presentation/widgets/times_per_day_selector.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/strings/app_strings.dart';
import '../../../core/constants/strings/validation_messages.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/app_validators.dart';
import '../../../shared/widgets/custom_dropdown.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/parent_widget.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../../../shared/widgets/text_widgets.dart';
import '../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../doctor/presentation/add_doctor_screen.dart';
import '../../doctor/presentation/bloc/doctor_bloc.dart';
import '../../hospital/data/model/hospital_model.dart';
import '../../hospital/presentation/add_hospital_screen.dart';
import '../../hospital/presentation/bloc/hospital_bloc.dart';
import '../../../shared/widgets/dropdown/custom_selection_drop_down.dart';
import '../data/model/request/edit_medication_req_model.dart';
import '../data/model/response/medication_detail_res_model.dart';
import 'bloc/medications_events.dart';
import 'bloc/medications_state.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class EditMedicationScreen extends StatefulWidget {
  final MedicationDetailData medicationDetailData;
  const EditMedicationScreen({
    super.key,
    required this.medicationDetailData,
  });

  @override
  State<EditMedicationScreen> createState() => _EditMedicationScreenState();
}

class _EditMedicationScreenState extends State<EditMedicationScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _medicationNameController =
  TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _dosageController = TextEditingController();
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _endDateController = TextEditingController();
  final TextEditingController _hospitalController = TextEditingController();
  final TextEditingController _doctorController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  late MedicationsBloc medBloc;

  @override
  void dispose() {
    _medicationNameController.dispose();
    _reasonController.dispose();
    _dosageController.dispose();
    _startDateController.dispose();
    _endDateController.dispose();
    _hospitalController.dispose();
    _doctorController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    medBloc = BlocProvider.of<MedicationsBloc>(context);
    medBloc.add(FetchFrequencyListEvent());
    context.read<HospitalBloc>().add(FetchHospitalListEvent());
    context.read<DoctorBloc>().add(FetchDoctorListEvent());
    _loadMedicationData();
  }



  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
        listeners: [
          BlocListener<DoctorBloc, DoctorState>(
            listener: _doctorBlocListener,
          ),
          BlocListener<HospitalBloc, HospitalState>(
            listener: _hospitalBlocListener,
          ),
        ],
       child: BlocConsumer<MedicationsBloc, MedicationsState>(
         listener: _medicationBlocListener,
         builder: (context, state) {
           return  Stack(
             children:[
           ParentWidget(
            hasHeader: true,
            appbarColor: AppColors.lightGreyColor,
            appbarTitle: AppStrings.editMedicationText,
            appbarTitleColor: AppColors.cblackColor,
            context: context,
            leadingWidget: IconButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                icon: Icon(Icons.arrow_back)),
            childWidget: Padding(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    spacing: 16,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.medicationNameLabel,
                        hintText: AppStrings.medicationNameHint,
                        TextInputType.text,
                        TextInputAction.next,
                        _medicationNameController,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.medicationNameRequired;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.reasonForUsageLabel,
                        hintText: AppStrings.reasonForUsageHint,
                        TextInputType.text,
                        TextInputAction.next,
                        _reasonController,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.reasonForUsageRequired;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.dosageLabel,
                        hintText: AppStrings.dosageHint,
                        TextInputType.text,
                        TextInputAction.next,
                        _dosageController,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.dosageRequired;
                          }
                          return null;
                        },
                      ),
                      CustomDropDown(
                        labelText: AppStrings.frequencyLabel,
                        hint: TextWidgets.textWidget(
                            fontSize: 14,
                            AppStrings.frequencyHint,
                            AppColors.cblackColor),
                        dropdownMenuItems: medBloc.isUIUpdated ? medBloc.frequencyLabelList : [],
                        value: medBloc.isUIUpdated ? medBloc.selectedFrequency : null,
                        onChanged: (value) {
                          medBloc.add(SelectFrequencyEvent(value));
                        },
                        validator: (value) {
                          if (value == null ||
                              AppValidators.emptyValidator(value)) {
                            return ValidationMessages.frequencyRequired;
                          }
                          return null;
                        },
                      ),
                      TimesPerDaySelector(
                        timesOfDayList: AppStrings.timesOfDayOptions,
                        selectedItems: medBloc.isUIUpdated ? medBloc.selectedTimesPerDay :[],
                        onSelectionChanged: (newSelections) {
                          medBloc.add(SelectTimesPerDayEvent(newSelections));
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.startDateLabel,
                        TextInputType.datetime,
                        TextInputAction.next,
                        _startDateController,
                        false,
                        readOnly: true,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        trailingIcon: Icon(Icons.date_range),
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.startDateRequired;
                          }
                          return null;
                        },
                        customTap: () async {
                          final DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (pickedDate != null) {
                            _startDateController.text =
                                AppUtils.formatDateFromDatePicker(pickedDate);
                          }
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.endDateLabel,
                        TextInputType.datetime,
                        TextInputAction.next,
                        _endDateController,
                        false,
                        readOnly: true,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        trailingIcon: Icon(Icons.date_range),
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.endDateRequired;
                          }
                          return null;
                        },
                        customTap: () async {
                          final DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (pickedDate != null) {
                            _endDateController.text =
                                AppUtils.formatDateFromDatePicker(pickedDate);
                          }
                        },
                      ),
                      CustomSingleSelectionDropdown<HospitalListData>(
                        controller: _hospitalController,
                        items: medBloc.isUIUpdated ? medBloc.hospitalList : [],
                        displayValue: (hospital) => hospital.hospitalName,
                        labelText: AppStrings.hospitalLabel,
                        hintText: AppStrings.hospitalHint,
                        headTitle: AppStrings.availableHospitals,
                        onSelected: (selectedHospital) {
                          _hospitalController.text = selectedHospital.hospitalName;
                          medBloc.add(SelectHospitalEvent(selectedHospital.id));
                        },
                        emptyStateText:  AppStrings.noHospitalAvailable,
                        addButtonText: AppStrings.addNewHospital,
                        onAddPressed: _handleAddHospital,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.hospitalRequired;
                          }
                          return null;
                        },
                      ),
                      CustomSingleSelectionDropdown<DoctorListData>(
                        controller: _doctorController,
                        items: medBloc.isUIUpdated ? medBloc.doctorList : [],
                        displayValue: (doctor) => doctor.doctorName,
                        labelText: AppStrings.doctorLabel,
                        hintText: AppStrings.doctorHint,
                        headTitle: AppStrings.availableDoctors,
                        onSelected: (selectedDoctor) {
                          _doctorController.text = selectedDoctor.doctorName;
                          medBloc.add(SelectDoctorEvent(selectedDoctor.id));
                        },
                        emptyStateText:  AppStrings.noDoctorAvailable,
                        addButtonText: AppStrings.addNewDoctor,
                        onAddPressed: _handleAddDoctor,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.doctorRequired;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        maxLines: 4,
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.notesLabel,
                        hintText: AppStrings.notesHint,
                        TextInputType.text,
                        TextInputAction.done,
                        _notesController,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                      ),
                      FileAttachmentsWidget(
                        maxFileSizeMB: AppStrings.maxFileSize,
                        supportedTypes: AppStrings.supportedFileTypes,
                        existingAttachments: widget.medicationDetailData.attachments,
                        selectedNewFiles: medBloc.isUIUpdated ? medBloc.newAttachments : [],
                        onFileSelected: (file) {
                          context.read<MedicationsBloc>().add(MedicationAddNewAttachmentEvent(file));
                        },
                        onFileDeleted: (file) {
                          context.read<MedicationsBloc>().add(MedicationRemoveNewAttachmentEvent(file));
                        },
                      ),
                      ButtonWidgets.elevatedButton(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        width: AppUtils.getScreenWidth(context),
                        radius: 7,
                        height: 50,
                        AppStrings.updateTxt,
                        AppColors.cprimaryColor,
                        AppColors.cwhiteColor,
                            () {
                          _onUpdateMedication(context);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ),
           Visibility(visible: state is MedicationsLoading, child:Loader.showLoader(AppStrings.loading))
           ]
           );
      },
    ),
    );
  }

  void _loadMedicationData() {
    final data = widget.medicationDetailData;
    final capitalizedTimes = data.timeOfDay
        .map((e) => e[0].toUpperCase() + e.substring(1))
        .toList();
    context.read<MedicationsBloc>().add(PreselectTimesPerDayEvent(capitalizedTimes));
    _medicationNameController.text = data.medicineName;
    _reasonController.text = data.reasonOfUse;
    _dosageController.text = data.dosage;
    _startDateController.text = data.startDate;
    _endDateController.text = data.endDate;
    _notesController.text = data.notes;

  }

  void _handleAddHospital() async {
    final result = await AddHospitalDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<HospitalBloc>().add(FetchHospitalListEvent());
    }
  }
  void _handleAddDoctor() async{
    final result = await AddDoctorDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<DoctorBloc>().add(FetchDoctorListEvent());
    }else if (result == AppStrings.openAddHospitalDialog) {
      _handleAddHospital();
    }
  }

  void _doctorBlocListener(BuildContext context, DoctorState state) {
    if (state is DoctorLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        //Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is DoctorListSuccess) {
      final doctors = state.doctors;
      medBloc.add(SetDoctorListEvent(doctors));
      final matched = doctors.firstWhere(
            (element) => element.id == widget.medicationDetailData.doctorId,
        orElse: () => DoctorListData(doctorName: '', id: ''),
      );
      medBloc.add(SelectDoctorEvent(matched.id));
      _doctorController.text = matched.doctorName;
    } else if (state is DoctorFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _hospitalBlocListener(BuildContext context, HospitalState state) {
    if (state is HospitalLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        // Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is HospitalListSuccess) {
      final hospitals = state.hospitals;
      context.read<MedicationsBloc>().add(SetHospitalListEvent(state.hospitals));
      final matched = hospitals.firstWhere(
            (element) => element.id == widget.medicationDetailData.hospitalId,
        orElse: () => HospitalListData(hospitalName: '', id: ''),
      );
      context.read<MedicationsBloc>().add(SelectHospitalEvent(matched.id));
      _hospitalController.text = matched.hospitalName;
    } else if (state is HospitalFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _medicationBlocListener(BuildContext context, MedicationsState state) {
    if (state is FrequencyListSuccess) {
      context.read<MedicationsBloc>().add(
        PreselectFrequencyEvent(widget.medicationDetailData.frequencyId),
      );
    }
    else if (state is MedicationsSuccess) {
      Navigator.of(context).pop(true);
    } else if (state is MedicationsFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onUpdateMedication(BuildContext context) async {
    if (_formKey.currentState!.validate()) {

      if (medBloc.selectedFrequencyId == null || medBloc.selectedFrequencyId!.isEmpty) {
        CustomSnackBar(
          context: context,
          message: ValidationMessages.frequencyRequired,
          messageType: AppStrings.failure,
        ).show();
        return;
      }

      if (medBloc.selectedTimesPerDay.isEmpty) {
        CustomSnackBar(
          context: context,
          message: ValidationMessages.timeADayRequired,
          messageType: AppStrings.failure,
        ).show();
        return;
      }

      final List<XFile> newFiles = medBloc.isUIUpdated
          ? medBloc.newAttachments
          : [];
      final List<File> attachmentFiles = newFiles.map((xfile) => File(xfile.path)).toList();

      final requestModel = UpdateMedicationReqModel(
        medicineName: _medicationNameController.text.trim(),
        dosage: _dosageController.text.trim(),
        frequency: medBloc.selectedFrequencyId ?? '',
        timeOfDay: medBloc.selectedTimesPerDay,
        startDate: _startDateController.text.trim(),
        endDate: _endDateController.text.trim(),
        hospitalId: medBloc.selectedHospitalId ?? '',
        prescribedBy: medBloc.selectedDoctorId ?? '',
        reasonOfUse: _reasonController.text.trim(),
        notes: _notesController.text.trim(),
        attachments: attachmentFiles,
      );
      context.read<MedicationsBloc>().add(
        UpdateMedicationEvent(updateMedicationReqModel: requestModel, medicationId: widget.medicationDetailData.id),
      );
    }
  }


}
