import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/file_utils.dart';
import 'package:child_health_story/features/medications/presentation/bloc/medications_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/file_attachments.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../core/utils/app_utils.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'bloc/medications_events.dart';
import 'bloc/medications_state.dart';


class MedicationDetailScreen extends StatefulWidget {
  final String medicationId;
  const MedicationDetailScreen({super.key, required this.medicationId});

  @override
  State<MedicationDetailScreen> createState() => _MedicationDetailScreenState();
}

class _MedicationDetailScreenState extends State<MedicationDetailScreen> {
  late MedicationsBloc medBloc;
  bool _hasUpdated = false;

  @override
  void initState() {
    super.initState();
    medBloc = BlocProvider.of<MedicationsBloc>(context);
    medBloc.add(
        FetchMedicationByIdEvent(medicationId: widget.medicationId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MedicationsBloc, MedicationsState>(
      listener: (context, state) {
      if (state is MedicationsSuccess) {
        CustomSnackBar(
          context: context,
          message: state.message,
          messageType: AppStrings.success,
        ).show();
        Navigator.of(context).pop(true);
      }
      else if (state is MedicationsFailure) {
        CustomSnackBar(
          context: context,
          message: state.error,
          messageType: AppStrings.failure,
        ).show();
      }
    },
      builder: (context, state) {
        final medicationData = medBloc.isUIUpdated
            ? medBloc.medicationData
            : null;
        return Stack(
          children: [
            ParentWidget(
              context: context,
              hasHeader: true,
              appbarColor: AppColors.lightGreyColor,
              appbarTitle: AppStrings.medicationDetails,
              appbarTitleColor: AppColors.cblackColor,
              leadingWidget: IconButton(
                onPressed: () {
                  if (_hasUpdated) {
                    Navigator.of(context).pop(true);
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(Icons.arrow_back),
              ),
              rightWidget: IconButton(
                onPressed: () async {
                  if (medicationData != null) {
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.editMedicationScreen,
                      arguments: medicationData,
                    );
                    if (result == true) {
                      medBloc.add(FetchMedicationByIdEvent(
                          medicationId: widget.medicationId));
                      _hasUpdated = true;
                    }
                  }
                },
                icon: const Icon(Icons.edit),
              ),
              childWidget: Padding(
                padding: const EdgeInsets.all(15),
                child: SingleChildScrollView(
                  child: Column(
                    spacing: 20,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 20,
                          children: [
                            ListviewCard(
                              icon: const Icon(Icons.medication),
                              title: AppStrings.medicationNameText,
                              subTitle: medicationData?.medicineName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.description),
                              title: AppStrings.reasonForUsageText,
                              subTitle: medicationData?.reasonOfUse ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.local_hospital),
                              title: AppStrings.dosageText,
                              subTitle: medicationData?.dosage ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.devices_other_rounded),
                              title: AppStrings.frequencyText,
                              subTitle: medicationData?.frequencyLabel ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.devices_other_rounded),
                              title: AppStrings.timesADayLabel,
                              subTitle: medicationData?.timeOfDay
                                  .map((e) => e[0].toUpperCase() + e.substring(1))
                                  .join(', ') ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range_outlined),
                              title: AppStrings.startDateText,
                              subTitle: AppUtils.formatDateOnly(
                                  medicationData?.startDate ?? ''),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range_outlined),
                              title: AppStrings.endDateText,
                              subTitle: AppUtils.formatDateOnly(
                                  medicationData?.endDate ?? ''),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.local_hospital),
                              title: AppStrings.hospitalNameText,
                              subTitle: medicationData?.hospitalName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.person),
                              title: AppStrings.doctorText,
                              subTitle: medicationData?.doctorName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.notes),
                              title: AppStrings.notesText,
                              subTitle: medicationData?.notes ?? '',
                              hasDivider: false,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 10,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidgets.textWidget(
                              AppStrings.attachmentsTxt,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                            FileAttachments(
                              files: medicationData?.attachments ?? [],
                              onFileTap: (filePath) {
                                String path  = AppUtils.buildImageFullUrl(filePath) ?? '';
                                FileUtils.previewOrDownloadFile(context, path);
                              },
                            ),
                          ],
                        ),
                      ),
                      ButtonWidgets.elevatedButton(
                        AppStrings.deleteTxt,
                        AppColors.lightRedColor,
                        AppColors.cwhiteColor,
                            () => _onDelete(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        radius: 7,
                        width: MediaQuery.of(context).size.width,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: state is MedicationsLoading,
              child: Loader.showLoader(AppStrings.loading),
            ),
          ],
        );
      },

    );
  }

  void _onDelete(BuildContext context) async {
    if (widget.medicationId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteMedicationTitle,
        contentText: AppStrings.deleteMedicationConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          context.read<MedicationsBloc>().add(DeleteMedicationEvent(medicationId: widget.medicationId));
        },
      );
    }
  }

}


