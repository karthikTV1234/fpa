import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';

class TimesPerDaySelector extends StatelessWidget {
  final List<String> timesOfDayList;
  final List<String> selectedItems;
  final Function(List<String>) onSelectionChanged;

  const TimesPerDaySelector({
    super.key,
    required this.timesOfDayList,
    required this.selectedItems,
    required this.onSelectionChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: TextWidgets.textWidget(
            AppStrings.selectTimesADay,
            AppColors.greyColor,
            fontSize: 16,
            fontWeight: FontWeight.w400,
            textAlign: TextAlign.left,
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: timesOfDayList.map((time) {
              final isSelected = selectedItems.contains(time);
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: isSelected,
                    onChanged: (value) {
                      final updatedSelections = List<String>.from(selectedItems);
                      if (value == true) {
                        updatedSelections.add(time);
                      } else {
                        updatedSelections.remove(time);
                      }
                      onSelectionChanged(updatedSelections);
                    },
                    activeColor: AppColors.cprimaryColor,
                  ),
                  TextWidgets.textWidget(
                    time,
                    AppColors.cblackColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
