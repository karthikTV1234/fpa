import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../model/request/add_medication_req_model.dart';
import '../model/request/edit_medication_req_model.dart';
import '../model/response/add_medication_res_model.dart';
import '../model/response/edit_medication_res_model.dart';
import '../model/response/frequency_list_res_model.dart';
import '../model/response/medication_detail_res_model.dart';
import '../model/response/medication_list_res_model.dart';

class MedicationsRepository {
  final Dio _dio;

  MedicationsRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddMedicationResModel>> addMedication(AddMedicationReqModel addMedicationReqModel) async {
    String errorMessage = ErrorMessages.addMedicationFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.createMedication}';
      final formData = await addMedicationReqModel.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addMedicationRes = AddMedicationResModel.fromJson(response.data);
        return Result.success(addMedicationRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetMedicationsListResModel>> getMedicationList(String childId) async {
    String errorMessage = ErrorMessages.fetchMedicationListFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medicationsList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final medicationListRes = GetMedicationsListResModel.fromJson(response.data);
        return Result.success(medicationListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<FrequencyListResModel>> getFrequencyList() async {
    String errorMessage = ErrorMessages.fetchFrequencyListFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.frequencyList}';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final frequencyListRes = FrequencyListResModel.fromJson(response.data);
        return Result.success(frequencyListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetMedicationsDetailResModel>> getMedicationDetails(String medicationId) async {
    String errorMessage = ErrorMessages.fetchMedicationDetailsFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medications}/$medicationId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.data != null && (response.statusCode == 200 || response.statusCode == 201)) {
        final childDetailRes = GetMedicationsDetailResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<UpdateMedicationResModel>> updateMedicationDetails(UpdateMedicationReqModel updateMedicationReqModel, String medicationId) async {
    String errorMessage = ErrorMessages.updateMedicationFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medications}/$medicationId';
      final formData = await updateMedicationReqModel.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final updateMedicationRes = UpdateMedicationResModel.fromJson(response.data);
        return Result.success(updateMedicationRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteMedication(String medicationId) async {
    String errorMessage = ErrorMessages.deleteMedicationFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medications}/$medicationId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
