import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class UpdateMedicationReqModel {
  final String medicineName;
  final String dosage;
  final String frequency;
  final List<String> timeOfDay;
  final String startDate;
  final String endDate;
  final String hospitalId;
  final String prescribedBy;
  final String reasonOfUse;
  final String notes;
  final List<File> attachments; // Use File for uploading

  UpdateMedicationReqModel({
    this.medicineName = '',
    this.dosage = '',
    this.frequency = '',
    this.timeOfDay = const [],
    this.startDate = '',
    this.endDate = '',
    this.hospitalId = '',
    this.prescribedBy = '',
    this.reasonOfUse = '',
    this.notes = '',
    this.attachments = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'medicineName': medicineName,
      'dosage': dosage,
      'frequency': frequency,
      'timeOfDay': timeOfDay,
      'startDate': startDate,
      'endDate': endDate,
      'hospitalId': hospitalId,
      'prescribedBy': prescribedBy,
      'reasonOfUse': reasonOfUse,
      'notes': notes,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());

    for (int i = 0; i < attachments.length; i++) {
      final file = attachments[i];
      final mimeType = lookupMimeType(file.path) ?? 'application/octet-stream';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'attachments',
          await MultipartFile.fromFile(
            file.path,
            filename: file.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }

    return formData;
  }
}