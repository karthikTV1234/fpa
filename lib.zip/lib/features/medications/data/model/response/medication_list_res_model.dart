class GetMedicationsListResModel {
  final int statusCode;
  final String message;
  final List<MedicationListData> data;

  GetMedicationsListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetMedicationsListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetMedicationsListResModel();

    return GetMedicationsListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => MedicationListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class MedicationListData {
  final String id;
  final String childId;
  final String medicineName;
  final String dosage;
  final String frequency;
  final List<String> timeOfDay;
  final String startDate;
  final String endDate;
  final String? nextDosage;

  MedicationListData({
    this.id = '',
    this.childId = '',
    this.medicineName = '',
    this.dosage = '',
    this.frequency = '',
    this.timeOfDay = const [],
    this.startDate = '',
    this.endDate = '',
    this.nextDosage = '',
  });

  factory MedicationListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicationListData();

    return MedicationListData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      medicineName: json['medicineName'] as String? ?? '',
      dosage: json['dosage'] as String? ?? '',
      frequency: json['frequency'] as String? ?? '',
      startDate: json['startDate'] as String? ?? '',
      endDate: json['endDate'] as String? ?? '',
      nextDosage: json['nextDosage'] as String? ?? '',
    );
  }
}