class FrequencyListResModel {
  final int statusCode;
  final String message;
  final List<FrequencyListData> data;

  FrequencyListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory FrequencyListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return FrequencyListResModel();

    return FrequencyListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => FrequencyListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class FrequencyListData {
  final String label;
  final String frequencyId;

  FrequencyListData({
    this.label = '',
    this.frequencyId = '',
  });

  factory FrequencyListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return FrequencyListData();

    return FrequencyListData(
      label: json['label'] as String? ?? '',
      frequencyId: json['frequencyId'] as String? ?? '',
    );
  }
}