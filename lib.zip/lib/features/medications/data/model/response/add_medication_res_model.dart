

class AddMedicationResModel {
  final int statusCode;
  final String message;
  final MedicationAddResData data;

  AddMedicationResModel({
    this.statusCode = 0,
    this.message = '',
    MedicationAddResData? data,
  }) : data = data ?? MedicationAddResData();

  factory AddMedicationResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddMedicationResModel();

    return AddMedicationResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: MedicationAddResData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}
class MedicationAddResData {
  final String id;
  final String childId;
  final String medicineName;
  final String dosage;
  final String frequency;
  final List<String> timeOfDay;
  final String startDate;
  final String endDate;
  final String prescribedBy;
  final String reasonOfUse;
  final String notes;
  final bool isActive;
  final String createdAt;
  final String updatedAt;
  final List<String> attachments;

  MedicationAddResData({
    this.id = '',
    this.childId = '',
    this.medicineName = '',
    this.dosage = '',
    this.frequency = '',
    this.timeOfDay = const [],
    this.startDate = '',
    this.endDate = '',
    this.prescribedBy = '',
    this.reasonOfUse = '',
    this.notes = '',
    this.isActive = false,
    this.createdAt = '',
    this.updatedAt = '',
    this.attachments = const [],
  });

  factory MedicationAddResData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicationAddResData();

    return MedicationAddResData(
      id: json['id'] as String? ?? '',
      childId: json['child_id'] as String? ?? '',
      medicineName: json['medicine_name'] as String? ?? '',
      dosage: json['dosage'] as String? ?? '',
      frequency: json['frequency'] as String? ?? '',
      timeOfDay: (json['time_of_day'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      startDate: json['start_date'] as String? ?? '',
      endDate: json['end_date'] as String? ?? '',
      prescribedBy: json['prescribed_by'] as String? ?? '',
      reasonOfUse: json['reason_of_use'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      isActive: json['is_active'] as bool? ?? false,
      createdAt: json['created_at'] as String? ?? '',
      updatedAt: json['updated_at'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
    );
  }
}