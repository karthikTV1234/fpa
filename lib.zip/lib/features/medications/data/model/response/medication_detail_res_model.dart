class GetMedicationsDetailResModel {
  final int statusCode;
  final String message;
  final MedicationDetailData data;

  GetMedicationsDetailResModel({
    this.statusCode = 0,
    this.message = '',
    MedicationDetailData? data,
  }) : data = data ?? MedicationDetailData();

  factory GetMedicationsDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetMedicationsDetailResModel();

    return GetMedicationsDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: MedicationDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class MedicationDetailData {
  final String id;
  final String childId;
  final String medicineName;
  final String dosage;
  final String frequencyLabel;
  final String frequencyId;
  final String doctorName;
  final String doctorId;
  final String hospitalName;
  final String hospitalId;
  final String reasonOfUse;
  final List<String> timeOfDay;
  final String startDate;
  final String endDate;
  final String nextDosage;
  final String notes;
  final List<String> attachments;

  MedicationDetailData({
    this.id = '',
    this.childId = '',
    this.medicineName = '',
    this.dosage = '',
    this.frequencyLabel = '',
    this.frequencyId = '',
    this.doctorName = '',
    this.doctorId = '',
    this.hospitalName = '',
    this.hospitalId = '',
    this.reasonOfUse = '',
    this.timeOfDay = const [],
    this.startDate = '',
    this.endDate = '',
    this.nextDosage = '',
    this.notes = '',
    this.attachments = const [],
  });

  factory MedicationDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicationDetailData();

    return MedicationDetailData(
      id: json['id'] as String? ?? '',
      childId: json['child_id'] as String? ?? '',
      medicineName: json['medicineName'] as String? ?? '',
      dosage: json['dosage'] as String? ?? '',
      frequencyLabel: json['frequencyLabel'] as String? ?? '',
      frequencyId: json['frequencyId'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      reasonOfUse: json['reasonOfUse'] as String? ?? '',
      timeOfDay: (json['timeOfDay'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      startDate: json['startDate'] as String? ?? '',
      endDate: json['endDate'] as String? ?? '',
      nextDosage: json['nextDosage'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
    );
  }
}