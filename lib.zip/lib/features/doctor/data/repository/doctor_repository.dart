import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/network/api_client.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../model/request/add_doctor_req_model.dart';
import '../model/response/add_doctor_res_model.dart';
import '../model/response/doctor_list_res_model.dart';
import '../model/response/doctor_speciality_list_res_model.dart';

class DoctorRepository {
  final Dio _dio;

  DoctorRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddDoctorResModel>> addDoctor(AddDoctorReqModel addDoctorReqModel) async {
    String errorMessage = ErrorMessages.addDoctorFailedError;
    try {
      const String url = '${ApiConstants.commonUrl}${ApiConstants.addDoctor}';

      final response = await _dio.post(
        url,
        data: addDoctorReqModel.toJson(),
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addDoctorRes = AddDoctorResModel.fromJson(response.data);
        return Result.success(addDoctorRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<DoctorListResModel>> getDoctorList() async {
    String errorMessage = ErrorMessages.fetchDoctorListFailedError;
    try {
      const String url = '${ApiConstants.commonUrl}${ApiConstants.doctorList}';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final doctorListRes = DoctorListResModel.fromJson(response.data);
        return Result.success(doctorListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<DoctorSpecialtyListResModel>> getDoctorSpecialtyList() async {
    String errorMessage = ErrorMessages.fetchDoctorSpecialityListFailedError;
    try {
      const String url = '${ApiConstants.commonUrl}${ApiConstants.doctorSpecialityList}';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final doctorSpecialtyListRes = DoctorSpecialtyListResModel.fromJson(response.data);
        return Result.success(doctorSpecialtyListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
