//Doctor List
class DoctorListResModel {
  final int statusCode;
  final String message;
  final List<DoctorListData> data;

  DoctorListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory DoctorListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorListResModel();

    return DoctorListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => DoctorListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}
class DoctorListData {
  final String id;
  final String doctorName;

  DoctorListData({
    this.id = '',
    this.doctorName = '',
  });

  factory DoctorListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorListData();

    return DoctorListData(
      id: json['id'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
    );
  }
}