
class AddDoctorResModel {
  final String message;
  final int statusCode;
  final DoctorAddData data;

  AddDoctorResModel({
    this.message = '',
    this.statusCode = 0,
    DoctorAddData? data,
  }) : data = data ?? DoctorAddData();

  factory AddDoctorResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddDoctorResModel();

    return AddDoctorResModel(
      message: json['message'] as String? ?? '',
      statusCode: json['statusCode'] as int? ?? 0,
      data: DoctorAddData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}
class DoctorAddData {
  final String id;
  final String doctorName;
  final String hospitalId;
  final List<String> specialty;
  final String phone;
  final String email;
  final String notes;
  final bool isFavorite;
  final String createdBy;
  final String childId;
  final String userId;
  final bool isDeleted;
  final String createdAt;
  final String updatedAt;

  DoctorAddData({
    this.id = '',
    this.doctorName = '',
    this.hospitalId = '',
    this.specialty = const [],
    this.phone = '',
    this.email = '',
    this.notes = '',
    this.isFavorite = false,
    this.createdBy = '',
    this.childId = '',
    this.userId = '',
    this.isDeleted = false,
    this.createdAt = '',
    this.updatedAt = '',
  });

  factory DoctorAddData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorAddData();

    return DoctorAddData(
      id: json['id'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      specialty: (json['specialty'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      phone: json['phone'] as String? ?? '',
      email: json['email'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      isFavorite: json['isFavorite'] as bool? ?? false,
      createdBy: json['createdBy'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
    );
  }
}