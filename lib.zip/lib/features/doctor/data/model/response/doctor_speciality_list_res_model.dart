
class DoctorSpecialtyListResModel {
  final int statusCode;
  final String message;
  final List<DoctorSpecialtyListData> data;

  DoctorSpecialtyListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory DoctorSpecialtyListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorSpecialtyListResModel();

    return DoctorSpecialtyListResModel(
      statusCode: json['statusCode'] is int ? json['statusCode'] ?? 0 : 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => DoctorSpecialtyListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}
class DoctorSpecialtyListData {
  final String id;
  final String specialtyName;

  DoctorSpecialtyListData({
    this.id = '',
    this.specialtyName = '',
  });

  factory DoctorSpecialtyListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorSpecialtyListData();

    return DoctorSpecialtyListData(
      id: json['id'] as String? ?? '',
      specialtyName: json['specialtyName'] as String? ?? '',
    );
  }
}