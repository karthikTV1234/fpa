
class AddDoctorReqModel {
  final String childId;
  final String doctorName;
  final List<String> specialty;
  final String hospitalId;
  final String? countryCode;
  final String? phone;
  final String? email;
  final String notes;

  AddDoctorReqModel({
    this.childId = '',
    this.doctorName = '',
    this.specialty = const [],
    this.hospitalId = '',
    this.countryCode = '',
    this.phone = '',
    this.email = '',
    this.notes = '',
  });

  Map<String, dynamic> toJson() {
    return {
      "childId": childId,
      "doctorName": doctorName,
      "specialty": specialty,
      "hospitalId": hospitalId,
      "countryCode": countryCode,
      "phone": phone,
      "email": email,
      "notes": notes,
    };
  }

  factory AddDoctorReqModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddDoctorReqModel();

    return AddDoctorReqModel(
      childId: json['childId'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
      specialty: (json['specialty'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      hospitalId: json['hospitalId'] as String? ?? '',
      countryCode: json['countryCode'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      email: json['email'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
    );
  }
}