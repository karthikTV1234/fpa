import 'package:child_health_story/features/hospital/data/model/hospital_model.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/app_validators.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import '../../../core/constants/strings/app_data.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_dropdown.dart';
import '../../../shared/widgets/dropdown/custom_multi_select_drop_down.dart';
import '../../../shared/widgets/dropdown/custom_selection_drop_down.dart';
import '../../../shared/widgets/text_widgets.dart';
import '../data/model/request/add_doctor_req_model.dart';
import '../data/model/response/doctor_speciality_list_res_model.dart';
import 'bloc/doctor_bloc.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';


class AddDoctorDialog extends StatefulWidget {
  const AddDoctorDialog({super.key});

  static Future<Object?> show(BuildContext context) async {
    final doctorBloc = context.read<DoctorBloc>();
    final hospitalBloc = context.read<HospitalBloc>();

    return await showDialog<Object>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => MultiBlocProvider(
        providers: [
          BlocProvider.value(value: doctorBloc),
          BlocProvider.value(value: hospitalBloc),
        ],
        child: Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: const AddDoctorDialog(),
          ),
        ),
      ),
    );
  }

  @override
  State<AddDoctorDialog> createState() => _AddDoctorDialogState();
}

class _AddDoctorDialogState extends State<AddDoctorDialog> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _hospitalController = TextEditingController();
  final TextEditingController _doctorNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _specialityController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  List<String> _selectedSpecialtyIds = [];
  late DoctorBloc doctorBloc;

  @override
  void initState() {
    super.initState();
    doctorBloc = BlocProvider.of<DoctorBloc>(context);
    doctorBloc.add(FetchDoctorSpecialityListEvent());
    context.read<HospitalBloc>().add(FetchHospitalListEvent());
  }



  @override
  void dispose() {
    _hospitalController.dispose();
    _doctorNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _specialityController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<HospitalBloc, HospitalState>(
          listener: _hospitalBlocListener,
        ),
      ],
    child: BlocConsumer<DoctorBloc, DoctorState>(
     listener: _doctorBlocListener,
     builder: (context, state) {
       return Container(
           color: AppColors.appBackGroundColor,
           child: Padding(
             padding: const EdgeInsets.all(20),
             child: SingleChildScrollView(
               child: Form(
                 key: _formKey,
                 child: Column(
                   spacing: 16,
                   mainAxisSize: MainAxisSize.min,
                   children: [
                     Align(
                       alignment: Alignment.centerLeft,
                       child: TextWidgets.textWidget(
                         AppStrings.addNewDoctor,
                         AppColors.cblackColor,
                         fontSize: 16,
                         fontWeight: FontWeight.w700,
                         textAlign: TextAlign.left,
                       ),
                     ),
                     CustomSingleSelectionDropdown<HospitalListData>(
                       controller: _hospitalController,
                       items: doctorBloc.isUIUpdated
                           ? doctorBloc.hospitalList
                           : [],
                       displayValue: (hospital) => hospital.hospitalName,
                       labelText: AppStrings.hospitalLabel,
                       hintText: AppStrings.hospitalHint,
                       headTitle: AppStrings.availableHospitals,
                       onSelected: (selectedHospital) {
                         _hospitalController.text =
                             selectedHospital.hospitalName;
                         doctorBloc.add(
                             DSelectHospitalEvent(selectedHospital.id));
                       },
                       emptyStateText: AppStrings.noHospitalAvailable,
                       addButtonText: AppStrings.addNewHospital,
                       onAddPressed: _handleAddHospital,
                       validator: (value) {
                         if (AppValidators.emptyValidator(value!)) {
                           return ValidationMessages.hospitalRequired;
                         }
                         return null;
                       },
                     ),
                     TextInputWidgets.textFormField(
                       fillColor: AppColors.appBackGroundColor,
                       AppStrings.doctorNameLabel,
                       hintText: AppStrings.doctorNameHint,
                       TextInputType.text,
                       TextInputAction.next,
                       _doctorNameController,
                       enabledBorderColor: AppColors.cmediumGrayColor,
                       focusedBorderColor: AppColors.cmediumGrayColor,
                       false,
                       validator: (value) {
                         if (AppValidators.emptyValidator(value!)) {
                           return ValidationMessages.doctorRequired;
                         }
                         return null;
                       },
                     ),
                     CustomMultiSelectDropDown<DoctorSpecialtyListData>(
                       controller: _specialityController,
                       items: doctorBloc.isUIUpdated
                           ? doctorBloc.doctorSpecialtyList
                           : [],
                       displayValue: (item) => item.specialtyName,
                       labelText: AppStrings.specialityLabel,
                       hintText: AppStrings.specialityHint,
                       headTitle: AppStrings.specialityHint,
                       onSave: (selectedList) {
                         _selectedSpecialtyIds =
                             selectedList.map((e) => e.id).toList();
                       },
                       validator: (value) {
                         if (AppValidators.emptyValidator(value!)) {
                           return ValidationMessages.specialtyRequired;
                         }
                         return null;
                       },
                     ),
                     Row(
                       spacing: 10,
                       children: [
                         Expanded(
                           flex: 2,
                           child: CustomDropDown(
                             labelText: AppStrings.countryCodeHintText,
                             hint: TextWidgets.textWidget(
                                 fontSize: 14,
                                 AppStrings.countryCodeHintText,
                                 AppColors.cblackColor),
                             dropdownMenuItems: AppData.countryCodes,
                             value: doctorBloc.selectedCountryCode,
                             onChanged: (value) {
                               doctorBloc.add(SelectCountryCodeEvent(value));
                             },
                             validator: (value) {
                               if (AppValidators.emptyValidator(value ?? '')) {
                                 return ValidationMessages.plsSelectCountryCode;
                               }
                               return null;
                             },
                           ),
                         ),
                         Expanded(
                           flex: 5,
                           child: TextInputWidgets.textFormField(
                             fillColor: AppColors.appBackGroundColor,
                             AppStrings.phoneLabelWithOutAsterisk,
                             hintText: AppStrings.enterPhoneNumberHintText,
                             TextInputType.phone,
                             TextInputAction.done,
                             _phoneController,
                             enabledBorderColor: AppColors.cmediumGrayColor,
                             focusedBorderColor: AppColors.cmediumGrayColor,
                             false,
                             validator: (value) {
                               final trimmedValue = value?.trim() ?? '';
                               if (trimmedValue.isEmpty) {
                                 return null;
                               } else if (!AppValidators.phoneValidator(trimmedValue)) {
                                 return ValidationMessages.plsEnterValidPhoneNumber; // show error on invalid
                               }
                               return null; // valid
                             },
                           ),
                         ),
                       ],
                     ),
                     TextInputWidgets.textFormField(
                       fillColor: AppColors.appBackGroundColor,
                       AppStrings.emailLabel,
                       hintText: AppStrings.enterEmailHintText,
                       TextInputType.emailAddress,
                       TextInputAction.done,
                       _emailController,
                       enabledBorderColor: AppColors.cmediumGrayColor,
                       focusedBorderColor: AppColors.cmediumGrayColor,
                       false,
                       validator: (value) {
                         if ((value ?? '').isEmpty) {
                           return null;
                         } else if (AppValidators.emailValidator(value!)) {
                           return ValidationMessages.plsEnterValidEmail;
                         }
                         return null;
                       },

                     ),
                     TextInputWidgets.textFormField(
                       AppStrings.notesLabelWithOutAsterisk,
                       TextInputType.text,
                       TextInputAction.done,
                       _notesController,
                       hintText: AppStrings.notesHint,
                       fillColor: AppColors.appBackGroundColor,
                       enabledBorderColor: AppColors.cmediumGrayColor,
                       focusedBorderColor: AppColors.cprimaryColor,
                       false,
                       maxLines: 3,
                     ),
                     ButtonWidgets.elevatedButton(
                       AppStrings.addDoctorBtnText,
                       AppColors.cprimaryColor,
                       AppColors.cwhiteColor,
                           () => _onAddDoctor(context),
                       width: AppUtils.getScreenWidth(context),
                       fontSize: 18,
                       fontWeight: FontWeight.w700,
                       height: 50,
                       radius: 7,
                     ),
                   ],
                 ),
               ),
             ),
           )
       );
     }
       ),
    );
  }

  void _doctorBlocListener(BuildContext context, DoctorState state) {
    if (state is DoctorLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        //Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is DoctorSpecialityListSuccess) {
      context.read<DoctorBloc>().add(DSetDoctorSpecialityListEvent(state.doctorsSpecialities));
    } else if (state is DoctorSuccess) {
      Navigator.of(context).pop(true);
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
    } else if (state is DoctorFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _hospitalBlocListener(BuildContext context, HospitalState state) {
    if (state is HospitalLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        // Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is HospitalListSuccess) {
      context.read<DoctorBloc>().add(DSetHospitalListEvent(state.hospitals));
    } else if (state is HospitalFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _handleAddHospital() {
    Navigator.of(context).pop(AppStrings.openAddHospitalDialog);
  }

  void _onAddDoctor(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final phone = _phoneController.text.trim();
      final doctorRequest = AddDoctorReqModel(
        childId: childId,
        hospitalId: doctorBloc.selectedHospitalId ?? '',
        doctorName: _doctorNameController.text,
        specialty: _selectedSpecialtyIds,
        countryCode: phone.isEmpty ? "" : doctorBloc.selectedCountryCode,
        phone: phone,
        email: _emailController.text.trim().isEmpty ? null : _emailController.text.trim(),
        notes: _notesController.text,
      );
      context.read<DoctorBloc>().add(AddDoctorEvent(addDoctorReqModel: doctorRequest));
    }
  }
}
