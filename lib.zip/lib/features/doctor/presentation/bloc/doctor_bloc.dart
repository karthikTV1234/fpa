import 'package:bloc/bloc.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/doctor/data/repository/doctor_repository.dart';
import '../../../../core/errors/failure.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/response/doctor_list_res_model.dart';
import '../../data/model/response/doctor_speciality_list_res_model.dart';

/// BLOC
class DoctorBloc extends Bloc<DoctorEvent, DoctorState> {
  final DoctorRepository doctorRepository;
  bool isUIUpdated = false;
  String? selectedHospitalId;
  List<HospitalListData> hospitalList = [];
  String? selectedDoctorSpecialtyId;
  List<DoctorSpecialtyListData> doctorSpecialtyList = [];
  String selectedCountryCode = "+91";

  DoctorBloc({required this.doctorRepository}) : super(DoctorInitial()) {
    on<DSetHospitalListEvent>((event, emit) {
      isUIUpdated = true;
      hospitalList = event.hospitals;
      emit(DHospitalListSet(event.hospitals));
    });
    on<DSelectHospitalEvent>((event, emit) {
      isUIUpdated = true;
      selectedHospitalId = event.hospitalId;
      emit(DHospitalSelected(event.hospitalId));
    });
    on<DSetDoctorSpecialityListEvent>((event, emit) {
      isUIUpdated = true;
      doctorSpecialtyList = event.specialities;
      emit(DDoctorSpecialityListSet(event.specialities));
    });
    on<DSelectDoctorSpecialityEvent>((event, emit) {
      isUIUpdated = true;
      selectedDoctorSpecialtyId = event.doctorSpecialityId;
      emit(DDoctorSpecialitySelected(event.doctorSpecialityId));
    });
    on<SelectCountryCodeEvent>((event, emit) {
      isUIUpdated = true;
      selectedCountryCode = event.countryCode;
      emit(CountryCodeSelected(event.countryCode));
    });

    on<AddDoctorEvent>((event, emit) async {
      emit(DoctorLoading());
      final result = await doctorRepository.addDoctor(event.addDoctorReqModel);
      if (result.isSuccess) {
        emit(DoctorSuccess(
          message: result.data?.message ?? AppStrings.doctorAddedSuccessMessage,
        ));
      } else {
        emit(DoctorFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchDoctorListEvent>((event, emit) async {
      emit(DoctorLoading());
      final result = await doctorRepository.getDoctorList();
      if (result.isSuccess && result.data != null) {
        final DoctorListResModel resModel = result.data!;
        emit(DoctorListSuccess(resModel.data));
      } else {
        emit(DoctorFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchDoctorSpecialityListEvent>((event, emit) async {
      emit(DoctorLoading());
      final result = await doctorRepository.getDoctorSpecialtyList();
      if (result.isSuccess && result.data != null) {
        final DoctorSpecialtyListResModel resModel = result.data!;
        emit(DoctorSpecialityListSuccess(resModel.data));
      } else {
        emit(DoctorFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
  }
}
