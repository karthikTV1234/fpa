import 'package:equatable/equatable.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/request/add_doctor_req_model.dart';
import '../../data/model/response/doctor_speciality_list_res_model.dart';

/// EVENTS
abstract class DoctorEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddDoctorEvent extends DoctorEvent {
  final AddDoctorReqModel addDoctorReqModel;
  AddDoctorEvent({required this.addDoctorReqModel});
  @override
  List<Object?> get props => [addDoctorReqModel];
}
class FetchDoctorListEvent extends DoctorEvent {}
class FetchDoctorSpecialityListEvent extends DoctorEvent {}
class DSetHospitalListEvent extends DoctorEvent {
  final List<HospitalListData> hospitals;
  DSetHospitalListEvent(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class DSelectHospitalEvent extends DoctorEvent {
  final String hospitalId;
  DSelectHospitalEvent(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DSetDoctorSpecialityListEvent extends DoctorEvent {
  final List<DoctorSpecialtyListData> specialities;
  DSetDoctorSpecialityListEvent(this.specialities);
  @override
  List<Object?> get props => [specialities];
}
class DSelectDoctorSpecialityEvent extends DoctorEvent {
  final String doctorSpecialityId;
  DSelectDoctorSpecialityEvent(this.doctorSpecialityId);
  @override
  List<Object?> get props => [doctorSpecialityId];
}
class SelectCountryCodeEvent extends DoctorEvent {
  final String countryCode;
  SelectCountryCodeEvent(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}