import 'package:equatable/equatable.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/model/response/doctor_list_res_model.dart';
import '../../data/model/response/doctor_speciality_list_res_model.dart';

/// STATES
abstract class DoctorState extends Equatable {
  @override
  List<Object?> get props => [];
}
class DoctorInitial extends DoctorState {}
class DoctorLoading extends DoctorState {}
class DoctorSuccess extends DoctorState {
  final String message;
  DoctorSuccess({required this.message});
  @override
  List<Object?> get props => [message];
}
class DoctorListSuccess extends DoctorState {
  final List<DoctorListData> doctors;
  DoctorListSuccess(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class DoctorSpecialityListSuccess extends DoctorState {
  final List<DoctorSpecialtyListData> doctorsSpecialities;
  DoctorSpecialityListSuccess(this.doctorsSpecialities);
  @override
  List<Object?> get props => [doctorsSpecialities];
}
class DoctorFailure extends DoctorState {
  final String error;
  DoctorFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class DHospitalListSet extends DoctorState {
  final List<HospitalListData> hospitals;
  DHospitalListSet(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class DHospitalSelected extends DoctorState {
  final String hospitalId;
  DHospitalSelected(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DDoctorSpecialityListSet extends DoctorState {
  final List<DoctorSpecialtyListData> specialities;
  DDoctorSpecialityListSet(this.specialities);
  @override
  List<Object?> get props => [specialities];
}
class DDoctorSpecialitySelected extends DoctorState {
  final String doctorSpecialityId;
  DDoctorSpecialitySelected(this.doctorSpecialityId);
  @override
  List<Object?> get props => [doctorSpecialityId];
}
class CountryCodeSelected extends DoctorState {
  final String countryCode;
  CountryCodeSelected(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}
