import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';
import 'dart:io';

class UpdateVaccinationReqModel {
  final String childId;
  final String scheduledDate;
  final String vaccinatedDate;
  final String hospitalId;
  final String doctorId;
  final String vaccineNumber;
  final String reactions;
  final List<File> attachments;

  UpdateVaccinationReqModel({
    this.childId = '',
    this.scheduledDate = '',
    this.vaccinatedDate = '',
    this.hospitalId = '',
    this.doctorId = '',
    this.vaccineNumber = '',
    this.reactions = '',
    this.attachments = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'childId': childId,
      'scheduledDate': scheduledDate,
      'vaccinatedDate': vaccinatedDate,
      'hospitalId': hospitalId,
      'doctorId': doctorId,
      'vaccineNumber': vaccineNumber,
      'reactions': reactions,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());

    for (int i = 0; i < attachments.length; i++) {
      final file = attachments[i];
      final mimeType = lookupMimeType(file.path) ?? 'application/octet-stream';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'attachments',
          await MultipartFile.fromFile(
            file.path,
            filename: file.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }

    return formData;
  }
}
