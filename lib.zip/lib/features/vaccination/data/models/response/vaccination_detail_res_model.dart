class GetVaccinationsDetailResModel {
  final int statusCode;
  final String message;
  final VaccinationDetailData data;

  GetVaccinationsDetailResModel({
    this.statusCode = 0,
    this.message = '',
    VaccinationDetailData? data,
  }) : data = data ?? VaccinationDetailData();

  factory GetVaccinationsDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetVaccinationsDetailResModel();

    return GetVaccinationsDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: VaccinationDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class VaccinationDetailData {
  final String id;
  final String childId;
  final String vaccineName;
  final String scheduledDate;
  final String vaccinatedDate;
  final String vaccineNumber;
  final String hospitalId;
  final String doctorId;
  final String disease;
  final String reactions;
  final bool isVaccinated;
  final List<String> attachments;
  final String createdAt;
  final String updatedAt;
  final bool isDeleted;
  final String doctorName;
  final String hospitalName;

  VaccinationDetailData({
    this.id = '',
    this.childId = '',
    this.vaccineName = '',
    this.scheduledDate = '',
    this.vaccinatedDate = '',
    this.vaccineNumber = '',
    this.hospitalId = '',
    this.doctorId = '',
    this.disease = '',
    this.reactions = '',
    this.isVaccinated = false,
    this.attachments = const [],
    this.createdAt = '',
    this.updatedAt = '',
    this.isDeleted = false,
    this.doctorName = '',
    this.hospitalName = '',
  });

  factory VaccinationDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return VaccinationDetailData();

    return VaccinationDetailData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      vaccineName: json['vaccineName'] as String? ?? '',
      scheduledDate: json['scheduledDate'] as String? ?? '',
      vaccinatedDate: json['vaccinatedDate'] as String? ?? '',
      vaccineNumber: json['vaccineNumber'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      disease: json['disease'] as String? ?? '',
      reactions: json['reactions'] as String? ?? '',
      isVaccinated: json['isVaccinated'] as bool? ?? false,
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
      doctorName: json['doctorName'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
    );
  }
}