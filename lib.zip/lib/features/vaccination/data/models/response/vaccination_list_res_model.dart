class GetVaccinationsListResModel {
  final int statusCode;
  final String message;
  final List<VaccinationListData> data;

  GetVaccinationsListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetVaccinationsListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetVaccinationsListResModel();

    return GetVaccinationsListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => VaccinationListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class VaccinationListData {
  final String id;
  final String vaccineName;
  final String scheduledDate;
  final String vaccinatedDate;
  final String disease;
  final bool isVaccinated;

  VaccinationListData({
    this.id = '',
    this.vaccineName = '',
    this.scheduledDate = '',
    this.vaccinatedDate = '',
    this.disease = '',
    this.isVaccinated = false,
  });

  factory VaccinationListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return VaccinationListData();

    return VaccinationListData(
      id: json['id'] as String? ?? '',
      vaccineName: json['vaccineName'] as String? ?? '',
      scheduledDate: json['scheduledDate'] as String? ?? '',
      vaccinatedDate: json['vaccinatedDate'] as String? ?? '',
      disease: json['disease'] as String? ?? '',
      isVaccinated: json['isVaccinated'] as bool? ?? false,
    );
  }
}