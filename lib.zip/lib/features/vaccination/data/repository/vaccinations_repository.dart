import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../models/request/add_vaccination_req_model.dart';
import '../models/request/edit_vaccination_req_model.dart';
import '../models/response/vaccination_detail_res_model.dart';
import '../models/response/vaccination_list_res_model.dart';

class VaccinationsRepository {
  final Dio _dio;

  VaccinationsRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<CommonResModel>> addVaccination(AddVaccinationReqModel addVaccinationReqModel) async {
    String errorMessage = ErrorMessages.addVaccinationFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.createVaccination}';
      final formData = await addVaccinationReqModel.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addVaccinationRes = CommonResModel.fromJson(response.data);
        return Result.success(addVaccinationRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetVaccinationsListResModel>> getVaccinationList(String childId) async {
    String errorMessage = ErrorMessages.fetchVaccinationListFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.vaccinationList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final vaccinationListRes = GetVaccinationsListResModel.fromJson(response.data);
        return Result.success(vaccinationListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetVaccinationsDetailResModel>> getVaccinationDetails(String healthTrackerId) async {
    String errorMessage = ErrorMessages.fetchVaccinationDetailsFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.vaccinationDetails}/$healthTrackerId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.data != null && (response.statusCode == 200 || response.statusCode == 201)) {
        final childDetailRes = GetVaccinationsDetailResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateVaccinationDetails(UpdateVaccinationReqModel updateVaccinationReqModel, String vaccinationId) async {
    String errorMessage = ErrorMessages.updateVaccinationFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.updateVaccination}/$vaccinationId';
      final formData = await updateVaccinationReqModel.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final updateVaccinationRes = CommonResModel.fromJson(response.data);
        return Result.success(updateVaccinationRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteVaccination(String vaccinationId) async {
    String errorMessage = ErrorMessages.deleteVaccinationFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.deleteVaccination}/$vaccinationId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
