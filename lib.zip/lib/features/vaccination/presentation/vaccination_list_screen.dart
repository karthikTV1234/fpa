import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/common_card_item.dart';
import 'package:child_health_story/shared/widgets/common_list_view.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../data/models/response/vaccination_list_res_model.dart';
import 'bloc/vaccinations_events.dart';

class VaccinationListScreen extends StatefulWidget {
  const VaccinationListScreen({super.key});

  @override
  State<VaccinationListScreen> createState() => _VaccinationListScreenState();
}

class _VaccinationListScreenState extends State<VaccinationListScreen> {
  final TextEditingController _searchController = TextEditingController();
  late final VaccinationsBloc _vaccinationsBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _vaccinationsBloc = context.read<VaccinationsBloc>();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      _vaccinationsBloc.add(FetchVaccinationsListEvent(childId: childId));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _mapVaccinationsToUI(List<VaccinationListData> vaccines) {
    return vaccines.map((vaccine) {
      final isVaccinated = vaccine.isVaccinated;

      final formattedDate = AppUtils.formatDateOnly(
        isVaccinated ? vaccine.vaccinatedDate : vaccine.scheduledDate,
      );

      final subtitleText = isVaccinated
          ? "${AppStrings.vaccinatedDatePrefix}$formattedDate"
          : "${AppStrings.scheduledDatePrefix}$formattedDate";

      return {
        "id": vaccine.id,
        "category": vaccine.disease,
        "status": isVaccinated ? null : AppStrings.pendingStatus,
        "statusColor": isVaccinated ? null : AppColors.vLightOrangeColor,
        "title": vaccine.vaccineName,
        "subtitle": subtitleText,
      };
    }).toList();
  }




  @override
  Widget build(BuildContext context) {
    return BlocConsumer<VaccinationsBloc, VaccinationState>(
      listener: (context, state) {
        if (state is VaccinationListSuccess) {
          mappedList = _mapVaccinationsToUI(state.vaccinationsList);
          _vaccinationsBloc.filteredVaccinationsList = mappedList;
        }else if (state is VaccinationListSearchSuccess) {
          _vaccinationsBloc.filteredVaccinationsList = state.filteredList;
        }

        if (state is VaccinationsFailure) {
          CustomSnackBar(
            context: context,
            message: state.error,
            messageType: AppStrings.failure,
          ).show();
        }
      },
      builder: (context, state) {
        return  Stack(
            children:[
              ParentWidget(
                appbarTitle: AppStrings.vaccinationText,
                appbarTitleColor: AppColors.cblackColor,
                appbarColor: AppColors.clightGrayColor,
                appbarSubtitle: AppStrings.vaccinationDetailsText(
                    SharedPreferencesHelper.instance.getSelectedChildName()
                ),
                leadingWidget: IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(
                      Icons.arrow_back,
                      color: AppColors.cblackColor,
                    )),
                context: context,
                hasHeader: true,
                childWidget: ConstrainedBox(
                  constraints:
                  BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Column(
                        spacing: 8,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextWidgets.textWidget(
                                AppStrings.historyText, AppColors.cblackColor,
                                fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextInputWidgets.getTextField(
                              fillColor: AppColors.clightGrayColor,
                              textColor: AppColors.cblackColor,
                              hintText: AppStrings.searchVaccineText,
                              prefixIcon: Icon(Icons.search, color: Colors.grey,
                                  size: 15),
                              controller: _searchController,
                              keyboardType: TextInputType.text,
                              onChanged: (value) {
                                _vaccinationsBloc.add(SearchVaccinationsListEvent(
                                  textSearch: value,
                                  list: mappedList,
                                ));
                              },
                            ),
                          ),
                          Expanded(
                            child: CommonListView<Map<String, dynamic>>(
                              data: _vaccinationsBloc.filteredVaccinationsList,
                              padding: const EdgeInsets.all(16),
                              itemBuilder: (item) =>
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: CommonCardItem(
                                      id: item["id"],
                                      category: item["category"] ?? "",
                                      status: item["status"] ?? "",
                                      statusColor: item["statusColor"],
                                      title: item["title"] ?? "",
                                      subtitle: item["subtitle"] ?? "",
                                      onTap: (selectedId)  {
                                        _navigateToDetailScreen(context, selectedId);
                                      },
                                    ),
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                floatingActionButton: ButtonWidgets.floatingActionButton(
                  Icons.add, AppColors.cwhiteColor, AppColors.cprimaryColor, () async {
                  final result = await Navigator.pushNamed(
                    context,
                    PathConstants.addVaccinationScreen,
                  );
                  if (result == true) {
                    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
                    if (childId.isNotEmpty) {
                      _vaccinationsBloc.add(FetchVaccinationsListEvent(childId: childId));
                    }
                  }
                },
                ),
              ),
              Visibility(visible: state is VaccinationsLoading, child:Loader.showLoader(AppStrings.loading))
            ]
        );
      },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.vaccinationDetailScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _vaccinationsBloc.add(FetchVaccinationsListEvent(childId: childId));
      }
    }
  }


}
