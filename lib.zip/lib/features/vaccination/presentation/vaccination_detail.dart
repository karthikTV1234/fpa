import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/file_utils.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/file_attachments.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';



class VaccinationDetailScreen extends StatefulWidget {
  final String vaccinationId;
  const VaccinationDetailScreen({super.key, required this.vaccinationId});

  @override
  State<VaccinationDetailScreen> createState() => _VaccinationDetailScreenState();
}

class _VaccinationDetailScreenState extends State<VaccinationDetailScreen> {
  late VaccinationsBloc _vaccinationsBloc;
  bool _hasUpdated = false;

  @override
  void initState() {
    super.initState();
    _vaccinationsBloc = BlocProvider.of<VaccinationsBloc>(context);
    _vaccinationsBloc.add(
        FetchVaccinationByIdEvent(vaccinationId: widget.vaccinationId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<VaccinationsBloc, VaccinationState>(
      listener: _vaccinationBlocListener,
      builder: (context, state) {
        final vaccinationData = _vaccinationsBloc.isUIUpdated
            ? _vaccinationsBloc.vaccinationDetailData
            : null;
        return Stack(
          children: [
            ParentWidget(
              context: context,
              hasHeader: true,
              appbarColor: AppColors.lightGreyColor,
              appbarTitle: AppStrings.vaccinationDetails,
              appbarTitleColor: AppColors.cblackColor,
              leadingWidget: IconButton(
                onPressed: () {
                  if (_hasUpdated) {
                    Navigator.of(context).pop(true);
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(Icons.arrow_back),
              ),
              rightWidget: IconButton(
                onPressed: () async {
                  if (vaccinationData != null) {
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.editVaccinationScreen,
                      arguments: vaccinationData,
                    );
                    if (result == true) {
                      _vaccinationsBloc.add(FetchVaccinationByIdEvent(
                          vaccinationId: widget.vaccinationId));
                      _hasUpdated = true;
                    }
                  }
                },
                icon: const Icon(Icons.edit),
              ),
              childWidget: Padding(
                padding: const EdgeInsets.all(15),
                child: SingleChildScrollView(
                  child: Column(
                    spacing: 20,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 20,
                          children: [
                            ListviewCard(
                              icon: const Icon(Icons.vaccines),
                              title: AppStrings.vaccineNameText,
                              subTitle: vaccinationData?.vaccineName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.bug_report),
                              title: AppStrings.diseaseText,
                              subTitle: vaccinationData?.disease ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range),
                              title: AppStrings.scheduledDateText,
                              subTitle: AppUtils.formatDateOnly(
                                vaccinationData?.scheduledDate ?? ''),
                            ),
                            if ((vaccinationData?.vaccinatedDate ?? '').isNotEmpty)
                              ListviewCard(
                                icon: const Icon(Icons.event_available),
                                title: AppStrings.vaccinatedDateText,
                                subTitle: AppUtils.formatDateOnly(
                                  vaccinationData!.vaccinatedDate),
                              ),
                            ListviewCard(
                              icon: const Icon(Icons.local_hospital),
                              title: AppStrings.hospitalNameText,
                              subTitle: vaccinationData?.hospitalName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.person),
                              title: AppStrings.doctorText,
                              subTitle: vaccinationData?.doctorName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.confirmation_number),
                              title: AppStrings.vaccineNumberText,
                              subTitle: vaccinationData?.vaccineNumber ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.report_problem),
                              title: AppStrings.reactionsText,
                              subTitle: vaccinationData?.reactions ?? '',
                              hasDivider: false,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 10,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidgets.textWidget(
                              AppStrings.attachmentsTxt,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                            FileAttachments(
                              files: vaccinationData?.attachments ?? [],
                              onFileTap: (filePath) {
                                String path  = AppUtils.buildImageFullUrl(filePath) ?? '';
                                FileUtils.previewOrDownloadFile(context, path);
                              },
                            ),
                          ],
                        ),
                      ),
                      ButtonWidgets.elevatedButton(
                        AppStrings.deleteTxt,
                        AppColors.lightRedColor,
                        AppColors.cwhiteColor,
                            () => _onDelete(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        radius: 7,
                        width: MediaQuery.of(context).size.width,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: state is VaccinationsLoading,
              child: Loader.showLoader(AppStrings.loading),
            ),
          ],
        );
      },

    );
  }

  void _vaccinationBlocListener(BuildContext context, VaccinationState state) {
    if (state is VaccinationsSuccess) {
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
      Navigator.of(context).pop(true);
    }
    else if (state is VaccinationsFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onDelete(BuildContext context) async {
    if (widget.vaccinationId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteVaccinationTitle,
        contentText: AppStrings.deleteVaccinationConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          _vaccinationsBloc.add(DeleteVaccinationEvent(vaccinationId: widget.vaccinationId));
        },
      );
    }
  }

}


