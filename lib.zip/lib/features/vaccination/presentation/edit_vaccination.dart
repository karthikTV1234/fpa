import 'dart:io';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_bloc.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/strings/app_strings.dart';
import '../../../core/constants/strings/validation_messages.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/app_validators.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/dropdown/custom_selection_drop_down.dart';
import '../../../shared/widgets/file_attachments_widget.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/parent_widget.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../doctor/presentation/add_doctor_screen.dart';
import '../../doctor/presentation/bloc/doctor_bloc.dart';
import '../../hospital/data/model/hospital_model.dart';
import '../../hospital/presentation/add_hospital_screen.dart';
import '../../hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

import '../data/models/request/edit_vaccination_req_model.dart';
import '../data/models/response/vaccination_detail_res_model.dart';

class EditVaccinationScreen extends StatefulWidget {
  final VaccinationDetailData vaccinationDetailData;

  const EditVaccinationScreen({
    super.key,
    required this.vaccinationDetailData,
  });

  @override
  State<EditVaccinationScreen> createState() => _EditVaccinationScreenState();
}

class _EditVaccinationScreenState extends State<EditVaccinationScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _vaccineNameController = TextEditingController();
  final TextEditingController _diseaseController = TextEditingController();
  final TextEditingController _scheduledDateController = TextEditingController();
  final TextEditingController _vaccinatedDateController = TextEditingController();
  final TextEditingController _hospitalController = TextEditingController();
  final TextEditingController _doctorController = TextEditingController();
  final TextEditingController _vaccineNumberController = TextEditingController();
  final TextEditingController _reactionsController = TextEditingController();
  late VaccinationsBloc _vaccinationsBloc;


  @override
  void dispose() {
    _vaccineNameController.dispose();
    _diseaseController.dispose();
    _scheduledDateController.dispose();
    _vaccinatedDateController.dispose();
    _hospitalController.dispose();
    _doctorController.dispose();
    _vaccineNumberController.dispose();
    _reactionsController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _vaccinationsBloc = BlocProvider.of<VaccinationsBloc>(context);
    context.read<HospitalBloc>().add(FetchHospitalListEvent());
    context.read<DoctorBloc>().add(FetchDoctorListEvent());
    _loadVaccinationData();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<DoctorBloc, DoctorState>(
          listener: _doctorBlocListener,
        ),
        BlocListener<HospitalBloc, HospitalState>(
          listener: _hospitalBlocListener,
        ),
      ],
      child: BlocConsumer<VaccinationsBloc, VaccinationState>(
          listener: _vaccinationBlocListener,
          builder: (context, state) {
            return Stack(
                children: [
                  ParentWidget(
                    hasHeader: true,
                    appbarColor: AppColors.lightGreyColor,
                    appbarTitle: AppStrings.editVaccinationText,
                    appbarTitleColor: AppColors.cblackColor,
                    context: context,
                    leadingWidget: IconButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          color: AppColors.cblackColor,
                        )),
                    childWidget: Padding(
                      padding: const EdgeInsets.all(20),
                      child: SingleChildScrollView(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            spacing: 16,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.vaccineNameLabel,
                                hintText: AppStrings.vaccineNameHint,
                                TextInputType.text,
                                TextInputAction.next,
                                _vaccineNameController,
                                enabled: false,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                false,
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value!)) {
                                    return ValidationMessages
                                        .vaccineNameRequired;
                                  }
                                  return null;
                                },
                              ),
                              TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.diseaseLabel,
                                hintText: AppStrings.diseaseHint,
                                TextInputType.text,
                                TextInputAction.next,
                                _diseaseController,
                                enabled: false,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                false,
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value!)) {
                                    return ValidationMessages.diseaseRequired;
                                  }
                                  return null;
                                },
                              ),
                              TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.scheduledDateLabel,
                                TextInputType.datetime,
                                TextInputAction.next,
                                _scheduledDateController,
                                false,
                                readOnly: true,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                trailingIcon: Icon(Icons.date_range),
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value!)) {
                                    return ValidationMessages
                                        .scheduledDateRequired;
                                  }
                                  return null;
                                },
                                customTap: () async {
                                  final DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(2000),
                                    lastDate: DateTime(2100),
                                  );
                                  if (pickedDate != null) {
                                    _scheduledDateController.text =
                                        AppUtils.formatDateFromDatePicker(pickedDate);
                                  }
                                },
                              ),
                              TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.vaccinatedDateWithoutAsteriskLabel,
                                TextInputType.datetime,
                                TextInputAction.next,
                                _vaccinatedDateController,
                                false,
                                readOnly: true,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                trailingIcon: Icon(Icons.date_range),
                                customTap: () async {
                                  final DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(2000),
                                    lastDate: DateTime(2100),
                                  );
                                  if (pickedDate != null) {
                                    _vaccinatedDateController.text =
                                        AppUtils.formatDateFromDatePicker(pickedDate);
                                  }
                                },
                              ),
                              CustomSingleSelectionDropdown<HospitalListData>(
                                controller: _hospitalController,
                                items: _vaccinationsBloc.isUIUpdated
                                    ? _vaccinationsBloc.hospitalList
                                    : [],
                                displayValue: (hospital) =>
                                hospital.hospitalName,
                                labelText: AppStrings.hospitalLabel,
                                hintText: AppStrings.hospitalHint,
                                headTitle: AppStrings.availableHospitals,
                                onSelected: (selectedHospital) {
                                  _hospitalController.text =
                                      selectedHospital.hospitalName;
                                  _vaccinationsBloc.add(
                                      SelectHospitalEvent(selectedHospital.id));
                                },
                                emptyStateText: AppStrings.noHospitalAvailable,
                                addButtonText: AppStrings.addNewHospital,
                                onAddPressed: _handleAddHospital,
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value!)) {
                                    return ValidationMessages.hospitalRequired;
                                  }
                                  return null;
                                },
                              ),
                              CustomSingleSelectionDropdown<DoctorListData>(
                                controller: _doctorController,
                                items: _vaccinationsBloc.isUIUpdated
                                    ? _vaccinationsBloc.doctorList
                                    : [],
                                displayValue: (doctor) => doctor.doctorName,
                                labelText: AppStrings.doctorLabel,
                                hintText: AppStrings.doctorHint,
                                headTitle: AppStrings.availableDoctors,
                                onSelected: (selectedDoctor) {
                                  _doctorController.text =
                                      selectedDoctor.doctorName;
                                  _vaccinationsBloc.add(
                                      SelectDoctorEvent(selectedDoctor.id));
                                },
                                emptyStateText: AppStrings.noDoctorAvailable,
                                addButtonText: AppStrings.addNewDoctor,
                                onAddPressed: _handleAddDoctor,
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value!)) {
                                    return ValidationMessages.doctorRequired;
                                  }
                                  return null;
                                },
                              ),
                              TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.vaccineNumberLabel,
                                hintText: AppStrings.vaccinatedDateHint,
                                TextInputType.text,
                                TextInputAction.next,
                                _vaccineNumberController,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                false,
                              ),
                              TextInputWidgets.textFormField(
                                  maxLines: 4,
                                  fillColor: AppColors.appBackGroundColor,
                                  AppStrings.reactionsLabel,
                                  hintText: AppStrings.reactionsHint,
                                  TextInputType.text,
                                  TextInputAction.done,
                                  _reactionsController,
                                  enabledBorderColor: AppColors
                                      .cmediumGrayColor,
                                  focusedBorderColor: AppColors
                                      .cmediumGrayColor,
                                  false
                              ),
                              FileAttachmentsWidget(
                                maxFileSizeMB: AppStrings.maxFileSize,
                                supportedTypes: AppStrings.supportedFileTypes,
                                existingAttachments: widget.vaccinationDetailData.attachments,
                                selectedNewFiles: _vaccinationsBloc.isUIUpdated ? _vaccinationsBloc.newAttachments : [],
                                onFileSelected: (file) {
                                  _vaccinationsBloc.add(VaccinationAddNewAttachmentEvent(file));
                                },
                                onFileDeleted: (file) {
                                  _vaccinationsBloc.add(VaccinationRemoveNewAttachmentEvent(file));
                                },
                              ),
                              ButtonWidgets.elevatedButton(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                width: AppUtils.getScreenWidth(context),
                                radius: 7,
                                height: 50,
                                AppStrings.updateTxt,
                                AppColors.cprimaryColor,
                                AppColors.cwhiteColor,
                                    () {
                                      _onUpdateVaccination(context);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Visibility(visible: state is VaccinationsLoading,
                      child: Loader.showLoader(AppStrings.loading))
                ]
            );
          }
      ),
    );
  }

  void _loadVaccinationData() {
    final data = widget.vaccinationDetailData;
    _vaccineNameController.text = data.vaccineName;
    _diseaseController.text = data.disease;
    _scheduledDateController.text = data.scheduledDate;
    _vaccinatedDateController.text = data.vaccinatedDate;
    _vaccineNumberController.text = data.vaccineNumber;
    _reactionsController.text = data.reactions;
  }

  void _handleAddHospital() async {
    final result = await AddHospitalDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<HospitalBloc>().add(FetchHospitalListEvent());
    }
  }
  void _handleAddDoctor() async{
    final result = await AddDoctorDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<DoctorBloc>().add(FetchDoctorListEvent());
    }else if (result == 'open_add_hospital') {
      _handleAddHospital();
    }
  }

  void _doctorBlocListener(BuildContext context, DoctorState state) {
    if (state is DoctorLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        //Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is DoctorListSuccess) {
      final doctors = state.doctors;
      _vaccinationsBloc.add(SetDoctorListEvent(doctors));
      final matched = doctors.firstWhere(
            (element) => element.id == widget.vaccinationDetailData.doctorId,
        orElse: () => DoctorListData(doctorName: '', id: ''),
      );
      _vaccinationsBloc.add(SelectDoctorEvent(matched.id));
      _doctorController.text = matched.doctorName;
    } else if (state is DoctorFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _hospitalBlocListener(BuildContext context, HospitalState state) {
    if (state is HospitalLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        // Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is HospitalListSuccess) {
      final hospitals = state.hospitals;
      _vaccinationsBloc.add(SetHospitalListEvent(state.hospitals));
      final matched = hospitals.firstWhere(
            (element) => element.id == widget.vaccinationDetailData.hospitalId,
        orElse: () => HospitalListData(hospitalName: '', id: ''),
      );
      _vaccinationsBloc.add(SelectHospitalEvent(matched.id));
      _hospitalController.text = matched.hospitalName;
    } else if (state is HospitalFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _vaccinationBlocListener(BuildContext context, VaccinationState state) {
    if (state is VaccinationsSuccess) {
      Navigator.of(context).pop(true);
    } else if (state is VaccinationsFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onUpdateVaccination(BuildContext context) async {
    if (_formKey.currentState!.validate()) {

      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final List<XFile> newFiles = _vaccinationsBloc.isUIUpdated
          ? _vaccinationsBloc.newAttachments
          : [];
      final List<File> attachmentFiles = newFiles.map((xfile) => File(xfile.path)).toList();

      final requestModel = UpdateVaccinationReqModel(
        childId: childId,
        scheduledDate: _scheduledDateController.text.trim(),
        vaccinatedDate: _vaccinatedDateController.text.trim(),
        hospitalId: _vaccinationsBloc.selectedHospitalId ?? '',
        doctorId: _vaccinationsBloc.selectedDoctorId ?? '',
        vaccineNumber: _vaccineNumberController.text.trim(),
        reactions: _reactionsController.text.trim(),
        attachments: attachmentFiles,
      );
      _vaccinationsBloc.add(
        UpdateVaccinationEvent(
            vaccinationId: widget.vaccinationDetailData.id,
            updateVaccinationReqModel: requestModel
        ),
      );
    }
  }


}
