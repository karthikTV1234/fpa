import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/request/add_vaccination_req_model.dart';
import '../../data/models/request/edit_vaccination_req_model.dart';

/// EVENTS
abstract class VaccinationsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddVaccinationEvent extends VaccinationsEvent with EquatableMixin {
  final AddVaccinationReqModel addVaccinationReqModel;
  AddVaccinationEvent({
    required this.addVaccinationReqModel
  });
  @override
  List<Object?> get props => [addVaccinationReqModel];
}
class FetchVaccinationsListEvent extends VaccinationsEvent {
  final String childId;
  FetchVaccinationsListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class SearchVaccinationsListEvent extends VaccinationsEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchVaccinationsListEvent({required this.textSearch, required this.list});
}
class FetchVaccinationByIdEvent extends VaccinationsEvent {
  final String vaccinationId;
  FetchVaccinationByIdEvent({required this.vaccinationId});
  @override
  List<Object?> get props => [vaccinationId];
}
class UpdateVaccinationEvent extends VaccinationsEvent {
  final String vaccinationId;
  final UpdateVaccinationReqModel updateVaccinationReqModel;
  UpdateVaccinationEvent({
    required this.vaccinationId,
    required this.updateVaccinationReqModel,
  });
  @override
  List<Object?> get props => [vaccinationId, updateVaccinationReqModel];
}
class DeleteVaccinationEvent extends VaccinationsEvent {
  final String vaccinationId;
  DeleteVaccinationEvent({required this.vaccinationId});
  @override
  List<Object?> get props => [vaccinationId];
}
class SetHospitalListEvent extends VaccinationsEvent {
  final List<HospitalListData> hospitals;
  SetHospitalListEvent(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class SelectHospitalEvent extends VaccinationsEvent {
  final String hospitalId;
  SelectHospitalEvent(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class SetDoctorListEvent extends VaccinationsEvent {
  final List<DoctorListData> doctors;
  SetDoctorListEvent(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class SelectDoctorEvent extends VaccinationsEvent {
  final String doctorId;
  SelectDoctorEvent(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class VaccinationAddNewAttachmentEvent extends VaccinationsEvent {
  final XFile file;
  VaccinationAddNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class VaccinationRemoveNewAttachmentEvent extends VaccinationsEvent {
  final XFile file;
  VaccinationRemoveNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class ClearVaccinationFormEvent extends VaccinationsEvent {}