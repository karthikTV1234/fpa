import 'package:child_health_story/features/vaccination/data/repository/vaccinations_repository.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_events.dart';
import 'package:child_health_story/features/vaccination/presentation/bloc/vaccinations_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/vaccination_detail_res_model.dart';
import '../../data/models/response/vaccination_list_res_model.dart';

/// BLOC
class VaccinationsBloc extends Bloc<VaccinationsEvent, VaccinationState> {
  List<Map<String, dynamic>> filteredVaccinationsList = [];
  final VaccinationsRepository vaccinationsRepository;
  bool isUIUpdated = false;
  String? selectedHospitalId;
  List<HospitalListData> hospitalList = [];
  String? selectedDoctorId;
  List<DoctorListData> doctorList = [];
  List<XFile> newAttachments = [];
  VaccinationDetailData? vaccinationDetailData;

  VaccinationsBloc({required this.vaccinationsRepository}) : super(VaccinationsInitial()) {
    on<SetHospitalListEvent>((event, emit) {
      hospitalList = event.hospitals;
      isUIUpdated = true;
      emit(HospitalListSet(event.hospitals));
    });
    on<SelectHospitalEvent>((event, emit) {
      isUIUpdated = true;
      selectedHospitalId = event.hospitalId;
      emit(HospitalSelected(event.hospitalId));
    });
    on<SetDoctorListEvent>((event, emit) {
      doctorList = event.doctors;
      isUIUpdated = true;
      emit(DoctorListSet(event.doctors));
    });
    on<SelectDoctorEvent>((event, emit) {
      isUIUpdated = true;
      selectedDoctorId = event.doctorId;
      emit(DoctorSelected(event.doctorId));
    });
    on<VaccinationAddNewAttachmentEvent>((event, emit) {
      newAttachments.add(event.file);
      isUIUpdated = true;
      emit(VaccinationsAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });
    on<VaccinationRemoveNewAttachmentEvent>((event, emit) {
      newAttachments.removeWhere((f) => f.path == event.file.path);
      isUIUpdated = true;
      newAttachments = List<XFile>.from(newAttachments);
      emit(VaccinationsAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<SearchVaccinationsListEvent>((event, emit) {
      if (event.textSearch.trim().isEmpty) {
        filteredVaccinationsList = event.list;
      } else {
        filteredVaccinationsList = event.list.where((element) {
          final title = (element["title"] ?? "").toLowerCase();
          return title.contains(event.textSearch.toLowerCase());
        }).toList();
      }
      emit(VaccinationListSearchSuccess(filteredVaccinationsList));
    });
    on<AddVaccinationEvent>((event, emit) async {
      emit(VaccinationsLoading());
      final result = await vaccinationsRepository.addVaccination(
          event.addVaccinationReqModel
      );
      if (result.isSuccess) {
        emit(VaccinationsSuccess(message: result.data?.message ?? AppStrings.vaccinationAddedSuccessMessage));
      } else {
        emit(VaccinationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchVaccinationsListEvent>((event, emit) async {
      emit(VaccinationsLoading());
      final result = await vaccinationsRepository.getVaccinationList(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetVaccinationsListResModel resModel = result.data!;
        emit(VaccinationListSuccess(resModel.data));
      } else {
        emit(VaccinationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchVaccinationByIdEvent>((event, emit) async {
      emit(VaccinationsLoading());
      final result = await vaccinationsRepository.getVaccinationDetails(event.vaccinationId);
      if (result.isSuccess && result.data != null) {
        final GetVaccinationsDetailResModel resModel = result.data!;
        vaccinationDetailData = resModel.data;
        isUIUpdated = true;
        emit(VaccinationByIdSuccess(resModel.data));
      } else {
        emit(VaccinationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateVaccinationEvent>((event, emit) async {
      emit(VaccinationsLoading());
      final result = await vaccinationsRepository.updateVaccinationDetails(
          event.updateVaccinationReqModel,
          event.vaccinationId
      );
      if (result.isSuccess) {
        emit(VaccinationsSuccess(message: result.data?.message ?? AppStrings.vaccinationUpdateSuccessMessage));
      } else {
        emit(VaccinationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteVaccinationEvent>((event, emit) async {
      emit(VaccinationsLoading());
      final result = await vaccinationsRepository.deleteVaccination(event.vaccinationId);
      if (result.isSuccess && result.data != null) {
        emit(VaccinationsSuccess(message: result.data?.message ??  AppStrings.vaccinationDeleteSuccessMessage));
      } else {
        emit(VaccinationsFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearVaccinationFormEvent>((event, emit) {
      hospitalList.clear();
      selectedHospitalId = null;
      doctorList.clear();
      selectedDoctorId = null;
      newAttachments.clear();
      isUIUpdated = false;
      emit(VaccinationsInitial());
    });
  }
}
