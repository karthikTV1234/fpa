import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/vaccination_detail_res_model.dart';
import '../../data/models/response/vaccination_list_res_model.dart';

/// STATES
abstract class VaccinationState extends Equatable {
  @override
  List<Object?> get props => [];
}
class VaccinationsInitial extends VaccinationState {}
class VaccinationsLoading extends VaccinationState {}
class VaccinationsSuccess extends VaccinationState {
  final String message;
  VaccinationsSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class VaccinationListSuccess extends VaccinationState {
  final List<VaccinationListData> vaccinationsList;
  VaccinationListSuccess(this.vaccinationsList);
  @override
  List<Object?> get props => [vaccinationsList];
}
class VaccinationListSearchSuccess extends VaccinationState {
  final List<Map<String, dynamic>> filteredList;
  VaccinationListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class VaccinationByIdSuccess extends VaccinationState {
  final VaccinationDetailData? medicationData;
  VaccinationByIdSuccess(this.medicationData);
  @override
  List<Object?> get props => [medicationData];
}
class VaccinationsFailure extends VaccinationState {
  final String error;
  VaccinationsFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class HospitalListSet extends VaccinationState {
  final List<HospitalListData> hospitals;
  HospitalListSet(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class HospitalSelected extends VaccinationState {
  final String hospitalId;
  HospitalSelected(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DoctorListSet extends VaccinationState {
  final List<DoctorListData> doctors;
  DoctorListSet(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class DoctorSelected extends VaccinationState {
  final String doctorId;
  DoctorSelected(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class VaccinationsAttachmentsUpdated extends VaccinationState with EquatableMixin {
  final List<XFile> attachments;
  VaccinationsAttachmentsUpdated(this.attachments);
  @override
  List<Object?> get props => [attachments];
}
class VaccinationFormReset extends VaccinationState {}
