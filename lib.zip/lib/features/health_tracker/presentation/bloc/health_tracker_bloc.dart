import 'package:child_health_story/features/health_tracker/data/repository/health_tracker_repository.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../data/models/response/health_tracker_detail_res_model.dart';
import '../../data/models/response/health_tracker_list_res_model.dart';


/// BLOC
class HealthTrackerBloc extends Bloc<HealthTrackerEvent, HealthTrackerState> {
  List<Map<String, dynamic>> filteredHealthTrackerList = [];
  final HealthTrackerRepository healthTrackerRepository;
  bool isUIUpdated = false;
  List<XFile> newAttachments = [];
  HealthRecordDetailData? healthRecordDetailData;

  HealthTrackerBloc({required this.healthTrackerRepository}) : super(HealthTrackerInitial()) {
    on<HealthAddNewAttachmentEvent>((event, emit) {
      newAttachments.add(event.file);
      isUIUpdated = true;
      emit(HealthTrackerAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });
    on<HealthRemoveNewAttachmentEvent>((event, emit) {
      newAttachments.removeWhere((f) => f.path == event.file.path);
      isUIUpdated = true;
      newAttachments = List<XFile>.from(newAttachments);
      emit(HealthTrackerAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<SearchHealthTrackerListEvent>((event, emit) {
      if (event.textSearch.trim().isEmpty) {
        filteredHealthTrackerList = event.list;
      } else {
        filteredHealthTrackerList = event.list.where((element) {
          final title = (element["title"] ?? "").toLowerCase();
          return title.contains(event.textSearch.toLowerCase());
        }).toList();
      }
      emit(HealthTrackerListSearchSuccess(filteredHealthTrackerList));
    });
    on<AddHealthTrackerEvent>((event, emit) async {
      emit(HealthTrackerLoading());
      final result = await healthTrackerRepository.addHealthRecord(
          event.addHealthTrackerReqModel
      );
      if (result.isSuccess) {
        emit(HealthTrackerSuccess(message: result.data?.message ?? AppStrings.healthRecordAddedSuccessMessage));
      } else {
        emit(HealthTrackerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchHealthTrackerListEvent>((event, emit) async {
      emit(HealthTrackerLoading());
      final result = await healthTrackerRepository.getHealthRecordList(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetHealthRecordsListResModel resModel = result.data!;
        emit(HealthTrackerListSuccess(resModel.data));
      } else {
        emit(HealthTrackerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchHealthTrackerByIdEvent>((event, emit) async {
      emit(HealthTrackerLoading());
      final result = await healthTrackerRepository.getHealthRecordDetails(event.healthTrackerId);
      if (result.isSuccess && result.data != null) {
        final GetHealthRecordDetailResModel resModel = result.data!;
        healthRecordDetailData = resModel.data;
        isUIUpdated = true;
        emit(HealthTrackerByIdSuccess(resModel.data));
      } else {
        emit(HealthTrackerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateHealthTrackerEvent>((event, emit) async {
      emit(HealthTrackerLoading());
      final result = await healthTrackerRepository.updateHealthRecordDetails(
          event.updateHealthRecordReqModel,
          event.healthTrackerId
      );
      if (result.isSuccess) {
        emit(HealthTrackerSuccess(message: result.data?.message ?? AppStrings.healthRecordUpdateSuccessMessage));
      } else {
        emit(HealthTrackerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteHealthTrackerEvent>((event, emit) async {
      emit(HealthTrackerLoading());
      final result = await healthTrackerRepository.deleteHealthRecord(event.healthTrackerId);
      if (result.isSuccess && result.data != null) {
        emit(HealthTrackerSuccess(message: result.data?.message ??  AppStrings.healthRecordDeleteSuccessMessage));
      } else {
        emit(HealthTrackerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearHealthTrackerFormEvent>((event, emit) {
      newAttachments.clear();
      isUIUpdated = false;
      emit(HealthTrackerInitial());
    });
  }
}
