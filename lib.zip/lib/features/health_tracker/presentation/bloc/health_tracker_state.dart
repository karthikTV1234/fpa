import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../data/models/response/health_tracker_detail_res_model.dart';
import '../../data/models/response/health_tracker_list_res_model.dart';

/// STATES
abstract class HealthTrackerState extends Equatable {
  @override
  List<Object?> get props => [];
}
class HealthTrackerInitial extends HealthTrackerState {}
class HealthTrackerLoading extends HealthTrackerState {}
class HealthTrackerSuccess extends HealthTrackerState {
  final String message;
  HealthTrackerSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class HealthTrackerListSuccess extends HealthTrackerState {
  final List<HealthRecordListData> healthTrackerList;
  HealthTrackerListSuccess(this.healthTrackerList);
  @override
  List<Object?> get props => [healthTrackerList];
}
class HealthTrackerListSearchSuccess extends HealthTrackerState {
  final List<Map<String, dynamic>> filteredList;
  HealthTrackerListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class HealthTrackerByIdSuccess extends HealthTrackerState {
  final HealthRecordDetailData? medicationData;
  HealthTrackerByIdSuccess(this.medicationData);
  @override
  List<Object?> get props => [medicationData];
}
class HealthTrackerFailure extends HealthTrackerState {
  final String error;
  HealthTrackerFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class HealthTrackerAttachmentsUpdated extends HealthTrackerState with EquatableMixin {
  final List<XFile> attachments;
  HealthTrackerAttachmentsUpdated(this.attachments);
  @override
  List<Object?> get props => [attachments];
}
class VaccinationFormReset extends HealthTrackerState {}
