import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../data/models/request/add_health_tracker_req_model.dart';
import '../../data/models/request/edit_health_tracker_req_model.dart';

/// EVENTS
abstract class HealthTrackerEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddHealthTrackerEvent extends HealthTrackerEvent with EquatableMixin {
  final AddHealthRecordReqModel addHealthTrackerReqModel;
  AddHealthTrackerEvent({
    required this.addHealthTrackerReqModel
  });
  @override
  List<Object?> get props => [addHealthTrackerReqModel];
}
class FetchHealthTrackerListEvent extends HealthTrackerEvent {
  final String childId;
  FetchHealthTrackerListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class SearchHealthTrackerListEvent extends HealthTrackerEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchHealthTrackerListEvent({required this.textSearch, required this.list});
}
class FetchHealthTrackerByIdEvent extends HealthTrackerEvent {
  final String healthTrackerId;
  FetchHealthTrackerByIdEvent({required this.healthTrackerId});
  @override
  List<Object?> get props => [healthTrackerId];
}
class UpdateHealthTrackerEvent extends HealthTrackerEvent {
  final String healthTrackerId;
  final UpdateHealthRecordReqModel updateHealthRecordReqModel;
  UpdateHealthTrackerEvent({
    required this.healthTrackerId,
    required this.updateHealthRecordReqModel,
  });
  @override
  List<Object?> get props => [healthTrackerId, updateHealthRecordReqModel];
}
class DeleteHealthTrackerEvent extends HealthTrackerEvent {
  final String healthTrackerId;
  DeleteHealthTrackerEvent({required this.healthTrackerId});
  @override
  List<Object?> get props => [healthTrackerId];
}
class HealthAddNewAttachmentEvent extends HealthTrackerEvent {
  final XFile file;
  HealthAddNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class HealthRemoveNewAttachmentEvent extends HealthTrackerEvent {
  final XFile file;
  HealthRemoveNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class ClearHealthTrackerFormEvent extends HealthTrackerEvent {}