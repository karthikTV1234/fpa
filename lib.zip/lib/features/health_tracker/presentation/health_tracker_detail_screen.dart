import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/file_utils.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/file_attachments.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';


class HealthTrackerDetailScreen extends StatefulWidget {
  final String healthTrackerId;
  const HealthTrackerDetailScreen({super.key, required this.healthTrackerId});

  @override
  State<HealthTrackerDetailScreen> createState() => _HealthTrackerDetailScreenState();
}

class _HealthTrackerDetailScreenState extends State<HealthTrackerDetailScreen> {
  late HealthTrackerBloc _healthTrackerBloc;
  bool _hasUpdated = false;

  @override
  void initState() {
    super.initState();
    _healthTrackerBloc = BlocProvider.of<HealthTrackerBloc>(context);
    _healthTrackerBloc.add(
        FetchHealthTrackerByIdEvent(healthTrackerId: widget.healthTrackerId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HealthTrackerBloc, HealthTrackerState>(
      listener: (context, state) {
      if (state is HealthTrackerSuccess) {
        CustomSnackBar(
          context: context,
          message: state.message,
          messageType: AppStrings.success,
        ).show();
        Navigator.of(context).pop(true);
      }
      else if (state is HealthTrackerFailure) {
        CustomSnackBar(
          context: context,
          message: state.error,
          messageType: AppStrings.failure,
        ).show();
      }
    },
      builder: (context, state) {
        final healthTrackerData = _healthTrackerBloc.isUIUpdated
            ? _healthTrackerBloc.healthRecordDetailData
            : null;
        return Stack(
          children: [
            ParentWidget(
              context: context,
              hasHeader: true,
              appbarColor: AppColors.lightGreyColor,
              appbarTitle: AppStrings.healthTrackerDetails,
              appbarTitleColor: AppColors.cblackColor,
              leadingWidget: IconButton(
                onPressed: () {
                  if (_hasUpdated) {
                    Navigator.of(context).pop(true);
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(Icons.arrow_back),
              ),
              rightWidget: IconButton(
                onPressed: () async {
                  if (healthTrackerData != null) {
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.editHealthTrackerScreen,
                      arguments: healthTrackerData,
                    );
                    if (result == true) {
                      _healthTrackerBloc.add(FetchHealthTrackerByIdEvent(
                          healthTrackerId: widget.healthTrackerId));
                      _hasUpdated = true;
                    }
                  }
                },
                icon: const Icon(Icons.edit),
              ),
              childWidget: Padding(
                padding: const EdgeInsets.all(15),
                child: SingleChildScrollView(
                  child: Column(
                    spacing: 20,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 20,
                          children: [
                            ListviewCard(
                              icon: const Icon(Icons.sick),
                              title: AppStrings.conditionNameLabelDetail,
                              subTitle: healthTrackerData?.conditionName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range_outlined),
                              title: AppStrings.dateLabelDetail,
                              subTitle: AppUtils.formatDateOnly(
                                healthTrackerData?.dateOfEntry ?? ''),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.thermostat),
                              title: AppStrings.temperatureLabelDetail,
                              subTitle: (healthTrackerData?.temperature.isNotEmpty ?? false)
                                  ? '${healthTrackerData!.temperature} ${AppStrings.degreeF}'
                                  : '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.favorite),
                              title: AppStrings.heartRateLabelDetail,
                              subTitle: healthTrackerData?.heartRate ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.air),
                              title: AppStrings.respiratoryLabelDetail,
                              subTitle: healthTrackerData?.respiratoryRate ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.notes),
                              title: AppStrings.healthTrackerNotesLabelDetail,
                              subTitle: healthTrackerData?.notes ?? '',
                              hasDivider: false,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 10,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidgets.textWidget(
                              AppStrings.attachmentsTxt,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                            FileAttachments(
                              files: healthTrackerData?.attachments ?? [],
                              onFileTap: (filePath) {
                                String path  = AppUtils.buildImageFullUrl(filePath) ?? '';
                                FileUtils.previewOrDownloadFile(context, path);
                              },
                            ),
                          ],
                        ),
                      ),
                      ButtonWidgets.elevatedButton(
                        AppStrings.deleteTxt,
                        AppColors.lightRedColor,
                        AppColors.cwhiteColor,
                            () => _onDelete(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        radius: 7,
                        width: MediaQuery.of(context).size.width,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: state is HealthTrackerLoading,
              child: Loader.showLoader(AppStrings.loading),
            ),
          ],
        );
      },

    );
  }

  void _onDelete(BuildContext context) async {
    if (widget.healthTrackerId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteHealthTrackerTitle,
        contentText: AppStrings.deleteHealthTrackerConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          _healthTrackerBloc.add(DeleteHealthTrackerEvent(healthTrackerId: widget.healthTrackerId));
        },
      );
    }
  }


}


