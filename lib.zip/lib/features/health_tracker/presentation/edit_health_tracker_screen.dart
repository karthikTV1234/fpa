import 'dart:io';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/strings/app_strings.dart';
import '../../../core/constants/strings/validation_messages.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/app_validators.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/parent_widget.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../data/models/request/edit_health_tracker_req_model.dart';
import '../data/models/response/health_tracker_detail_res_model.dart';

class EditHealthTrackerScreen extends StatefulWidget {
  final HealthRecordDetailData healthRecordDetailData;
  const EditHealthTrackerScreen({
    super.key,
    required this.healthRecordDetailData,
  });

  @override
  State<EditHealthTrackerScreen> createState() => _EditHealthTrackerScreenState();
}

class _EditHealthTrackerScreenState extends State<EditHealthTrackerScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _conditionNameController =
  TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _temperatureController = TextEditingController();
  final TextEditingController _heartRateController = TextEditingController();
  final TextEditingController _respiratoryRateController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  late HealthTrackerBloc heathBloc;


  @override
  void dispose() {
    _conditionNameController.dispose();
    _dateController.dispose();
    _temperatureController.dispose();
    _heartRateController.dispose();
    _respiratoryRateController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    heathBloc = BlocProvider.of<HealthTrackerBloc>(context);
    _loadHealthTrackerData();
  }

  @override
  Widget build(BuildContext context) {
    return  BlocConsumer<HealthTrackerBloc, HealthTrackerState>(
      listener: _healthTrackerBlocListener,
      builder: (context, state) {
        return  Stack(
            children:[
              ParentWidget(
                hasHeader: true,
                appbarColor: AppColors.lightGreyColor,
                appbarTitle: AppStrings.editHealthTrackerText,
                appbarTitleColor: AppColors.cblackColor,
                context: context,
                leadingWidget: IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.arrow_back)),
                childWidget: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SingleChildScrollView(
                    child: Form(
                      key: _formKey,
                      child: Column(
                        spacing: 16,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.conditionNameLabel,
                            hintText: AppStrings.conditionNameHint,
                            TextInputType.text,
                            TextInputAction.next,
                            _conditionNameController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.conditionNameValidation;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.dateLabel,
                            TextInputType.datetime,
                            TextInputAction.next,
                            _dateController,
                            false,
                            readOnly: true,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            trailingIcon: Icon(Icons.date_range),
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.dateValidation;
                              }
                              return null;
                            },
                            customTap: () async {
                              final DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(2000),
                                lastDate: DateTime(2100),
                              );
                              if (pickedDate != null) {
                                _dateController.text =
                                    AppUtils.formatDateFromDatePicker(pickedDate);
                              }
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.temperatureLabel,
                            hintText: AppStrings.temperatureHint,
                            TextInputType.numberWithOptions(decimal: true),
                            TextInputAction.next,
                            _temperatureController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.temperatureEmptyValidation;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.heartRateLabel,
                            hintText: AppStrings.heartRateHint,
                            TextInputType.number,
                            TextInputAction.next,
                            _heartRateController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.respiratoryLabel,
                            hintText: AppStrings.respiratoryHint,
                            TextInputType.number,
                            TextInputAction.next,
                            _respiratoryRateController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                          ),
                          TextInputWidgets.textFormField(
                            maxLines: 4,
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.healthTrackerNotesLabel,
                            hintText: AppStrings.healthTrackerNotesHint,
                            TextInputType.text,
                            TextInputAction.done,
                            _notesController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                          ),
                          FileAttachmentsWidget(
                            maxFileSizeMB: AppStrings.maxFileSize,
                            supportedTypes: AppStrings.supportedFileTypes,
                            existingAttachments: widget.healthRecordDetailData.attachments,
                            selectedNewFiles: heathBloc.isUIUpdated ? heathBloc.newAttachments : [],
                            onFileSelected: (file) {
                              heathBloc.add(HealthAddNewAttachmentEvent(file));
                            },
                            onFileDeleted: (file) {
                              heathBloc.add(HealthRemoveNewAttachmentEvent(file));
                            },
                          ),
                          ButtonWidgets.elevatedButton(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            width: AppUtils.getScreenWidth(context),
                            radius: 7,
                            height: 50,
                            AppStrings.updateTxt,
                            AppColors.cprimaryColor,
                            AppColors.cwhiteColor,
                                () {
                                  _onUpdateHealthTracker(context);
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Visibility(visible: state is HealthTrackerLoading, child:Loader.showLoader(AppStrings.loading))
            ]
        );
      },
    );
  }

  void _loadHealthTrackerData() {
    final data = widget.healthRecordDetailData;
    _conditionNameController.text = data.conditionName;
    _dateController.text = data.dateOfEntry;
    _temperatureController.text = data.temperature;
    _heartRateController.text = data.heartRate;
    _respiratoryRateController.text = data.respiratoryRate;
    _notesController.text = data.notes;

  }

  void _healthTrackerBlocListener(BuildContext context, HealthTrackerState state) {
    if (state is HealthTrackerSuccess) {
      Navigator.of(context).pop(true);
    } else if (state is HealthTrackerFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onUpdateHealthTracker(BuildContext context) async {
    if (_formKey.currentState!.validate()) {

      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final List<XFile> newFiles = heathBloc.isUIUpdated
          ? heathBloc.newAttachments
          : [];
      final List<File> attachmentFiles = newFiles.map((xfile) => File(xfile.path)).toList();
      final requestModel = UpdateHealthRecordReqModel(
        childId: childId,
        dateOfEntry: _dateController.text,
        temperature: _temperatureController.text,
        heartRate: _heartRateController.text,
        respiratoryRate: _respiratoryRateController.text,
        notes: _notesController.text,
        conditionName: _conditionNameController.text,
        attachments: attachmentFiles,
      );
      heathBloc.add(
        UpdateHealthTrackerEvent(
          healthTrackerId: widget.healthRecordDetailData.id,
            updateHealthRecordReqModel: requestModel
        ),
      );
    }
  }


}
