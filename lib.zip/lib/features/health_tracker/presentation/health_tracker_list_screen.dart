import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_bloc.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_events.dart';
import 'package:child_health_story/features/health_tracker/presentation/bloc/health_tracker_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/common_card_item.dart';
import 'package:child_health_story/shared/widgets/common_list_view.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../data/models/response/health_tracker_list_res_model.dart';

class HealthTrackerListScreen extends StatefulWidget {
  const HealthTrackerListScreen({super.key});

  @override
  State<HealthTrackerListScreen> createState() => _HealthTrackerListScreenState();
}

class _HealthTrackerListScreenState extends State<HealthTrackerListScreen> {
  final TextEditingController _searchController = TextEditingController();
  late final HealthTrackerBloc _healthTrackerBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _healthTrackerBloc = context.read<HealthTrackerBloc>();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      _healthTrackerBloc.add(FetchHealthTrackerListEvent(childId: childId));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _mapHealthTrackerToUI(List<HealthRecordListData> data) {
    return data.map((record) {
      final formattedDate = AppUtils.formatDateOnly(record.dateOfEntry);
      final condition = record.conditionName;
      final temperature = record.temperature.trim();
      final heartRate = record.heartRate.toString();

      final subtitleText = temperature.isNotEmpty
          ? "${AppStrings.temperaturePrefix}$temperature ${AppStrings.degreeF}"
          : "";

      final subtitle2Text = heartRate.isNotEmpty
          ? "${AppStrings.heartRatePrefix}$heartRate"
          : "";
      return {
        "id": record.id,
        "category": formattedDate,
        "title": condition,
        "subtitle": subtitleText,
        "subtitle2": subtitle2Text,
      };
    }).toList();
  }


  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HealthTrackerBloc, HealthTrackerState>(
        listener: (context, state) {
          if (state is HealthTrackerListSuccess) {
             mappedList = _mapHealthTrackerToUI(state.healthTrackerList);
             _healthTrackerBloc.filteredHealthTrackerList = mappedList;
          }else if (state is HealthTrackerListSearchSuccess) {
            _healthTrackerBloc.filteredHealthTrackerList = state.filteredList;
          }

          if (state is HealthTrackerFailure) {
            CustomSnackBar(
              context: context,
              message: state.error,
              messageType: AppStrings.failure,
            ).show();
          }
        },
    builder: (context, state) {
      return  Stack(
        children:[
       ParentWidget(
        appbarTitle: AppStrings.healthTrackerText,
        appbarTitleColor: AppColors.cblackColor,
        appbarColor: AppColors.clightGrayColor,
        appbarSubtitle: AppStrings.healthTrackerDetailsText(
            SharedPreferencesHelper.instance.getSelectedChildName()
        ),
        leadingWidget: IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: Icon(
              Icons.arrow_back,
              color: AppColors.cblackColor,
            )),
        context: context,
        hasHeader: true,
        childWidget: ConstrainedBox(
          constraints:
          BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
          child: IntrinsicHeight(
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Column(
                spacing: 8,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextWidgets.textWidget(
                        AppStrings.healthHistoryText, AppColors.cblackColor,
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: TextInputWidgets.getTextField(
                      fillColor: AppColors.clightGrayColor,
                      textColor: AppColors.cblackColor,
                      hintText: AppStrings.searchHealthTrackerText,
                      prefixIcon: Icon(Icons.search, color: Colors.grey,
                          size: 15),
                      controller: _searchController,
                        keyboardType: TextInputType.text,
                        onChanged: (value) {
                          _healthTrackerBloc.add(SearchHealthTrackerListEvent(
                          textSearch: value,
                          list: mappedList,
                        ));
                      },
                    ),
                  ),
                  Expanded(
                    child: CommonListView<Map<String, dynamic>>(
                      data: _healthTrackerBloc.filteredHealthTrackerList,
                      padding: const EdgeInsets.all(16),
                      itemBuilder: (item) =>
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: CommonCardItem(
                              id: item["id"],
                              category: item["category"] ?? "",
                              title: item["title"] ?? "",
                              subtitle: item["subtitle"] ?? "",
                              subtitle2: item["subtitle2"] ?? "",
                              onTap: (selectedId) {
                                _navigateToDetailScreen(context, selectedId);
                              },
                            ),
                          ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        floatingActionButton: ButtonWidgets.floatingActionButton(
          Icons.add, AppColors.cwhiteColor, AppColors.cprimaryColor, () async {
          final result = await Navigator.pushNamed(
            context,
            PathConstants.addHealthTrackerScreen,
          );
          if (result == true) {
            final childId = SharedPreferencesHelper.instance.getSelectedChildId();
            if (childId.isNotEmpty) {
              _healthTrackerBloc.add(FetchHealthTrackerListEvent(childId: childId));
            }
          }
        },
        ),
      ),
       Visibility(visible: state is HealthTrackerLoading, child:Loader.showLoader(AppStrings.loading))
     ]
      );
    },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.healthTrackerDetailScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _healthTrackerBloc.add(FetchHealthTrackerListEvent(childId: childId));
      }
    }
  }

}
