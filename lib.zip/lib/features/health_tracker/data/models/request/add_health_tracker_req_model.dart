import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class AddHealthRecordReqModel {
  final String childId;
  final String dateOfEntry;
  final String temperature;
  final String heartRate;
  final String respiratoryRate;
  final String notes;
  final String conditionName;
  final List<File> attachments;

  AddHealthRecordReqModel({
    this.childId = '',
    this.dateOfEntry = '',
    this.temperature = '',
    this.heartRate = '',
    this.respiratoryRate = '',
    this.notes = '',
    this.conditionName = '',
    this.attachments = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'childId': childId,
      'dateOfEntry': dateOfEntry,
      'temperature': temperature,
      'heartRate': heartRate,
      'respiratoryRate': respiratoryRate,
      'notes': notes,
      'conditionName': conditionName,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());

    for (int i = 0; i < attachments.length; i++) {
      final file = attachments[i];
      final mimeType = lookupMimeType(file.path) ?? 'application/octet-stream';
      final mimeSplit = mimeType.split('/');

      formData.files.add(
        MapEntry(
          'attachments',
          await MultipartFile.fromFile(
            file.path,
            filename: file.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }

    return formData;
  }
}
