class AddHealthRecordResModel {
  final int statusCode;
  final String message;
  final HealthRecordAddResData data;

  AddHealthRecordResModel({
    this.statusCode = 0,
    this.message = '',
    HealthRecordAddResData? data,
  }) : data = data ?? HealthRecordAddResData();

  factory AddHealthRecordResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddHealthRecordResModel();

    return AddHealthRecordResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: HealthRecordAddResData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}
class HealthRecordAddResData {
  final String id;
  final String childId;
  final String dateOfEntry;
  final String temperature;
  final String heartRate;
  final String respiratoryRate;
  final String notes;
  final List<String> attachments;
  final String conditionName;
  final String createdAt;
  final String updatedAt;
  final bool isDeleted;

  HealthRecordAddResData({
    this.id = '',
    this.childId = '',
    this.dateOfEntry = '',
    this.temperature = '',
    this.heartRate = '',
    this.respiratoryRate = '',
    this.notes = '',
    this.attachments = const [],
    this.conditionName = '',
    this.createdAt = '',
    this.updatedAt = '',
    this.isDeleted = false,
  });

  factory HealthRecordAddResData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HealthRecordAddResData();

    return HealthRecordAddResData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      dateOfEntry: json['dateOfEntry'] as String? ?? '',
      temperature: json['temperature'] as String? ?? '',
      heartRate: json['heartRate'] as String? ?? '',
      respiratoryRate: json['respiratoryRate'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      conditionName: json['conditionName'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
    );
  }
}