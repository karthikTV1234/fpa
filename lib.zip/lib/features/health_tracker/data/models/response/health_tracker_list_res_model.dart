class GetHealthRecordsListResModel {
  final int statusCode;
  final String message;
  final List<HealthRecordListData> data;

  GetHealthRecordsListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetHealthRecordsListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetHealthRecordsListResModel();

    return GetHealthRecordsListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => HealthRecordListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class HealthRecordListData {
  final String id;
  final String dateOfEntry;
  final String temperature;
  final int heartRate;
  final int respiratoryRate;
  final String conditionName;

  HealthRecordListData({
    this.id = '',
    this.dateOfEntry = '',
    this.temperature = '',
    this.heartRate = 0,
    this.respiratoryRate = 0,
    this.conditionName = '',
  });

  factory HealthRecordListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HealthRecordListData();

    return HealthRecordListData(
      id: json['id'] as String? ?? '',
      dateOfEntry: json['dateOfEntry'] as String? ?? '',
      temperature: json['temperature'] as String? ?? '',
      heartRate: json['heartRate'] as int? ?? 0,
      respiratoryRate: json['respiratoryRate'] as int? ?? 0,
      conditionName: json['conditionName'] as String? ?? '',
    );
  }
}