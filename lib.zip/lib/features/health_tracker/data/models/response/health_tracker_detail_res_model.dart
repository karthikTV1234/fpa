class GetHealthRecordDetailResModel {
  final int statusCode;
  final String message;
  final HealthRecordDetailData data;

  GetHealthRecordDetailResModel({
    this.statusCode = 0,
    this.message = '',
    HealthRecordDetailData? data,
  }) : data = data ?? HealthRecordDetailData();

  factory GetHealthRecordDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetHealthRecordDetailResModel();

    return GetHealthRecordDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: HealthRecordDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class HealthRecordDetailData {
  final String id;
  final String childId;
  final String dateOfEntry;
  final String temperature;
  final String heartRate;
  final String respiratoryRate;
  final String notes;
  final List<String> attachments;
  final String conditionName;
  final String createdAt;
  final String updatedAt;
  final bool isDeleted;

  HealthRecordDetailData({
    this.id = '',
    this.childId = '',
    this.dateOfEntry = '',
    this.temperature = '',
    this.heartRate = '',
    this.respiratoryRate = '',
    this.notes = '',
    this.attachments = const [],
    this.conditionName = '',
    this.createdAt = '',
    this.updatedAt = '',
    this.isDeleted = false,
  });

  factory HealthRecordDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HealthRecordDetailData();

    return HealthRecordDetailData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      dateOfEntry: json['dateOfEntry'] as String? ?? '',
      temperature: json['temperature']?.toString() ?? '',
      heartRate: json['heartRate']?.toString() ?? '',
      respiratoryRate: json['respiratoryRate']?.toString() ?? '',
      notes: json['notes'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      conditionName: json['conditionName'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
    );
  }
}