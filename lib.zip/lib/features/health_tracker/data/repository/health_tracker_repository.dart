import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../models/request/add_health_tracker_req_model.dart';
import '../models/request/edit_health_tracker_req_model.dart';
import '../models/response/add_health_tracker_res_model.dart';
import '../models/response/health_tracker_detail_res_model.dart';
import '../models/response/health_tracker_list_res_model.dart';

class HealthTrackerRepository {
  final Dio _dio;

  HealthTrackerRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddHealthRecordResModel>> addHealthRecord(AddHealthRecordReqModel addReqModel) async {
    String errorMessage = ErrorMessages.addHealthRecordFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.createHealthRecord}';
      final formData = await addReqModel.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addRes = AddHealthRecordResModel.fromJson(response.data);
        return Result.success(addRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetHealthRecordsListResModel>> getHealthRecordList(String childId) async {
    String errorMessage = ErrorMessages.fetchHealthRecordListFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.healthRecordList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final healthListRes = GetHealthRecordsListResModel.fromJson(response.data);
        return Result.success(healthListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetHealthRecordDetailResModel>> getHealthRecordDetails(String healthTrackerId) async {
    String errorMessage = ErrorMessages.fetchHealthRecordDetailsFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.healthRecordDetails}/$healthTrackerId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.data != null && (response.statusCode == 200 || response.statusCode == 201)) {
        final childDetailRes = GetHealthRecordDetailResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateHealthRecordDetails(UpdateHealthRecordReqModel updateReqModel, String healthTrackerId) async {
    String errorMessage = ErrorMessages.updateHealthRecordFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.updateHealthRecord}/$healthTrackerId';
      final formData = await updateReqModel.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final updateRes = CommonResModel.fromJson(response.data);
        return Result.success(updateRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteHealthRecord(String healthTrackerId) async {
    String errorMessage = ErrorMessages.deleteHealthRecordFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.deleteHealthRecord}/$healthTrackerId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
