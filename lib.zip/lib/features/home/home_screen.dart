import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/doctor_visits/presentation/doctor_visit_list_screen.dart';
import 'package:child_health_story/features/growth_milestones/growth/growth_tracker.dart';
import 'package:child_health_story/features/health_records/health_records.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../child_profile/data/repository/child_repository.dart';
import '../child_profile/presentation/bloc/child_bloc.dart';
import '../child_profile/presentation/screens/my_child_screen.dart';
import '../doctor_visits/data/repository/doctor_visit_repository.dart';
import '../doctor_visits/presentation/bloc/doctor_visit_bloc.dart';
import '../health_records/bloc/health_record_bloc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HealthRecords(),
      GrowthTracker(),
      BlocProvider(
        create: (_) => DoctorVisitBloc(
          doctorVisitRepository: DoctorVisitRepository(),
        ),
        child: const DoctorVisitListScreen(),
      ),
      MyChildScreen(),
    ];

    return MultiBlocProvider(
      providers: [
        // Single instance of ChildBloc shared across tabs
        BlocProvider(
          create: (_) => ChildBloc(childRepository: ChildRepository()),
        ),
        BlocProvider(
          create: (_) => HealthRecordBloc(),
        ),
      ],
      child: Scaffold(
        body: ParentWidget(
          context: context,
          hasHeader: false,
          childWidget: screens[_selectedIndex],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppColors.cprimaryColor,
          unselectedItemColor: AppColors.cblackColor,
          showUnselectedLabels: true,
          items: AppStrings.navItems,
        ),
      ),
    );
  }
}



