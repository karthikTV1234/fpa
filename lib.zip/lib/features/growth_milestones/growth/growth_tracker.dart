import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';

class GrowthTracker extends StatelessWidget {
  const GrowthTracker({super.key});

  @override
  Widget build(BuildContext context) {
    return ParentWidget(
        context: context,
        hasHeader: false,
        childWidget: Center(
          child: TextWidgets.textWidget(
              AppStrings.growthTrackerText, AppColors.cblackColor,
              fontSize: 14),
        ));
  }
}
