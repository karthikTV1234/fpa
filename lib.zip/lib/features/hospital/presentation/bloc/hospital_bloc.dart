import 'package:bloc/bloc.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/hospital/data/repository/hospital_repository.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import '../../../../core/errors/failure.dart';
import '../../data/model/address_search_model.dart';
import '../../data/model/hospital_model.dart';

/// BLOC
class HospitalBloc extends Bloc<HospitalEvent, HospitalState> {
  final HospitalRepository hospitalRepository;
  String selectedCountryCode = "+91";
  List<AddressSearchResModel> addressSearchList = [];

  HospitalBloc({required this.hospitalRepository}) : super(HospitalInitial()) {
    on<SelectCountryCodeHEvent>((event, emit) {
      selectedCountryCode = event.countryCode;
      emit(CountryCodeSelectedH(event.countryCode));
    });
    on<AddHospitalEvent>((event, emit) async {
      emit(HospitalLoading());
      final result = await hospitalRepository.addHospital(event.addHospitalReqModel);
      if (result.isSuccess) {
        emit(HospitalSuccess(
          message: result.data?.message ?? AppStrings.hospitalAddedSuccessMessage,
        ));
      } else {
        emit(HospitalFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchHospitalListEvent>((event, emit) async {
      emit(HospitalLoading());
      final result = await hospitalRepository.getHospitalList();
      if (result.isSuccess && result.data != null) {
        final HospitalListResModel resModel = result.data!;
        emit(HospitalListSuccess(resModel.data));
      } else {
        emit(HospitalFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<SearchAddressEvent>((event, emit) async {
      final result = await hospitalRepository.searchAddress(event.query);
      if (result.isSuccess) {
        addressSearchList = result.data ?? [];
        emit(AddressSearchSuccess([...addressSearchList]));
      } else {
        emit(HospitalFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });


  }
}
