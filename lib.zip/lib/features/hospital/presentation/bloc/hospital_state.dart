import 'package:equatable/equatable.dart';
import '../../data/model/address_search_model.dart';
import '../../data/model/hospital_model.dart';

/// STATES
abstract class HospitalState extends Equatable {
  @override
  List<Object?> get props => [];
}
class HospitalInitial extends HospitalState {}
class HospitalLoading extends HospitalState {}
class HospitalSuccess extends HospitalState {
  final String message;
  HospitalSuccess({required this.message});
  @override
  List<Object?> get props => [message];
}
class HospitalListSuccess extends HospitalState {
  final List<HospitalListData> hospitals;
  HospitalListSuccess(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class HospitalFailure extends HospitalState {
  final String error;
  HospitalFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class CountryCodeSelectedH extends HospitalState {
  final String countryCode;
  CountryCodeSelectedH(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}
class AddressSearchSuccess extends HospitalState {
  final List<AddressSearchResModel> suggestions;
  AddressSearchSuccess(this.suggestions);
  @override
  List<Object?> get props => [suggestions];
}
