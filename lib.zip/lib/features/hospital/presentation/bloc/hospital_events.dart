import 'package:equatable/equatable.dart';
import '../../data/model/hospital_model.dart';

/// EVENTS
abstract class HospitalEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddHospitalEvent extends HospitalEvent {
  final AddHospitalReqModel addHospitalReqModel;
  AddHospitalEvent({required this.addHospitalReqModel});
  @override
  List<Object?> get props => [addHospitalReqModel];
}
class FetchHospitalListEvent extends HospitalEvent {}
class SelectCountryCodeHEvent extends HospitalEvent {
  final String countryCode;
  SelectCountryCodeHEvent(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}
class SearchAddressEvent extends HospitalEvent {
  final String query;
  SearchAddressEvent(this.query);
  @override
  List<Object?> get props => [query];
}