import 'package:flutter/material.dart';
import '../../../../core/constants/color/app_colors.dart';
import '../../../../shared/widgets/text_input_widgets.dart';
import '../../../../shared/widgets/text_widgets.dart';
import '../../data/model/address_search_model.dart';

class CustomAddressSearchField extends StatelessWidget {
  final TextEditingController controller;
  final List<AddressSearchResModel> items;
  final String labelText;
  final String hintText;
  final void Function(String address, double lat, double lon) onSelected;
  final void Function(String)? onChanged;
  final String? Function(String?)? validator;

  const CustomAddressSearchField({
    super.key,
    required this.controller,
    required this.items,
    required this.labelText,
    required this.hintText,
    required this.onSelected,
    this.onChanged,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Autocomplete<AddressSearchResModel>(
      optionsBuilder: (TextEditingValue textEditingValue) {
        if (textEditingValue.text.isEmpty) {
          return const Iterable<AddressSearchResModel>.empty();
        }

        return items.where((item) => item.displayName
            .toLowerCase()
            .contains(textEditingValue.text.toLowerCase()));
      },
      displayStringForOption: (option) => option.displayName,
      fieldViewBuilder: (context, textEditingController, focusNode, _) {
        textEditingController.value = controller.value;

        return TextInputWidgets.textFormField(
          focusNode: focusNode,
          fillColor: AppColors.appBackGroundColor,
          labelText,
          hintText: hintText,
          TextInputType.text,
          TextInputAction.next,
          controller,
          maxLines: 2,
          trailingIcon: const Icon(Icons.location_on),
          enabledBorderColor: AppColors.cmediumGrayColor,
          focusedBorderColor: AppColors.cmediumGrayColor,
          false,
          onChanged: onChanged,
          validator: validator,
        );
      },
      optionsViewBuilder: (context, onSelected, options) {
        return Align(
          alignment: Alignment.topLeft,
          child: Material(
            elevation: 4,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 200),
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: options.length,
                itemBuilder: (context, index) {
                  final option = options.elementAt(index);
                  return ListTile(
                    dense: true,
                    title: TextWidgets.textWidget(
                      option.displayName,
                      AppColors.cblackColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      textAlign: TextAlign.left,
                    ),
                    onTap: () => onSelected(option),
                  );
                },
              ),
            ),
          ),
        );
      },
      onSelected: (AddressSearchResModel option) {
        controller.text = option.displayName;
        onSelected(option.displayName, option.lat, option.lon);
      },
    );
  }
}
