import 'package:child_health_story/features/hospital/presentation/widgets/custom_address_search_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/app_validators.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import '../../../core/constants/strings/app_data.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_dropdown.dart';
import '../../../shared/widgets/text_widgets.dart';
import '../data/model/hospital_model.dart';
import 'bloc/hospital_bloc.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';


class AddHospitalDialog extends StatefulWidget {
  const AddHospitalDialog({super.key});

  static Future<bool?> show(BuildContext context) async {
    final bloc = context.read<HospitalBloc>();
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: bloc,
        child: Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: const AddHospitalDialog(),
          ),
        ),
      ),
    );
  }

  @override
  State<AddHospitalDialog> createState() => _AddHospitalDialogState();
}

class _AddHospitalDialogState extends State<AddHospitalDialog> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _hospitalNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  late HospitalBloc hospitalBloc;
  double? _latitude;
  double? _longitude;
  String? _address;

  @override
  void initState() {
    super.initState();
    hospitalBloc = BlocProvider.of<HospitalBloc>(context);
  }


  @override
  void dispose() {
    _hospitalNameController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return  BlocConsumer<HospitalBloc, HospitalState>(
      listener: _hospitalBlocListener,
      builder: (context, state) {
        return Container(
          color: AppColors.appBackGroundColor,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  spacing: 16,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextWidgets.textWidget(
                        AppStrings.addNewHospital,
                        AppColors.cblackColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        textAlign: TextAlign.left,
                      ),
                    ),
                    TextInputWidgets.textFormField(
                      fillColor: AppColors.appBackGroundColor,
                      AppStrings.hospitalNameLabel,
                      hintText: AppStrings.hospitalNameHint,
                      TextInputType.text,
                      TextInputAction.next,
                      _hospitalNameController,
                      enabledBorderColor: AppColors.cmediumGrayColor,
                      focusedBorderColor: AppColors.cmediumGrayColor,
                      false,
                      validator: (value) {
                        if (AppValidators.emptyValidator(value!)) {
                          return ValidationMessages.hospitalNameRequired;
                        }
                        return null;
                      },
                    ),
                    CustomAddressSearchField(
                      controller: _addressController,
                      items: hospitalBloc.addressSearchList,
                      labelText: AppStrings.searchAddressLabel,
                      hintText: AppStrings.searchAddressHint,
                      onSelected: (address, lat, lon) {
                        _address = address;
                        _latitude = lat;
                        _longitude = lon;
                      },
                      onChanged: (value) {
                        if (value.length >= 3) {
                          hospitalBloc.add(SearchAddressEvent(value));
                        }
                      },
                      validator: (value) {
                        if (AppValidators.emptyValidator(value!)) {
                          return ValidationMessages.addressRequired;
                        }
                        return null;
                      },
                    ),
                    Row(
                      spacing: 10,
                      children: [
                        Expanded(
                          flex: 2,
                          child: CustomDropDown(
                            labelText: AppStrings.countryCodeHintText,
                            hint: TextWidgets.textWidget(
                                fontSize: 14,
                                AppStrings.countryCodeHintText,
                                AppColors.cblackColor),
                            dropdownMenuItems: AppData.countryCodes,
                            value: hospitalBloc.selectedCountryCode,
                            onChanged: (value) {
                              hospitalBloc.add(SelectCountryCodeHEvent(value));
                            },
                            validator: (value) {
                              if (AppValidators.emptyValidator(value ?? '')) {
                                return ValidationMessages.plsSelectCountryCode;
                              }
                              return null;
                            },
                          ),
                        ),
                        Expanded(
                          flex: 5,
                          child: TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.phoneLabelWithOutAsterisk,
                            hintText: AppStrings.enterPhoneNumberHintText,
                            TextInputType.phone,
                            TextInputAction.done,
                            _phoneController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              final trimmedValue = value?.trim() ?? '';
                              if (trimmedValue.isEmpty) {
                                return null;
                              } else
                              if (!AppValidators.phoneValidator(trimmedValue)) {
                                return ValidationMessages
                                    .plsEnterValidPhoneNumber; // show error on invalid
                              }
                              return null; // valid
                            },
                          ),
                        ),
                      ],
                    ),

                    TextInputWidgets.textFormField(
                      fillColor: AppColors.appBackGroundColor,
                      AppStrings.emailLabel,
                      hintText: AppStrings.enterEmailHintText,
                      TextInputType.emailAddress,
                      TextInputAction.done,
                      _emailController,
                      enabledBorderColor: AppColors.cmediumGrayColor,
                      focusedBorderColor: AppColors.cmediumGrayColor,
                      false,
                      validator: (value) {
                        if ((value ?? '').isEmpty) {
                          return null;
                        } else if (AppValidators.emailValidator(value!)) {
                          return ValidationMessages.plsEnterValidEmail;
                        }
                        return null;
                      },
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.notesLabelWithOutAsterisk,
                      TextInputType.text,
                      TextInputAction.done,
                      _notesController,
                      hintText: AppStrings.notesHint,
                      fillColor: AppColors.appBackGroundColor,
                      enabledBorderColor: AppColors.cmediumGrayColor,
                      focusedBorderColor: AppColors.cprimaryColor,
                      false,
                      maxLines: 3,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: ButtonWidgets.elevatedButton(
                        AppStrings.addHospitalBtnText,
                        AppColors.cprimaryColor,
                        AppColors.cwhiteColor,
                            () => _onAddHospital(context),
                        width: AppUtils.getScreenWidth(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        height: 50,
                        radius: 7,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      }
    );
  }

  void _hospitalBlocListener(BuildContext context, HospitalState state) {
    if (state is HospitalLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        // Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is HospitalSuccess) {
      Navigator.of(context).pop(true);
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
    } else if (state is HospitalFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onAddHospital(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final phone = _phoneController.text.trim();
      final reqModel = AddHospitalReqModel(
        childId: childId,
        hospitalName: _hospitalNameController.text,
        address: _address ?? '',
        latitude: _latitude ?? 0.0,
        longitude: _longitude ?? 0.0,
          countryCode: phone.isEmpty ? "" : hospitalBloc.selectedCountryCode,
          phone: phone,
          email: _emailController.text.trim().isEmpty ? "" : _emailController.text.trim(),
        notes: _notesController.text
      );
      context.read<HospitalBloc>().add(
        AddHospitalEvent(addHospitalReqModel: reqModel),
      );
    }
  }


}
