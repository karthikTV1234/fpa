
class HospitalListResModel {
  final int statusCode;
  final String message;
  final List<HospitalListData> data;

  HospitalListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory HospitalListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HospitalListResModel();

    return HospitalListResModel(
      statusCode: json['statusCode'] is int ? json['statusCode'] ?? 0 : 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => HospitalListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}
class HospitalListData {
  final String id;
  final String hospitalName;

  HospitalListData({
    this.id = '',
    this.hospitalName = '',
  });

  factory HospitalListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HospitalListData();

    return HospitalListData(
      id: json['id'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
    );
  }
}

//Add Hospital Request and Response Models
class AddHospitalReqModel {
  final String childId;
  final String hospitalName;
  final String address;
  final double latitude;
  final double longitude;
  final String? email;
  final String? countryCode;
  final String? phone;
  final String notes;
  final bool isFavorite;

  AddHospitalReqModel({
    this.childId = '',
    this.hospitalName = '',
    this.address = '',
    this.latitude = 0.0,
    this.longitude = 0.0,
    this.email = '',
    this.countryCode = '',
    this.phone = '',
    this.notes = '',
    this.isFavorite = false,
  });

  Map<String, dynamic> toJson() {
    return {
      "childId": childId,
      "hospitalName": hospitalName,
      "address": address,
      "latitude": latitude,
      "longitude": longitude,
      "email": email,
      "countryCode": countryCode,
      "phone": phone,
      "notes": notes,
      "is_favorite": isFavorite,
    };
  }

  factory AddHospitalReqModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddHospitalReqModel();

    return AddHospitalReqModel(
      childId: json['childId'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
      address: json['address'] as String? ?? '',
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      countryCode: json['countryCode'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      isFavorite: json['is_favorite'] as bool? ?? false,
    );
  }
}

class AddHospitalResModel {
  final int statusCode;
  final String message;
  final HospitalAddData data;

  AddHospitalResModel({
    this.statusCode = 0,
    this.message = '',
    HospitalAddData? data,
  }) : data = data ?? HospitalAddData();

  factory AddHospitalResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddHospitalResModel();

    return AddHospitalResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: HospitalAddData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}
class HospitalAddData {
  final String id;
  final String userId;
  final String childId;
  final String hospitalName;
  final String phone;
  final String email;
  final String address;
  final String notes;
  final bool isFavorite;
  final double latitude;
  final double longitude;
  final String createdBy;
  final String createdAt;
  final String updatedAt;

  HospitalAddData({
    this.id = '',
    this.userId = '',
    this.childId = '',
    this.hospitalName = '',
    this.phone = '',
    this.email = '',
    this.address = '',
    this.notes = '',
    this.isFavorite = false,
    this.latitude = 0.0,
    this.longitude = 0.0,
    this.createdBy = '',
    this.createdAt = '',
    this.updatedAt = '',
  });

  factory HospitalAddData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return HospitalAddData();

    return HospitalAddData(
      id: json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      email: json['email'] as String? ?? '',
      address: json['address'] as String? ?? '',
      notes: json['notes'] as String? ?? '',
      isFavorite: json['is_favorite'] as bool? ?? false,
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
      createdBy: json['createdBy'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
    );
  }
}

