import 'package:equatable/equatable.dart';

class AddressSearchResModel extends Equatable {
  final String displayName;
  final double lat;
  final double lon;

  AddressSearchResModel({
    required this.displayName,
    required this.lat,
    required this.lon,
  });

  factory AddressSearchResModel.fromJson(Map<String, dynamic> json) {
    return AddressSearchResModel(
      displayName: json['display_name'],
      lat: double.parse(json['lat']),
      lon: double.parse(json['lon']),
    );
  }
  @override
  List<Object?> get props => [displayName, lat, lon];
}