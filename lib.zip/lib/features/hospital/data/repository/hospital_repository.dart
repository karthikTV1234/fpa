import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/network/api_client.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../model/address_search_model.dart';
import '../model/hospital_model.dart';

class HospitalRepository {
  final Dio _dio;

  HospitalRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddHospitalResModel>> addHospital(AddHospitalReqModel addHospitalReqModel) async {
    String errorMessage = ErrorMessages.addHospitalFailedError;
    try {
      const String url = '${ApiConstants.commonUrl}${ApiConstants.addHospital}';

      final response = await _dio.post(
        url,
        data: addHospitalReqModel.toJson(),
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addHospitalRes = AddHospitalResModel.fromJson(response.data);
        return Result.success(addHospitalRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<HospitalListResModel>> getHospitalList() async {
    String errorMessage = ErrorMessages.fetchHospitalListFailedError;
    try {
      const String url = '${ApiConstants.commonUrl}${ApiConstants.hospitalList}';
      final response = await _dio.get(
        url,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final hospitalListRes = HospitalListResModel.fromJson(response.data);
        return Result.success(hospitalListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<List<AddressSearchResModel>>> searchAddress(String query) async {
    String errorMessage = ErrorMessages.somethingWentWrongError;
    if (query.length < 3) return Result.success([]);
    try {
      final response = await _dio.get(
        ApiConstants.openStreamBaseURL,
        queryParameters: {
          'q': query,
          'format': 'json',
          'limit': 10,
          'countrycodes': AppStrings.countryAddressSearchCodes,
        },
        options: Options(
          headers: {'User-Agent': 'FlutterApp'},
          extra: {'requiresAuth': false},
        ),
      );

      final List data = response.data;
      final results = data.map((e) => AddressSearchResModel.fromJson(e)).toList();
      return Result.success(results);
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(errorMessage);
    }
  }

}
