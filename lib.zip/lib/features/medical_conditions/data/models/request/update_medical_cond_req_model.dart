import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class UpdateMedicalCondReqModel {
  final String childId;
  final String diagnosedDate;
  final String hospitalId;
  final String doctorId;
  final String dateOfAdmission;
  final String dateOfDischarge;
  final String severity;
  final String currentStatus;
  final String treatmentPlan;
  final List<File> attachments;

  UpdateMedicalCondReqModel({
    this.childId = '',
    this.diagnosedDate = '',
    this.hospitalId = '',
    this.doctorId = '',
    this.dateOfAdmission = '',
    this.dateOfDischarge = '',
    this.severity = '',
    this.currentStatus = '',
    this.treatmentPlan = '',
    this.attachments = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'childId': childId,
      'diagnosedDate': diagnosedDate,
      'hospitalId': hospitalId,
      'doctorId': doctorId,
      'dateOfAdmission': dateOfAdmission,
      'dateOfDischarge': dateOfDischarge,
      'severity': severity,
      'currentStatus': currentStatus,
      'treatmentPlan': treatmentPlan,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());

    for (int i = 0; i < attachments.length; i++) {
      final file = attachments[i];
      final mimeType = lookupMimeType(file.path) ?? 'application/octet-stream';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'attachments',
          await MultipartFile.fromFile(
            file.path,
            filename: file.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }

    return formData;
  }
}
