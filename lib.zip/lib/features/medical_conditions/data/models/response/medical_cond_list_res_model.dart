class MedicalConditionListResModel {
  final int statusCode;
  final String message;
  final List<MedicalConditionListData> data;

  MedicalConditionListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory MedicalConditionListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalConditionListResModel();

    return MedicalConditionListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) =>
          MedicalConditionListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class MedicalConditionListData {
  final String id;
  final String childId;
  final String conditionName;
  final String diagnosedDate;
  final String doctorId;
  final String severity;
  final String currentStatus;
  final String doctorName;

  MedicalConditionListData({
    this.id = '',
    this.childId = '',
    this.conditionName = '',
    this.diagnosedDate = '',
    this.doctorId = '',
    this.severity = '',
    this.currentStatus = '',
    this.doctorName = '',
  });

  factory MedicalConditionListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalConditionListData();

    return MedicalConditionListData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      conditionName: json['conditionName'] as String? ?? '',
      diagnosedDate: json['diagnosedDate'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      severity: json['severity'] as String? ?? '',
      currentStatus: json['currentStatus'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
    );
  }
}
