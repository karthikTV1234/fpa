class MedicalConditionStatusListResModel {
  final int statusCode;
  final String message;
  final List<MedicalConditionStatusData> data;

  MedicalConditionStatusListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory MedicalConditionStatusListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalConditionStatusListResModel();

    return MedicalConditionStatusListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) =>
          MedicalConditionStatusData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class MedicalConditionStatusData {
  final String id;
  final String conditionStatus;

  MedicalConditionStatusData({
    this.id = '',
    this.conditionStatus = '',
  });

  factory MedicalConditionStatusData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalConditionStatusData();

    return MedicalConditionStatusData(
      id: json['id'] as String? ?? '',
      conditionStatus: json['conditionStatus'] as String? ?? '',
    );
  }
}
