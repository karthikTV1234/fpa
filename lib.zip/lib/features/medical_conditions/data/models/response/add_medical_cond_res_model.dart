class AddMedicalCondResModel {
  final int statusCode;
  final String message;
  final MedicalCondAddResData data;

  AddMedicalCondResModel({
    this.statusCode = 0,
    this.message = '',
    MedicalCondAddResData? data,
  }) : data = data ?? MedicalCondAddResData();

  factory AddMedicalCondResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return AddMedicalCondResModel();

    return AddMedicalCondResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: MedicalCondAddResData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class MedicalCondAddResData {
  final String id;
  final String childId;
  final String conditionName;
  final String diagnosedDate;
  final String hospitalId;
  final String doctorId;
  final String dateOfAdmission;
  final String dateOfDischarge;
  final String severity;
  final String currentStatus;
  final String treatmentPlan;
  final List<String> attachments;
  final String createdAt;
  final String updatedAt;
  final bool isDeleted;

  MedicalCondAddResData({
    this.id = '',
    this.childId = '',
    this.conditionName = '',
    this.diagnosedDate = '',
    this.hospitalId = '',
    this.doctorId = '',
    this.dateOfAdmission = '',
    this.dateOfDischarge = '',
    this.severity = '',
    this.currentStatus = '',
    this.treatmentPlan = '',
    this.attachments = const [],
    this.createdAt = '',
    this.updatedAt = '',
    this.isDeleted = false,
  });

  factory MedicalCondAddResData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalCondAddResData();

    return MedicalCondAddResData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      conditionName: json['conditionName'] as String? ?? '',
      diagnosedDate: json['diagnosedDate'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      dateOfAdmission: json['dateOfAdmission'] as String? ?? '',
      dateOfDischarge: json['dateOfDischarge'] as String? ?? '',
      severity: json['severity'] as String? ?? '',
      currentStatus: json['currentStatus'] as String? ?? '',
      treatmentPlan: json['treatmentPlan'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
    );
  }
}
