class GetMedicalConditionDetailResModel {
  final int statusCode;
  final String message;
  final MedicalConditionDetailData data;

  GetMedicalConditionDetailResModel({
    this.statusCode = 0,
    this.message = '',
    MedicalConditionDetailData? data,
  }) : data = data ?? MedicalConditionDetailData();

  factory GetMedicalConditionDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetMedicalConditionDetailResModel();

    return GetMedicalConditionDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: MedicalConditionDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class MedicalConditionDetailData {
  final String id;
  final String childId;
  final String conditionName;
  final String diagnosedDate;
  final String hospitalId;
  final String doctorId;
  final String dateOfAdmission;
  final String dateOfDischarge;
  final String severity;
  final String currentStatus;
  final String treatmentPlan;
  final List<String> attachments;
  final String createdAt;
  final String updatedAt;
  final bool isDeleted;
  final String doctorName;
  final String hospitalName;
  final String currentStatusName;

  MedicalConditionDetailData({
    this.id = '',
    this.childId = '',
    this.conditionName = '',
    this.diagnosedDate = '',
    this.hospitalId = '',
    this.doctorId = '',
    this.dateOfAdmission = '',
    this.dateOfDischarge = '',
    this.severity = '',
    this.currentStatus = '',
    this.treatmentPlan = '',
    this.attachments = const [],
    this.createdAt = '',
    this.updatedAt = '',
    this.isDeleted = false,
    this.doctorName = '',
    this.hospitalName = '',
    this.currentStatusName = '',
  });

  factory MedicalConditionDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return MedicalConditionDetailData();

    return MedicalConditionDetailData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      conditionName: json['conditionName'] as String? ?? '',
      diagnosedDate: json['diagnosedDate'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      dateOfAdmission: json['dateOfAdmission'] as String? ?? '',
      dateOfDischarge: json['dateOfDischarge'] as String? ?? '',
      severity: json['severity'] as String? ?? '',
      currentStatus: json['currentStatus'] as String? ?? '',
      treatmentPlan: json['treatmentPlan'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
      doctorName: json['doctorName'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
      currentStatusName: json['currentStatusName'] as String? ?? '',
    );
  }
}
