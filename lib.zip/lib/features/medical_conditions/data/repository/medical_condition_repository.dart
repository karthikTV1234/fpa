import 'package:child_health_story/features/medical_conditions/data/models/request/add_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/update_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/add_medical_cond_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../models/response/medical_cond_status_list_res_model.dart';

class MedicalConditionRepository {
  final Dio _dio;

  MedicalConditionRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddMedicalCondResModel>> addMedicalCondition(AddMedicalCondReqModel addReq) async {
    String errorMessage = ErrorMessages.addMedicalConditionFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.createMedicalCondition}';
      final formData = await addReq.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addRes = AddMedicalCondResModel.fromJson(response.data);
        return Result.success(addRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<MedicalConditionListResModel>> getMedicalConditionList(String childId) async {
    String errorMessage = ErrorMessages.fetchMedicalConditionListFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medicalConditionList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final listRes = MedicalConditionListResModel.fromJson(response.data);
        return Result.success(listRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetMedicalConditionDetailResModel>> getMedicalConditionDetails(String conditionId) async {
    String errorMessage = ErrorMessages.fetchMedicalConditionDetailsFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.medicalConditionDetails}/$conditionId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      if (response.data != null && (response.statusCode == 200 || response.statusCode == 201)) {
        final childDetailRes = GetMedicalConditionDetailResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateMedicalConditionDetails(UpdateMedicalCondReqModel updateReq, String conditionId) async {
    String errorMessage = ErrorMessages.updateMedicalConditionFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.updateMedicalCondition}/$conditionId';
      final formData = await updateReq.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final updateRes = CommonResModel.fromJson(response.data);
        return Result.success(updateRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteMedicalCondition(String conditionId) async {
    String errorMessage = ErrorMessages.deleteMedicalConditionFailedError;
    try {
      final String url = '${ApiConstants.featureURL}${ApiConstants.deleteMedicalCondition}/$conditionId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<MedicalConditionStatusListResModel>> getMedicalConditionStatusList() async {
    String errorMessage = ErrorMessages.fetchMedicalConditionStatusListFailedError;
    try {
      const String url = '${ApiConstants.featureURL}${ApiConstants.medicalConditionStatusList}';
      final response = await _dio.get(
          url,
          options: ApiClient.authOptions()
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final listRes = MedicalConditionStatusListResModel.fromJson(response.data);
        return Result.success(listRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
