import 'dart:io';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_events.dart';
import 'package:child_health_story/features/hospital/presentation/bloc/hospital_state.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/add_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/shared/widgets/custom_dropdown.dart';
import 'package:child_health_story/shared/widgets/file_attachments_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/strings/app_strings.dart';
import '../../../core/constants/strings/validation_messages.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/app_validators.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/dropdown/custom_selection_drop_down.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/parent_widget.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../doctor/presentation/add_doctor_screen.dart';
import '../../doctor/presentation/bloc/doctor_bloc.dart';
import '../../hospital/data/model/hospital_model.dart';
import '../../hospital/presentation/add_hospital_screen.dart';
import '../../hospital/presentation/bloc/hospital_bloc.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_events.dart';
import 'package:child_health_story/features/doctor/presentation/bloc/doctor_state.dart';

class AddMedicalConditionScreen extends StatefulWidget {
  const AddMedicalConditionScreen({super.key});

  @override
  State<AddMedicalConditionScreen> createState() => _AddMedicalConditionScreenState();
}

class _AddMedicalConditionScreenState extends State<AddMedicalConditionScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _conditionNameController =
  TextEditingController();
  final TextEditingController _diagnoseDateController = TextEditingController();
  final TextEditingController _hospitalController = TextEditingController();
  final TextEditingController _doctorController = TextEditingController();
  final TextEditingController _dateOfAdmissionController = TextEditingController();
  final TextEditingController _dateOfDischargeController = TextEditingController();
  final TextEditingController _treatmentPlanController = TextEditingController();
  late MedicalConditionBloc _conditionBloc;


  @override
  void dispose() {
    _conditionNameController.dispose();
    _diagnoseDateController.dispose();
    _hospitalController.dispose();
    _doctorController.dispose();
    _dateOfAdmissionController.dispose();
    _dateOfDischargeController.dispose();
    _treatmentPlanController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _conditionBloc = BlocProvider.of<MedicalConditionBloc>(context);
    _conditionBloc.add(FetchStatusListEvent());
    context.read<HospitalBloc>().add(FetchHospitalListEvent());
    context.read<DoctorBloc>().add(FetchDoctorListEvent());
  }



  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<DoctorBloc, DoctorState>(
          listener: _doctorBlocListener,
        ),
        BlocListener<HospitalBloc, HospitalState>(
          listener: _hospitalBlocListener,
        ),
      ],
      child: BlocConsumer<MedicalConditionBloc, MedicalConditionState>(
        listener: _medicalConditionBlocListener,
        builder: (context, state) {
          return  Stack(
              children:[
                ParentWidget(
                  hasHeader: true,
                  appbarColor: AppColors.lightGreyColor,
                  appbarTitle: AppStrings.addNewCondition,
                  appbarTitleColor: AppColors.cblackColor,
                  context: context,
                  leadingWidget: IconButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(Icons.arrow_back)),
                  childWidget: Padding(
                    padding: const EdgeInsets.all(20),
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          spacing: 16,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            TextInputWidgets.textFormField(
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.conditionNameLabel,
                              hintText: AppStrings.conditionNameHint,
                              TextInputType.text,
                              TextInputAction.next,
                              _conditionNameController,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              false,
                              validator: (value) {
                                if (AppValidators.emptyValidator(value!)) {
                                  return ValidationMessages.conditionNameRequired;
                                }
                                return null;
                              },
                            ),
                            TextInputWidgets.textFormField(
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.diagnosedDateLabel,
                              TextInputType.datetime,
                              TextInputAction.next,
                              _diagnoseDateController,
                              false,
                              readOnly: true,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              trailingIcon: Icon(Icons.date_range),
                              validator: (value) {
                                if (AppValidators.emptyValidator(value!)) {
                                  return ValidationMessages.diagnosedDateRequired;
                                }
                                return null;
                              },
                              customTap: () async {
                                final DateTime? pickedDate = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2100),
                                );
                                if (pickedDate != null) {
                                  _diagnoseDateController.text =
                                      AppUtils.formatDateFromDatePicker(pickedDate);
                                }
                              },
                            ),

                            CustomSingleSelectionDropdown<HospitalListData>(
                              controller: _hospitalController,
                              items: _conditionBloc.isUIUpdated ? _conditionBloc.hospitalList : [],
                              displayValue: (hospital) => hospital.hospitalName,
                              labelText: AppStrings.hospitalLabel,
                              hintText: AppStrings.hospitalHint,
                              headTitle: AppStrings.availableHospitals,
                              onSelected: (selectedHospital) {
                                _hospitalController.text = selectedHospital.hospitalName;
                                _conditionBloc.add(SelectHospitalEvent(selectedHospital.id));
                              },
                              emptyStateText:  AppStrings.noHospitalAvailable,
                              addButtonText: AppStrings.addNewHospital,
                              onAddPressed: _handleAddHospital,
                              validator: (value) {
                                if (AppValidators.emptyValidator(value!)) {
                                  return ValidationMessages.hospitalRequired;
                                }
                                return null;
                              },
                            ),
                            CustomSingleSelectionDropdown<DoctorListData>(
                              controller: _doctorController,
                              items: _conditionBloc.isUIUpdated ? _conditionBloc.doctorList : [],
                              displayValue: (doctor) => doctor.doctorName,
                              labelText: AppStrings.doctorLabel,
                              hintText: AppStrings.doctorHint,
                              headTitle: AppStrings.availableDoctors,
                              onSelected: (selectedDoctor) {
                                _doctorController.text = selectedDoctor.doctorName;
                                _conditionBloc.add(SelectDoctorEvent(selectedDoctor.id));
                              },
                              emptyStateText:  AppStrings.noDoctorAvailable,
                              addButtonText: AppStrings.addNewDoctor,
                              onAddPressed: _handleAddDoctor,
                              validator: (value) {
                                if (AppValidators.emptyValidator(value!)) {
                                  return ValidationMessages.doctorRequired;
                                }
                                return null;
                              },
                            ),
                            TextInputWidgets.textFormField(
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.admissionDateLabel,
                              TextInputType.datetime,
                              TextInputAction.next,
                              _dateOfAdmissionController,
                              false,
                              readOnly: true,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              trailingIcon: Icon(Icons.date_range),
                              validator: (value) {
                                if (AppValidators.emptyValidator(value!)) {
                                  return ValidationMessages.admissionDateRequired;
                                }
                                return null;
                              },
                              customTap: () async {
                                final DateTime? pickedDate = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2100),
                                );
                                if (pickedDate != null) {
                                  _dateOfAdmissionController.text =
                                      AppUtils.formatDateFromDatePicker(pickedDate);
                                }
                              },
                            ),
                            CustomDropDown(
                              labelText: AppStrings.currentStatusLabel,
                              hint: TextWidgets.textWidget(
                                  fontSize: 14,
                                  AppStrings.statusHint,
                                  AppColors.cblackColor),
                              dropdownMenuItems: _conditionBloc.isUIUpdated ? _conditionBloc.statusLabelList : [],
                              value: _conditionBloc.isUIUpdated ? _conditionBloc.selectedStatus : null,
                              onChanged: (value) {
                                _conditionBloc.add(SelectStatusEvent(value));
                              },
                              validator: (value) {
                                if (value == null ||
                                    AppValidators.emptyValidator(value)) {
                                  return ValidationMessages.statusRequired;
                                }
                                return null;
                              },
                            ),
                            TextInputWidgets.textFormField(
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.dischargeDateLabel,
                              TextInputType.datetime,
                              TextInputAction.next,
                              _dateOfDischargeController,
                              false,
                              readOnly: true,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              trailingIcon: Icon(Icons.date_range),
                              customTap: () async {
                                final DateTime? pickedDate = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2100),
                                );
                                if (pickedDate != null) {
                                  _dateOfDischargeController.text =
                                      AppUtils.formatDateFromDatePicker(pickedDate);
                                }
                              },
                            ),
                            CustomDropDown(
                              labelText: AppStrings.severityLabel,
                              hint: TextWidgets.textWidget(
                                  fontSize: 14,
                                  AppStrings.severityHintText,
                                  AppColors.cblackColor),
                              dropdownMenuItems: AppStrings.severityList,
                              value: _conditionBloc.isUIUpdated ? _conditionBloc.selectedSeverity : null,
                              onChanged: (value) {
                                _conditionBloc.add(SelectSeverityEvent(value));
                              },
                            ),
                            TextInputWidgets.textFormField(
                              maxLines: 4,
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.treatmentNotesLabel,
                              hintText: AppStrings.treatmentNotesHint,
                              TextInputType.text,
                              TextInputAction.done,
                              _treatmentPlanController,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              false,
                            ),
                            FileAttachmentsWidget(
                              maxFileSizeMB: AppStrings.maxFileSize,
                              supportedTypes: AppStrings.supportedFileTypes,
                              selectedNewFiles: _conditionBloc.isUIUpdated ? _conditionBloc.newAttachments : [],
                              onFileSelected: (file) {
                                _conditionBloc.add(MedicalConditionAddNewAttachmentEvent(file));
                              },
                              onFileDeleted: (file) {
                                _conditionBloc.add(MedicalConditionRemoveNewAttachmentEvent(file));
                              },
                            ),
                            ButtonWidgets.elevatedButton(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              width: AppUtils.getScreenWidth(context),
                              radius: 7,
                              height: 50,
                              AppStrings.saveText,
                              AppColors.cprimaryColor,
                              AppColors.cwhiteColor,
                                  () {
                                    _onAddMedicalCondition(context);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Visibility(visible: state is MedicalConditionLoading, child:Loader.showLoader(AppStrings.loading))
              ]
          );
        },
      ),
    );
  }

  void _handleAddHospital() async {
    final result = await AddHospitalDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<HospitalBloc>().add(FetchHospitalListEvent());
    }
  }
  void _handleAddDoctor() async{
    final result = await AddDoctorDialog.show(context);
    if (!mounted) return;
    if (result == true) {
      context.read<DoctorBloc>().add(FetchDoctorListEvent());
    }else if (result == AppStrings.openAddHospitalDialog) {
      _handleAddHospital();
    }
  }

  void _doctorBlocListener(BuildContext context, DoctorState state) {
    if (state is DoctorLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        //Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is DoctorListSuccess) {
      final doctors = state.doctors;
      _conditionBloc.add(SetDoctorListEvent(doctors));
    } else if (state is DoctorFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _hospitalBlocListener(BuildContext context, HospitalState state) {
    if (state is HospitalLoading) {
      Loader.showLoader(AppStrings.loading);
    } else {
      if (Navigator.of(context).canPop()) {
        // Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is HospitalListSuccess) {
      _conditionBloc.add(SetHospitalListEvent(state.hospitals));
    } else if (state is HospitalFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _medicalConditionBlocListener(BuildContext context, MedicalConditionState state) {
    if (state is MedicalConditionSuccess) {
      Navigator.of(context).pop(true);
    } else if (state is MedicalConditionFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onAddMedicalCondition(BuildContext context) async {
    if (_formKey.currentState!.validate()) {

      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final List<XFile> newFiles = _conditionBloc.isUIUpdated
          ? _conditionBloc.newAttachments
          : [];
      final List<File> attachmentFiles = newFiles.map((xfile) => File(xfile.path)).toList();

      final requestModel = AddMedicalCondReqModel(
        childId: childId,
        conditionName: _conditionNameController.text.trim(),
        diagnosedDate: _diagnoseDateController.text.trim(),
        hospitalId: _conditionBloc.selectedHospitalId ?? '',
        doctorId: _conditionBloc.selectedDoctorId ?? '',
        dateOfAdmission: _dateOfAdmissionController.text.trim(),
        currentStatus: _conditionBloc.selectedStatusId ?? '',
        dateOfDischarge: _dateOfDischargeController.text.trim(),
        severity: _conditionBloc.selectedSeverity ?? '',
        treatmentPlan: _treatmentPlanController.text.trim(),
        attachments: attachmentFiles,
      );
      _conditionBloc.add(
        AddMedicalConditionEvent(addMedicalCondReqModel: requestModel),
      );
    }
  }


}
