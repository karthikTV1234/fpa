import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/common_card_item.dart';
import 'package:child_health_story/shared/widgets/common_list_view.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/text_input_widgets.dart';

class MedicalConditionsListScreen extends StatefulWidget {
  const MedicalConditionsListScreen({super.key});

  @override
  State<MedicalConditionsListScreen> createState() => _MedicalConditionsListScreenState();
}

class _MedicalConditionsListScreenState extends State<MedicalConditionsListScreen> {
  final TextEditingController _searchController = TextEditingController();
  late final MedicalConditionBloc _medicalConditionBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _medicalConditionBloc = context.read<MedicalConditionBloc>();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      _medicalConditionBloc.add(FetchMedicalConditionListEvent(childId: childId));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _mapMedicalConditionsToUI(List<MedicalConditionListData> conditions) {
    return conditions.map((condition) {
      final formattedDiagnosedDate =
      AppUtils.formatDateOnly(condition.diagnosedDate);

      Color statusColor;
      switch (condition.currentStatus.toLowerCase()) {
        case AppStrings.statusAdmitted:
          statusColor = AppColors.cBlueColor;
          break;
        case AppStrings.statusDischarged:
          statusColor = AppColors.cLightGreenColor;
          break;
        case AppStrings.statusDeceased:
          statusColor = AppColors.clRedColor;
          break;
        case AppStrings.statusObservation:
          statusColor = AppColors.yellowColor;
          break;
        case AppStrings.statusReceivingTreatment:
          statusColor = AppColors.cOrangeColor;
          break;
        default:
          statusColor = AppColors.greyColor;
      }

      return {
        "id": condition.id,
        "category": condition.doctorName,
        "status": condition.currentStatus,
        "statusColor": statusColor,
        "title": condition.conditionName,
        "subtitle": "${AppStrings.diagnosedDatePrefix}$formattedDiagnosedDate",
      };
    }).toList();
  }


  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MedicalConditionBloc, MedicalConditionState>(
      listener: (context, state) {
        if (state is MedicalConditionListSuccess) {
          mappedList = _mapMedicalConditionsToUI(state.medicalConditions);
          _medicalConditionBloc.filteredMedicalConditionList = mappedList;
        }else if (state is MedicalConditionListSearchSuccess) {
          _medicalConditionBloc.filteredMedicalConditionList = state.filteredList;
        }

        if (state is MedicalConditionFailure) {
          CustomSnackBar(
            context: context,
            message: state.error,
            messageType: AppStrings.failure,
          ).show();
        }
      },
      builder: (context, state) {
        return  Stack(
            children:[
              ParentWidget(
                appbarTitle: AppStrings.medicalConditionsTxt,
                appbarTitleColor: AppColors.cblackColor,
                appbarColor: AppColors.clightGrayColor,
                appbarSubtitle: AppStrings.medicalConditionDetailsText(
                    SharedPreferencesHelper.instance.getSelectedChildName()
                ),
                leadingWidget:IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(
                      Icons.arrow_back,
                      color: AppColors.cblackColor,
                    )),
                context: context,
                hasHeader: true,
                childWidget: ConstrainedBox(
                  constraints:
                  BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Column(
                        spacing: 8,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextWidgets.textWidget(
                                AppStrings.historyText, AppColors.cblackColor,
                                fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextInputWidgets.getTextField(
                              fillColor: AppColors.clightGrayColor,
                              textColor: AppColors.cblackColor,
                              hintText: AppStrings.searchConditionText,
                              prefixIcon: Icon(Icons.search, color: Colors.grey,
                                  size: 15),
                              controller: _searchController,
                              keyboardType: TextInputType.text,
                              onChanged: (value) {
                                _medicalConditionBloc.add(SearchMedicalConditionListEvent(
                                  textSearch: value,
                                  list: mappedList,
                                ));
                              },
                            ),
                          ),
                          Expanded(
                            child: CommonListView<Map<String, dynamic>>(
                              data: _medicalConditionBloc.filteredMedicalConditionList,
                              padding: const EdgeInsets.all(16),
                              itemBuilder: (item) =>
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: CommonCardItem(
                                      id: item["id"],
                                      category: item["category"] ?? "",
                                      status: item["status"] ?? "",
                                      statusColor: item["statusColor"],
                                      title: item["title"] ?? "",
                                      subtitle: item["subtitle"] ?? "",
                                      onTap: (selectedId)  {
                                        _navigateToDetailScreen(context, selectedId);
                                      },
                                    ),
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                floatingActionButton: ButtonWidgets.floatingActionButton(
                  Icons.add,
                  AppColors.cwhiteColor,
                  AppColors.cprimaryColor,
                      () async {
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.addMedicalConditionScreen,
                    );
                    if (result == true) {
                      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
                      if (childId.isNotEmpty) {
                        _medicalConditionBloc.add(FetchMedicalConditionListEvent(childId: childId));
                      }
                    }
                  },
                ),
              ),
              Visibility(visible: state is MedicalConditionLoading, child:Loader.showLoader(AppStrings.loading))
            ]
        );
      },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.medicalConditionDetailScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _medicalConditionBloc.add(FetchMedicalConditionListEvent(childId: childId));
      }
    }
  }

}
