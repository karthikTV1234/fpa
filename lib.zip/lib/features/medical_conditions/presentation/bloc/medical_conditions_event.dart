import 'package:child_health_story/features/medical_conditions/data/models/request/add_medical_cond_req_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/request/update_medical_cond_req_model.dart';
import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';


/// EVENTS
abstract class MedicalConditionEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddMedicalConditionEvent extends MedicalConditionEvent with EquatableMixin {
  final AddMedicalCondReqModel addMedicalCondReqModel;
  AddMedicalConditionEvent({
    required this.addMedicalCondReqModel
  });
  @override
  List<Object?> get props => [addMedicalCondReqModel];
}
class FetchMedicalConditionListEvent extends MedicalConditionEvent {
  final String childId;
  FetchMedicalConditionListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class FetchStatusListEvent extends MedicalConditionEvent {}
class SearchMedicalConditionListEvent extends MedicalConditionEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchMedicalConditionListEvent({required this.textSearch, required this.list});
}
class FetchMedicalConditionByIdEvent extends MedicalConditionEvent {
  final String medicalConditionId;
  FetchMedicalConditionByIdEvent({required this.medicalConditionId});
  @override
  List<Object?> get props => [medicalConditionId];
}
class UpdateMedicalConditionEvent extends MedicalConditionEvent {
  final String medicalConditionId;
  final UpdateMedicalCondReqModel updateMedicalCondReqModel;
  UpdateMedicalConditionEvent({
    required this.medicalConditionId,
    required this.updateMedicalCondReqModel,
  });
  @override
  List<Object?> get props => [medicalConditionId, updateMedicalCondReqModel];
}
class DeleteMedicalConditionEvent extends MedicalConditionEvent {
  final String medicalConditionId;
  DeleteMedicalConditionEvent({required this.medicalConditionId});
  @override
  List<Object?> get props => [medicalConditionId];
}
class SetHospitalListEvent extends MedicalConditionEvent {
  final List<HospitalListData> hospitals;
  SetHospitalListEvent(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class SelectHospitalEvent extends MedicalConditionEvent {
  final String hospitalId;
  SelectHospitalEvent(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class SetDoctorListEvent extends MedicalConditionEvent {
  final List<DoctorListData> doctors;
  SetDoctorListEvent(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class SelectDoctorEvent extends MedicalConditionEvent {
  final String doctorId;
  SelectDoctorEvent(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class SelectSeverityEvent extends MedicalConditionEvent {
  final String severity;
  SelectSeverityEvent(this.severity);
}
class SelectStatusEvent extends MedicalConditionEvent {
  final String statusValue;
  SelectStatusEvent(this.statusValue);
  @override
  List<Object?> get props => [statusValue];
}
class PreselectStatusEvent extends MedicalConditionEvent {
  final String statusId;
  PreselectStatusEvent(this.statusId);
  @override
  List<Object?> get props => [statusId];
}
class MedicalConditionAddNewAttachmentEvent extends MedicalConditionEvent {
  final XFile file;
  MedicalConditionAddNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class MedicalConditionRemoveNewAttachmentEvent extends MedicalConditionEvent {
  final XFile file;
  MedicalConditionRemoveNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class ClearMedicalConditionFormEvent extends MedicalConditionEvent {}


