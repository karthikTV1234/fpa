import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/repository/medical_condition_repository.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/medical_cond_status_list_res_model.dart';

/// BLOC
class MedicalConditionBloc extends Bloc<MedicalConditionEvent, MedicalConditionState> {
  List<Map<String, dynamic>> filteredMedicalConditionList = [];
  final MedicalConditionRepository medicalConditionRepository;
  bool isUIUpdated = false;
  dynamic selectedSeverity;
  String? selectedHospitalId;
  List<HospitalListData> hospitalList = [];
  String? selectedDoctorId;
  List<DoctorListData> doctorList = [];
  List<MedicalConditionStatusData> statusList = [];
  List<String> statusLabelList = [];
  String? selectedStatus;
  String? selectedStatusId;
  List<XFile> newAttachments = [];
  MedicalConditionDetailData? medicalConditionDetailData;

  MedicalConditionBloc({required this.medicalConditionRepository}) : super(MedicalConditionInitial()) {
    on<SetHospitalListEvent>((event, emit) {
      hospitalList = event.hospitals;
      isUIUpdated = true;
      emit(HospitalListSet(event.hospitals));
    });
    on<SelectHospitalEvent>((event, emit) {
      isUIUpdated = true;
      selectedHospitalId = event.hospitalId;
      emit(HospitalSelected(event.hospitalId));
    });
    on<SetDoctorListEvent>((event, emit) {
      doctorList = event.doctors;
      isUIUpdated = true;
      emit(DoctorListSet(event.doctors));
    });
    on<SelectDoctorEvent>((event, emit) {
      isUIUpdated = true;
      selectedDoctorId = event.doctorId;
      emit(DoctorSelected(event.doctorId));
    });
    on<SelectSeverityEvent>((event, emit) {
      isUIUpdated = true;
      selectedSeverity = event.severity;
      emit(SeveritySelected(event.severity));
    });
    on<SelectStatusEvent>((event, emit) {
      isUIUpdated = true;
      selectedStatus = event.statusValue;
      final selectedModel = statusList.firstWhere(
            (element) => element.conditionStatus == selectedStatus,
        orElse: () => MedicalConditionStatusData(),
      );
      selectedStatusId = selectedModel.id;
      emit(StatusSelected(event.statusValue));
    });
    on<PreselectStatusEvent>((event, emit) {
      final matched = statusList.firstWhere(
            (element) => element.id == event.statusId,
        orElse: () => MedicalConditionStatusData(),
      );
      selectedStatusId = matched.id;
      selectedStatus = matched.conditionStatus;
      isUIUpdated = true;
      emit(StatusSelected(matched.conditionStatus));
    });
    on<MedicalConditionAddNewAttachmentEvent>((event, emit) {
      newAttachments.add(event.file);
      isUIUpdated = true;
      emit(MedicalConditionAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });
    on<MedicalConditionRemoveNewAttachmentEvent>((event, emit) {
      newAttachments.removeWhere((f) => f.path == event.file.path);
      isUIUpdated = true;
      newAttachments = List<XFile>.from(newAttachments);
      emit(MedicalConditionAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<SearchMedicalConditionListEvent>((event, emit) {
      if (event.textSearch.trim().isEmpty) {
        filteredMedicalConditionList = event.list;
      } else {
        filteredMedicalConditionList = event.list.where((element) {
          final title = (element["title"] ?? "").toLowerCase();
          return title.contains(event.textSearch.toLowerCase());
        }).toList();
      }
      emit(MedicalConditionListSearchSuccess(filteredMedicalConditionList));
    });

    on<AddMedicalConditionEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.addMedicalCondition(
          event.addMedicalCondReqModel
      );
      if (result.isSuccess) {
        emit(MedicalConditionSuccess(message: result.data?.message ?? AppStrings.medicalConditionAddedSuccessMessage));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchMedicalConditionListEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.getMedicalConditionList(event.childId);
      if (result.isSuccess && result.data != null) {
        final MedicalConditionListResModel resModel = result.data!;
        emit(MedicalConditionListSuccess(resModel.data));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchStatusListEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.getMedicalConditionStatusList();
      if (result.isSuccess && result.data != null) {
        final MedicalConditionStatusListResModel resModel = result.data!;
        statusList = resModel.data;
        statusLabelList.addAll(
          statusList.map((e) => e.conditionStatus).where((e) => e.isNotEmpty),
        );
        isUIUpdated = true;
        emit(StatusListSuccess(resModel.data));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchMedicalConditionByIdEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.getMedicalConditionDetails(event.medicalConditionId);
      if (result.isSuccess && result.data != null) {
        final GetMedicalConditionDetailResModel resModel = result.data!;
        medicalConditionDetailData = resModel.data;
        isUIUpdated = true;
        emit(MedicalConditionByIdSuccess(resModel.data));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateMedicalConditionEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.updateMedicalConditionDetails(
          event.updateMedicalCondReqModel,
          event.medicalConditionId
      );
      if (result.isSuccess) {
        emit(MedicalConditionSuccess(message: result.data?.message ?? AppStrings.medicalConditionUpdateSuccessMessage));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteMedicalConditionEvent>((event, emit) async {
      emit(MedicalConditionLoading());
      final result = await medicalConditionRepository.deleteMedicalCondition(event.medicalConditionId);
      if (result.isSuccess && result.data != null) {
        emit(MedicalConditionSuccess(message: result.data?.message ??  AppStrings.medicalConditionDeleteSuccessMessage));
      } else {
        emit(MedicalConditionFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearMedicalConditionFormEvent>((event, emit) {
      hospitalList.clear();
      selectedHospitalId = null;
      doctorList.clear();
      selectedDoctorId = null;
      newAttachments.clear();
      isUIUpdated = false;
      emit(MedicalConditionInitial());
    });
  }
}
