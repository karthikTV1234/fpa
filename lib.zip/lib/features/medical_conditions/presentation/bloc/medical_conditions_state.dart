import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_detail_res_model.dart';
import 'package:child_health_story/features/medical_conditions/data/models/response/medical_cond_list_res_model.dart';
import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/medical_cond_status_list_res_model.dart';

/// STATES
abstract class MedicalConditionState extends Equatable {
  @override
  List<Object?> get props => [];
}
class MedicalConditionInitial extends MedicalConditionState {}
class MedicalConditionLoading extends MedicalConditionState {}
class MedicalConditionSuccess extends MedicalConditionState {
  final String message;
  MedicalConditionSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class MedicalConditionListSuccess extends MedicalConditionState {
  final List<MedicalConditionListData> medicalConditions;
  MedicalConditionListSuccess(this.medicalConditions);
  @override
  List<Object?> get props => [medicalConditions];
}
class MedicalConditionListSearchSuccess extends MedicalConditionState {
  final List<Map<String, dynamic>> filteredList;
  MedicalConditionListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class StatusListSuccess extends MedicalConditionState {
  final List<MedicalConditionStatusData> statusList;
  StatusListSuccess(this.statusList);
  @override
  List<Object?> get props => [statusList];
}
class MedicalConditionByIdSuccess extends MedicalConditionState {
  final MedicalConditionDetailData? medicalConditionDetailData;
  MedicalConditionByIdSuccess(this.medicalConditionDetailData);
  @override
  List<Object?> get props => [medicalConditionDetailData];
}
class MedicalConditionFailure extends MedicalConditionState {
  final String error;
  MedicalConditionFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class HospitalListSet extends MedicalConditionState {
  final List<HospitalListData> hospitals;
  HospitalListSet(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class HospitalSelected extends MedicalConditionState {
  final String hospitalId;
  HospitalSelected(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DoctorListSet extends MedicalConditionState {
  final List<DoctorListData> doctors;
  DoctorListSet(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class DoctorSelected extends MedicalConditionState {
  final String doctorId;
  DoctorSelected(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class SeveritySelected extends MedicalConditionState {
  final String severity;
  SeveritySelected(this.severity);
  @override
  List<Object?> get props => [severity];
}
class StatusSelected extends MedicalConditionState {
  final String status;
  StatusSelected(this.status);
  @override
  List<Object?> get props => [status];
}
class MedicalConditionAttachmentsUpdated extends MedicalConditionState with EquatableMixin {
  final List<XFile> attachments;
  MedicalConditionAttachmentsUpdated(this.attachments);
  @override
  List<Object?> get props => [attachments];
}
class MedicalConditionFormReset extends MedicalConditionState {}
