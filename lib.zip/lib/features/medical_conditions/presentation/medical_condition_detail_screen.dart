import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_bloc.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_event.dart';
import 'package:child_health_story/features/medical_conditions/presentation/bloc/medical_conditions_state.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/file_attachments.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/file_utils.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';

class MedicalConditionDetailScreen extends StatefulWidget {
  final String medicalConditionId;
  const MedicalConditionDetailScreen({super.key, required this.medicalConditionId});

  @override
  State<MedicalConditionDetailScreen> createState() => _MedicalConditionDetailScreenState();
}

class _MedicalConditionDetailScreenState extends State<MedicalConditionDetailScreen> {
  late MedicalConditionBloc _conditionBloc;
  bool _hasUpdated = false;

  @override
  void initState() {
    super.initState();
    _conditionBloc = BlocProvider.of<MedicalConditionBloc>(context);
    _conditionBloc.add(
        FetchMedicalConditionByIdEvent(medicalConditionId: widget.medicalConditionId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MedicalConditionBloc, MedicalConditionState>(
      listener: _conditionBlocListener,
      builder: (context, state) {
        final conditionData = _conditionBloc.isUIUpdated
            ? _conditionBloc.medicalConditionDetailData
            : null;
        return Stack(
            children: [
             ParentWidget(
            context: context,
            hasHeader: true,
            appbarColor: AppColors.lightGreyColor,
            appbarTitle: AppStrings.medicationConditionDetails,
            appbarTitleColor: AppColors.cblackColor,
                 leadingWidget: IconButton(
                   onPressed: () {
                     if (_hasUpdated) {
                       Navigator.of(context).pop(true);
                     } else {
                       Navigator.of(context).pop();
                     }
                   },
                   icon: const Icon(Icons.arrow_back),
                 ),
            rightWidget: IconButton(
              onPressed: () async {
                if (conditionData != null) {
                  final result = await Navigator.pushNamed(
                    context,
                    PathConstants.editMedicalConditionScreen,
                    arguments: conditionData,
                  );
                  if (result == true) {
                    _conditionBloc.add(FetchMedicalConditionByIdEvent(
                        medicalConditionId: widget.medicalConditionId));
                    _hasUpdated = true;
                  }
                }
              },
              icon: const Icon(Icons.edit),
            ),
            childWidget: Padding(
              padding: const EdgeInsets.all(15),
              child: SingleChildScrollView(
                child: Column(
                  spacing: 20,
                  children: [
                    Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                            color: AppColors.cwhiteColor,
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          spacing: 20,
                          children: [
                            ListviewCard(
                                icon: Icon(Icons.description),
                                title: AppStrings.conditionName,
                                subTitle: conditionData?.conditionName ?? '',
                            ),
                            ListviewCard(
                                icon: Icon(Icons.date_range_outlined),
                                title: AppStrings.diagonosedDate,
                                subTitle: AppUtils.formatDateOnly(
                                    conditionData?.diagnosedDate ?? ''),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.local_hospital),
                              title: AppStrings.hospitalNameText,
                              subTitle: conditionData?.hospitalName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.person),
                              title: AppStrings.doctorText,
                              subTitle: conditionData?.doctorName ?? '',
                            ),
                            ListviewCard(
                              icon: Icon(Icons.date_range_outlined),
                              title: AppStrings.admissionDateLabelDetail,
                              subTitle: AppUtils.formatDateOnly(
                                  conditionData?.dateOfAdmission ?? ''),
                            ),
                            ListviewCard(
                                icon: Icon(Icons.star_outline_sharp),
                                title: AppStrings.currentStatus,
                                subTitle:  conditionData?.currentStatusName ?? '',
                            ),
                            ListviewCard(
                                icon: Icon(Icons.health_and_safety),
                                title: AppStrings.severityDetailLabel,
                                subTitle:  conditionData?.severity ?? '',
                            ),
                            ListviewCard(
                              icon: Icon(Icons.date_range_outlined),
                              title: AppStrings.dischargeDateLabelDetail,
                              subTitle: AppUtils.formatDateOnly(
                                  conditionData?.dateOfDischarge ?? ''),
                            ),
                            ListviewCard(
                              icon: Icon(Icons.notes),
                              title: AppStrings.treatmentNotes,
                              subTitle: conditionData?.treatmentPlan ?? '',
                              hasDivider: false,
                            )
                          ],
                        )),
                    Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                        spacing: 10,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWidgets.textWidget(
                              AppStrings.attachmentsTxt, AppColors.cblackColor,
                              fontSize: 16, fontWeight: FontWeight.w700),
                          FileAttachments(
                            files: conditionData?.attachments ?? [],
                            onFileTap: (filePath) {
                              String path  = AppUtils.buildImageFullUrl(filePath) ?? '';
                              FileUtils.previewOrDownloadFile(context, path);
                            },
                          ),
                        ],
                      ),
                    ),
                    ButtonWidgets.elevatedButton(AppStrings.deleteTxt,
                        AppColors.lightRedColor, AppColors.cwhiteColor,
                            () => _onDelete(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        radius: 7,
                        width: MediaQuery.of(context).size.width,
                        height: 50)
                  ],
                ),
              ),
            )
        ),
             Visibility(
              visible: state is MedicalConditionLoading,
              child: Loader.showLoader(AppStrings.loading),
             ),
           ],
        );
      },
    );
  }

  void _conditionBlocListener(BuildContext context, MedicalConditionState state) {
    if (state is MedicalConditionSuccess) {
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
      Navigator.of(context).pop(true);
    }
    else if (state is MedicalConditionFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onDelete(BuildContext context) async {
    if (widget.medicalConditionId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteMedicalConditionTitle,
        contentText: AppStrings.deleteMedicalConditionConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          _conditionBloc.add(DeleteMedicalConditionEvent(medicalConditionId: widget.medicalConditionId));
        },
      );
    }
  }
}
