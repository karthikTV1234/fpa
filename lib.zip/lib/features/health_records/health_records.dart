import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/features/health_records/bloc/health_record_events.dart';
import 'package:child_health_story/shared/widgets/custom_listview_separted.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/utils/shared_preferences.dart';
import 'bloc/health_record_bloc.dart';
import 'bloc/health_record_state.dart';

class HealthRecords extends StatefulWidget {
  const HealthRecords({super.key});

  @override
  State<HealthRecords> createState() => _HealthRecordsState();
}

class _HealthRecordsState extends State<HealthRecords> {
  final TextEditingController _searchController = TextEditingController();
  late final HealthRecordBloc _healthRecordBloc;

  @override
  void initState() {
    super.initState();
    _healthRecordBloc = context.read<HealthRecordBloc>();
    final childName = SharedPreferencesHelper.instance.getSelectedChildName();
    final childProfileImage = SharedPreferencesHelper.instance.getSelectedChildProfilePhoto();
    _healthRecordBloc.add(
      SetSelectedChildEvent(
        name: childName,
        profileImage: childProfileImage,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HealthRecordBloc, HealthRecordState>(
        listener: (context, state) {
        },
        builder: (context, state) {
    return ParentWidget(
      hasHeader: true,
      appbarTitle: _healthRecordBloc.isUIUpdated ? _healthRecordBloc.selectedChildName : "",
      appbarTitleColor: AppColors.cblackColor,
      appbarColor: AppColors.clightGrayColor,
      appbarHeight: 91,
      appbarSubtitle: AppStrings.switchChildText,
      subtitleTrailingWidget: Icon(
        Icons.sync_alt,
        size: 15,
      ),
      onSubTitlePressed: () async {
        final result = await context.showChildListBottomSheet();
        if (result == true) {
          final childName = SharedPreferencesHelper.instance.getSelectedChildName();
          final childProfileImage = SharedPreferencesHelper.instance.getSelectedChildProfilePhoto();
          _healthRecordBloc.add(
            SetSelectedChildEvent(
              name: childName,
              profileImage: childProfileImage,
            ),
          );
        }
      },
      rightWidget: CircleAvatar(
        radius: 12,
        backgroundColor: AppColors.cwhiteColor,
        child: Icon(
          Icons.person,
          color: AppColors.cblackColor,
        ),
      ),
      rightLabel: AppStrings.parentProfileText,
      onRightWidgetTap: () {},
      leadingWidget: GestureDetector(
        onTap: () {},
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.cwhiteColor,
            image: _healthRecordBloc.selectedChildProfileImage.isNotEmpty
                ? DecorationImage(
              image: NetworkImage(_healthRecordBloc.selectedChildProfileImage),
              fit: BoxFit.cover,
            )
                : null,
            border: Border.all(color: AppColors.circleBorderColor, width: 1),
          ),
        ),
      ),
      context: context,
      childWidget: ConstrainedBox(
        constraints:
            BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
        child: IntrinsicHeight(
          child: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Column(
              spacing: 8,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: TextWidgets.textWidget(
                      AppStrings.healthRecordsText, AppColors.cblackColor,
                      fontSize: 24, fontWeight: FontWeight.bold),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: TextInputWidgets.getTextField(
                    fillColor: AppColors.clightGrayColor,
                    textColor: AppColors.cblackColor,
                    hintText: AppStrings.searchText,
                    controller: _searchController,
                    onChanged: (value) {},
                  ),
                ),
                Expanded(
                  child: CustomSeparatedListView(
                    items: AppStrings.healthRecords,
                    onItemTap: (record) {
                      final route = record["route"];
                      if (route != null) {
                        Navigator.pushNamed(context, route);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
        },
          );
  }

}
