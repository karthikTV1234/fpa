import 'package:flutter_bloc/flutter_bloc.dart';
import 'health_record_events.dart';
import 'health_record_state.dart';

/// BLOC
class HealthRecordBloc extends Bloc<HealthRecordEvent, HealthRecordState> {
  bool isUIUpdated = false;
  String selectedChildName ='';
  String selectedChildProfileImage ='';

  HealthRecordBloc() : super(HealthRecordInitial()) {
    on<SetSelectedChildEvent>((event, emit) {
      emit(HealthRecordLoading());
      selectedChildName = event.name;
      selectedChildProfileImage = event.profileImage;
      isUIUpdated = true;
      emit(SelectedChildSet(event.name, event.profileImage));
    });
  }
}
