import 'package:equatable/equatable.dart';

/// STATES
abstract class HealthRecordState extends Equatable {
  @override
  List<Object?> get props => [];
}
class HealthRecordInitial extends HealthRecordState {}
class HealthRecordLoading extends HealthRecordState {}
class SelectedChildSet extends HealthRecordState {
  final String name;
  final String profileImage;
  SelectedChildSet(this.name, this.profileImage);
}
