import 'package:equatable/equatable.dart';

/// EVENTS
abstract class HealthRecordEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class SetSelectedChildEvent extends HealthRecordEvent {
  final String name;
  final String profileImage;
  SetSelectedChildEvent({
    required this.name,
    required this.profileImage,
  });
}