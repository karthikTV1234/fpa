import 'package:child_health_story/features/care_taker/data/model/request/add_care_taker_req_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/utils/extensions.dart';
import '../model/response/care_taker_detail_res_model.dart';
import '../model/response/care_taker_list_res_model.dart';
import '../model/response/care_taker_relationship_list_res_model.dart';


class CareTakerRepository {
  final Dio _dio;

  CareTakerRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<CommonResModel>> addCareTaker(AddCaretakerReqModel addReqModel) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.add, AppStrings.careTakerLowerCase);
    try {
      const String url = '${ApiConstants.baseUrl}${ApiConstants.createCareTaker}';
      final response = await _dio.post(
        url,
        data: addReqModel.toJson(),
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final addRes = CommonResModel.fromJson(response.data);
        return Result.success(addRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetCaretakersListResModel>> getCareTakerList(String childId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.fetch, AppStrings.careTakerLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.careTakerList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final listRes = GetCaretakersListResModel.fromJson(response.data);
        return Result.success(listRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetRelationshipTypesListResModel>> getCareTakerRelationshipList() async {
    String errorMessage = AppStrings.errorMessage(EntityAction.fetch, AppStrings.careTakerLowerCase);
    try {
      const String url = '${ApiConstants.baseUrl}${ApiConstants.careTakerRelationshipList}';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final listRes = GetRelationshipTypesListResModel.fromJson(response.data);
        return Result.success(listRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetCaretakerDetailResModel>> getCareTakerDetails(String careTakerId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.fetchDetails, AppStrings.careTakerLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.careTakerDetails}/$careTakerId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final res = GetCaretakerDetailResModel.fromJson(response.data);
        return Result.success(res);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateCareTaker(String careTakerId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.update, AppStrings.careTakerLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.updateCareTakerRecord}/$careTakerId';
      final response = await _dio.patch(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || response.statusCode == 201) {
        final res = CommonResModel.fromJson(response.data);
        return Result.success(res);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteCareTaker(String careTakerId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.delete, AppStrings.careTakerLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.deleteCareTaker}/$careTakerId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 ||codeLevelStatus == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
