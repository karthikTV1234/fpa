class AddCaretakerReqModel {
  final String childId;
  final String name;
  final String email;
  final String phoneNumber;
  final String countryCode;
  final String address;
  final bool isPrimary;
  final String relationship;
  final double latitude;
  final double longitude;

  AddCaretakerReqModel({
    this.childId = '',
    this.name = '',
    this.email = '',
    this.phoneNumber = '',
    this.countryCode = '',
    this.address = '',
    this.isPrimary = false,
    this.relationship = '',
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  Map<String, dynamic> toJson() {
    return {
      "childId": childId,
      "name": name,
      "email": email,
      "phoneNumber": phoneNumber,
      "countryCode": countryCode,
      "address": address,
      "isPrimary": isPrimary,
      "relationship": relationship,
      "latitude": latitude,
      "longitude": longitude,
    };
  }
}
