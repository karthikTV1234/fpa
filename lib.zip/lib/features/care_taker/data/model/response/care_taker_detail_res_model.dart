class GetCaretakerDetailResModel {
  final int statusCode;
  final String message;
  final CaretakerDetailData data;

  GetCaretakerDetailResModel({
    this.statusCode = 0,
    this.message = '',
    CaretakerDetailData? data,
  }) : data = data ?? CaretakerDetailData();

  factory GetCaretakerDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetCaretakerDetailResModel();

    return GetCaretakerDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: CaretakerDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class CaretakerDetailData {
  final String id;
  final String name;
  final String email;
  final String phoneNumber;
  final String countryCode;
  final String address;
  final bool isPrimary;
  final String relationshipId;
  final String relationshipName;

  CaretakerDetailData({
    this.id = '',
    this.name = '',
    this.email = '',
    this.phoneNumber = '',
    this.countryCode = '',
    this.address = '',
    this.isPrimary = false,
    this.relationshipId = '',
    this.relationshipName = '',
  });

  factory CaretakerDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return CaretakerDetailData();

    return CaretakerDetailData(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phoneNumber: json['phoneNumber'] as String? ?? '',
      countryCode: json['countryCode'] as String? ?? '',
      address: json['address'] as String? ?? '',
      isPrimary: json['isPrimary'] as bool? ?? false,
      relationshipId: json['relationshipId'] as String? ?? '',
      relationshipName: json['relationshipName'] as String? ?? '',
    );
  }
}
