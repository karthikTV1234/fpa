class GetCaretakersListResModel {
  final int statusCode;
  final String message;
  final List<CaretakerListData> data;

  GetCaretakersListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetCaretakersListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetCaretakersListResModel();

    return GetCaretakersListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => CaretakerListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class CaretakerListData {
  final String id;
  final String name;
  final String phoneNumber;
  final String countryCode;
  final String address;
  final bool isPrimary;

  CaretakerListData({
    this.id = '',
    this.name = '',
    this.phoneNumber = '',
    this.countryCode = '',
    this.address = '',
    this.isPrimary = false,
  });

  factory CaretakerListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return CaretakerListData();

    return CaretakerListData(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      phoneNumber: json['phoneNumber'] as String? ?? '',
      countryCode: json['countryCode'] as String? ?? '',
      address: json['address'] as String? ?? '',
      isPrimary: json['isPrimary'] as bool? ?? false,
    );
  }
}
