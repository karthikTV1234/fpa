class GetRelationshipTypesListResModel {
  final int statusCode;
  final String message;
  final List<RelationshipTypeListData> data;

  GetRelationshipTypesListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetRelationshipTypesListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetRelationshipTypesListResModel();

    return GetRelationshipTypesListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => RelationshipTypeListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class RelationshipTypeListData {
  final String id;
  final String relationshipName;

  RelationshipTypeListData({
    this.id = '',
    this.relationshipName = '',
  });

  factory RelationshipTypeListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return RelationshipTypeListData();

    return RelationshipTypeListData(
      id: json['id'] as String? ?? '',
      relationshipName: json['relationshipName'] as String? ?? '',
    );
  }
}
