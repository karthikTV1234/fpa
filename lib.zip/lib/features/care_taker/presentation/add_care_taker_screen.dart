import 'package:child_health_story/features/care_taker/data/model/request/add_care_taker_req_model.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/constants/color/app_colors.dart';
import '../../../../../core/constants/strings/app_strings.dart';
import '../../../../../core/constants/strings/validation_messages.dart';
import '../../../../../core/utils/app_utils.dart';
import '../../../../../core/utils/app_validators.dart';
import '../../../../../shared/widgets/button_widgets.dart';
import '../../../../../shared/widgets/custom_dropdown.dart';
import '../../../../../shared/widgets/custom_radio_list_tile.dart';
import '../../../../../shared/widgets/parent_widget.dart';
import '../../../../../shared/widgets/text_input_widgets.dart';
import '../../../../../shared/widgets/text_widgets.dart';
import '../../../core/constants/strings/app_data.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'bloc/care_taker_events.dart';

class AddCareTakerScreen extends StatefulWidget {
  const AddCareTakerScreen({super.key});

  @override
  State<AddCareTakerScreen> createState() => _AddCareTakerScreenState();
}

class _AddCareTakerScreenState extends State<AddCareTakerScreen> {
  final TextEditingController _careTakerNameController =
      TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  late CareTakerBloc _careTakerBloc;
  int? selectedValue;

  @override
  void dispose() {
    _careTakerNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _careTakerBloc = BlocProvider.of<CareTakerBloc>(context);
    _careTakerBloc.add(FetchCareTakerRelationshipListEvent());
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CareTakerBloc, CareTakerState>(
        listener: (context, state) {
          if (state is CareTakerSuccess) {
            CustomSnackBar(
              context: context,
              message: state.message,
              messageType: AppStrings.success,
            ).show();
            Navigator.of(context).pop(true);
          }
          else if (state is CareTakerFailure) {
            CustomSnackBar(
              context: context,
              message: state.error,
              messageType: AppStrings.failure,
            ).show();
          }
        },
        builder: (context, state) {
          return Stack(
              children: [
                ParentWidget(
        appbarHeight: 70,
        hasHeader: true,
        appbarTitle: AppStrings.addCareTakerText,
        appbarColor: AppColors.clightGrayColor,
        leadingWidget: ButtonWidgets.getIconButton(Icon(Icons.arrow_back), () {
          Navigator.pop(context);
        }),
        context: context,
        childWidget: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
              child: IntrinsicHeight(
                child: Form(
                  key: _formKey,
                  child: Column(
                      spacing: 16,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextInputWidgets.textFormField(
                          fillColor: AppColors.appBackGroundColor,
                          AppStrings.careTakerNameLabel,
                          hintText: AppStrings.careTakerHintText,
                          TextInputType.text,
                          TextInputAction.next,
                          _careTakerNameController,
                          enabledBorderColor: AppColors.cmediumGrayColor,
                          focusedBorderColor: AppColors.cmediumGrayColor,
                          false,
                          validator: (value) {
                            if (AppValidators.emptyValidator(value!)) {
                              return ValidationMessages.careTakerNameReq;
                            }
                            return null;
                          },
                        ),
                        Row(
                          spacing: 10,
                          children: [
                            Expanded(
                              flex: 2,
                              child: CustomDropDown(
                                labelText: AppStrings.countryCodeLabel,
                                hint: TextWidgets.textWidget(
                                    fontSize: 14,
                                    AppStrings.countryCodeHintText,
                                    AppColors.cblackColor),
                                dropdownMenuItems: AppData.countryCodes,
                                value: _careTakerBloc.selectedCountryCode,
                                onChanged: (value) {
                                  _careTakerBloc.add(SelectCountryCodeEvent(value));
                                },
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value ?? '')) {
                                    return ValidationMessages.plsSelectCountryCode;
                                  }
                                  return null;
                                },
                              ),
                            ),
                            Expanded(
                              flex: 5,
                              child: TextInputWidgets.textFormField(
                                fillColor: AppColors.appBackGroundColor,
                                AppStrings.phoneLabelWithOutAsterisk,
                                hintText: AppStrings.enterPhoneNumberHintText,
                                TextInputType.phone,
                                TextInputAction.done,
                                _phoneController,
                                enabledBorderColor: AppColors.cmediumGrayColor,
                                focusedBorderColor: AppColors.cmediumGrayColor,
                                false,
                                validator: (value) {
                                  if (AppValidators.emptyValidator(value ?? '')) {
                                    return ValidationMessages.plsEnterPhoneNumber;
                                  } else if (!AppValidators.phoneValidator(value!)) {
                                    return ValidationMessages.plsEnterValidPhoneNumber;
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ],
                        ),
                        CustomDropDown(
                          labelText: AppStrings.relationshipText,
                          hint: TextWidgets.textWidget(
                              fontSize: 14,
                              AppStrings.relationShipHintText,
                              AppColors.cblackColor),
                          dropdownMenuItems: _careTakerBloc.isUIUpdated ? _careTakerBloc.relationshipLabelList : [],
                          value: _careTakerBloc.isUIUpdated ? _careTakerBloc.selectedRelationship : null,
                          onChanged: (value) {
                            _careTakerBloc.add(SelectRelationshipTypeEvent(value));
                          },
                          validator: (value) {
                            if (value == null ||
                                AppValidators.emptyValidator(value)) {
                              return ValidationMessages.relationShip;
                            }
                            return null;
                          },
                        ),
                        TextInputWidgets.textFormField(
                          fillColor: AppColors.appBackGroundColor,
                          AppStrings.emailLabel,
                          hintText: AppStrings.enterEmailHintText,
                          TextInputType.text,
                          TextInputAction.next,
                          _emailController,
                          enabledBorderColor: AppColors.cmediumGrayColor,
                          focusedBorderColor: AppColors.cmediumGrayColor,
                          false,
                        ),
                        TextInputWidgets.textFormField(
                          maxLines: 4,
                          fillColor: AppColors.appBackGroundColor,
                          AppStrings.addressText,
                          hintText: AppStrings.enterAddressHintText,
                          TextInputType.text,
                          TextInputAction.done,
                          _addressController,
                          enabledBorderColor: AppColors.cmediumGrayColor,
                          focusedBorderColor: AppColors.cmediumGrayColor,
                          false,
                          validator: (value) {
                            if (AppValidators.emptyValidator(value!)) {
                              return ValidationMessages.addressReq;
                            }
                            return null;
                          },
                        ),
                        CustomRadioListTile(
                          title: AppStrings.setPrimaryCareTakerText,
                          value: 0,
                          groupValue: _careTakerBloc.isUIUpdated ? _careTakerBloc.isPrimarySelected : null,
                          onChanged: (val) {
                            _careTakerBloc.add(SelectPrimaryCareTakerEvent(val!));
                          },
                        ),
                        ButtonWidgets.elevatedButton(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            width: AppUtils.getScreenWidth(context),
                            radius: 7,
                            height: 50,
                            AppStrings.addCareTakerBtnText,
                            AppColors.cprimaryColor,
                            AppColors.cwhiteColor, () {
                          _onAddCareTaker(context);
                        },
                        )
                      ]),
                ),
              ),
            ),
          ),
        )
          ),
                Visibility(
            visible: state is CareTakerLoading,
            child: Loader.showLoader(AppStrings.loading),
          ),
              ],
          );
        },
    );
  }

  void _onAddCareTaker(BuildContext context) async {
    if (_formKey.currentState!.validate()) {

      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final phone = _phoneController.text.trim();
      final requestModel = AddCaretakerReqModel(
        childId: childId,
        name: _careTakerNameController.text.trim(),
        countryCode: phone.isEmpty ? "" : _careTakerBloc.selectedCountryCode,
        phoneNumber: phone,
        email: _emailController.text.trim().isEmpty ? "" : _emailController.text.trim(),
        address: _addressController.text.trim(),
        relationship: _careTakerBloc.selectedRelationshipId ?? '',
        isPrimary: (_careTakerBloc.isPrimarySelected) == 0 ? true : false,
      );
      _careTakerBloc.add(
        AddCareTakerEvent(addCaretakerReqModel: requestModel),
      );
    }
  }
}
