import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_bloc.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/constants/color/app_colors.dart';
import '../../../../../core/constants/dimensions.dart';
import '../../../../../core/constants/strings/app_strings.dart';
import '../../../../../core/utils/app_utils.dart';
import '../../../../../shared/widgets/button_widgets.dart';
import '../../../../../shared/widgets/custom_radio_list_tile.dart';
import '../../../../../shared/widgets/listview_card.dart';
import '../../../../../shared/widgets/parent_widget.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'bloc/care_taker_state.dart';

class CareTakerDetailScreen extends StatefulWidget {
  final String careTakerId;
  const CareTakerDetailScreen({super.key, required this.careTakerId});

  @override
  State<CareTakerDetailScreen> createState() => _CareTakerDetailScreenState();
}

class _CareTakerDetailScreenState extends State<CareTakerDetailScreen> {
  late CareTakerBloc _careTakerBloc;

  @override
  void initState() {
    super.initState();
    _careTakerBloc = BlocProvider.of<CareTakerBloc>(context);
    _careTakerBloc.add(
        FetchCareTakerByIdEvent(careTakerId: widget.careTakerId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CareTakerBloc, CareTakerState>(
        listener: (context, state) {
          if (state is CareTakerSuccess) {
            CustomSnackBar(
              context: context,
              message: state.message,
              messageType: AppStrings.success,
            ).show();
            Navigator.of(context).pop(true);
          }
          else if (state is CareTakerFailure) {
            CustomSnackBar(
              context: context,
              message: state.error,
              messageType: AppStrings.failure,
            ).show();
          }
        },
        builder: (context, state) {
          final careTakerData = _careTakerBloc.isUIUpdated
              ? _careTakerBloc.careTakerDetailData
              : null;
          return Stack(
            children: [
     ParentWidget(
      hasHeader: true,
      appbarTitle: AppStrings.careTakerDetailsText,
      appbarTitleColor: AppColors.cblackColor,
      appbarColor: AppColors.clightGrayColor,
      appbarHeight: AppDimensions.appbarHeight,
      leadingWidget: ButtonWidgets.getIconButton(
        const Icon(Icons.arrow_back),
        () => Navigator.pop(context),
      ),
      context: context,
      childWidget: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          spacing: 12,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.cwhiteColor,
                borderRadius: BorderRadius.circular(6),
              ),
              child: CustomRadioListTile(
                title: AppStrings.setPrimaryCareTakerText,
                value: 0,
                groupValue: careTakerData?.isPrimary == true ? 0 : null,
                onChanged: (p0) {},
              ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.cwhiteColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                children: [
                  ListviewCard(
                    title: AppStrings.genderLabel,
                    subTitle: careTakerData?.name ?? AppStrings.noDataText,
                    icon: Icon(Icons.person),
                    titlefontSize: 16,
                    titlefontWeight: FontWeight.bold,
                    subtitlefontSize: 16,
                    subtitlefontWeight: FontWeight.w400,
                  ),
                  ListviewCard(
                    title: AppStrings.phoneLabel,
                    subTitle: careTakerData?.phoneNumber ?? AppStrings.noDataText,
                    icon: Icon(Icons.person),
                    titlefontSize: 16,
                    titlefontWeight: FontWeight.bold,
                    subtitlefontSize: 16,
                    subtitlefontWeight: FontWeight.w400,
                  ),
                  ListviewCard(
                    title: AppStrings.emailLabel,
                    subTitle: careTakerData?.email ?? AppStrings.noDataText,
                    icon: Icon(Icons.email),
                    titlefontSize: 16,
                    titlefontWeight: FontWeight.bold,
                    subtitlefontSize: 16,
                    subtitlefontWeight: FontWeight.w400,
                  ),
                  ListviewCard(
                    title: AppStrings.relationshipText,
                    subTitle: careTakerData?.relationshipName ?? AppStrings.noDataText,
                    icon: Icon(Icons.family_restroom),
                    titlefontSize: 16,
                    titlefontWeight: FontWeight.bold,
                    subtitlefontSize: 16,
                    subtitlefontWeight: FontWeight.w400,
                  ),
                  ListviewCard(
                    hasDivider: false,
                    title: AppStrings.addressText,
                    subTitle: careTakerData?.address ?? AppStrings.noDataText,
                    icon: Icon(Icons.family_restroom),
                    titlefontSize: 16,
                    titlefontWeight: FontWeight.bold,
                    subtitlefontSize: 16,
                    subtitlefontWeight: FontWeight.w400,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ButtonWidgets.elevatedButton(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              width: AppUtils.getScreenWidth(context),
              radius: 7,
              height: 50,
              AppStrings.deleteText,
              AppColors.clightRedColor,
              AppColors.cwhiteColor,
                  () => _onDelete(context),
            )
          ],
        ),
      ),
    ),
          Visibility(
          visible: state is CareTakerLoading,
          child: Loader.showLoader(AppStrings.loading),
          ),
            ],
          );
        },
    );
  }

  void _onDelete(BuildContext context) async {
    if (widget.careTakerId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteCareTakerTitle,
        contentText: AppStrings.deleteCareTakerConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          _careTakerBloc.add(DeleteCareTakerEvent(careTakerId: widget.careTakerId));
        },
      );
    }
  }
}
