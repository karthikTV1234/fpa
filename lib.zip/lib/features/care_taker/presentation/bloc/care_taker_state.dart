import 'package:child_health_story/features/care_taker/data/model/response/care_taker_detail_res_model.dart';
import 'package:equatable/equatable.dart';
import '../../data/model/response/care_taker_list_res_model.dart';
import '../../data/model/response/care_taker_relationship_list_res_model.dart';

/// STATES
abstract class CareTakerState extends Equatable {
  @override
  List<Object?> get props => [];
}
class CareTakerInitial extends CareTakerState {}
class CareTakerLoading extends CareTakerState {}
class CareTakerSuccess extends CareTakerState {
  final String message;
  CareTakerSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class CareTakerUpdateSuccess extends CareTakerState {
  final String message;
  CareTakerUpdateSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class CareTakerListSuccess extends CareTakerState {
  final List<CaretakerListData> careTakerList;
  CareTakerListSuccess(this.careTakerList);
  @override
  List<Object?> get props => [careTakerList];
}
class CareTakerRelationshipListSuccess extends CareTakerState {
  final List<RelationshipTypeListData> careTakerRelationshipList;
  CareTakerRelationshipListSuccess(this.careTakerRelationshipList);
  @override
  List<Object?> get props => [careTakerRelationshipList];
}
class CareTakerListSearchSuccess extends CareTakerState {
  final List<Map<String, dynamic>> filteredList;
  CareTakerListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class CareTakerByIdSuccess extends CareTakerState {
  final CaretakerDetailData? careTakerData;
  CareTakerByIdSuccess(this.careTakerData);
  @override
  List<Object?> get props => [careTakerData];
}
class CareTakerFailure extends CareTakerState {
  final String error;
  CareTakerFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class CountryCodeSelected extends CareTakerState {
  final String countryCode;
  CountryCodeSelected(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}
class RelationshipSelected extends CareTakerState {
  final String relationship;
  RelationshipSelected(this.relationship);
  @override
  List<Object?> get props => [relationship];
}
class PrimaryCareTakerSelected extends CareTakerState {
  final int selectedValue;
  PrimaryCareTakerSelected(this.selectedValue);
  @override
  List<Object?> get props => [selectedValue];
}

class VaccinationFormReset extends CareTakerState {}
