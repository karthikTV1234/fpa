import 'package:child_health_story/features/care_taker/data/model/response/care_taker_detail_res_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/utils/extensions.dart';
import '../../data/model/response/care_taker_list_res_model.dart';
import '../../data/model/response/care_taker_relationship_list_res_model.dart';
import '../../data/repository/care_taker_repository.dart';
import 'care_taker_events.dart';
import 'care_taker_state.dart';


/// BLOC
class CareTakerBloc extends Bloc<CareTakerEvent, CareTakerState> {
  List<Map<String, dynamic>> filteredCareTakerList = [];
  final CareTakerRepository careTakerRepository;
  bool isUIUpdated = false;
  List<XFile> newAttachments = [];
  String selectedCountryCode = "+91";
  CaretakerDetailData? careTakerDetailData;
  List<RelationshipTypeListData> relationshipList = [];
  List<String> relationshipLabelList = [];
  String? selectedRelationship;
  String? selectedRelationshipId;
  int? isPrimarySelected;

  CareTakerBloc({required this.careTakerRepository}) : super(CareTakerInitial()) {
    on<SelectPrimaryCareTakerEvent>((event, emit) {
      isUIUpdated = true;
      isPrimarySelected = event.value;
      emit(PrimaryCareTakerSelected(event.value));
    });
    on<SelectCountryCodeEvent>((event, emit) {
      selectedCountryCode = event.countryCode;
       isUIUpdated = true;
      emit(CountryCodeSelected(event.countryCode));
    });
    on<SelectRelationshipTypeEvent>((event, emit) {
      isUIUpdated = true;
      selectedRelationship = event.relationshipValue;
      final selectedModel = relationshipList.firstWhere(
            (element) => element.relationshipName == selectedRelationship,
        orElse: () => RelationshipTypeListData(),
      );
      selectedRelationshipId = selectedModel.id;
      emit(RelationshipSelected(event.relationshipValue));
    });
    on<AddCareTakerEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.addCareTaker(
          event.addCaretakerReqModel
      );
      if (result.isSuccess) {
        emit(CareTakerSuccess(message: result.data?.message ?? AppStrings.successMessage(
            EntityAction.add, AppStrings.careTakerTitleCase
        )));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchCareTakerListEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.getCareTakerList(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetCaretakersListResModel resModel = result.data!;
        emit(CareTakerListSuccess(resModel.data));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchCareTakerRelationshipListEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.getCareTakerRelationshipList();
      if (result.isSuccess && result.data != null) {
        final GetRelationshipTypesListResModel resModel = result.data!;
        relationshipList = resModel.data;
        relationshipLabelList.addAll(
          relationshipList.map((e) => e.relationshipName).where((e) => e.isNotEmpty),
        );
        isUIUpdated = true;
        emit(CareTakerRelationshipListSuccess(resModel.data));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchCareTakerByIdEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.getCareTakerDetails(event.careTakerId);
      if (result.isSuccess && result.data != null) {
        final GetCaretakerDetailResModel resModel = result.data!;
        careTakerDetailData = resModel.data;
        isUIUpdated = true;
        emit(CareTakerByIdSuccess(resModel.data));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateCareTakerEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.updateCareTaker(
          event.careTakerId
      );
      if (result.isSuccess) {
        emit(CareTakerUpdateSuccess(message: result.data?.message ?? AppStrings.successMessage(
            EntityAction.update, AppStrings.careTakerTitleCase
        )));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteCareTakerEvent>((event, emit) async {
      emit(CareTakerLoading());
      final result = await careTakerRepository.deleteCareTaker(event.careTakerId);
      if (result.isSuccess && result.data != null) {
        emit(CareTakerSuccess(message: result.data?.message ??  AppStrings.successMessage(
            EntityAction.delete, AppStrings.careTakerTitleCase
        )));
      } else {
        emit(CareTakerFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearCareTakerFormEvent>((event, emit) {
      newAttachments.clear();
      isUIUpdated = false;
      emit(CareTakerInitial());
    });
  }
}
