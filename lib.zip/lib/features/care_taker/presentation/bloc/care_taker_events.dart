import 'package:child_health_story/features/care_taker/data/model/request/add_care_taker_req_model.dart';
import 'package:equatable/equatable.dart';

/// EVENTS
abstract class CareTakerEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddCareTakerEvent extends CareTakerEvent with EquatableMixin {
  final AddCaretakerReqModel addCaretakerReqModel;
  AddCareTakerEvent({
    required this.addCaretakerReqModel
  });
  @override
  List<Object?> get props => [addCaretakerReqModel];
}
class FetchCareTakerListEvent extends CareTakerEvent {
  final String childId;
  FetchCareTakerListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class FetchCareTakerRelationshipListEvent extends CareTakerEvent {}
class SearchCareTakerListEvent extends CareTakerEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchCareTakerListEvent({required this.textSearch, required this.list});
}
class FetchCareTakerByIdEvent extends CareTakerEvent {
  final String careTakerId;
  FetchCareTakerByIdEvent({required this.careTakerId});
  @override
  List<Object?> get props => [careTakerId];
}
class UpdateCareTakerEvent extends CareTakerEvent {
  final String careTakerId;
  UpdateCareTakerEvent({
    required this.careTakerId,
  });
  @override
  List<Object?> get props => [careTakerId];
}
class DeleteCareTakerEvent extends CareTakerEvent {
  final String careTakerId;
  DeleteCareTakerEvent({required this.careTakerId});
  @override
  List<Object?> get props => [careTakerId];
}
class SelectCountryCodeEvent extends CareTakerEvent {
  final String countryCode;
  SelectCountryCodeEvent(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}
class SelectRelationshipTypeEvent extends CareTakerEvent {
  final String relationshipValue;
  SelectRelationshipTypeEvent(this.relationshipValue);
  @override
  List<Object?> get props => [relationshipValue];
}
class SelectPrimaryCareTakerEvent extends CareTakerEvent {
  final int value;
  SelectPrimaryCareTakerEvent(this.value);
}
class ClearCareTakerFormEvent extends CareTakerEvent {}