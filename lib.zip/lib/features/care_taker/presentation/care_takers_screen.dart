import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/features/care_taker/data/model/response/care_taker_list_res_model.dart';
import 'package:child_health_story/features/care_taker/presentation/bloc/care_taker_events.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/custom_card_widget.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/common_list_view.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'bloc/care_taker_bloc.dart';
import 'bloc/care_taker_state.dart';

class CareTakerListScreen extends StatefulWidget {
  const CareTakerListScreen({super.key});

  @override
  State<CareTakerListScreen> createState() => _CareTakerListScreenState();
}

class _CareTakerListScreenState extends State<CareTakerListScreen> {
  late final CareTakerBloc _careTakerBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _careTakerBloc = BlocProvider.of<CareTakerBloc>(context);
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      _careTakerBloc.add(FetchCareTakerListEvent(childId: childId));
    }
  }

  List<Map<String, dynamic>> _mapCareTakersToUI(List<CaretakerListData> list) {
    return list.map((c) {
      return {
        "id": c.id,
        "badge": c.isPrimary == true ? AppStrings.primaryCareTaker : "",
        "category": AppStrings.childCareTaker,
        "name": c.name,
        "subtitle1": c.phoneNumber.isNotEmpty
            ? "${AppStrings.phonePrefix}${c.phoneNumber}"
            : "",
        "subtitle2": c.address.isNotEmpty
            ? "${AppStrings.addressPrefix}${c.address}"
            : "",
        "isPrimary": c.isPrimary,
      };
    }).toList();
  }



  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CareTakerBloc, CareTakerState>(
        listener: (context, state) {
          if (state is CareTakerListSuccess) {
            mappedList = _mapCareTakersToUI(state.careTakerList);
            _careTakerBloc.filteredCareTakerList = mappedList;
          }
          else if (state is CareTakerUpdateSuccess) {
            final childId = SharedPreferencesHelper.instance.getSelectedChildId();
            if (childId.isNotEmpty) {
              _careTakerBloc.add(FetchCareTakerListEvent(childId: childId));
            }
          }
          else if (state is CareTakerFailure) {
            CustomSnackBar(
              context: context,
              message: state.error,
              messageType: AppStrings.failure,
            ).show();
          }
        },
        builder: (context, state) {
          return  Stack(
            children:[
     ParentWidget(
      hasHeader: true,
      appbarTitle: AppStrings.careTakerText,
      appbarTitleColor: AppColors.cblackColor,
      appbarColor: AppColors.clightGrayColor,
      appbarHeight: 70,
      leadingWidget: ButtonWidgets.getIconButton(Icon(Icons.arrow_back), () {
        Navigator.pop(context);
      }),
      context: context,
      childWidget: ConstrainedBox(
        constraints:
            BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
        child: IntrinsicHeight(
          child: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Column(
              spacing: 8,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: CommonListView<Map<String, dynamic>>(
                    data: _careTakerBloc.filteredCareTakerList,
                    padding: const EdgeInsets.all(16),
                    itemBuilder: (item) =>
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: CustomCardView(
                            id: item["id"],
                            badge: item["badge"],
                            cardColor: AppColors.cwhiteColor,
                            margin: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 10),
                            borderRadius: 8,
                            title: item["category"] ?? "",
                            title2: item["name"] ?? "",
                            subtitle1: item["subtitle1"],
                            subtitle2: item["subtitle2"],
                            isPrimary: item["isPrimary"] ?? false,
                            onTap: (id) {
                              _navigateToDetailScreen(context, id);
                            },
                            onTapRadioButton: (id, isPrimary) {
                              if (!isPrimary) {
                                _updateCareTakerPrimary(context, id);
                              }
                            },
                          ),
                        ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: ButtonWidgets.floatingActionButton(
          Icons.add, AppColors.cwhiteColor, AppColors.cprimaryColor, () async{
        final result = await Navigator.pushNamed(
          context,
          PathConstants.addCareTakerScreen,
        );
        if (result == true) {
          final childId = SharedPreferencesHelper.instance.getSelectedChildId();
          if (childId.isNotEmpty) {
            _careTakerBloc.add(FetchCareTakerListEvent(childId: childId));
          }
        }
      }),
    ),
          Visibility(visible: state is CareTakerLoading, child:Loader.showLoader(AppStrings.loading))
            ]
          );
        },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.careTakerDetailsScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _careTakerBloc.add(FetchCareTakerListEvent(childId: childId));
      }
    }
  }


  void _updateCareTakerPrimary(BuildContext context, String careTakerId) async {
    CustomAlertDialogue.show(
      context,
      titleText: AppStrings.updatePrimaryCareTakerTitle,
      contentText: AppStrings.setPrimaryCareTakerMessage,
      noButtonText: AppStrings.cancelBtnText,
      yesButtonText: AppStrings.updateBtnText,
      onNoPressed: () {
        Navigator.of(context).pop();
      },
      onYesPressed: () {
        Navigator.of(context).pop();
        _careTakerBloc.add(UpdateCareTakerEvent(
            careTakerId: careTakerId)
        );
      },
    );
  }


}
