import 'dart:async';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/utils/shared_preferences.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/widgets.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateAfterDelay();
  }

  void _navigateAfterDelay() async {
    await Future.delayed(const Duration(seconds: 2));
    final token = SharedPreferencesHelper.instance.token;
    if (!mounted) return;
    if (token != null && token.isNotEmpty) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final childList = SharedPreferencesHelper.instance.childListSize;
      if (childId.isNotEmpty) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          PathConstants.homeScreen,
              (Route<dynamic> route) => false,
        );
      }else{
        if(childList>0 ){
          Navigator.pushNamedAndRemoveUntil(
            context,
            PathConstants.childListScreen,
                (Route<dynamic> route) => false,
          );
        }else{
          Navigator.pushNamedAndRemoveUntil(
            context,
            PathConstants.addChild,
                (Route<dynamic> route) => false,
          );
        }
      }

    } else {
      Navigator.pushNamedAndRemoveUntil(
        context,
        PathConstants.loginScreen,
            (Route<dynamic> route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ParentWidget(
        context: context,
        childWidget: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.center,
                child: TextWidgets.textWidget("CHS", AppColors.cblackColor,
                    textAlign: TextAlign.center,
                    fontSize: 32,
                    fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
        hasHeader: false);
  }
}
