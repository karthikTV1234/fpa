import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/utils/extensions.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/doctor_visit_detail_res_model.dart';
import '../../data/models/response/doctor_visit_list_res_model.dart';
import '../../data/repository/doctor_visit_repository.dart';
import 'doctor_visit_events.dart';
import 'doctor_visit_state.dart';

/// BLOC
class DoctorVisitBloc extends Bloc<DoctorVisitEvent, DoctorVisitState> {
  List<Map<String, dynamic>> filteredDoctorVisitList = [];
  final DoctorVisitRepository doctorVisitRepository;
  bool isUIUpdated = false;
  String selectedChildName ='';
  String selectedChildProfileImage ='';
  String? selectedHospitalId;
  List<HospitalListData> hospitalList = [];
  String? selectedDoctorId;
  List<DoctorListData> doctorList = [];
  List<XFile> newAttachments = [];
  DoctorVisitDetailData? doctorVisitDetailData;

  DoctorVisitBloc({required this.doctorVisitRepository}) : super(DoctorVisitInitial()) {
    on<SetSelectedChildEvent>((event, emit) {
      selectedChildName = event.name;
      selectedChildProfileImage = event.profileImage;
      isUIUpdated = true;
      emit(SelectedChildSet(event.name, event.profileImage));
    });
    on<SetHospitalListEvent>((event, emit) {
      hospitalList = event.hospitals;
      isUIUpdated = true;
      emit(HospitalListSet(event.hospitals));
    });
    on<SelectHospitalEvent>((event, emit) {
      isUIUpdated = true;
      selectedHospitalId = event.hospitalId;
      emit(HospitalSelected(event.hospitalId));
    });
    on<SetDoctorListEvent>((event, emit) {
      doctorList = event.doctors;
      isUIUpdated = true;
      emit(DoctorListSet(event.doctors));
    });
    on<SelectDoctorEvent>((event, emit) {
      isUIUpdated = true;
      selectedDoctorId = event.doctorId;
      emit(DoctorSelected(event.doctorId));
    });
    on<DoctorVisitAddNewAttachmentEvent>((event, emit) {
      newAttachments.add(event.file);
      isUIUpdated = true;
      emit(DoctorVisitAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });
    on<DoctorVisitRemoveNewAttachmentEvent>((event, emit) {
      newAttachments.removeWhere((f) => f.path == event.file.path);
      isUIUpdated = true;
      newAttachments = List<XFile>.from(newAttachments);
      emit(DoctorVisitAttachmentsUpdated(List<XFile>.from(newAttachments)));
    });

    on<SearchDoctorVisitListEvent>((event, emit) {
      if (event.textSearch.trim().isEmpty) {
        filteredDoctorVisitList = event.list;
      } else {
        filteredDoctorVisitList = event.list.where((element) {
          final title = (element["title"] ?? "").toLowerCase();
          return title.contains(event.textSearch.toLowerCase());
        }).toList();
      }
      emit(DoctorVisitListSearchSuccess(filteredDoctorVisitList));
    });
    on<AddDoctorVisitEvent>((event, emit) async {
      emit(DoctorVisitLoading());
      final result = await doctorVisitRepository.addDoctorVisit(
          event.addDoctorVisitReqModel
      );
      if (result.isSuccess) {
        emit(DoctorVisitSuccess(message: result.data?.message ?? AppStrings.successMessage(
            EntityAction.add, AppStrings.doctorVisitTitleCase
        )));
      } else {
        emit(DoctorVisitFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchDoctorVisitListEvent>((event, emit) async {
      emit(DoctorVisitLoading());
      final result = await doctorVisitRepository.getDoctorVisitList(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetDoctorVisitListResModel resModel = result.data!;
        emit(DoctorVisitListSuccess(resModel.data));
      } else {
        emit(DoctorVisitFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchDoctorVisitByIdEvent>((event, emit) async {
      emit(DoctorVisitLoading());
      final result = await doctorVisitRepository.getDoctorVisitDetails(event.doctorVisitId);
      if (result.isSuccess && result.data != null) {
        final GetDoctorVisitDetailResModel resModel = result.data!;
        doctorVisitDetailData = resModel.data;
        isUIUpdated = true;
        emit(DoctorVisitByIdSuccess(resModel.data));
      } else {
        emit(DoctorVisitFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateDoctorVisitEvent>((event, emit) async {
      emit(DoctorVisitLoading());
      final result = await doctorVisitRepository.updateDoctorVisitDetails(
          event.updateDoctorVisitReqModel,
          event.doctorVisitId
      );
      if (result.isSuccess) {
        emit(DoctorVisitSuccess(message: result.data?.message ?? AppStrings.successMessage(
            EntityAction.update, AppStrings.doctorVisitTitleCase
        )));
      } else {
        emit(DoctorVisitFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteDoctorVisitEvent>((event, emit) async {
      emit(DoctorVisitLoading());
      final result = await doctorVisitRepository.deleteDoctorVisit(event.doctorVisitId);
      if (result.isSuccess && result.data != null) {
        emit(DoctorVisitSuccess(message: result.data?.message ?? AppStrings.successMessage(
            EntityAction.delete, AppStrings.doctorVisitTitleCase
        )));
      } else {
        emit(DoctorVisitFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
    on<ClearDoctorVisitFormEvent>((event, emit) {
      hospitalList.clear();
      selectedHospitalId = null;
      doctorList.clear();
      selectedDoctorId = null;
      newAttachments.clear();
      isUIUpdated = false;
      emit(DoctorVisitInitial());
    });
  }
}
