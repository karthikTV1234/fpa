import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/response/doctor_visit_detail_res_model.dart';
import '../../data/models/response/doctor_visit_list_res_model.dart';

/// STATES
abstract class DoctorVisitState extends Equatable {
  @override
  List<Object?> get props => [];
}
class DoctorVisitInitial extends DoctorVisitState {}
class DoctorVisitLoading extends DoctorVisitState {}
class DoctorVisitSuccess extends DoctorVisitState {
  final String message;
  DoctorVisitSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class DoctorVisitListSuccess extends DoctorVisitState {
  final List<DoctorVisitListData> doctorVisitList;
  DoctorVisitListSuccess(this.doctorVisitList);
  @override
  List<Object?> get props => [doctorVisitList];
}
class DoctorVisitListSearchSuccess extends DoctorVisitState {
  final List<Map<String, dynamic>> filteredList;
  DoctorVisitListSearchSuccess(this.filteredList);
  @override
  List<Object?> get props => [filteredList];
}
class DoctorVisitByIdSuccess extends DoctorVisitState {
  final DoctorVisitDetailData? medicationData;
  DoctorVisitByIdSuccess(this.medicationData);
  @override
  List<Object?> get props => [medicationData];
}
class DoctorVisitFailure extends DoctorVisitState {
  final String error;
  DoctorVisitFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class HospitalListSet extends DoctorVisitState {
  final List<HospitalListData> hospitals;
  HospitalListSet(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class HospitalSelected extends DoctorVisitState {
  final String hospitalId;
  HospitalSelected(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class DoctorListSet extends DoctorVisitState {
  final List<DoctorListData> doctors;
  DoctorListSet(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class DoctorSelected extends DoctorVisitState {
  final String doctorId;
  DoctorSelected(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class DoctorVisitAttachmentsUpdated extends DoctorVisitState with EquatableMixin {
  final List<XFile> attachments;
  DoctorVisitAttachmentsUpdated(this.attachments);
  @override
  List<Object?> get props => [attachments];
}
class SelectedChildSet extends DoctorVisitState {
  final String name;
  final String profileImage;
  SelectedChildSet(this.name, this.profileImage);
}
class DoctorVisitFormReset extends DoctorVisitState {}
