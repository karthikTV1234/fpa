import 'package:child_health_story/features/doctor_visits/data/models/request/add_doctor_visit_req_model.dart';
import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';
import '../../../doctor/data/model/response/doctor_list_res_model.dart';
import '../../../hospital/data/model/hospital_model.dart';
import '../../data/models/request/edit_doctor_visit_req_model.dart';

/// EVENTS
abstract class DoctorVisitEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class AddDoctorVisitEvent extends DoctorVisitEvent with EquatableMixin {
  final AddDoctorVisitReqModel addDoctorVisitReqModel;
  AddDoctorVisitEvent({
    required this.addDoctorVisitReqModel
  });
  @override
  List<Object?> get props => [addDoctorVisitReqModel];
}
class FetchDoctorVisitListEvent extends DoctorVisitEvent {
  final String childId;
  FetchDoctorVisitListEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class SearchDoctorVisitListEvent extends DoctorVisitEvent {
  final String textSearch;
  final List<Map<String, dynamic>> list;
  SearchDoctorVisitListEvent({required this.textSearch, required this.list});
}
class FetchDoctorVisitByIdEvent extends DoctorVisitEvent {
  final String doctorVisitId;
  FetchDoctorVisitByIdEvent({required this.doctorVisitId});
  @override
  List<Object?> get props => [doctorVisitId];
}
class UpdateDoctorVisitEvent extends DoctorVisitEvent {
  final String doctorVisitId;
  final UpdateDoctorVisitReqModel updateDoctorVisitReqModel;
  UpdateDoctorVisitEvent({
    required this.doctorVisitId,
    required this.updateDoctorVisitReqModel,
  });
  @override
  List<Object?> get props => [doctorVisitId, updateDoctorVisitReqModel];
}
class DeleteDoctorVisitEvent extends DoctorVisitEvent {
  final String doctorVisitId;
  DeleteDoctorVisitEvent({required this.doctorVisitId});
  @override
  List<Object?> get props => [doctorVisitId];
}
class SetHospitalListEvent extends DoctorVisitEvent {
  final List<HospitalListData> hospitals;
  SetHospitalListEvent(this.hospitals);
  @override
  List<Object?> get props => [hospitals];
}
class SelectHospitalEvent extends DoctorVisitEvent {
  final String hospitalId;
  SelectHospitalEvent(this.hospitalId);
  @override
  List<Object?> get props => [hospitalId];
}
class SetDoctorListEvent extends DoctorVisitEvent {
  final List<DoctorListData> doctors;
  SetDoctorListEvent(this.doctors);
  @override
  List<Object?> get props => [doctors];
}
class SelectDoctorEvent extends DoctorVisitEvent {
  final String doctorId;
  SelectDoctorEvent(this.doctorId);
  @override
  List<Object?> get props => [doctorId];
}
class DoctorVisitAddNewAttachmentEvent extends DoctorVisitEvent {
  final XFile file;
  DoctorVisitAddNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class DoctorVisitRemoveNewAttachmentEvent extends DoctorVisitEvent {
  final XFile file;
  DoctorVisitRemoveNewAttachmentEvent(this.file);
  @override
  List<Object?> get props => [file];
}
class SetSelectedChildEvent extends DoctorVisitEvent {
  final String name;
  final String profileImage;
  SetSelectedChildEvent({
    required this.name,
    required this.profileImage,
  });
}
class ClearDoctorVisitFormEvent extends DoctorVisitEvent {}