import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/common_card_item.dart';
import 'package:child_health_story/shared/widgets/common_list_view.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../../../shared/widgets/text_input_widgets.dart';
import '../data/models/response/doctor_visit_list_res_model.dart';
import 'bloc/doctor_visit_bloc.dart';
import 'bloc/doctor_visit_events.dart';
import 'bloc/doctor_visit_state.dart';

class DoctorVisitListScreen extends StatefulWidget {
  const DoctorVisitListScreen({super.key});

  @override
  State<DoctorVisitListScreen> createState() => _DoctorVisitListScreenState();
}

class _DoctorVisitListScreenState extends State<DoctorVisitListScreen> {
  final TextEditingController _searchController = TextEditingController();
  late final DoctorVisitBloc _doctorVisitBloc;
  List<Map<String, dynamic>> mappedList = [];

  @override
  void initState() {
    super.initState();
    _doctorVisitBloc = context.read<DoctorVisitBloc>();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    final childName = SharedPreferencesHelper.instance.getSelectedChildName();
    final childProfileImage = SharedPreferencesHelper.instance.getSelectedChildProfilePhoto();
    if (childId.isNotEmpty) {
      _doctorVisitBloc.add(
        SetSelectedChildEvent(
          name: childName,
          profileImage: childProfileImage,
        ),
      );
      _doctorVisitBloc.add(FetchDoctorVisitListEvent(childId: childId));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _mapDoctorVisitToUI(List<DoctorVisitListData> data) {
    return data.map((visit) {
      final formattedDate = AppUtils.formatDateOnly(visit.dateOfVisit);

      final String subtitle = "${AppStrings.doctorPrefix} ${visit.doctorName}";
      final String subtitle2 = visit.treatmentNotes.isNotEmpty
          ? "${AppStrings.notePrefix} ${visit.treatmentNotes}"
          : "";
      return {
        "id": visit.id,
        "category": formattedDate,
        "title": visit.purpose,
        "subtitle": subtitle,
        "subtitle2": subtitle2,
      };
    }).toList();
  }




  @override
  Widget build(BuildContext context) {
    return BlocConsumer<DoctorVisitBloc, DoctorVisitState>(
      listener: (context, state) {
        if (state is DoctorVisitLoading) {
          mappedList = [];
          _doctorVisitBloc.filteredDoctorVisitList = [];
        }
        if (state is DoctorVisitListSuccess) {
          mappedList = _mapDoctorVisitToUI(state.doctorVisitList);
          _doctorVisitBloc.filteredDoctorVisitList = mappedList;
        }else if (state is DoctorVisitListSearchSuccess) {
          _doctorVisitBloc.filteredDoctorVisitList = state.filteredList;
        }

        if (state is DoctorVisitFailure) {
          mappedList = [];
          _doctorVisitBloc.filteredDoctorVisitList = [];
          CustomSnackBar(
            context: context,
            message: state.error,
            messageType: AppStrings.failure,
          ).show();
        }
      },
      builder: (context, state) {
        return  Stack(
            children:[
              ParentWidget(
                hasHeader: true,
                appbarTitle: _doctorVisitBloc.isUIUpdated ? _doctorVisitBloc.selectedChildName : "",
                appbarTitleColor: AppColors.cblackColor,
                appbarColor: AppColors.clightGrayColor,
                appbarHeight: 91,
                appbarSubtitle: AppStrings.switchChildText,
                subtitleTrailingWidget: Icon(
                  Icons.sync_alt,
                  size: 15,
                ),
                onSubTitlePressed: () async {
                  final result = await context.showChildListBottomSheet();
                  if (result == true) {
                    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
                    if (childId.isNotEmpty) {
                      _doctorVisitBloc.add(FetchDoctorVisitListEvent(childId: childId));
                    }
                    final childName = SharedPreferencesHelper.instance.getSelectedChildName();
                    final childProfileImage = SharedPreferencesHelper.instance.getSelectedChildProfilePhoto();
                    _doctorVisitBloc.add(
                      SetSelectedChildEvent(
                        name: childName,
                        profileImage: childProfileImage,
                      ),
                    );
                  }
                },
                rightWidget: CircleAvatar(
                  radius: 12,
                  backgroundColor: AppColors.cwhiteColor,
                  child: Icon(
                    Icons.person,
                    color: AppColors.cblackColor,
                  ),
                ),
                rightLabel: AppStrings.parentProfileText,
                onRightWidgetTap: () {},
                leadingWidget: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.cwhiteColor,
                      image: _doctorVisitBloc.selectedChildProfileImage.isNotEmpty
                          ? DecorationImage(
                        image: NetworkImage(_doctorVisitBloc.selectedChildProfileImage),
                        fit: BoxFit.cover,
                      )
                          : null,
                      border: Border.all(color: AppColors.circleBorderColor, width: 1),
                    ),
                  ),
                ),
                context: context,
                childWidget: ConstrainedBox(
                  constraints:
                  BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Column(
                        spacing: 8,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextWidgets.textWidget(
                                AppStrings.doctorVisitsText, AppColors.cblackColor,
                                fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: TextInputWidgets.getTextField(
                              fillColor: AppColors.clightGrayColor,
                              textColor: AppColors.cblackColor,
                              hintText: AppStrings.searchDoctorVisitText,
                              prefixIcon: Icon(Icons.search, color: Colors.grey,
                                  size: 15),
                              controller: _searchController,
                              keyboardType: TextInputType.text,
                              onChanged: (value) {
                                _doctorVisitBloc.add(SearchDoctorVisitListEvent(
                                  textSearch: value,
                                  list: mappedList,
                                ));
                              },
                            ),
                          ),
                          Expanded(
                            child: CommonListView<Map<String, dynamic>>(
                              data: _doctorVisitBloc.filteredDoctorVisitList,
                              padding: const EdgeInsets.all(16),
                              itemBuilder: (item) =>
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: CommonCardItem(
                                      id: item["id"],
                                      category: item["category"] ?? "",
                                      status: item["status"] ?? "",
                                      statusColor: item["statusColor"],
                                      title: item["title"] ?? "",
                                      subtitle: item["subtitle"] ?? "",
                                      subtitle2: item["subtitle2"] ?? "",
                                      onTap: (selectedId)  {
                                        _navigateToDetailScreen(context, selectedId);
                                      },
                                    ),
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                floatingActionButton: ButtonWidgets.floatingActionButton(
                  Icons.add, AppColors.cwhiteColor, AppColors.cprimaryColor, () async {
                  final result = await Navigator.pushNamed(
                    context,
                    PathConstants.doctorVisitFormScreen,
                    arguments: null,
                  );
                  if (result == true) {
                    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
                    if (childId.isNotEmpty) {
                      _doctorVisitBloc.add(FetchDoctorVisitListEvent(childId: childId));
                    }
                  }
                },
                ),
              ),
              Visibility(visible: state is DoctorVisitLoading, child:Loader.showLoader(AppStrings.loading))
            ]
        );
      },
    );
  }

  Future<void> _navigateToDetailScreen(BuildContext context, String selectedId) async {
    final result = await Navigator.pushNamed(
      context,
      PathConstants.doctorVisitDetailScreen,
      arguments: selectedId,
    );

    if (result == true) {
      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      if (childId.isNotEmpty) {
        _doctorVisitBloc.add(FetchDoctorVisitListEvent(childId: childId));
      }
    }
  }


}
