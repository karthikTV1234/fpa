import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/core/utils/file_utils.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/file_attachments.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../core/utils/app_utils.dart';
import '../../../shared/widgets/custom_dialogue.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'bloc/doctor_visit_bloc.dart';
import 'bloc/doctor_visit_events.dart';
import 'bloc/doctor_visit_state.dart';


class DoctorVisitDetailScreen extends StatefulWidget {
  final String doctorVisitId;
  const DoctorVisitDetailScreen({super.key, required this.doctorVisitId});

  @override
  State<DoctorVisitDetailScreen> createState() => _DoctorVisitDetailScreenState();
}

class _DoctorVisitDetailScreenState extends State<DoctorVisitDetailScreen> {
  late DoctorVisitBloc _doctorVisitBloc;
  bool _hasUpdated = false;

  @override
  void initState() {
    super.initState();
    _doctorVisitBloc = BlocProvider.of<DoctorVisitBloc>(context);
    _doctorVisitBloc.add(
        FetchDoctorVisitByIdEvent(doctorVisitId: widget.doctorVisitId)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<DoctorVisitBloc, DoctorVisitState>(
      listener: (context, state) {
      if (state is DoctorVisitSuccess) {
        CustomSnackBar(
          context: context,
          message: state.message,
          messageType: AppStrings.success,
        ).show();
        Navigator.of(context).pop(true);
      }
      else if (state is DoctorVisitFailure) {
        CustomSnackBar(
          context: context,
          message: state.error,
          messageType: AppStrings.failure,
        ).show();
      }
    },
      builder: (context, state) {
        final doctorVisitData = _doctorVisitBloc.isUIUpdated
            ? _doctorVisitBloc.doctorVisitDetailData
            : null;
        return Stack(
          children: [
            ParentWidget(
              context: context,
              hasHeader: true,
              appbarColor: AppColors.lightGreyColor,
              appbarTitle: AppStrings.doctorVisitDetails,
              appbarTitleColor: AppColors.cblackColor,
              leadingWidget: IconButton(
                onPressed: () {
                  if (_hasUpdated) {
                    Navigator.of(context).pop(true);
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(Icons.arrow_back),
              ),
              rightWidget: IconButton(
                onPressed: () async {
                  if (doctorVisitData != null) {
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.doctorVisitFormScreen,
                      arguments: doctorVisitData,
                    );
                    if (result == true) {
                      _doctorVisitBloc.add(FetchDoctorVisitByIdEvent(
                          doctorVisitId: widget.doctorVisitId));
                      _hasUpdated = true;
                    }
                  }
                },
                icon: const Icon(Icons.edit),
              ),
              childWidget: Padding(
                padding: const EdgeInsets.all(15),
                child: SingleChildScrollView(
                  child: Column(
                    spacing: 20,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 20,
                          children: [
                            ListviewCard(
                              icon: const Icon(Icons.medical_services),
                              title: AppStrings.purposeText,
                              subTitle: doctorVisitData?.purpose ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range_outlined),
                              title: AppStrings.dateOfVisitText,
                              subTitle: (doctorVisitData?.dateOfVisit ?? '')
                                  .formatAsDateTime(),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.local_hospital),
                              title: AppStrings.hospitalNameText,
                              subTitle: doctorVisitData?.hospitalName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.person),
                              title: AppStrings.doctorText,
                              subTitle: doctorVisitData?.doctorName ?? '',
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.date_range_outlined),
                              title: AppStrings.followUpDateText,
                              subTitle: (doctorVisitData?.followUpDate ?? '')
                                  .formatAsDateTime(),
                            ),
                            ListviewCard(
                              icon: const Icon(Icons.notes),
                              title: AppStrings.treatmentNotesText,
                              subTitle: doctorVisitData?.treatmentNotes ?? '',
                              hasDivider: false,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.cwhiteColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          spacing: 10,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidgets.textWidget(
                              AppStrings.attachmentsTxt,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                            FileAttachments(
                              files: doctorVisitData?.attachments ?? [],
                              onFileTap: (filePath) {
                                String path  = AppUtils.buildImageFullUrl(filePath) ?? '';
                                FileUtils.previewOrDownloadFile(context, path);
                              },
                            ),
                          ],
                        ),
                      ),
                      ButtonWidgets.elevatedButton(
                        AppStrings.deleteTxt,
                        AppColors.lightRedColor,
                        AppColors.cwhiteColor,
                            () => _onDelete(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        radius: 7,
                        width: MediaQuery.of(context).size.width,
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: state is DoctorVisitLoading,
              child: Loader.showLoader(AppStrings.loading),
            ),
          ],
        );
      },

    );
  }

  void _onDelete(BuildContext context) async {
    if (widget.doctorVisitId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteDoctorVisitTitle,
        contentText: AppStrings.deleteDoctorVisitConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context).pop();
          _doctorVisitBloc.add(DeleteDoctorVisitEvent(
              doctorVisitId: widget.doctorVisitId));
        },
      );
    }
  }

}


