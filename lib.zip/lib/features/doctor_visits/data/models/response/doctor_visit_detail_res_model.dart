class GetDoctorVisitDetailResModel {
  final int statusCode;
  final String message;
  final DoctorVisitDetailData data;

  GetDoctorVisitDetailResModel({
    this.statusCode = 0,
    this.message = '',
    DoctorVisitDetailData? data,
  }) : data = data ?? DoctorVisitDetailData();

  factory GetDoctorVisitDetailResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetDoctorVisitDetailResModel();

    return GetDoctorVisitDetailResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: DoctorVisitDetailData.fromJson(json['data'] as Map<String, dynamic>?),
    );
  }
}

class DoctorVisitDetailData {
  final String id;
  final String childId;
  final String dateOfVisit;
  final String doctorId;
  final String purpose;
  final String treatmentNotes;
  final String followUpDate;
  final List<String> attachments;
  final String createdAt;
  final String updatedAt;
  final String hospitalId;
  final bool isDeleted;
  final String doctorName;
  final String hospitalName;

  DoctorVisitDetailData({
    this.id = '',
    this.childId = '',
    this.dateOfVisit = '',
    this.doctorId = '',
    this.purpose = '',
    this.treatmentNotes = '',
    this.followUpDate = '',
    this.attachments = const [],
    this.createdAt = '',
    this.updatedAt = '',
    this.hospitalId = '',
    this.isDeleted = false,
    this.doctorName = '',
    this.hospitalName = '',
  });

  factory DoctorVisitDetailData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorVisitDetailData();

    return DoctorVisitDetailData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      dateOfVisit: json['dateOfVisit'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      purpose: json['purpose'] as String? ?? '',
      treatmentNotes: json['treatmentNotes'] as String? ?? '',
      followUpDate: json['followUpDate'] as String? ?? '',
      attachments: (json['attachments'] as List<dynamic>?)
          ?.map((e) => e as String? ?? '')
          .where((e) => e.isNotEmpty)
          .toList() ??
          [],
      createdAt: json['createdAt'] as String? ?? '',
      updatedAt: json['updatedAt'] as String? ?? '',
      hospitalId: json['hospitalId'] as String? ?? '',
      isDeleted: json['isDeleted'] as bool? ?? false,
      doctorName: json['doctorName'] as String? ?? '',
      hospitalName: json['hospitalName'] as String? ?? '',
    );
  }
}
