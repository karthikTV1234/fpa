class GetDoctorVisitListResModel {
  final int statusCode;
  final String message;
  final List<DoctorVisitListData> data;

  GetDoctorVisitListResModel({
    this.statusCode = 0,
    this.message = '',
    this.data = const [],
  });

  factory GetDoctorVisitListResModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) return GetDoctorVisitListResModel();

    return GetDoctorVisitListResModel(
      statusCode: json['statusCode'] as int? ?? 0,
      message: json['message'] as String? ?? '',
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => DoctorVisitListData.fromJson(e as Map<String, dynamic>?))
          .toList() ??
          [],
    );
  }
}

class DoctorVisitListData {
  final String id;
  final String childId;
  final String dateOfVisit;
  final String doctorId;
  final String purpose;
  final String treatmentNotes;
  final String doctorName;

  DoctorVisitListData({
    this.id = '',
    this.childId = '',
    this.dateOfVisit = '',
    this.doctorId = '',
    this.purpose = '',
    this.treatmentNotes = '',
    this.doctorName = '',
  });

  factory DoctorVisitListData.fromJson(Map<String, dynamic>? json) {
    if (json == null) return DoctorVisitListData();

    return DoctorVisitListData(
      id: json['id'] as String? ?? '',
      childId: json['childId'] as String? ?? '',
      dateOfVisit: json['dateOfVisit'] as String? ?? '',
      doctorId: json['doctorId'] as String? ?? '',
      purpose: json['purpose'] as String? ?? '',
      treatmentNotes: json['treatmentNotes'] as String? ?? '',
      doctorName: json['doctorName'] as String? ?? '',
    );
  }
}
