import 'package:child_health_story/features/doctor_visits/data/models/request/add_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/request/edit_doctor_visit_req_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_detail_res_model.dart';
import 'package:child_health_story/features/doctor_visits/data/models/response/doctor_visit_list_res_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/constants/strings/app_strings.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/utils/extensions.dart';

class DoctorVisitRepository {
  final Dio _dio;

  DoctorVisitRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<CommonResModel>> addDoctorVisit(AddDoctorVisitReqModel addReqModel) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.add, AppStrings.doctorVisitLowerCase);
    try {
      const String url = '${ApiConstants.baseUrl}${ApiConstants.createDoctorVisit}';
      final formData = await addReqModel.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final addRes = CommonResModel.fromJson(response.data);
        return Result.success(addRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetDoctorVisitListResModel>> getDoctorVisitList(String childId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.fetch, AppStrings.doctorVisitLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.doctorVisitList}/$childId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final listRes = GetDoctorVisitListResModel.fromJson(response.data);
        return Result.success(listRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetDoctorVisitDetailResModel>> getDoctorVisitDetails(String doctorVisitId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.fetchDetails, AppStrings.doctorVisitLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.doctorVisitDetails}/$doctorVisitId';
      final response = await _dio.get(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final childDetailRes = GetDoctorVisitDetailResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateDoctorVisitDetails(UpdateDoctorVisitReqModel updateReqModel, String doctorVisitId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.update, AppStrings.doctorVisitLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.updateDoctorVisit}/$doctorVisitId';
      final formData = await updateReqModel.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final updateRes = CommonResModel.fromJson(response.data);
        return Result.success(updateRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteDoctorVisit(String doctorVisitId) async {
    String errorMessage = AppStrings.errorMessage(EntityAction.delete, AppStrings.doctorVisitLowerCase);
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.deleteDoctorVisit}/$doctorVisitId';
      final response = await _dio.delete(
        url,
        options: ApiClient.authOptions()
      );
      final codeLevelStatus = response.data['statusCode'] ?? response.statusCode;
      if (codeLevelStatus == 200 || codeLevelStatus == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
