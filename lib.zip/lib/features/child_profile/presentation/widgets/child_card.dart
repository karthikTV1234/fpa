import 'package:flutter/material.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';

class ChildCard extends StatelessWidget {
  final String name;
  final String age;
  final String details;
  final String? profileImageUrl;
  final VoidCallback? onTap;

  const ChildCard({
    super.key,
    required this.name,
    required this.age,
    required this.details,
    this.profileImageUrl,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: AppColors.cwhiteColor,
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        leading: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.cmediumGrayColor,
            image: (profileImageUrl != null && profileImageUrl!.isNotEmpty)
                ? DecorationImage(
              image: NetworkImage(profileImageUrl!),
              fit: BoxFit.cover,
            )
                : null,
            border: Border.all(color: AppColors.circleBorderColor, width: 1),
          )
        ),
        title: TextWidgets.textWidget(
          name,
          AppColors.cblackColor,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          textAlign: TextAlign.left,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidgets.textWidget(
              age,
              AppColors.cprimaryColor,
              fontSize: 14,
              fontWeight: FontWeight.w400,
              textAlign: TextAlign.left,
            ),
            TextWidgets.textWidget(
              details,
              AppColors.cblackColor,
              fontSize: 16,
              fontWeight: FontWeight.w400,
              textAlign: TextAlign.left,
            ),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
