import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/core/utils/shared_preferences.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import '../../data/model/child_list_model.dart';
import 'child_list_with_add.dart';

class ChildListBottomSheet extends StatefulWidget {
  const ChildListBottomSheet({super.key});

  @override
  State<ChildListBottomSheet> createState() => _ChildListBottomSheetState();
}

class _ChildListBottomSheetState extends State<ChildListBottomSheet> {
  late final ChildBloc childBloc;

  @override
  void initState() {
    super.initState();
    childBloc = context.read<ChildBloc>();
    childBloc.add(FetchChildListEvent());
  }

  void _onChildSelected(BuildContext context, List<ChildProfile> children, int index) async {
    final child = children[index];

    await SharedPreferencesHelper.instance.saveSelectedChildDetails(
      id: child.id ?? '',
      name: child.name ?? '',
      age: child.age ?? '',
      profilePhoto: child.profilePictureUrl,
      coverPhoto: child.coverPhotoUrl,
    );
    await SharedPreferencesHelper.instance.setChildListSize(children.length);
    if (!context.mounted) return;
    Navigator.pop(context, true);

  }

  void _onAddNewPressed() {
    Navigator.pop(context);
    Navigator.pushNamed(context, PathConstants.addChild);
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChildBloc, ChildState>(
      listener: _childBlocListener,
      builder: (context, state) {
        List<ChildProfile> children = [];
        if (state is ChildListSuccess) {
          children = state.children;
        }
        return Stack(
            children: [
         SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              spacing: 10,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.cmediumGrayColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: ChildListWithAdd(
                      children: children,
                      onChildSelected: (index) =>
                          _onChildSelected(context, children, index),
                      onAddNewPressed: _onAddNewPressed,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Visibility(
          visible: state is ChildLoading,
           child: Loader.showLoader(AppStrings.loading),
        ),
      ],
        );
      },
    );
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

}


