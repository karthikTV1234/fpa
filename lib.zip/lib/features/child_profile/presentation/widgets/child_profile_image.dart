import 'dart:io';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/image_picker_helper.dart';
import 'package:child_health_story/shared/widgets/custom_circular_avatar.dart';
import 'package:flutter/material.dart';

class ChildProfileImage extends StatelessWidget {
  final bool isEditable;

  final File? pickedProfileFile;
  final String? profileImageUrl;
  final Function(File file)? onProfilePicked;

  final File? pickedWallpaperFile;
  final String? wallpaperImageUrl;
  final Function(File file)? onWallpaperPicked;

  const ChildProfileImage({
    super.key,
    this.isEditable = false,
    this.pickedProfileFile,
    this.profileImageUrl,
    this.onProfilePicked,
    this.pickedWallpaperFile,
    this.wallpaperImageUrl,
    this.onWallpaperPicked,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      clipBehavior: Clip.none,
      children: [
        GestureDetector(
          onTap: isEditable ? () => _pickWallpaperImage(context) : null,
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.15,
            child: pickedWallpaperFile != null
                ? Image.file(pickedWallpaperFile!, fit: BoxFit.cover)
                : (wallpaperImageUrl != null && wallpaperImageUrl!.isNotEmpty
                ? Image.network(wallpaperImageUrl!, fit: BoxFit.cover)
                : Container(
                    color: AppColors.circleBorderColor,
                   child: Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.image, size: 48, color: AppColors.cwhiteColor),
                      ),
                   ),
                  )),
          ),
        ),
        Positioned(
          bottom: -70,
          child: CustomCircleAvatar(
            mainContext: context,
            isEditable: isEditable,
            imageFile: pickedProfileFile,
            imageUrl: profileImageUrl,
            callback: (file, name) {
              if (isEditable && onProfilePicked != null) {
                onProfilePicked!(file);
              }
            },
          ),
        ),
      ],
    );
  }

  void _pickWallpaperImage(BuildContext context) {
    FilePickerHelper.pickFile(
      context: context,
      allowedFileTypes: AppStrings.supportedFileTypes.contains('image') ? ['image'] : [],
      onFilePicked: (file, name) {
        if (isEditable && onWallpaperPicked != null) {
          onWallpaperPicked!(file);
        }
      },
    );
  }



}
