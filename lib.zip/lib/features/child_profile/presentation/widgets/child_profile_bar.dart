import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'child_profile_image.dart';

class ChildProfileBar extends StatelessWidget {
  final String childName;
  final String childAge;
  final String? profileImageUrl;
  final String? wallpaperImageUrl;

  const ChildProfileBar({
    super.key,
    required this.childName,
    required this.childAge,
    this.profileImageUrl,
    this.wallpaperImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ChildProfileImage(
          isEditable: false,
          profileImageUrl: profileImageUrl,
          wallpaperImageUrl: wallpaperImageUrl,
        ),
        const SizedBox(height: 90),
        TextWidgets.textWidget(
          childName,
          AppColors.cblackColor,
          fontSize: 18.0,
          fontWeight: FontWeight.w700,
        ),
        TextWidgets.textWidget(
          childAge,
          AppColors.cblackColor,
          fontSize: 16.0,
          fontWeight: FontWeight.w400,
        ),
      ],
    );
  }
}
