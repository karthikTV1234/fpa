import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import '../../../../core/utils/app_utils.dart';
import '../../data/model/child_list_model.dart';
import 'child_card.dart';

class ChildListWithAdd extends StatelessWidget {
  final List<ChildProfile> children;
  final void Function(int index) onChildSelected;
  final VoidCallback onAddNewPressed;

  const ChildListWithAdd({
    super.key,
    required this.children,
    required this.onChildSelected,
    required this.onAddNewPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: children.length + 1,
      itemBuilder: (context, index) {
        if (index < children.length) {
          final child = children[index];
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: ChildCard(
              name: child.name ?? "",
              age: child.age ?? "",
              details:
              '${child.height != null ? '${child.height} ${AppStrings.cmUnit}' : ''}'
                  '${child.height != null && child.weight != null ? ', ' : ''}'
                  '${child.weight != null ? '${child.weight} ${AppStrings.kgUnit}' : ''}',
              profileImageUrl: AppUtils.buildImageFullUrl(child.profilePictureUrl) ?? "",
              onTap: () => onChildSelected(index),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: ButtonWidgets.addNewOutlinedButton(
              addNewPlusCircle: ButtonWidgets.addNewPlusCircle(
                Icons.add,
                AppColors.cprimaryColor,
              ),
              text: AppStrings.addNewText,
              iconColor: AppColors.cprimaryColor,
              onPressed: onAddNewPressed,
            ),
          );
        }
      },
    );
  }
}
