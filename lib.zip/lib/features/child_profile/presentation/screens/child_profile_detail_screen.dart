import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/storage_keys.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/core/utils/shared_preferences.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/custom_dialogue.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/listview_card.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/utils/app_utils.dart';
import '../widgets/child_profile_bar.dart';

class ChildProfileDetailScreen extends StatefulWidget {
  const ChildProfileDetailScreen({super.key});

  @override
  State<ChildProfileDetailScreen> createState() => _ChildProfileDetailScreenState();
}

class _ChildProfileDetailScreenState extends State<ChildProfileDetailScreen> {
  String _childDeletedSuccessMessage ='';

  @override
  void initState() {
    super.initState();
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId.isNotEmpty) {
      context.read<ChildBloc>().add(FetchChildByIdEvent(childId: childId));
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChildBloc, ChildState>(
        listener: _childBlocListener,
        builder: (context, state) {
          final childData = state is ChildByIdSuccess ? state.childData : null;
          return ParentWidget(
            hasHeader: true,
            appbarColor: AppColors.lightGreyColor,
            appbarTitle: AppStrings.aboutBabyHintText,
            appbarTitleColor: AppColors.cblackColor,
            leadingWidget: IconButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                icon: Icon(Icons.arrow_back)),
            rightWidget: IconButton(
                onPressed: () async {
                  if (childData != null) {
                    final childBloc = context.read<ChildBloc>();
                    final result = await Navigator.pushNamed(
                      context,
                      PathConstants.editChildProfile,
                      arguments: childData,
                    );

                    if (result == true) {
                      final childId = SharedPreferencesHelper.instance
                          .getSelectedChildId();
                      if (childId.isNotEmpty) {
                        childBloc.add(FetchChildByIdEvent(childId: childId));
                      }
                    }
                  }
                },
                icon: Icon(Icons.edit)),
            context: context,
            childWidget: SingleChildScrollView(
              child: Column(
                children: [
                  ChildProfileBar(
                    childName: childData?.name ?? '',
                    childAge: childData?.birthDate ?? '',
                    profileImageUrl: (childData?.profilePictureUrl
                        ?.isNotEmpty ?? false)
                        ? AppUtils.buildImageFullUrl(
                        childData!.profilePictureUrl)
                        : null,
                    wallpaperImageUrl: (childData?.coverPhotoUrl?.isNotEmpty ??
                        false)
                        ? AppUtils.buildImageFullUrl(childData!.coverPhotoUrl)
                        : null,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      spacing: 20,
                      children: [
                        Container(
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                              color: AppColors.cwhiteColor,
                              borderRadius: BorderRadius.circular(10)),
                          child: Column(
                            children: [
                              ListviewCard(
                                title: AppStrings.genderLabel,
                                subTitle: childData?.gender ?? '',
                                icon: Icon(Icons.person),
                              ),
                              ListviewCard(
                                title: AppStrings.dobLabel,
                                subTitle: (childData?.timeOfBirth ?? '')
                                    .formatAsDateTime(),
                                icon: Icon(Icons.lock_clock),
                              ),
                              ListviewCard(
                                title: AppStrings.heightLabel,
                                subTitle: (childData?.height != null &&
                                    childData!.height != 0)
                                    ? '${childData.height} ${AppStrings
                                    .cmUnit}'
                                    : '',
                                icon: Icon(Icons.height),
                              ),
                              ListviewCard(
                                title: AppStrings.weightLabel,
                                subTitle: (childData?.weight ?? 0) != 0
                                    ? '${childData!.weight} ${AppStrings
                                    .kgUnit}'
                                    : '',
                                icon: Icon(Icons.line_weight),
                              ),
                              ListviewCard(
                                title: AppStrings.headCircumferenceLabel,
                                subTitle: childData?.headCircumference != null
                                    ? childData?.headCircumference
                                    ?.toStringAsFixed(2)
                                    : '',
                                icon: Icon(Icons.headphones),
                              ),
                              ListviewCard(
                                title: AppStrings.bloodGroupLabel,
                                subTitle: childData?.bloodType ?? '',
                                icon: Icon(Icons.bloodtype),
                              ),
                              ListviewCard(
                                title: AppStrings.aboutChildLabel,
                                subTitle: childData?.description ?? '',
                                icon: Icon(Icons.info),
                                hasDivider: false,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        ButtonWidgets.elevatedButton(
                            AppStrings.deleteTxt,
                            AppColors.lightRedColor,
                            AppColors.cwhiteColor,
                                () {
                              _onDelete(context);
                            },
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            radius: 7,
                            width: MediaQuery
                                .of(context)
                                .size
                                .width,
                            height: 50),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
    );
  }

  void _childBlocListener(BuildContext context, ChildState state) async {
    if (state is ChildLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    }else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is ChildByIdSuccess) {
      _saveChildData(context, state);
    }else if (state is ChildSuccess) {
      _childDeletedSuccessMessage = state.message;
      _handleChildDeleted(context, state);
      context.read<ChildBloc>().add(FetchChildListEvent());
    }else if (state is ChildListSuccess) {
      _handleChildListSuccess(context, state);
    }
    else if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  Future<void> _handleChildDeleted(BuildContext context, ChildSuccess state) async {
    await SharedPreferencesHelper.instance.removeKeys([
      PreferenceKeys.selectedChildId,
      PreferenceKeys.selectedChildName,
      PreferenceKeys.selectedChildAge,
      PreferenceKeys.selectedChildProfilePhoto,
      PreferenceKeys.selectedChildCoverPhoto,
    ]);
  }

  Future<void> _saveChildData(BuildContext context, ChildByIdSuccess state) async {
    final child = state.childData;
   await SharedPreferencesHelper.instance.saveSelectedChildDetails(
      id: child?.id ?? '',
      name: child?.name ?? '',
      age: child?.age ?? '',
      profilePhoto: child?.profilePictureUrl ?? '',
      coverPhoto: child?.coverPhotoUrl ?? '',
    );
  }


  void _onDelete(BuildContext context) async {
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();

    if (childId.isNotEmpty) {
      CustomAlertDialogue.show(
        context,
        titleText: AppStrings.deleteBabyProfileTitle,
        contentText: AppStrings.deleteBabyProfileConfirmationMessage,
        noButtonText: AppStrings.cancelBtnText,
        yesButtonText: AppStrings.deleteBtnText,
        onNoPressed: () {
          Navigator.of(context).pop();
        },
        onYesPressed: () {
          Navigator.of(context, rootNavigator: true).pop();
          context.read<ChildBloc>().add(DeleteChildEvent(childId: childId));
        },
      );
    }
  }

  Future<void> _handleChildListSuccess(BuildContext context, ChildListSuccess state) async {
      CustomSnackBar(
        context: context,
        message: _childDeletedSuccessMessage,
        messageType: AppStrings.success,
      ).show();
    if (state.children.isEmpty) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        PathConstants.addChild,
            (route) => false,
      );
    } else {
      final mounted = context.mounted;
      await SharedPreferencesHelper.instance.setChildListSize(state.children.length);
      if (!context.mounted) return;
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          PathConstants.childListScreen,
              (route) => false,
          arguments: state.children,
        );
      }
    }
  }

}
