import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/constants/strings/validation_messages.dart';
import '../../../../core/utils/app_utils.dart';
import '../../../../core/utils/app_validators.dart';
import '../../../../core/utils/shared_preferences.dart';
import '../../../../shared/widgets/custom_dropdown.dart';
import '../../../../shared/widgets/custom_snack_bar.dart';
import '../../../../shared/widgets/loader.dart';
import '../../../../shared/widgets/text_style_widget.dart';
import '../../../../shared/widgets/text_widgets.dart';
import '../../data/model/child_detail_model.dart';
import '../widgets/child_profile_image.dart';

class EditChildProfile extends StatefulWidget {
  final GetChildData childData;
  const EditChildProfile({
    super.key,
    required this.childData,
  });

  @override
  State<EditChildProfile> createState() => _EditChildProfileState();
}

class _EditChildProfileState extends State<EditChildProfile> {
  late final TextEditingController _babyNameController;
  late final TextEditingController _dateTimeController;
  late final TextEditingController _heightController;
  late final TextEditingController _weightController;
  late final TextEditingController _headCircumferenceController;
  late final TextEditingController _bloodGroupController;
  late final TextEditingController _aboutChildController;
  final _formKey = GlobalKey<FormState>();
  late ChildBloc childBloc;


  @override
  void initState() {
    super.initState();
    childBloc = BlocProvider.of<ChildBloc>(context);
    _babyNameController = TextEditingController(text: widget.childData.name.toSafeString());
    _dateTimeController = TextEditingController(
      text: widget.childData.timeOfBirth != null
          ? AppUtils.formatBackendDateTimeForUI(widget.childData.timeOfBirth!)
          : "",
    );
    _heightController = TextEditingController(text: widget.childData.height.toSafeString());
    _weightController = TextEditingController(text: widget.childData.weight.toSafeString());
    _headCircumferenceController = TextEditingController(text: widget.childData.headCircumference.toSafeString());
    _bloodGroupController = TextEditingController(text: widget.childData.bloodType.toSafeString());
    _aboutChildController = TextEditingController(text: widget.childData.description.toSafeString());
    if (widget.childData.gender != null && widget.childData.gender!.isNotEmpty) {
      context.read<ChildBloc>().add(SelectGenderEvent(widget.childData.gender!));
    }
  }

  @override
  void dispose() {
    _babyNameController.dispose();
    _dateTimeController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _headCircumferenceController.dispose();
    _bloodGroupController.dispose();
    _aboutChildController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChildBloc, ChildState>(
      listener: _childBlocListener,
      builder: (context, state) {
      return  Stack(
        children:[
        ParentWidget(
          context: context,
          hasHeader: true,
          appbarTitle: AppStrings.updateChildTxt,
          appbarTitleColor: AppColors.cblackColor,
          appbarColor: AppColors.lightGreyColor,
          leadingWidget:
              IconButton(onPressed: () {
                Navigator.of(context).pop();
              }, icon: Icon(Icons.arrow_back)),
          childWidget: SingleChildScrollView(
            child: Form(
             key: _formKey,
             child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 0),
              child: Column(
                children: [
                  ChildProfileImage(
                    isEditable: true,
                    pickedProfileFile: childBloc.isUIUpdated
                        ? childBloc.selectedPhotoProfile
                        : null,
                    profileImageUrl: AppUtils.buildImageFullUrl(widget.childData.profilePictureUrl),
                    onProfilePicked: (file) {
                      context.read<ChildBloc>().add(UploadProfilePicEvent(file));
                    },
                    pickedWallpaperFile: childBloc.isUIUpdated
                        ? childBloc.selectedCoverProfile
                        : null,
                    wallpaperImageUrl: AppUtils.buildImageFullUrl(widget.childData.coverPhotoUrl),
                    onWallpaperPicked: (file) {
                      context.read<ChildBloc>().add(UploadCoverPicEvent(file));
                    },
                  ),
                  SizedBox(
                  height: 90,
                ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    spacing: 10,
                    children: [
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.babyNameLabel,
                        hintText: AppStrings.babyNameHintText,
                        TextInputType.text,
                        TextInputAction.next,
                        _babyNameController,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        enabled: _babyNameController.text.isEmpty,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.babyNameReq;
                          }
                          return null;
                        },
                      ),
                      CustomDropDown(
                        labelText: AppStrings.genderLabel,
                        hint: TextWidgets.textWidget(
                            fontSize: 14,
                            AppStrings.genderHintText,
                            AppColors.cblackColor),
                        dropdownMenuItems: AppStrings.gendersList,
                        value: childBloc.isUIUpdated ? childBloc.selectedGender : null,
                        enabled: childBloc.isUIUpdated ?(childBloc.selectedGender.isEmpty) : true,
                        onChanged: (value) {
                            context.read<ChildBloc>().add(SelectGenderEvent(value));
                         },
                        validator: (value) {
                          if (value == null ||
                              AppValidators.emptyValidator(value)) {
                            return ValidationMessages.genderReq;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        fillColor: AppColors.appBackGroundColor,
                        labelStyle: TextStyleWidget.textStyleWidget(
                            AppColors.cblackColor,
                            fontSize: 14),
                        AppStrings.dobLabel,
                        TextInputType.datetime,
                        TextInputAction.next,
                        _dateTimeController,
                        false,
                        enabled: _dateTimeController.text.isEmpty,
                        readOnly: true,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.dobReq;
                          }
                          return null;
                        },
                        customTap: () async {
                          final DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime(2100),
                          );

                          if (pickedDate != null) {
                            final TimeOfDay? pickedTime =
                            await showTimePicker(
                              // ignore: use_build_context_synchronously
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );

                            if (pickedTime != null) {
                              final DateTime combined = DateTime(
                                pickedDate.year,
                                pickedDate.month,
                                pickedDate.day,
                                pickedTime.hour,
                                pickedTime.minute,
                              );

                              _dateTimeController.text =
                                  AppUtils.formatDateTime(combined);
                            }
                          }
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.heightLabel,
                        TextInputType.number,
                        TextInputAction.next,
                        _heightController,
                        hintText: AppStrings.babyHeightHintText,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        enabled: _heightController.text.isEmpty,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.babyHeightReq;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.weightLabel,
                        TextInputType.number,
                        TextInputAction.next,
                        _weightController,
                        hintText: AppStrings.babyWeightHintText,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        enabled: _weightController.text.isEmpty,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.babyWeightReq;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.headCircumferenceLabel,
                        TextInputType.number,
                        TextInputAction.next,
                        _headCircumferenceController,
                        hintText: AppStrings.babyHeadCircumFranceHintText,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        enabled: _headCircumferenceController.text.isEmpty,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages
                                .babyHeadCircumfranceReq;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                        fillColor: AppColors.appBackGroundColor,
                        AppStrings.bloodGroupLabel,
                        TextInputType.text,
                        TextInputAction.next,
                        _bloodGroupController,
                        hintText: AppStrings.babyBloodGroupHintText,
                        enabledBorderColor: AppColors.cmediumGrayColor,
                        focusedBorderColor: AppColors.cmediumGrayColor,
                        false,
                        enabled: _bloodGroupController.text.isEmpty,
                        validator: (value) {
                          if (AppValidators.emptyValidator(value!)) {
                            return ValidationMessages.babyBloodGroupReq;
                          }
                          return null;
                        },
                      ),
                      TextInputWidgets.textFormField(
                          maxLines: 4,
                          fillColor: AppColors.appBackGroundColor,
                          AppStrings.aboutyourChildLabel,
                          TextInputType.text,
                          TextInputAction.done,
                          _aboutChildController,
                          hintText: AppStrings.aboutBabyHintText,
                          enabledBorderColor: AppColors.cmediumGrayColor,
                          focusedBorderColor: AppColors.cmediumGrayColor,
                          false
                      ),
                      SizedBox(height: 20),
                      ButtonWidgets.elevatedButton(
                          AppStrings.updateTxt,
                              AppColors.lightRedColor, AppColors.cwhiteColor, () {
                               _onUpdate(context, state);
                             },
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              radius: 7,
                              width: MediaQuery.of(context).size.width,
                              height: 50
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
            )
          )
            ),
        Visibility(visible: state is ChildLoading, child:Loader.showLoader(AppStrings.loading))
      ]
        );
      }
    );
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildSuccess) {
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
      Navigator.of(context).pop(true);
    } else if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }


  void _onUpdate(BuildContext context, ChildState state) async {
    if (_formKey.currentState!.validate()) {
      final childBloc = context.read<ChildBloc>();
      final profileFile = childBloc.isUIUpdated
          ? childBloc.selectedPhotoProfile
          : null;

      final coverFile = childBloc.isUIUpdated
          ? childBloc.selectedCoverProfile
          : null;
      if (profileFile == null && (widget.childData.profilePictureUrl?.isEmpty ?? true)) {
        CustomSnackBar(
          context: context,
          message: ValidationMessages.selectProfilePic,
          messageType: AppStrings.failure,
        ).show();
        return;
      }

      final childId = SharedPreferencesHelper.instance.getSelectedChildId();
      final updateChildReqModel = UpdateChildReqModel(
        userId: childId.toString(),
        name: _babyNameController.text.trim(),
        gender: childBloc.isUIUpdated ? childBloc.selectedGender : "",
        birthDate: _dateTimeController.text.split(" ").first,
        timeOfBirth: AppUtils.formatDateTimeStringForBackend(_dateTimeController.text),
        height: double.tryParse(_heightController.text.trim()) ?? 0,
        weight: double.tryParse(_weightController.text.trim()) ?? 0,
        weightUnit: AppStrings.kgUnit,
        headCircumference: double.tryParse(_headCircumferenceController.text.trim()) ?? 0,
        bloodType: _bloodGroupController.text.trim(),
        description: _aboutChildController.text.trim().toString(),
        profilePicture: profileFile,
        coverPhoto: coverFile,
      );
      childBloc.add(
          UpdateChildEvent(updateChildReqModel: updateChildReqModel)
      );
    }
  }
}
