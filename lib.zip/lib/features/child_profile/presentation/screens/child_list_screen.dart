import 'package:child_health_story/core/utils/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../shared/widgets/custom_snack_bar.dart';
import '../../../../shared/widgets/loader.dart';
import '../../data/model/child_list_model.dart';
import '../bloc/child_bloc.dart';
import '../widgets/child_list_with_add.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/core/constants/path_constants.dart';


class ChildListScreen extends StatefulWidget {
  final List<ChildProfile>? children;
  const ChildListScreen({super.key,  this.children});

  @override
  State<ChildListScreen> createState() => _ChildListScreenState();
}

class _ChildListScreenState extends State<ChildListScreen> {
  late ChildBloc childBloc;

  void _onChildSelected(BuildContext context, List<ChildProfile> children, int index) async {
    final child = children[index];

    await SharedPreferencesHelper.instance.saveSelectedChildDetails(
      id: child.id ?? '',
      name: child.name ?? '',
      age: child.age ?? '',
      profilePhoto: child.profilePictureUrl,
      coverPhoto: child.coverPhotoUrl,
    );
    await SharedPreferencesHelper.instance.setChildListSize(children.length);
    if (!context.mounted) return;
    Navigator.pushNamedAndRemoveUntil(
      context,
      PathConstants.homeScreen,
          (Route<dynamic> route) => false,
    );

  }


  void _onAddNewPressed() {
    Navigator.pushNamed(context, PathConstants.addChild);
  }


  @override
  void initState() {
    super.initState();
    childBloc = context.read<ChildBloc>();
    final hasChildren = widget.children?.isNotEmpty ?? false;
    if (!hasChildren) {
      childBloc.add(FetchChildListEvent());
    }
  }


  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChildBloc, ChildState>(
        listener: _childBlocListener,
        builder: (context, state) {
          List<ChildProfile> children = [];

          if (state is ChildListSuccess) {
            children = state.children;
          } else if (widget.children != null) {
            children = widget.children!;
          }
          return ParentWidget(
              context: context,
              hasHeader: false,
              childWidget: SafeArea(
                child: Center(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        spacing: 10,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWidgets.textWidget(
                            AppStrings.chooseYourChildText,
                            AppColors.cblackColor,
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            textAlign: TextAlign.left,
                          ),
                          TextWidgets.textWidget(
                            AppStrings.selectChildDetailsText,
                            AppColors.cblackColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            textAlign: TextAlign.left,
                          ),
                          ChildListWithAdd(
                            children: children,
                            onChildSelected: (index) =>
                                _onChildSelected(context, children, index),
                            onAddNewPressed: _onAddNewPressed,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
          );
        }
    );
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    } else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

     if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }
}
