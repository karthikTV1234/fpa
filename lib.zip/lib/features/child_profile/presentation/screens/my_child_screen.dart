import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/shared_preferences.dart';
import 'package:child_health_story/shared/widgets/custom_listview_separted.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:flutter/material.dart';
import '../widgets/child_profile_bar.dart';

class MyChildScreen extends StatefulWidget {
  const MyChildScreen({super.key});

  @override
  State<MyChildScreen> createState() => _MyChildScreenState();
}

class _MyChildScreenState extends State<MyChildScreen> {
  String? _childName;
  String? _childAge;
  String? _profileImageUrl;
  String? _wallpaperImageUrl;

  @override
  void initState() {
    super.initState();
    _loadChildData();
  }

  void _loadChildData() {
    setState(() {
      _childName = SharedPreferencesHelper.instance.getSelectedChildName();
      _childAge = SharedPreferencesHelper.instance.getSelectedChildAge();
      _profileImageUrl = SharedPreferencesHelper.instance.getSelectedChildProfilePhoto();
      _wallpaperImageUrl = SharedPreferencesHelper.instance.getSelectedChildCoverPhoto();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ParentWidget(
        hasHeader: false,
        context: context,
        childWidget: SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            child: Column(
              children: [
                ChildProfileBar(
                  childName: _childName ?? '',
                  childAge: _childAge ?? '',
                  profileImageUrl: (_profileImageUrl != null && _profileImageUrl!.isNotEmpty)
                      ? _profileImageUrl
                      : null,
                  wallpaperImageUrl: (_wallpaperImageUrl != null && _wallpaperImageUrl!.isNotEmpty)
                      ? _wallpaperImageUrl
                      : null,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: AppColors.cwhiteColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: CustomSeparatedListView(
                    items: AppStrings.childProfileDetails,
                    onItemTap: (item) {
                      _redirectTo(item);
                    },
                  ),
                )
              ],
            ),
          ),
        ),
    );
  }

  void _redirectTo(Map<String, dynamic> item) {
    String title = item[AppStrings.titleTxt];
    if (title == AppStrings.profileTxt) {
      Navigator.pushNamed(
        context,
        PathConstants.viewChildProfile,
      ).then((_) {
        _loadChildData();
      });
    } else if (title == AppStrings.careTakersTxt) {
      Navigator.pushNamed(context, PathConstants.careTakersScreen);
    } else if (title == AppStrings.alertsTxt) {
    } else if (title == AppStrings.favoritesTxt) {
    } else if (title == AppStrings.insuranceText) {}
  }
}
