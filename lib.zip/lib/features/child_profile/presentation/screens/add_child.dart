import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/app_validators.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/custom_circular_avatar.dart';
import 'package:child_health_story/shared/widgets/custom_dropdown.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/text_style_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/utils/shared_preferences.dart';
import '../../../../shared/widgets/custom_snack_bar.dart';
import '../../data/model/add_child_model.dart';

class AddChild extends StatefulWidget {
  const AddChild({super.key});

  @override
  State<AddChild> createState() => _AddChildState();
}

class _AddChildState extends State<AddChild> {
  final TextEditingController _babyNameController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _dateTimeController = TextEditingController();
  final TextEditingController _headCircumferenceController =
      TextEditingController();
  final TextEditingController _bloodGroupController = TextEditingController();
  final TextEditingController _aboutChildController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  late ChildBloc childBloc;

  @override
  void initState() {
    childBloc = BlocProvider.of<ChildBloc>(context);
    super.initState();
  }

  @override
  void dispose() {
    _babyNameController.dispose();
    _dateTimeController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _headCircumferenceController.dispose();
    _bloodGroupController.dispose();
    _aboutChildController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChildBloc, ChildState>(
      listener: _childBlocListener,
      builder: (context, state) {
        return  Stack(
         children:[
         ParentWidget(
            hasHeader: false,
            context: context,
            childWidget: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 30),
                    child: Column(
                        spacing: 16,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWidgets.textWidget(
                              AppStrings.addaChildText, AppColors.cblackColor,
                              fontSize: 32, fontWeight: FontWeight.bold
                          ),
                          TextWidgets.textWidget(
                              textAlign: TextAlign.left,
                              AppStrings.provideDetailsText,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                          Align(
                            alignment: Alignment.center,
                            child: CustomCircleAvatar(
                              mainContext: context,
                              isEditable: true,
                              callback: (imagePath, imageName) {
                                context.read<ChildBloc>().add(UploadProfilePicEvent(imagePath));
                              },
                              imageFile: childBloc.isUIUpdated
                                  ? childBloc.selectedPhotoProfile
                                  : null,
                            ),
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.babyNameLabel,
                            hintText: AppStrings.babyNameHintText,
                            TextInputType.text,
                            TextInputAction.next,
                            _babyNameController,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.babyNameReq;
                              }
                              return null;
                            },
                          ),
                          CustomDropDown(
                            labelText: AppStrings.genderLabel,
                            hint: TextWidgets.textWidget(
                                fontSize: 14,
                                AppStrings.genderHintText,
                                AppColors.cblackColor),
                            dropdownMenuItems: AppStrings.gendersList,
                            value: childBloc.isUIUpdated ? childBloc.selectedGender : null,
                            onChanged: (value) {
                              context.read<ChildBloc>().add(SelectGenderEvent(value));
                            },
                            validator: (value) {
                              if (value == null ||
                                  AppValidators.emptyValidator(value)) {
                                return ValidationMessages.genderReq;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            fillColor: AppColors.appBackGroundColor,
                            labelStyle: TextStyleWidget.textStyleWidget(
                                AppColors.cblackColor,
                                fontSize: 14),
                            AppStrings.dobLabel,
                            TextInputType.datetime,
                            TextInputAction.next,
                            _dateTimeController,
                            false,
                            readOnly: true,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.dobReq;
                              }
                              return null;
                            },
                            customTap: () async {
                              final DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime(2100),
                              );

                              if (pickedDate != null) {
                                final TimeOfDay? pickedTime =
                                    await showTimePicker(
                                  // ignore: use_build_context_synchronously
                                  context: context,
                                  initialTime: TimeOfDay.now(),
                                );

                                if (pickedTime != null) {
                                  final DateTime combined = DateTime(
                                    pickedDate.year,
                                    pickedDate.month,
                                    pickedDate.day,
                                    pickedTime.hour,
                                    pickedTime.minute,
                                  );
                                  _dateTimeController.text =
                                      AppUtils.formatDateTime(combined);
                                }
                              }
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.heightLabel,
                            TextInputType.number,
                            TextInputAction.next,
                            _heightController,
                            hintText: AppStrings.babyHeightHintText,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.babyHeightReq;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.weightLabel,
                            TextInputType.number,
                            TextInputAction.next,
                            _weightController,
                            hintText: AppStrings.babyWeightHintText,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.babyWeightReq;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.headCircumferenceLabel,
                            TextInputType.number,
                            TextInputAction.next,
                            _headCircumferenceController,
                            hintText: AppStrings.babyHeadCircumFranceHintText,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages
                                    .babyHeadCircumfranceReq;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                            fillColor: AppColors.appBackGroundColor,
                            AppStrings.bloodGroupLabel,
                            TextInputType.text,
                            TextInputAction.next,
                            _bloodGroupController,
                            hintText: AppStrings.babyBloodGroupHintText,
                            enabledBorderColor: AppColors.cmediumGrayColor,
                            focusedBorderColor: AppColors.cmediumGrayColor,
                            false,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value!)) {
                                return ValidationMessages.babyBloodGroupReq;
                              }
                              return null;
                            },
                          ),
                          TextInputWidgets.textFormField(
                              maxLines: 4,
                              fillColor: AppColors.appBackGroundColor,
                              AppStrings.aboutyourChildLabel,
                              TextInputType.text,
                              TextInputAction.done,
                              _aboutChildController,
                              hintText: AppStrings.aboutBabyHintText,
                              enabledBorderColor: AppColors.cmediumGrayColor,
                              focusedBorderColor: AppColors.cmediumGrayColor,
                              false),
                          ButtonWidgets.elevatedButton(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              width: AppUtils.getScreenWidth(context),
                              radius: 7,
                              height: 50,
                              AppStrings.nextText,
                              AppColors.cprimaryColor,
                              AppColors.cwhiteColor, () {
                                _onSubmit(context, state);
                          })
                        ]),
                  ),
                ),
              ),
            )
        ),
         Visibility(visible: state is ChildLoading, child:Loader.showLoader(AppStrings.loading))
         ]
        );
      }
    );
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildAddSuccess) {
      CustomSnackBar(
        context: context,
        message: state.message,
        messageType: AppStrings.success,
      ).show();
      _handleChildAddSuccess(context, state);
    } else if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  Future<void> _handleChildAddSuccess(BuildContext context, ChildAddSuccess state) async {
    final childId = SharedPreferencesHelper.instance.getSelectedChildId();
    if (childId == '' || childId.isEmpty || childId == 'null') {
      final child = state.childData;
      await SharedPreferencesHelper.instance.saveSelectedChildDetails(
        id: child?.id ?? '',
        name: child?.name ?? '',
        age: child?.age ?? '',
        profilePhoto: child?.profilePictureUrl ?? '',
        coverPhoto: child?.coverPhotoUrl ?? '',
      );
    }
    if (context.mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        PathConstants.homeScreen,
            (Route<dynamic> route) => false,
      );
    }
  }


  void _onSubmit(BuildContext context, ChildState state) async {
    if (_formKey.currentState!.validate()) {
      final childBloc = context.read<ChildBloc>();
      final pickedFile = childBloc.isUIUpdated
          ? childBloc.selectedPhotoProfile
          : null;

      if (pickedFile == null) {
        CustomSnackBar(
          context: context,
          message: ValidationMessages.selectProfilePic,
          messageType: AppStrings.failure,
        ).show();
        return;
      }

      final addChildReqModel = AddChildReqModel(
        name: _babyNameController.text.trim(),
        gender: childBloc.isUIUpdated ? childBloc.selectedGender : "",
        birthDate: _dateTimeController.text.split(" ").first,
        timeOfBirth: AppUtils.formatDateTimeStringForBackend(_dateTimeController.text),
        weight: double.tryParse(_weightController.text.trim()) ?? 0,
        weightUnit: AppStrings.kgUnit,
        height: double.tryParse(_heightController.text.trim()) ?? 0,
        headCircumference: double.tryParse(_headCircumferenceController.text.trim()) ?? 0,
        bloodType: _bloodGroupController.text.trim(),
        description: _aboutChildController.text.trim().toString(),
        profilePicture: pickedFile,
      );
      childBloc.add(
          AddChildEvent(addChildReqModel: addChildReqModel)
      );
    }
  }


}
