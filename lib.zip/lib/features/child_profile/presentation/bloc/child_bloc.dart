import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/features/child_profile/data/repository/child_repository.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/errors/failure.dart';
import '../../data/model/add_child_model.dart';
import '../../data/model/child_detail_model.dart';

/// EVENTS
abstract class ChildEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class UploadProfilePicEvent extends ChildEvent {
  final File pickedFile;
  UploadProfilePicEvent(this.pickedFile);

  @override
  List<Object?> get props => [pickedFile];
}
class UploadCoverPicEvent extends ChildEvent {
  final File coverFile;
  UploadCoverPicEvent(this.coverFile);
  @override
  List<Object?> get props => [coverFile];
}
class SelectGenderEvent extends ChildEvent {
  final String gender;
  SelectGenderEvent(this.gender);
}
class AddChildEvent extends ChildEvent with EquatableMixin {
  final AddChildReqModel addChildReqModel;
  AddChildEvent({
    required this.addChildReqModel
  });
  @override
  List<Object?> get props => [addChildReqModel];
}
class FetchChildListEvent extends ChildEvent {}
class FetchChildByIdEvent extends ChildEvent {
  final String childId;
  FetchChildByIdEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}
class UpdateChildEvent extends ChildEvent {
  final UpdateChildReqModel updateChildReqModel;
  UpdateChildEvent({
    required this.updateChildReqModel
  });
  @override
  List<Object?> get props => [updateChildReqModel];
}
class DeleteChildEvent extends ChildEvent {
  final String childId;
  DeleteChildEvent({required this.childId});
  @override
  List<Object?> get props => [childId];
}

/// STATES
abstract class ChildState extends Equatable {
  @override
  List<Object?> get props => [];
}
class ProfilePhotoSelected extends ChildState {
  final File profilePhoto;
  ProfilePhotoSelected(this.profilePhoto);
  @override
  List<Object?> get props => [profilePhoto];
}
class CoverPhotoSelected extends ChildState {
  final File coverPhoto;
  CoverPhotoSelected(this.coverPhoto);
  @override
  List<Object?> get props => [coverPhoto];
}
class GenderSelected extends ChildState {
  final String gender;
  GenderSelected(this.gender);
  @override
  List<Object?> get props => [gender];
}
class ChildInitial extends ChildState {}
class ChildLoading extends ChildState {}
class ChildSuccess extends ChildState {
  final String message;
  ChildSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class ChildAddSuccess extends ChildState {
  final String message;
  final AddChildData? childData;
  ChildAddSuccess({
    required this.message,
    this.childData,
  });
  @override
  List<Object?> get props => [message, childData];
}
class ChildListSuccess extends ChildState {
  final List<ChildProfile> children;
  ChildListSuccess(this.children);
  @override
  List<Object?> get props => [children];
}
class ChildByIdSuccess extends ChildState {
  final GetChildData? childData;
  ChildByIdSuccess(this.childData);
  @override
  List<Object?> get props => [childData];
}
class ChildFailure extends ChildState {
  final String error;
  ChildFailure(this.error);
  @override
  List<Object?> get props => [error];
}

/// BLOC
class ChildBloc extends Bloc<ChildEvent, ChildState> {
  final ChildRepository childRepository;
  bool isUIUpdated = false;
  dynamic selectedGender;
  File? selectedPhotoProfile;
  File? selectedCoverProfile;
  ChildBloc({required this.childRepository}) : super(ChildInitial()) {
    on<UploadProfilePicEvent>((event, emit) {
      isUIUpdated = true;
      selectedPhotoProfile = event.pickedFile;
      emit(ProfilePhotoSelected(event.pickedFile));
    });

    on<UploadCoverPicEvent>((event, emit) {
      isUIUpdated = true;
      selectedCoverProfile = event.coverFile;
      emit(CoverPhotoSelected(event.coverFile));
    });

    on<SelectGenderEvent>((event, emit) {
      isUIUpdated = true;
      selectedGender = event.gender;
      emit(GenderSelected(event.gender));
    });

    on<AddChildEvent>((event, emit) async {
      emit(ChildLoading());
      final result = await childRepository.addChild(
        event.addChildReqModel
      );
      if (result.isSuccess) {
        emit(ChildAddSuccess(
            message: result.data?.message ?? AppStrings.childAddedSuccessMessage,
          childData: result.data?.data,
        ));
      } else {
        emit(ChildFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchChildListEvent>((event, emit) async {
      emit(ChildLoading());
      final result = await childRepository.getChildList();
      if (result.isSuccess && result.data != null) {
        final ChildListResModel resModel = result.data!;
        emit(ChildListSuccess(resModel.data ?? []));
      } else {
        emit(ChildFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<FetchChildByIdEvent>((event, emit) async {
      emit(ChildLoading());
      final result = await childRepository.getChildDetails(event.childId);
      if (result.isSuccess && result.data != null) {
        final GetChildProfileResModel resModel = result.data!;
        emit(ChildByIdSuccess(resModel.data));
      } else {
        emit(ChildFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<UpdateChildEvent>((event, emit) async {
      emit(ChildLoading());
      final result = await childRepository.updateChildDetails(
        event.updateChildReqModel
      );
      if (result.isSuccess) {
        emit(ChildSuccess(message: result.data?.message ?? AppStrings.childUpdateSuccessMessage));
      } else {
        emit(ChildFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });

    on<DeleteChildEvent>((event, emit) async {
      emit(ChildLoading());
      final result = await childRepository.deleteChild(event.childId);
      if (result.isSuccess && result.data != null) {
        emit(ChildSuccess(message: result.data?.message ??  AppStrings.childDeleteSuccessMessage));
      } else {
        emit(ChildFailure(result.error ?? ErrorMessages.somethingWentWrongError));
      }
    });
  }
}
