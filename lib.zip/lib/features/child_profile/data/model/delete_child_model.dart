class DeleteChildResModel {
  final int? statusCode;
  final String? message;
  final String? id;

  DeleteChildResModel({
    this.statusCode,
    this.message,
    this.id,
  });

  factory DeleteChildResModel.fromJson(Map<String, dynamic> json) {
    return DeleteChildResModel(
      statusCode: json['statusCode'] as int?,
      message: json['message'] as String?,
      id: json['data'] != null ? json['data']['id'] as String? : null,
    );
  }
}
