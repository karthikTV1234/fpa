class ChildListResModel {
  final int? statusCode;
  final String? message;
  final List<ChildProfile>? data;

  const ChildListResModel({
    this.statusCode,
    this.message,
    this.data,
  });

  factory ChildListResModel.fromJson(Map<String, dynamic> json) {
    return ChildListResModel(
      statusCode: json['statusCode'] as int?,
      message: json['message'] as String?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => ChildProfile.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class ChildProfile {
  final String? id;
  final String? userId;
  final String? name;
  final String? age;
  final String? birthDate;
  final String? timeOfBirth;
  final double? weight;
  final String? weightUnit;
  final int? height;
  final int? headCircumference;
  final String? gender;
  final String? bloodType;
  final String? profilePictureUrl;
  final String? coverPhotoUrl;
  final String? description;
  final String? createdAt;
  final String? updatedAt;
  final bool? isDeleted;

  const ChildProfile({
    this.id,
    this.userId,
    this.name,
    this.age,
    this.birthDate,
    this.timeOfBirth,
    this.weight,
    this.weightUnit,
    this.height,
    this.headCircumference,
    this.gender,
    this.bloodType,
    this.profilePictureUrl,
    this.coverPhotoUrl,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isDeleted,
  });

  factory ChildProfile.fromJson(Map<String, dynamic> json) {
    return ChildProfile(
      id: json['id'] as String?,
      userId: json['userId'] as String?,
      name: json['name'] as String?,
      age: json['age'] as String?,
      birthDate: json['birthDate'] as String?,
      timeOfBirth: json['timeOfBirth'] as String?,
      weight: (json['weight'] as num?)?.toDouble(),
      weightUnit: json['weightUnit'] as String?,
      height: json['height'] as int?,
      headCircumference: json['headCircumference'] as int?,
      gender: json['gender'] as String?,
      bloodType: json['bloodType'] as String?,
      profilePictureUrl: json['profilePictureUrl'] as String?,
      coverPhotoUrl: json['coverPhotoUrl'] as String?,
      description: json['description'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      isDeleted: json['is_deleted'] as bool?,
    );
  }
}
