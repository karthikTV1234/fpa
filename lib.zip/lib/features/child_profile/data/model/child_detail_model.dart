class GetChildProfileResModel {
  final int? statusCode;
  final String? message;
  final GetChildData? data;

  GetChildProfileResModel({
    this.statusCode,
    this.message,
    this.data,
  });

  factory GetChildProfileResModel.fromJson(Map<String, dynamic> json) {
    return GetChildProfileResModel(
      statusCode: json['statusCode'] as int?,
      message: json['message'] as String?,
      data: json['data'] != null ? GetChildData.fromJson(json['data']) : null,
    );
  }
}

class GetChildData {
  final String? id;
  final String? userId;
  final String? name;
  final String? birthDate;
  final String? timeOfBirth;
  final String? age;
  final double? weight;
  final String? weightUnit;
  final double? height;
  final double? headCircumference;
  final String? gender;
  final String? bloodType;
  final String? profilePictureUrl;
  final String? coverPhotoUrl;
  final String? description;
  final String? createdAt;
  final String? updatedAt;
  final bool? isDeleted;

  GetChildData({
    this.id,
    this.userId,
    this.name,
    this.birthDate,
    this.timeOfBirth,
    this.age,
    this.weight,
    this.weightUnit,
    this.height,
    this.headCircumference,
    this.gender,
    this.bloodType,
    this.profilePictureUrl,
    this.coverPhotoUrl,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isDeleted,
  });

  factory GetChildData.fromJson(Map<String, dynamic> json) {
    return GetChildData(
      id: json['id'] as String?,
      userId: json['userId'] as String?,
      name: json['name'] as String?,
      birthDate: json['birthDate'] as String?,
      timeOfBirth: json['timeOfBirth'] as String?,
      age: json['age'] as String?,
      weight: (json['weight'] as num?)?.toDouble(),
      weightUnit: json['weightUnit'] as String?,
      height: (json['height'] as num?)?.toDouble(),
      headCircumference: (json['headCircumference'] as num?)?.toDouble(),
      gender: json['gender'] as String?,
      bloodType: json['bloodType'] as String?,
      profilePictureUrl: json['profilePictureUrl'] as String?,
      coverPhotoUrl: json['coverPhotoUrl'] as String?,
      description: json['description'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      isDeleted: json['is_deleted'] as bool?,
    );
  }
}