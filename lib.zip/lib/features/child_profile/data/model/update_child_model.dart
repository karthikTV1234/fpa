import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class UpdateChildReqModel {
  final String userId;
  final String name;
  final String birthDate;
  final String timeOfBirth;
  final double weight;
  final String weightUnit;
  final double height;
  final double headCircumference;
  final String gender;
  final String bloodType;
  final String description;
  final File? profilePicture;
  final File? coverPhoto;

  UpdateChildReqModel({
    required this.userId,
    required this.name,
    required this.birthDate,
    required this.timeOfBirth,
    required this.weight,
    required this.weightUnit,
    required this.height,
    required this.headCircumference,
    required this.gender,
    required this.bloodType,
    required this.description,
     this.profilePicture,
     this.coverPhoto,
  });

  Map<String, dynamic> toMap() {
    return {
      "userId": userId,
      "name": name,
      "birthDate": birthDate,
      "timeOfBirth": timeOfBirth,
      "weight": weight,
      "weightUnit": weightUnit,
      "height": height,
      "headCircumference": headCircumference,
      "gender": gender,
      "bloodType": bloodType,
      "description": description,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());
    if (profilePicture != null) {
      final mimeType = lookupMimeType(profilePicture!.path) ?? 'image/jpeg';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'profilePicture',
          await MultipartFile.fromFile(
            profilePicture!.path,
            filename: profilePicture!.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }
    if (coverPhoto != null) {
      final mimeType = lookupMimeType(coverPhoto!.path) ?? 'image/jpeg';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'coverPhoto',
          await MultipartFile.fromFile(
            coverPhoto!.path,
            filename: coverPhoto!.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }

    return formData;
  }
}


class UpdateChildProfileResModel {
  final int? statusCode;
  final String? message;
  final ChildProfileData? data;

  UpdateChildProfileResModel({
    this.statusCode,
    this.message,
    this.data,
  });

  factory UpdateChildProfileResModel.fromJson(Map<String, dynamic> json) {
    return UpdateChildProfileResModel(
      statusCode: json['statusCode'] as int?,
      message: json['message'] as String?,
      data: json['data'] != null ? ChildProfileData.fromJson(json['data']) : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'statusCode': statusCode,
    'message': message,
    'data': data?.toJson(),
  };
}

class ChildProfileData {
  final String? id;
  final String? userId;
  final String? name;
  final String? birthDate;
  final String? timeOfBirth;
  final num? weight;
  final String? weightUnit;
  final num? height;
  final num? headCircumference;
  final String? gender;
  final String? bloodType;
  final String? profilePictureUrl;
  final String? coverPhotoUrl;
  final String? description;
  final String? createdAt;
  final String? updatedAt;
  final bool? isDeleted;

  ChildProfileData({
    this.id,
    this.userId,
    this.name,
    this.birthDate,
    this.timeOfBirth,
    this.weight,
    this.weightUnit,
    this.height,
    this.headCircumference,
    this.gender,
    this.bloodType,
    this.profilePictureUrl,
    this.coverPhotoUrl,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isDeleted,
  });

  factory ChildProfileData.fromJson(Map<String, dynamic> json) {
    return ChildProfileData(
      id: json['id'] as String?,
      userId: json['userId'] as String?,
      name: json['name'] as String?,
      birthDate: json['birthDate'] as String?,
      timeOfBirth: json['timeOfBirth'] as String?,
      weight: json['weight'] is num ? json['weight'] as num : null,
      weightUnit: json['weightUnit'] as String?,
      height: json['height'] is num ? json['height'] as num : null,
      headCircumference: json['headCircumference'] is num ? json['headCircumference'] as num : null,
      gender: json['gender'] as String?,
      bloodType: json['bloodType'] as String?,
      profilePictureUrl: json['profilePictureUrl'] as String?,
      coverPhotoUrl: json['coverPhotoUrl'] as String?,
      description: json['description'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      isDeleted: json['is_deleted'] as bool?,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'userId': userId,
    'name': name,
    'birthDate': birthDate,
    'timeOfBirth': timeOfBirth,
    'weight': weight,
    'weightUnit': weightUnit,
    'height': height,
    'headCircumference': headCircumference,
    'gender': gender,
    'bloodType': bloodType,
    'profilePictureUrl': profilePictureUrl,
    'coverPhotoUrl': coverPhotoUrl,
    'description': description,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    'is_deleted': isDeleted,
  };
}


