import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class AddChildReqModel {
  final String name;
  final String birthDate;
  final String timeOfBirth;
  final double weight;
  final String weightUnit;
  final double height;
  final double headCircumference;
  final String gender;
  final String bloodType;
  final File? profilePicture;
  final File? coverPhoto;
  final String description;

  AddChildReqModel({
    required this.name,
    required this.birthDate,
    required this.timeOfBirth,
    required this.weight,
    required this.weightUnit,
    required this.height,
    required this.headCircumference,
    required this.gender,
    required this.bloodType,
     this.profilePicture,
     this.coverPhoto,
    required this.description,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'birthDate': birthDate,
      'timeOfBirth': timeOfBirth,
      'weight': weight,
      'weightUnit': weightUnit,
      'height': height,
      'headCircumference': headCircumference,
      'gender': gender,
      'bloodType': bloodType,
      'description': description,
    };
  }

  Future<FormData> toFormData() async {
    final formData = FormData.fromMap(toMap());
    if (profilePicture != null) {
      final mimeType = lookupMimeType(profilePicture!.path) ?? 'image/jpeg';
      final mimeSplit = mimeType.split('/');
      formData.files.add(
        MapEntry(
          'profilePicture',
          await MultipartFile.fromFile(
            profilePicture!.path,
            filename: profilePicture!.path.split('/').last,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        ),
      );
    }
    return formData;
  }

}


class AddChildResModel {
  final int? statusCode;
  final String? message;
  final AddChildData? data;

  AddChildResModel({
    this.statusCode,
    this.message,
    this.data,
  });

  factory AddChildResModel.fromJson(Map<String, dynamic> json) {
    return AddChildResModel(
      statusCode: json['statusCode'] as int?,
      message: json['message'] as String?,
      data: json['data'] != null ? AddChildData.fromJson(json['data']) : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'statusCode': statusCode,
    'message': message,
    'data': data?.toJson(),
  };
}

class AddChildData {
  final String? id;
  final String? userId;
  final String? name;
  final String? birthDate;
  final String? age;
  final String? timeOfBirth;
  final num? weight;
  final String? weightUnit;
  final num? height;
  final num? headCircumference;
  final String? gender;
  final String? bloodType;
  final String? profilePictureUrl;
  final String? coverPhotoUrl;
  final String? description;
  final String? createdAt;
  final String? updatedAt;
  final bool? isDeleted;

  AddChildData({
    this.id,
    this.userId,
    this.name,
    this.birthDate,
    this.age,
    this.timeOfBirth,
    this.weight,
    this.weightUnit,
    this.height,
    this.headCircumference,
    this.gender,
    this.bloodType,
    this.profilePictureUrl,
    this.coverPhotoUrl,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isDeleted,
  });

  factory AddChildData.fromJson(Map<String, dynamic> json) {
    return AddChildData(
      id: json['id'] as String?,
      userId: json['userId'] as String?,
      name: json['name'] as String?,
      birthDate: json['birthDate'] as String?,
      age: json['age'] as String?,
      timeOfBirth: json['timeOfBirth'] as String?,
      weight: json['weight'] as num?,
      weightUnit: json['weightUnit'] as String?,
      height: json['height'] as num?,
      headCircumference: json['headCircumference'] as num?,
      gender: json['gender'] as String?,
      bloodType: json['bloodType'] as String?,
      profilePictureUrl: json['profilePictureUrl'] as String?,
      coverPhotoUrl: json['coverPhotoUrl'] as String?,
      description: json['description'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      isDeleted: json['is_deleted'] as bool?,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'userId': userId,
    'name': name,
    'birthDate': birthDate,
    'age': age,
    'timeOfBirth': timeOfBirth,
    'weight': weight,
    'weightUnit': weightUnit,
    'height': height,
    'headCircumference': headCircumference,
    'gender': gender,
    'bloodType': bloodType,
    'profilePictureUrl': profilePictureUrl,
    'coverPhotoUrl': coverPhotoUrl,
    'description': description,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    'is_deleted': isDeleted,
  };
}

