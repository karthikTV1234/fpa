import 'package:child_health_story/features/child_profile/data/model/child_list_model.dart';
import 'package:child_health_story/features/child_profile/data/model/delete_child_model.dart';
import 'package:child_health_story/features/child_profile/data/model/update_child_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/network/api_client.dart';
import 'package:child_health_story/core/utils/result.dart';
import '../../../../core/errors/failure.dart';
import '../model/add_child_model.dart';
import '../model/child_detail_model.dart';

class ChildRepository {
  final Dio _dio;

  ChildRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<AddChildResModel>> addChild(AddChildReqModel addChildReqModel) async {
    String errorMessage = ErrorMessages.addChildFailedError;
    try {
      const String url = '${ApiConstants.baseUrl}${ApiConstants.childProfiles}';
      final formData = await addChildReqModel.toFormData();
      final response = await _dio.post(
        url,
        data: formData,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final addChildRes = AddChildResModel.fromJson(response.data);
        return Result.success(addChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<ChildListResModel>> getChildList() async {
    String errorMessage = ErrorMessages.fetchChildListFailedError;
    try {
      const String url = '${ApiConstants.baseUrl}${ApiConstants.childProfiles}';
      final response = await _dio.get(
          url,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final childListRes = ChildListResModel.fromJson(response.data);
        return Result.success(childListRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<GetChildProfileResModel>> getChildDetails(String childId) async {
    String errorMessage = ErrorMessages.fetchChildFailedError;
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.childProfiles}/$childId';
      final response = await _dio.get(
          url,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.data != null && (response.statusCode == 200 || response.statusCode == 201)) {
        final childDetailRes = GetChildProfileResModel.fromJson(response.data);
        return Result.success(childDetailRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> updateChildDetails(UpdateChildReqModel updateChildReqModel) async {
    String errorMessage = ErrorMessages.updateChildFailedError;
    try {
      final String childId = updateChildReqModel.userId;
      final String url = '${ApiConstants.baseUrl}${ApiConstants.childProfiles}/$childId';
      final formData = await updateChildReqModel.toFormData();
      final response = await _dio.patch(
        url,
        data: formData,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final updateChildRes = CommonResModel.fromJson(response.data);
        return Result.success(updateChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> deleteChild(String childId) async {
    String errorMessage = ErrorMessages.deleteChildFailedError;
    try {
      final String url = '${ApiConstants.baseUrl}${ApiConstants.childProfiles}/$childId';
      final response = await _dio.delete(
        url,
        options: Options(
          extra: {'requiresAuth': true},
        ),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        final deleteChildRes = CommonResModel.fromJson(response.data);
        return Result.success(deleteChildRes);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      } else if (e.type == DioExceptionType.connectionError) {
        errorMessage = ErrorMessages.networkError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

}
