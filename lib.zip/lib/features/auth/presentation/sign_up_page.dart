import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_bloc.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_events.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:child_health_story/shared/widgets/loader.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/path_constants.dart';
import '../../../core/constants/strings/app_data.dart';
import '../../../core/constants/strings/validation_messages.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import '../../../core/errors/failure.dart';
import '../../../core/utils/app_validators.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/country_drop_down.dart';
import '../data/model/sing_up_model.dart';
import 'bloc/sign_up/sing_up_state.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  late SignUpBloc _signUpBloc;

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _signUpBloc = BlocProvider.of<SignUpBloc>(context);
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
        listeners: [
          BlocListener<SignUpBloc, SignUpState>(
            listener: _signInBlocListener,
          ),
          BlocListener<ChildBloc, ChildState>(
            listener: _childBlocListener,
          ),
        ],
        child: ParentWidget(
          context: context,
          hasHeader: false,
            childWidget: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: AppUtils.getScreenHeight(context),
                ),
            child: IntrinsicHeight(
              child: Form(
                key: _formKey,
                child: Column(
                  spacing: 16,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidgets.textWidget(
                      AppStrings.letsGetStartedText,
                      AppColors.cblackColor,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                    TextWidgets.textWidget(
                      AppStrings.createAccountDescriptionText,
                      AppColors.cblackColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      textAlign: TextAlign.left,
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.firstNameHint,
                      TextInputType.text,
                      TextInputAction.done,
                      hintText: AppStrings.firstNameHint,
                      _firstNameController,
                      validator: (value) =>
                      AppValidators.emptyValidator(value ?? '')
                          ? ValidationMessages.plsEnterFirstName
                          : null,
                      false,
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.lastNameHint,
                      TextInputType.text,
                      TextInputAction.done,
                      hintText: AppStrings.lastNameHint,
                      _lastNameController,
                      validator: (value) =>
                      AppValidators.emptyValidator(value ?? '')
                          ? ValidationMessages.plsEnterLastName
                          : null,
                      false,
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.emailHint,
                      TextInputType.emailAddress,
                      TextInputAction.done,
                      hintText: AppStrings.emailHint,
                      _emailController,
                      validator: (value) {
                        if (AppValidators.emptyValidator(value ?? '')) {
                          return ValidationMessages.plsEnterEmail;
                        } else if (AppValidators.emailValidator(value!)) {
                          return ValidationMessages.plsEnterValidEmail;
                        }
                        return null;
                      },
                      false,
                    ),
                    Row(
                      spacing: 10,
                      children: [
                        Expanded(
                          flex: 2,
                          child: CustomCountryDropDown(
                            hint: TextWidgets.textWidget(
                              fontSize: 12,
                              AppStrings.countryCodeHintText,
                              AppColors.cblackColor,
                            ),
                            dropdownMenuItems: AppData.countryCodes,
                            value: _signUpBloc.selectedCountryCode,
                            onChanged: (value) {
                              _signUpBloc.add(SelectCountryCodeEvent(value));
                            },
                            validator: (value) {
                              if (value == null || AppValidators.emptyValidator(value)) {
                                return ValidationMessages.plsSelectCountryCode;
                              }
                              return null;
                            },
                          ),
                        ),
                        Expanded(
                          flex: 5,
                          child: TextInputWidgets.textFormField(
                            AppStrings.phoneLabel,
                            TextInputType.phone,
                            TextInputAction.done,
                            hintText: AppStrings.enterPhoneNumberHintText,
                            _phoneController,
                            validator: (value) {
                              if (AppValidators.emptyValidator(value ?? '')) {
                                return ValidationMessages.plsEnterPhoneNumber;
                              } else if (!AppValidators.phoneValidator(value!)) {
                                return ValidationMessages.plsEnterValidPhoneNumber;
                              }
                              return null;
                            },
                            false,
                          ),
                        ),
                      ],
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.passwordHint,
                      TextInputType.text,
                      TextInputAction.done,
                      hintText: AppStrings.passwordHint,
                      _passwordController,
                      validator: (value) {
                        if (AppValidators.emptyValidator(value ?? '')) {
                          return ValidationMessages.plsEnterPassword;
                        } else if (AppValidators.strongPasswordValidator(value!)) {
                          return ValidationMessages.passwordPolicy;
                        }
                        return null;
                      },
                      false,
                    ),
                    TextInputWidgets.textFormField(
                      AppStrings.confirmPasswordHint,
                      TextInputType.text,
                      TextInputAction.done,
                      hintText: AppStrings.confirmPasswordHint,
                      _confirmPasswordController,
                      validator: (value) {
                        if (AppValidators.emptyValidator(value ?? '')) {
                          return ValidationMessages.plsEnterConfirmPassword;
                        } else if (AppValidators.confirmPasswordValidator(
                            _passwordController.text, value!)) {
                          return ValidationMessages.passwordDoNotMatch;
                        }
                        return null;
                      },
                      false,
                    ),
                    ButtonWidgets.elevatedButton(
                      AppStrings.createMyAccountText,
                      AppColors.cprimaryColor,
                      AppColors.cwhiteColor,
                          () => _onSubmit(context),
                      width: AppUtils.getScreenWidth(context),
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      height: 50,
                      radius: 7,
                    ),
                    Center(
                      child: TextWidgets.termsAndPrivacyRichText(
                        firstText: AppStrings.signUpAgreement,
                        firstTextColor: AppColors.cblackColor,
                        firstTextFontSize: 16,
                        secondText: AppStrings.termsConditionsText,
                        secondTextColor: AppColors.cprimaryColor,
                        secondTextFontSize: 16,
                        thirdText: AppStrings.and,
                        thirdTextColor: AppColors.cblackColor,
                        thirdTextFontSize: 16,
                        fourthText: AppStrings.privacyPolicyText,
                        fourthTextColor: AppColors.cprimaryColor,
                        fourthTextFontSize: 16,
                        onSecondTextTap: () {/* handle terms tap */},
                        onFourthTextTap: () {/* handle privacy tap */},
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          )
          )
        ),
    );
  }

  void _signInBlocListener(BuildContext context, SignUpState state) {
    if (state is RegisterLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    }else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is RegisterSuccess) {
      context.read<ChildBloc>().add(FetchChildListEvent());
    }
    if (state is RegisterFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    } else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is ChildListSuccess) {
      _handleChildListSuccess(context, state);
    } else if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: ErrorMessages.somethingWentWrongError,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onSubmit(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      final phone = _phoneController.text.trim();
      final requestModel = SignUpReqModel(
        firstName: _firstNameController.text.trim(),
        lastName: _lastNameController.text.trim(),
        countryCode: phone.isEmpty ? "" : _signUpBloc.selectedCountryCode,
        phone: phone,
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        deviceId: "",
      );
      _signUpBloc.add(
        RegisterSubmitEvent(signUpReqModel: requestModel),
      );
    }
  }

  Future<void> _handleChildListSuccess(BuildContext context, ChildListSuccess state) async {
    CustomSnackBar(
      context: context,
      message: AppStrings.signupSuccess,
      messageType: AppStrings.success,
    ).show();
    if (state.children.isEmpty) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        PathConstants.addChild,
            (route) => false,
      );
    } else {
      final mounted = context.mounted;
      await SharedPreferencesHelper.instance.setChildListSize(state.children.length);
      if (!context.mounted) return;
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          PathConstants.childListScreen,
              (route) => false,
          arguments: state.children,
        );
      }
    }
  }
}
