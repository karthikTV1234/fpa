import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/app_validators.dart';
import 'package:child_health_story/features/auth/data/model/forgot_password_model.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import 'args/otp_screen_args.dart';
import 'bloc/forgot_password_bloc.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _emailController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ForgotPasswordBloc, ForgotPasswordState>(
        listener: (context, state) {
      if (state is ForgotPasswordLoading) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => Loader.showLoader(AppStrings.loading),
        );
      }else {
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop(); // hide loader
        }
      }

      if (state is ForgotPasswordSuccess) {
        CustomSnackBar(
          context: context,
          message: state.message,
          messageType: AppStrings.success,
        ).show();
        Navigator.pushNamed(
          context,
          PathConstants.otpScreen,
          arguments: OtpScreenArgs(
            isFromForgotPassword: true,
            email: _emailController.text.trim()
          ),
        );
      } else if (state is ForgotPasswordFailure) {
        CustomSnackBar(
          context: context,
          message: state.message,
          messageType: AppStrings.failure,
        ).show();
      }
    },
     child:  ParentWidget(
      hasHeader: false,
      context: context,
      childWidget: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints:
                BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
            child: IntrinsicHeight(
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidgets.textWidget(
                      AppStrings.forgotPasswordHeadText,
                      AppColors.cblackColor,
                      fontSize: 32,
                      fontWeight: FontWeight.w700,
                      textAlign: TextAlign.left,
                    ),
                    TextWidgets.textWidget(
                      AppStrings.sendEmail,
                      AppColors.cblackColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      textAlign: TextAlign.left,
                    ),
                    SizedBox(height: 16),
                    TextInputWidgets.textFormField(
                        AppStrings.emailHint,
                        hintText: AppStrings.emailHint,
                        TextInputType.text,
                        TextInputAction.done,
                        _emailController, validator: (value) {
                      if (AppValidators.emptyValidator(value!)) {
                        return ValidationMessages.emailReq;
                      } else if (AppValidators.emailValidator(value)) {
                        return ValidationMessages.invalidEmail;
                      }

                      return null;
                    }, false),
                    SizedBox(height: 16),
                    ButtonWidgets.elevatedButton(AppStrings.shareOTPText,
                        AppColors.cprimaryColor, AppColors.cwhiteColor, () {
                          _onSubmit(context);
                    },
                        width: AppUtils.getScreenWidth(context),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        height: 50,
                        radius: 7),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
     )
    );
  }

  void _onSubmit(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      final loginReqModel = ForgotPasswordReqModel(
        email: _emailController.text.trim()
      );
      context.read<ForgotPasswordBloc>().add(
        EmailSubmitted(
          email: loginReqModel.email
        ),
      );
    }
  }
}
