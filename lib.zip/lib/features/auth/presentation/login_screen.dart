import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/path_constants.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/constants/strings/validation_messages.dart';
import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:child_health_story/core/utils/app_validators.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/parent_widget.dart';
import 'package:child_health_story/shared/widgets/text_input_widgets.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/shared_preferences.dart';
import '../../../shared/widgets/custom_snack_bar.dart';
import '../../../shared/widgets/loader.dart';
import '../data/model/login_model.dart';
import 'bloc/login_bloc.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
        listeners: [
          BlocListener<LoginBloc, LoginState>(
            listener: _loginBlocListener,
          ),
          BlocListener<ChildBloc, ChildState>(
            listener: _childBlocListener,
          ),
        ],
    child: ParentWidget(
        context: context,
        childWidget: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(minHeight: AppUtils.getScreenHeight(context)),
              child: IntrinsicHeight(
                child: Form(
                  key: _formKey,
                  child: Column(
                    spacing: 20,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidgets.textWidget(
                        AppStrings.welcomeText,
                        AppColors.cblackColor,
                        fontSize: 32,
                        fontWeight: FontWeight.w700,
                        textAlign: TextAlign.left,
                      ),
                      TextWidgets.textWidget(
                        AppStrings.enterEmailOrPwdtext,
                        AppColors.cblackColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        textAlign: TextAlign.left,
                      ),
                      TextInputWidgets.textFormField(
                          AppStrings.emailLabel,
                          TextInputType.text,
                          TextInputAction.done,
                          hintText: AppStrings.enterEmailHintText,
                          _emailController, validator: (value) {
                        if (AppValidators.emptyValidator(value!)) {
                          return ValidationMessages.emailReq;
                        } else if (AppValidators.emailValidator(value)) {
                          return ValidationMessages.invalidEmail;
                        }

                        return null;
                      }, false),
                      TextInputWidgets.textFormField(
                          AppStrings.passwordtext,
                          TextInputType.text,
                          TextInputAction.done,
                          hintText: AppStrings.passwordHintText,
                          _passwordController, validator: (value) {
                        if (AppValidators.emptyValidator(value!)) {
                          return ValidationMessages.passwordReq;
                        }else if (AppValidators.strongPasswordValidator(value)) {
                          return ValidationMessages.passwordPolicy;
                        }
                        return null;
                      }, true),
                      ButtonWidgets.elevatedButton(AppStrings.continueText,
                          AppColors.cprimaryColor, AppColors.cwhiteColor, () {
                            _onSubmit(context);
                      },
                          width: AppUtils.getScreenWidth(context),
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          height: 50,
                          radius: 7),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: TextWidgets.richText(
                            AppStrings.signInUsingText,
                            AppColors.cblackColor,
                            16.0,
                            AppStrings.mobileNumberText,
                            AppColors.cprimaryColor,
                            16.0,
                            rTextFontWeight: FontWeight.bold,
                            rDecoration: TextDecoration.underline,
                            isRTextClickable: true,
                            rDecorationColor: AppColors.cprimaryColor,
                            onRTextTap: () {
                              Navigator.pushNamed(
                                  context, PathConstants.loginWithOtp);
                        }),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: ButtonWidgets.textButton(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            AppStrings.forgotPasswordText,
                            AppColors.cprimaryColor,
                            () {
                              Navigator.pushNamed(
                                  context, PathConstants.forgotPasswordScreen);
                            }),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: TextWidgets.richText(
                            AppStrings.dontHaveAccountText,
                            AppColors.cblackColor,
                            16.0,
                            AppStrings.signUpText,
                            AppColors.cprimaryColor,
                            16.0,
                            rTextFontWeight: FontWeight.bold,
                            rDecoration: TextDecoration.none,
                            isRTextClickable: true,
                            rDecorationColor: AppColors.cprimaryColor,
                            onRTextTap: () {
                          Navigator.pushNamed(
                              context, PathConstants.signUpScreen);
                        }),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        hasHeader: false)
    );
  }

  void _loginBlocListener(BuildContext context, LoginState state) {
    if (state is LoginLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    }else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is LoginSuccess) {
      context.read<ChildBloc>().add(FetchChildListEvent());
    } else if (state is LoginFailure) {
      CustomSnackBar(
        context: context,
        message: state.error,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _childBlocListener(BuildContext context, ChildState state) {
    if (state is ChildLoading) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Loader.showLoader(AppStrings.loading),
      );
    } else {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // hide loader
      }
    }

    if (state is ChildListSuccess) {
      _handleChildListSuccess(context, state);
    } else if (state is ChildFailure) {
      CustomSnackBar(
        context: context,
        message: ErrorMessages.somethingWentWrongError,
        messageType: AppStrings.failure,
      ).show();
    }
  }

  void _onSubmit(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      final loginReqModel = LoginReqModel(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        deviceId: "",
      );
      context.read<LoginBloc>().add(
        LoginSubmitted(
          email: loginReqModel.email,
          password: loginReqModel.password,
          deviceId: loginReqModel.deviceId,
        ),
      );
    }
  }

  Future<void> _handleChildListSuccess(BuildContext context, ChildListSuccess state) async {
    CustomSnackBar(
      context: context,
      message: AppStrings.loginSuccess,
      messageType: AppStrings.success,
    ).show();
    if (state.children.isEmpty) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        PathConstants.addChild,
            (route) => false,
      );
    } else {
      final mounted = context.mounted;
      await SharedPreferencesHelper.instance.setChildListSize(state.children.length);
      if (!context.mounted) return;
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          PathConstants.childListScreen,
              (route) => false,
          arguments: state.children,
        );
      }
    }
  }
}
