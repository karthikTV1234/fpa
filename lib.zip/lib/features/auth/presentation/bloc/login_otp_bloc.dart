import 'package:bloc/bloc.dart';
import 'package:child_health_story/features/auth/data/model/login_with_otp.dart';
import 'package:child_health_story/features/auth/data/repository/auth_repository.dart';
import 'package:equatable/equatable.dart';
import '../../data/repository/firebase_auth_repository.dart';

//Events
abstract class LoginOtpEvent extends Equatable {
  @override
  List<Object> get props => [];
}
class AuthRequestOtp extends LoginOtpEvent {
  final String phoneNumber;
  AuthRequestOtp(this.phoneNumber);
  @override
  List<Object> get props => [phoneNumber];
}
class AuthResendOtp extends LoginOtpEvent {
  final String phoneNumber;
  AuthResendOtp(this.phoneNumber);
  @override
  List<Object> get props => [phoneNumber];
}

class AuthSubmitOtp extends LoginOtpEvent {
  final String otp;
  final String verificationId;
  AuthSubmitOtp({required this.otp, required this.verificationId});
  @override
  List<Object> get props => [otp, verificationId];
}

//States
abstract class LoginOtpState extends Equatable {
  @override
  List<Object?> get props => [];
}
class LoginOtpInitial extends LoginOtpState {}
class LoginOtpLoading extends LoginOtpState {}
class LoginResendOtpLoading extends LoginOtpState {}
class LoginOtpSuccess extends LoginOtpState {}
class LoginOtpError extends LoginOtpState {
  final String message;
  LoginOtpError(this.message);
  @override
  List<Object?> get props => [message];
}
class OtpSent extends LoginOtpState {
  final String verificationId;
  OtpSent({required this.verificationId});
  @override
  List<Object?> get props => [verificationId];
}

// Bloc
class LoginOtpBloc extends Bloc<LoginOtpEvent, LoginOtpState> {
  final FirebaseAuthRepository firebaseAuthRepository;
  final AuthRepository authRepository;

  LoginOtpBloc({
    required this.firebaseAuthRepository,
    required this.authRepository,
  }) : super(LoginOtpInitial()){
    on<AuthRequestOtp>((event, emit) async {
      emit(LoginOtpLoading());
      final result = await firebaseAuthRepository.requestOtp(phoneNumber: event.phoneNumber);
      if (result.isSuccess) {
        emit(OtpSent(verificationId: result.data!));
      } else {
        emit(LoginOtpError(result.error!));
      }
    });

    on<AuthResendOtp>((event, emit) async {
      emit(LoginResendOtpLoading());
      final result = await firebaseAuthRepository.requestOtp(phoneNumber: event.phoneNumber);
      if (result.isSuccess) {
        emit(OtpSent(verificationId: result.data!));
      } else {
        emit(LoginOtpError(result.error!));
      }
    });

    on<AuthSubmitOtp>((event, emit) async {
      emit(LoginOtpLoading());
      final submitOTPResponse = await firebaseAuthRepository.submitOtp(
        otp: event.otp,
        verificationId: event.verificationId,
      );
      final response = await authRepository.loginWithOTP(
          LoginWithOtpReqModel(idToken: submitOTPResponse.data!)
      );
      if (response.isSuccess) {
        emit(LoginOtpSuccess());
      } else {
        emit(LoginOtpError(response.error!));
      }
    });
  }
}

