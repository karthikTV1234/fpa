import 'package:bloc/bloc.dart';
import 'package:child_health_story/features/auth/data/model/forgot_password_model.dart';
import 'package:child_health_story/features/auth/data/model/reset_password_model.dart';
import 'package:child_health_story/features/auth/data/repository/forgot_password_repository.dart';
import 'package:child_health_story/features/auth/data/model/validate_reset_code_model.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/errors/failure.dart';

/// EVENTS
abstract class ForgotPasswordEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class EmailSubmitted extends ForgotPasswordEvent {
  final String email;
  EmailSubmitted({
    required this.email,
  });
  @override
  List<Object?> get props => [email];
}
class EmailResendOTP extends ForgotPasswordEvent {
  final String email;
  EmailResendOTP({
    required this.email,
  });
  @override
  List<Object?> get props => [email];
}
class EmailOTPSubmit extends ForgotPasswordEvent {
  final String email;
  final String code;
  EmailOTPSubmit({required this.email, required this.code});
  @override
  List<Object> get props => [email, code];
}
class SetNewPassword extends ForgotPasswordEvent {
  final String email;
  final String newPassword;
  SetNewPassword({required this.email, required this.newPassword});
  @override
  List<Object> get props => [email, newPassword];
}

/// STATES
abstract class ForgotPasswordState extends Equatable {
  @override
  List<Object?> get props => [];
}
class ForgotPasswordInitial extends ForgotPasswordState {}
class ForgotPasswordLoading extends ForgotPasswordState {}
class ForgotPasswordResendOtpLoading extends ForgotPasswordState {}
class ForgotPasswordSuccess extends ForgotPasswordState {
  final String message;
  ForgotPasswordSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class ResendOTPSuccess extends ForgotPasswordState {
  final String message;
  ResendOTPSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class ForgotPasswordFailure extends ForgotPasswordState {
  final String message;
  ForgotPasswordFailure(this.message);
  @override
  List<Object?> get props => [message];
}


/// BLOC
class ForgotPasswordBloc extends Bloc<ForgotPasswordEvent, ForgotPasswordState> {
  final ForgotPasswordRepository forgotPasswordRepository;
  ForgotPasswordBloc({required this.forgotPasswordRepository}) : super(ForgotPasswordInitial()) {
    on<EmailSubmitted>((event, emit) async {
      emit(ForgotPasswordLoading());
      final result = await forgotPasswordRepository.resetPassword(
        ForgotPasswordReqModel(
          email: event.email
        ),
      );
      if (result.isSuccess) {
        final response = result.data!;
        emit(ForgotPasswordSuccess(message: response.message));
      } else {
        emit(ForgotPasswordFailure(result.error ?? ErrorMessages.forgotPasswordFailedError));
      }
    });

    on<EmailResendOTP>((event, emit) async {
      emit(ForgotPasswordResendOtpLoading());
      final result = await forgotPasswordRepository.resetPassword(
        ForgotPasswordReqModel(
          email: event.email
        ),
      );
      if (result.isSuccess) {
        final response = result.data!;
        emit(ResendOTPSuccess(message: response.message));
      } else {
        emit(ForgotPasswordFailure(result.error ?? ErrorMessages.forgotPasswordFailedError));
      }
    });

    on<EmailOTPSubmit>((event, emit) async {
      emit(ForgotPasswordLoading());
      final result = await forgotPasswordRepository.validateResetCode(
          ValidateResetCodeReqModel(
            email: event.email,
            code: event.code,
          )
      );
      if (result.isSuccess) {
        final response = result.data!;
        emit(ForgotPasswordSuccess(message: response.message));
      } else {
        emit(ForgotPasswordFailure(result.error!));
      }
    });

    on<SetNewPassword>((event, emit) async {
      emit(ForgotPasswordLoading());
      final result = await forgotPasswordRepository.setNewPassword(
          SetNewPasswordReqModel(
            email: event.email,
            newPassword: event.newPassword,
          )
      );
      if (result.isSuccess) {
        final response = result.data!;
        emit(ForgotPasswordSuccess(message: response.message));
      } else {
        emit(ForgotPasswordFailure(result.error!));
      }
    });
  }

}