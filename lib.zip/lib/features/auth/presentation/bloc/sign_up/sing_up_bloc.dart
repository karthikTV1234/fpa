import 'package:child_health_story/core/errors/failure.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_events.dart';
import 'package:child_health_story/features/auth/presentation/bloc/sign_up/sing_up_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../data/repository/auth_repository.dart';

// Bloc
class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  final AuthRepository authRepository;
  String selectedCountryCode = "+91";
  bool isUIUpdated = false;

  SignUpBloc({required this.authRepository}) : super(RegisterInitial()) {
    on<SelectCountryCodeEvent>((event, emit) {
      selectedCountryCode = event.countryCode;
      isUIUpdated = true;
      emit(CountryCodeSelected(event.countryCode));
    });
    on<RegisterSubmitEvent>((event, emit) async {
      emit(RegisterLoading());
      final result = await authRepository.register(
          event.signUpReqModel
      );
      if (result.isSuccess) {
        final signUpRes = result.data!;
        emit(RegisterSuccess(message: signUpRes.message));
      } else {
        emit(RegisterFailure(result.error ?? ErrorMessages.registrationFailedError));
      }
    });
  }
}