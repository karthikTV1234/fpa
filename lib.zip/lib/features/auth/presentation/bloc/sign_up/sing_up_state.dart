import 'package:equatable/equatable.dart';


// States
abstract class SignUpState extends Equatable {
  @override
  List<Object?> get props => [];
}
class RegisterInitial extends SignUpState {}
class RegisterLoading extends SignUpState {}
class RegisterSuccess extends SignUpState {
  final String message;
  RegisterSuccess({required this.message});
  @override
  List<Object> get props => [message];
}
class RegisterFailure extends SignUpState {
  final String error;
  RegisterFailure(this.error);
  @override
  List<Object?> get props => [error];
}
class CountryCodeSelected extends SignUpState {
  final String countryCode;
  CountryCodeSelected(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}