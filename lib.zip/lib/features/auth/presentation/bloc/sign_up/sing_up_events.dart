import 'package:child_health_story/core/errors/failure.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../data/model/sing_up_model.dart';
import '../../../data/repository/auth_repository.dart';

// Events
abstract class SignUpEvent extends Equatable {
  @override
  List<Object?> get props => [];
}
class RegisterSubmitEvent extends SignUpEvent with EquatableMixin {
  final SignUpReqModel signUpReqModel;
  RegisterSubmitEvent({
    required this.signUpReqModel
  });
  @override
  List<Object?> get props => [signUpReqModel];
}
class SelectCountryCodeEvent extends SignUpEvent {
  final String countryCode;
  SelectCountryCodeEvent(this.countryCode);
  @override
  List<Object?> get props => [countryCode];
}