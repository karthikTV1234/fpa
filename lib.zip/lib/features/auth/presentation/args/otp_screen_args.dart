class OtpScreenArgs {
  final String verificationId;
  final bool isFromForgotPassword;
  final String phoneNumber;
  final String countryCode;
  final String email;

  OtpScreenArgs({
    this.verificationId = '',
    this.isFromForgotPassword = false,
     this.phoneNumber = '',
     this.countryCode = '+91',
     this.email = '',
  });
}
