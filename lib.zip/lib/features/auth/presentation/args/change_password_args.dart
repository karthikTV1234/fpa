class ChangePasswordScreenArgs {
  final bool isFromForgotPassword;
  final String email;

  ChangePasswordScreenArgs({
    this.isFromForgotPassword = false,
    this.email = '',
  });
}
