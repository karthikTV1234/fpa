class ValidateResetCodeReqModel {
  final String email;
  final String code;

  ValidateResetCodeReqModel({
    required this.email,
    required this.code,
  });

  factory ValidateResetCodeReqModel.fromJson(Map<String, dynamic> json) {
    return ValidateResetCodeReqModel(
      email: json['email'] as String,
      code: json['code'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'email': email,
      'code': code,
    };
  }
}
