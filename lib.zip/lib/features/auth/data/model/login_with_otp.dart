class LoginWithOtpReqModel {
  final String idToken;

  LoginWithOtpReqModel({required this.idToken});

  Map<String, dynamic> toJson() => {
    'idToken': idToken,
  };
}

class LoginWithOTPResModel {
  final String accessToken;
  final int statusCode;
  final String message;
  final String firstName;
  final String lastName;

  LoginWithOTPResModel({
    required this.accessToken,
    required this.statusCode,
    required this.message,
    required this.firstName,
    required this.lastName,
  });

  factory LoginWithOTPResModel.fromJson(Map<String, dynamic> json) {
    return LoginWithOTPResModel(
      accessToken: json['accessToken'] as String,
      statusCode: json['statusCode'] as int,
      message: json['message'] as String,
      firstName: json['firstName'] as String,
      lastName: json['lastName'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'accessToken': accessToken,
      'statusCode': statusCode,
      'message': message,
      'firstName': firstName,
      'lastName': lastName,
    };
  }
}

