class SignUpReqModel {
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final String password;
  final String deviceId;
  final String countryCode;

  SignUpReqModel({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phone,
    required this.password,
    required this.deviceId,
    required this.countryCode,
  });

  // Method to convert the UserModel object to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'first_name': firstName,
      'last_name': lastName,
      'email': email,
      'phone': phone,
      'password': password,
      'device_id': deviceId,
      'countryCode': countryCode,
    };
  }
}

class SignUpResModel {
  final String message;
  final String id;
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final String token;

  SignUpResModel({
    required this.message,
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phone,
    required this.token,
  });

  factory SignUpResModel.fromJson(Map<String, dynamic> json) {
    return SignUpResModel(
      message: json['message'] ?? '',
      id: json['id'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      token: json['token'] ?? '',
    );
  }
}
