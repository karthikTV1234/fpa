class ForgotPasswordReqModel {
  final String email;

  ForgotPasswordReqModel({required this.email});

  factory ForgotPasswordReqModel.fromJson(Map<String, dynamic> json) {
    return ForgotPasswordReqModel(
      email: json['email'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'email': email,
    };
  }
}