import 'dart:async';
import 'package:child_health_story/core/errors/failure.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../../core/utils/result.dart';

class FirebaseAuthRepository {
  final FirebaseAuth _firebaseAuth;

  FirebaseAuthRepository({FirebaseAuth? firebaseAuth})
      : _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance;

  Future<Result<String>> requestOtp({
    required String phoneNumber,
  }) async {
    final String formattedNumber = phoneNumber.trim();

    try {
      final completer = Completer<Result<String>>();

      await _firebaseAuth.verifyPhoneNumber(
        phoneNumber: formattedNumber,
        verificationCompleted: (_) {
          // Optionally handle auto verification
        },
        verificationFailed: (FirebaseAuthException e) {
          if (!completer.isCompleted) {
            if (e.code == ErrorMessages.invalidPhoneNumberCode) {
              completer.complete(Result.failure(ErrorMessages.invalidPhoneNumber));
            } else if (e.code == ErrorMessages.tooManyAttemptsCode) {
              completer.complete(Result.failure(ErrorMessages.tooManyAttempts));
            } else {
              completer.complete(Result.failure(ErrorMessages.otpVerificationFailed));
            }
          }
        },
        codeSent: (String verificationId, int? resendToken) {
          if (!completer.isCompleted) {
            completer.complete(Result.success(verificationId));
          }
        },
        codeAutoRetrievalTimeout: (_) {
          // Optionally handle timeout if needed
        },
      );
      return completer.future;
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<String>> submitOtp({
    required String otp,
    required String verificationId,
  }) async {
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: otp.trim(),
      );

      await _firebaseAuth.signInWithCredential(credential);
      String? idToken = await _firebaseAuth.currentUser!.getIdToken();
      if (idToken == null) {
        return Result.failure(ErrorMessages.somethingWentWrongError);
      }
      return Result.success(idToken);
    } on FirebaseAuthException catch (e) {
      return Result.failure(e.message ?? ErrorMessages.otpVerificationFailed);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }
}
