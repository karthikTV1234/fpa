import 'dart:async';
import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/network/api_client.dart';
import 'package:child_health_story/features/auth/data/model/reset_password_model.dart';
import 'package:child_health_story/features/auth/data/model/validate_reset_code_model.dart';
import 'package:child_health_story/shared/model/common_response_model.dart';
import 'package:dio/dio.dart';
import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../model/forgot_password_model.dart';

class ForgotPasswordRepository {
  final Dio _dio;
  
  ForgotPasswordRepository({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  Future<Result<CommonResModel>> resetPassword(
      ForgotPasswordReqModel forgotPasswordReqModel) async {
    String errorMessage = ErrorMessages.somethingWentWrongError;
    try {
      final response = await _dio.post(
        '${ApiConstants.authBaseUrl}${ApiConstants.forgotPassword}',
        data: forgotPasswordReqModel.toJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final forgotPasswordResModel =
        CommonResModel.fromJson(response.data);
        return Result.success(forgotPasswordResModel);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> validateResetCode(
      ValidateResetCodeReqModel validateResetCodeReqModel) async {
    String errorMessage = ErrorMessages.somethingWentWrongError;
    try {
      final response = await _dio.post(
        '${ApiConstants.authBaseUrl}${ApiConstants.validateResetCode}',
        data: validateResetCodeReqModel.toJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final commonResModel =
        CommonResModel.fromJson(response.data);
        return Result.success(commonResModel);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }

  Future<Result<CommonResModel>> setNewPassword(
      SetNewPasswordReqModel resetPasswordReqModel) async {
    String errorMessage = ErrorMessages.somethingWentWrongError;
    try {
      final response = await _dio.post(
        '${ApiConstants.authBaseUrl}${ApiConstants.setNewPassword}',
        data: resetPasswordReqModel.toJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final commonResModel =
        CommonResModel.fromJson(response.data);
        return Result.success(commonResModel);
      } else {
        return Result.failure(response.data['message'] ?? errorMessage);
      }
    } on DioException catch (e) {
      if (e.response != null && e.response?.data != null) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        errorMessage = ErrorMessages.connectionTimeOutError;
      }
      return Result.failure(errorMessage);
    } catch (e) {
      return Result.failure(ErrorMessages.somethingWentWrongError);
    }
  }
}