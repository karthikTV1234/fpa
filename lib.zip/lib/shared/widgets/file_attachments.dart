import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/shared/widgets/button_widgets.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:flutter/material.dart';

class FileAttachments extends StatefulWidget {
  final List<String> files;
  final void Function(String filePath)? onFileTap;

  const FileAttachments({
    super.key,
    required this.files,
    this.onFileTap,
  });

  @override
  State<FileAttachments> createState() => _FileAttachmentsState();
}

class _FileAttachmentsState extends State<FileAttachments> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: widget.files.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final filePath = widget.files[index];

        return GestureDetector(
          onTap: () => widget.onFileTap?.call(filePath),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              color: AppColors.vLightGreyColor,
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.copy_rounded,
                  size: 14.0,
                  color: AppColors.cblackColor,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextWidgets.textWidget(
                    filePath.extractedFileName,
                    AppColors.cblackColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    hasOverflow: true,
                    maxLines: 2,
                    textAlign: TextAlign.start,
                  ),
                ),
                const SizedBox(width: 10),
                ButtonWidgets.getIconButton(
                  Icon(
                    Icons.remove_red_eye_outlined,
                    size: 16.0,
                    color: AppColors.lightPrimaryColor,
                  ),
                      () {
                    // Optional: remove this if not needed
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
