import 'dart:io';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/utils/image_picker_helper.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'image_selector_widget.dart';

// ignore: must_be_immutable
class CustomCircleAvatar extends StatelessWidget {
  final bool isEditable;
  final picker = ImagePicker();
  File? imageFile;
  final String? imageUrl;
  final BuildContext mainContext;
  final Function(File, String) callback;
  CustomCircleAvatar({
      super.key,
      required this.isEditable,
      this.imageFile,
      this.imageUrl,
      required this.mainContext,
      required this.callback
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isEditable
          ? () {
        FilePickerHelper.pickFile(
          context: mainContext,
          allowedFileTypes: ['image'],
          onFilePicked: (file, name) {
            callback(file, name);
          },
        );
      }
        : null,
    child: Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 160,
          height: 160,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: AppColors.cmediumGrayColor,
              width: 1,
            ),
          ),
          child: CircleAvatar(
            radius: 80,
            backgroundColor: AppColors.circleBorderColor,
            backgroundImage: imageFile != null
                ? FileImage(imageFile!)
                : (imageUrl != null ? NetworkImage(imageUrl!) : null),
            child: (imageFile == null && imageUrl == null)
                ? Icon(Icons.image, size: 60, color: AppColors.cwhiteColor)
                : null,
          ),
        ),
      ],
    ),
    );
  }

}
