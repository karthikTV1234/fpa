import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:flutter/material.dart';
import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:image_picker/image_picker.dart';
import 'package:child_health_story/core/utils/image_picker_helper.dart';
import 'package:child_health_story/shared/widgets/file_attachments_delete.dart';
import 'file_attachments.dart';

class FileAttachmentsWidget extends StatelessWidget {
  final int maxFileSizeMB;
  final List<String> supportedTypes;

  final List<XFile> selectedNewFiles;
  final List<String>? existingAttachments;
  final void Function(XFile file)? onFileSelected;
  final void Function(XFile file)? onFileDeleted;

  const FileAttachmentsWidget({
    super.key,
    required this.maxFileSizeMB,
    required this.supportedTypes,
     this.existingAttachments,
    required this.selectedNewFiles,
    this.onFileSelected,
    this.onFileDeleted,
  });

  void _pickFile(BuildContext context) {
    FilePickerHelper.pickFile(
      context: context,
      allowedFileTypes: supportedTypes,
      onFilePicked: (file, name) async {
        final fileSizeInMB = await file.length() / (1024 * 1024);

        if (fileSizeInMB > maxFileSizeMB) {
          CustomSnackBar(
            context: context,
            message: AppStrings.fileSizeExceededMessage(maxFileSizeMB),
            messageType: AppStrings.failure,
          ).show();
          return;
        }

        final xfile = XFile(file.path);
        onFileSelected?.call(xfile);
      },
    );
  }

  void _removeNewFile(int index) {
    if (index < selectedNewFiles.length) {
      final file = selectedNewFiles[index];
      onFileDeleted?.call(file);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(2),
      color: AppColors.cwhiteColor,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextWidgets.textWidget(
                AppStrings.attachments,
                AppColors.cblackColor,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Center(
              child: Card(
                color: AppColors.appBackGroundColor,
                elevation: 0,
                margin: const EdgeInsets.symmetric(horizontal: 16.0),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => _pickFile(context),
                  child: SizedBox(
                    width: double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(top: 16.0),
                          child: Icon(Icons.upload_file, size: 40, color: AppColors.cblackColor),
                        ),
                        TextWidgets.textWidget(
                          AppStrings.uploadAFile,
                          AppColors.cblackColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 16.0),
                          child: TextWidgets.textWidget(
                            AppStrings.fileSizeLimit(maxFileSizeMB),
                            AppColors.cblackColor,
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            if (existingAttachments?.isNotEmpty ?? false)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: FileAttachments(files: existingAttachments!),
              ),
            if (selectedNewFiles.isNotEmpty)
              FileAttachmentsDelete(
                files: selectedNewFiles.map((file) => file.name).toList(),
                onDelete: (index) => _removeNewFile(index),
              ),
          ],
        ),
      ),
    );
  }
}
