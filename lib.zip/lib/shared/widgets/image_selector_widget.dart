import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import '../../core/constants/color/app_colors.dart';
import '../../core/constants/strings/app_strings.dart';

class FileSelectorWidget extends StatelessWidget {
  final bool allowCamera;
  final bool allowGallery;
  final bool allowFile;
  final VoidCallback onCameraSelected;
  final VoidCallback onGallerySelected;
  final VoidCallback onFileSelected;

  const FileSelectorWidget({
    super.key,
    required this.allowCamera,
    required this.allowGallery,
    required this.allowFile,
    required this.onCameraSelected,
    required this.onGallerySelected,
    required this.onFileSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
      child: Row(
        children: [
          if (allowCamera)
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: onCameraSelected,
                    icon: const Icon(Icons.camera_alt),
                  ),
                  TextWidgets.textWidget(
                    AppStrings.cameraText,
                    AppColors.cblackColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
            ),
          if (allowGallery)
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: onGallerySelected,
                    icon: const Icon(Icons.photo_library),
                  ),
                  TextWidgets.textWidget(
                    AppStrings.galleryText,
                    AppColors.cblackColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
            ),
          if (allowFile)
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: onFileSelected,
                    icon: const Icon(Icons.insert_drive_file),
                  ),
                  TextWidgets.textWidget(
                    AppStrings.pdfText,
                    AppColors.cblackColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

