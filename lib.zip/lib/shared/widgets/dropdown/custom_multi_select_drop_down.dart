import 'package:flutter/material.dart';
import '../../../core/constants/color/app_colors.dart';
import '../../../core/constants/strings/app_strings.dart';
import '../button_widgets.dart';
import '../text_input_widgets.dart';
import '../text_widgets.dart';

class CustomMultiSelectDropDown<T> extends StatefulWidget {
  final TextEditingController controller;
  final List<T> items;
  final String Function(T) displayValue;
  final String labelText;
  final String hintText;
  final String headTitle;
  final void Function(List<T>)? onSave;
  final String? Function(String?)? validator;

  const CustomMultiSelectDropDown({
    super.key,
    required this.controller,
    required this.items,
    required this.displayValue,
    required this.labelText,
    required this.hintText,
    required this.headTitle,
    this.onSave,
    this.validator,
  });

  @override
  State<CustomMultiSelectDropDown<T>> createState() =>
      _MultiSelectionDropdownOverlayState<T>();
}

class _MultiSelectionDropdownOverlayState<T>
    extends State<CustomMultiSelectDropDown<T>> {
  final LayerLink _layerLink = LayerLink();
  final Set<T> _selectedItems = {};
  OverlayEntry? _overlayEntry;

  void _toggleDropdown() {
    if (_overlayEntry == null) {
      _showOverlay();
    } else {
      _removeOverlay();
    }
  }

  void _showOverlay() {
    final overlay = Overlay.of(context);
    final renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;

    _overlayEntry = OverlayEntry(
      builder: (context) => Stack(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: _removeOverlay,
            child: Container(color: Colors.transparent),
          ),
          Positioned(
            width: size.width,
            child: CompositedTransformFollower(
              link: _layerLink,
              showWhenUnlinked: false,
              offset: Offset(0.0, size.height + 8.0),
              child: Material(
                elevation: 4,
                borderRadius: BorderRadius.circular(8),
                child: StatefulBuilder(
                  builder: (context, setOverlayState) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: TextWidgets.textWidget(
                              widget.headTitle,
                              AppColors.cblackColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxHeight: 260),
                          child: ListView.builder(
                            shrinkWrap: true,
                            padding: EdgeInsets.zero,
                            itemCount: widget.items.length,
                            itemBuilder: (context, index) {
                              final item = widget.items[index];
                              final isSelected = _selectedItems.contains(item);

                              return CheckboxListTile(
                                value: isSelected,
                                onChanged: (checked) {
                                  setOverlayState(() {
                                    if (checked == true) {
                                      _selectedItems.add(item);
                                    } else {
                                      _selectedItems.remove(item);
                                    }
                                  });
                                },
                                title: TextWidgets.textWidget(
                                  widget.displayValue(item),
                                  AppColors.cblackColor,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  textAlign: TextAlign.left,
                                ),
                              );
                            },
                          ),
                        ),
                        Row(
                          spacing: 10,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0, bottom: 12.0), // Add left margin here
                                child: ButtonWidgets.elevatedButton(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  height: 50,
                                  radius: 7,
                                  width: 80,
                                  AppStrings.cancelBtnText,
                                  AppColors.vvLightGreyColor,
                                  AppColors.cwhiteColor,
                                      () {
                                    _removeOverlay();
                                  },
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(right: 12.0, bottom: 12.0), // Add right margin here
                                child: ButtonWidgets.elevatedButton(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  height: 50,
                                  radius: 7,
                                  width: 80,
                                  AppStrings.saveText,
                                  AppColors.cprimaryColor,
                                  AppColors.cwhiteColor,
                                      () {
                                    final selected = _selectedItems.map(widget.displayValue).join(', ');
                                    widget.controller.text = selected;
                                    widget.onSave?.call(_selectedItems.toList());
                                    _removeOverlay();
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),

                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );

    overlay.insert(_overlayEntry!);
  }

  void _removeOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  @override
  void dispose() {
    _removeOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: GestureDetector(
        onTap: _toggleDropdown,
        child: AbsorbPointer(
          child: TextInputWidgets.textFormField(
              fillColor: AppColors.appBackGroundColor,
              widget.labelText,
              TextInputType.text,
              TextInputAction.next,
              hintText: widget.hintText,
              widget.controller,
              enabledBorderColor: AppColors.cmediumGrayColor,
              focusedBorderColor: AppColors.cmediumGrayColor,
              false,
              maxLines: 2,
              readOnly: true,
              trailingIcon: const Icon(Icons.arrow_drop_down),
              validator: widget.validator,
          ),
        ),
      ),
    );
  }
}
