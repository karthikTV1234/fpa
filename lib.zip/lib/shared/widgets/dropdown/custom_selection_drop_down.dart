import 'package:flutter/material.dart';
import '../../../../core/constants/color/app_colors.dart';
import '../button_widgets.dart';
import '../text_input_widgets.dart';
import '../text_widgets.dart';

class CustomSingleSelectionDropdown<T> extends StatefulWidget {
  final TextEditingController controller;
  final List<T> items;
  final String Function(T) displayValue;
  final String labelText;
  final String hintText;
  final String headTitle;
  final String emptyStateText;
  final String addButtonText;
  final VoidCallback? onAddPressed;
  final void Function(T selectedItem)? onSelected;
  final String? Function(String?)? validator;
  final bool enabled;

  const CustomSingleSelectionDropdown({
    super.key,
    required this.controller,
    required this.items,
    required this.displayValue,
    required this.labelText,
    required this.hintText,
    required this.headTitle,
    required this.emptyStateText,
    required this.addButtonText,
    this.onSelected,
    this.onAddPressed,
    this.validator,
    this.enabled = true,
  });

  @override
  State<CustomSingleSelectionDropdown<T>> createState() => _SingleSelectionDropdownOverlayState<T>();
}

class _SingleSelectionDropdownOverlayState<T> extends State<CustomSingleSelectionDropdown<T>> {
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  void _toggleOverlay() {
    if (_overlayEntry == null) {
      _showOverlay();
    } else {
      _removeOverlay();
    }
  }

  void _removeOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  void _showOverlay() {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final Size size = renderBox.size;
    final bool isEmpty = widget.items.isEmpty;

    final double fixedHeight = MediaQuery.of(context).size.height * 0.4;

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned.fill(
        child: Stack(
          children: [
            GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: _removeOverlay,
            ),
            CompositedTransformFollower(
              link: _layerLink,
              showWhenUnlinked: false,
              offset: Offset(0.0, size.height + 6.0),
              child: Material(
                elevation: 4,
                color: AppColors.appBackGroundColor,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: size.width,
                  height: fixedHeight,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                        child: TextWidgets.textWidget(
                          widget.headTitle,
                          AppColors.cblackColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          textAlign: TextAlign.left,
                        ),
                      ),
                      const Divider(height: 1),
                      Expanded(
                        child: isEmpty
                            ? Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: TextWidgets.textWidget(
                              widget.emptyStateText,
                              AppColors.cblackColor,
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              textAlign: TextAlign.center,
                            ),
                          ),
                        )
                            : ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          itemCount: widget.items.length,
                          itemBuilder: (context, index) {
                            final item = widget.items[index];
                            return ListTile(
                              title: TextWidgets.textWidget(
                                widget.displayValue(item),
                                AppColors.cblackColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                textAlign: TextAlign.left,
                              ),
                              onTap: () {
                                widget.controller.text = widget.displayValue(item);
                                widget.onSelected?.call(item);
                                _removeOverlay();
                              },
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        child: ButtonWidgets.addNewOutlinedButton(
                          addNewPlusCircle: ButtonWidgets.addNewPlusCircle(
                            Icons.add,
                            AppColors.cprimaryColor,
                          ),
                          text: widget.addButtonText,
                          iconColor: AppColors.cprimaryColor,
                          onPressed: () {
                            _removeOverlay();
                            widget.onAddPressed?.call();
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }


  @override
  void dispose() {
    _removeOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: GestureDetector(
        onTap: widget.enabled ? _toggleOverlay : null,
        child: AbsorbPointer(
          child: TextInputWidgets.textFormField(
            fillColor: AppColors.appBackGroundColor,
            widget.labelText,
            hintText: widget.hintText,
            TextInputType.text,
            TextInputAction.next,
            widget.controller,
            enabledBorderColor: AppColors.cmediumGrayColor,
            focusedBorderColor: AppColors.cmediumGrayColor,
            false,
            trailingIcon: const Icon(Icons.arrow_drop_down),
            readOnly: true,
            validator: widget.validator,
            enabled: widget.enabled,
          ),
        ),
      ),
    );
  }
}
