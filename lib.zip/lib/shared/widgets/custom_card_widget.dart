import 'package:child_health_story/shared/widgets/text_widgets.dart';
import 'package:flutter/material.dart';
import '../../core/constants/color/app_colors.dart';

class CustomCardView extends StatelessWidget {
  final String id;
  final Color cardColor;
  final EdgeInsetsGeometry margin;
  final double borderRadius;
  final String title;
  final String? badge;
  final Color? badgeColor;
  final String title2;
  final String subtitle1;
  final String subtitle2;
  final bool isPrimary;
  final void Function(String id, bool isPrimary)? onTapRadioButton;
  final void Function(String id)? onTap;

  const CustomCardView({
    super.key,
    required this.id,
    required this.cardColor,
    required this.margin,
    required this.borderRadius,
    required this.title,
    this.badge,
    this.badgeColor,
    required this.title2,
    required this.subtitle1,
    required this.subtitle2,
    this.isPrimary = false,
    this.onTapRadioButton,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!(id);
        }
      },
      child: Card(
        color: cardColor,
        margin: margin,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            spacing: 3,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  TextWidgets.textWidget(
                    title,
                    AppColors.cblackColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                  ),
                  if (badge!.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(left: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: badgeColor ?? Colors.blue,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: TextWidgets.textWidget(
                        badge!,
                        AppColors.cwhiteColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () {
                      if (onTapRadioButton != null) {
                        onTapRadioButton!(id, isPrimary);
                      }
                    },
                    child: Icon(
                      isPrimary
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      size: 20,
                      color: isPrimary ? Colors.blue : Colors.grey,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: TextWidgets.textWidget(
                      textAlign: TextAlign.left,
                      title2,
                      AppColors.cblackColor,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios, size: 14),
                ],
              ),
              TextWidgets.textWidget(
                subtitle1,
                AppColors.cblackColor,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
              subtitle2.isNotEmpty
                  ? TextWidgets.textWidget(
                subtitle2,
                AppColors.cblackColor,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              )
                  : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }
}
