class CommonResModel {
  final int statusCode;
  final String message;

  CommonResModel({
    required this.statusCode,
    required this.message,
  });

  factory CommonResModel.fromJson(Map<String, dynamic> json) {
    return CommonResModel(
      statusCode: json['statusCode'] as int,
      message: json['message'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'statusCode': statusCode,
      'message': message,
    };
  }
}
