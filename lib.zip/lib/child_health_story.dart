import 'package:flutter/material.dart';

import 'config/router/app_router.dart';
import 'core/constants/path_constants.dart';
import 'core/constants/strings/app_strings.dart';

class ChildHealthStory extends StatelessWidget {
  const ChildHealthStory({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppStrings.appName,
      initialRoute: PathConstants.initScreen,
      onGenerateRoute: AppRouter.generateRoute,
    );
  }
}
