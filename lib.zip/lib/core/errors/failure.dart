class ErrorMessages {
  static const String userNotFound = 'User not found.';
  static const String networkError = 'Please check your internet connection.';
  static const String somethingWentWrongError = 'Something went wrong. Please try again.';
  static const String connectionTimeOutError = 'Connection timeout. Please check your internet and try again';
  static const String tooManyAttempts = 'Too many attempts. Please try again later.';
  static const String invalidPhoneNumberCode = 'invalid-phone-number';
  static const String tooManyAttemptsCode = 'too-many-requests';

  //Auth Errors
  static const String registrationFailedError = 'Registration failed. Please try again.';
  static const String loginFailedError = 'Login failed. Please try again.';
  static const String invalidPhoneNumber = 'Invalid phone number. Please check and try again.';
  static const String otpVerificationFailed = 'OTP verification failed. Please try again.';
  static const String forgotPasswordFailedError = 'Failed to send reset code. Please try again';

  //Child
  static const String addChildFailedError = "Unable to add child. Please try again.";
  static const String fetchChildFailedError = "Unable to fetch child details. Please try again.";
  static const String fetchChildListFailedError = "Unable to fetch child list. Please try again.";
  static const String updateChildFailedError = "Unable to update child. Please try again.";
  static const String deleteChildFailedError = "Unable to delete child. Please try again.";

  //Hospital
  static const String addHospitalFailedError = "Unable to add hospital. Please try again.";
  static const String fetchHospitalListFailedError = "Unable to fetch hospital list. Please try again.";

  //Doctor
  static const String addDoctorFailedError = "Unable to add doctor. Please try again.";
  static const String fetchDoctorListFailedError = "Unable to fetch doctor list. Please try again.";
  static const String fetchDoctorSpecialityListFailedError = "Unable to fetch doctor speciality list. Please try again.";


  //Medications
  static const String addMedicationFailedError = 'Failed to add medication. Please try again.';
  static const String fetchMedicationListFailedError = 'Failed to fetch medication list.';
  static const String fetchMedicationDetailsFailedError = 'Failed to fetch medication details.';
  static const String updateMedicationFailedError = 'Failed to update medication details.';
  static const String deleteMedicationFailedError = 'Failed to delete medication.';
  static const String fetchFrequencyListFailedError = 'Failed to fetch frequency list.';


  //Vaccinations
  static const String addVaccinationFailedError = "Failed to add vaccination. Please try again.";
  static const String fetchVaccinationListFailedError = "Failed to fetch vaccinations. Please try again.";
  static const String fetchVaccinationDetailsFailedError = "Failed to load vaccination details. Please try again.";
  static const String updateVaccinationFailedError = "Failed to update vaccination. Please try again.";
  static const String deleteVaccinationFailedError = "Failed to delete vaccination. Please try again.";

  //Health Tracker
  static const String addHealthRecordFailedError = "Failed to add health record. Please try again.";
  static const String fetchHealthRecordListFailedError = "Failed to fetch health records. Please try again.";
  static const String fetchHealthRecordDetailsFailedError = "Failed to load health record details. Please try again.";
  static const String updateHealthRecordFailedError = "Failed to update health record. Please try again.";
  static const String deleteHealthRecordFailedError = "Failed to delete health record. Please try again.";


  // Medical Condition
  static const String addMedicalConditionFailedError = "Failed to add medical condition. Please try again.";
  static const String fetchMedicalConditionListFailedError = "Failed to fetch medical conditions. Please try again.";
  static const String fetchMedicalConditionStatusListFailedError = "Failed to fetch medical conditions status. Please try again.";
  static const String fetchMedicalConditionDetailsFailedError = "Failed to load medical condition details. Please try again.";
  static const String updateMedicalConditionFailedError = "Failed to update medical condition. Please try again.";
  static const String deleteMedicalConditionFailedError = "Failed to delete medical condition. Please try again.";





}
