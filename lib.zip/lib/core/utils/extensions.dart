import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import '../../shared/widgets/image_selector_widget.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/features/child_profile/presentation/bloc/child_bloc.dart';
import 'package:child_health_story/features/child_profile/presentation/widgets/child_list_bottom_sheet.dart';

extension SafeString on dynamic {
  String toSafeString() {
    if (this == null) return '';
    if (this is double || this is int) return this.toString();
    if (this is String) return this;
    return '';
  }
}

extension DateFormatExtension on String {
  String formatAsDateTime({String pattern = 'dd MMM yyyy, hh:mm a'}) {
    try {
      final dateTime = DateTime.parse(this).toLocal();
      return DateFormat(pattern).format(dateTime);
    } catch (_) {
      return this;
    }
  }
}

extension FilePathUtils on String {
  String get extractedFileName {
    final fullFileName = p.basename(this);
    final firstDotIndex = fullFileName.indexOf('.');
    if (firstDotIndex != -1 && firstDotIndex < fullFileName.length - 1) {
      return fullFileName.substring(firstDotIndex + 1);
    }
    return fullFileName;
  }
}

// Extension to show the file selector bottom sheet
extension FileSelectorExtension on BuildContext {
  Future<void> showFileSelector({
    required bool allowCamera,
    required bool allowGallery,
    required bool allowFile,
    required VoidCallback onCameraSelected,
    required VoidCallback onGallerySelected,
    required VoidCallback onFileSelected,
  }) async {
    await showModalBottomSheet(
      context: this,
      builder: (context) => FileSelectorWidget(
        allowCamera: allowCamera,
        allowGallery: allowGallery,
        allowFile: allowFile,
        onCameraSelected: onCameraSelected,
        onGallerySelected: onGallerySelected,
        onFileSelected: onFileSelected,
      ),
    );
  }
}

extension ChildListBottomSheetExtension on BuildContext {
  Future<bool?> showChildListBottomSheet() {
    final childBloc = read<ChildBloc>();

    return showModalBottomSheet<bool>(
      context: this,
      isScrollControlled: true,
      backgroundColor: AppColors.appBackGroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => BlocProvider.value(
        value: childBloc,
        child: const SizedBox(
          height: 600,
          child: ChildListBottomSheet(),
        ),
      ),
    );
  }
}

enum EntityAction { add, update, delete, fetch, fetchDetails }