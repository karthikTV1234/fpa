import 'package:child_health_story/core/constants/storage_keys.dart';
import 'package:child_health_story/core/utils/app_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesHelper {
  static final SharedPreferencesHelper instance = SharedPreferencesHelper._internal();
  static SharedPreferences? _prefs;

  SharedPreferencesHelper._internal();

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  String? get token => _prefs?.getString(PreferenceKeys.authToken);
  Future<void> saveToken(String value) async {
    await _prefs?.setString(PreferenceKeys.authToken, value);
  }

  String? get firstName => _prefs?.getString(PreferenceKeys.firstName);
  Future<void> saveFirstName(String value) async {
    await _prefs?.setString(PreferenceKeys.firstName, value);
  }

  String? get lastName => _prefs?.getString(PreferenceKeys.lastName);
  Future<void> saveLastName(String value) async {
    await _prefs?.setString(PreferenceKeys.lastName, value);
  }

  int get childListSize => _prefs?.getInt(PreferenceKeys.childListSize) ?? 0;
  Future<void> setChildListSize(int value) async {
    await _prefs?.setInt(PreferenceKeys.childListSize, value);
  }



  Future<void> saveSelectedChildDetails({
    required String id,
    required String name,
    required String age,
    required String? profilePhoto,
    required String? coverPhoto,
  }) async {
    await _prefs?.setString(PreferenceKeys.selectedChildId, id);
    await _prefs?.setString(PreferenceKeys.selectedChildName, name);
    await _prefs?.setString(PreferenceKeys.selectedChildAge, age);
    final profileUrl = AppUtils.buildImageFullUrl(profilePhoto) ?? '';
    final coverUrl = AppUtils.buildImageFullUrl(coverPhoto) ?? '';
    await _prefs?.setString(PreferenceKeys.selectedChildProfilePhoto, profileUrl);
    await _prefs?.setString(PreferenceKeys.selectedChildCoverPhoto, coverUrl);
  }

  String getSelectedChildId() {
    return _prefs?.getString(PreferenceKeys.selectedChildId) ?? '';
  }
  String getSelectedChildName() {
    return _prefs?.getString(PreferenceKeys.selectedChildName) ?? '';
  }
  String getSelectedChildAge() {
    return _prefs?.getString(PreferenceKeys.selectedChildAge) ?? '';
  }
  String getSelectedChildProfilePhoto() {
    return _prefs?.getString(PreferenceKeys.selectedChildProfilePhoto) ?? '';
  }
  String getSelectedChildCoverPhoto() {
    return _prefs?.getString(PreferenceKeys.selectedChildCoverPhoto) ?? '';
  }

  Future<void> removeKey(String key) async {
    await _prefs?.remove(key);
  }


  Future<void> removeKeys(List<String> keys) async {
    for (final key in keys) {
      await _prefs?.remove(key);
    }
  }


  Future<void> clear() async {
    await _prefs?.clear();
  }

}
