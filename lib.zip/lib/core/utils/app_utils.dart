import 'package:child_health_story/core/constants/api_constants.dart';
import 'package:child_health_story/core/constants/color/app_colors.dart';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';

class AppUtils {
  static getScreenWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  static getScreenHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }

  static Color getSnackBarColor(messageType) {
    var selectedColor = AppColors.cSkyBlueColor;
    switch (messageType) {
      case AppStrings.warning:
        return selectedColor = AppColors.cLightOrangeColor;
      case AppStrings.success:
        return selectedColor = AppColors.cgreenColor;
      case AppStrings.failure:
        return selectedColor = AppColors.cRedColor;
    }
    return selectedColor;
  }

  static String formatDateTime(DateTime dateTime) {
    return DateFormat('yyyy-MM-dd HH:mm').format(dateTime);
  }
  static String formatDateFromDatePicker(DateTime dateTime) {
    return DateFormat('yyyy-MM-dd').format(dateTime);
  }

  static String formatDateTimeStringForBackend(String dateString) {
    final dateTime = DateFormat('yyyy-MM-dd HH:mm').parse(dateString);
    return dateTime.toUtc().toIso8601String();
  }

  static String formatBackendDateTimeForUI(String backendDateTime) {
    final dateTime = DateTime.parse(backendDateTime).toLocal();
    return DateFormat('yyyy-MM-dd HH:mm').format(dateTime);
  }

  static String formatBackendDateTimeReadable(String backendDateTime) {
    if (backendDateTime.trim().isEmpty) {
      return '';
    }
    try {
      final dateTime = DateTime.parse(backendDateTime).toLocal();
      return DateFormat('d MMMM, h:mm a').format(dateTime);
    } catch (_) {
      return '';
    }
  }

  static String formatDateOnly(String backendDate) {
    if (backendDate.trim().isEmpty) {
      return '';
    }
    try {
      final date = DateTime.parse(backendDate).toLocal();
      return DateFormat('d MMMM yyyy').format(date);
    } catch (_) {
      return '';
    }
  }

  static String? buildImageFullUrl(String? path) {
    if (path != null && path.isNotEmpty) {
      final uri = Uri.parse(ApiConstants.commonUrl).replace(
        path: ApiConstants.fileUpload,
        queryParameters: {'path': path},
      );
      return uri.toString();
    }
    return null;
  }

}
