import 'dart:io';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:child_health_story/core/utils/extensions.dart';
import 'package:child_health_story/shared/widgets/custom_snack_bar.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

class FilePickerHelper {
  static final ImagePicker _picker = ImagePicker();

  static Future<void> pickFile({
    required BuildContext context,
    required Function(File file, String name) onFilePicked,
    required List<String> allowedFileTypes,
  }) async {
    final allowImage = allowedFileTypes.contains('image');
    final allowDoc = allowedFileTypes.any((type) => AppStrings.documentTypes.contains(type));
    context.showFileSelector(
      allowCamera: allowImage,
      allowGallery: allowImage,
      allowFile: allowDoc,
      onCameraSelected: () async {
        XFile? selectedImage = await _picker.pickImage(source: ImageSource.camera);
        if (selectedImage != null) {
          final ext = selectedImage.name.split('.').last.toLowerCase();
          if (!AppStrings.imageSupportTypes.contains(ext)) {
            if (!context.mounted) return;
            CustomSnackBar(
              context: context,
              message: AppStrings.allowedImageTypesMessage,
              messageType: AppStrings.failure,
            ).show();
            return;
          }
          if (context.mounted) Navigator.pop(context);
          onFilePicked(File(selectedImage.path), selectedImage.name);
        }
      },
      onGallerySelected: () async {
        XFile? selectedImage = await _picker.pickImage(source: ImageSource.gallery);
        if (selectedImage != null) {
          final ext = selectedImage.name.split('.').last.toLowerCase();
          if (!AppStrings.imageSupportTypes.contains(ext)) {
            if (!context.mounted) return;
            CustomSnackBar(
              context: context,
              message: AppStrings.allowedImageTypesMessage,
              messageType: AppStrings.failure,
            ).show();
            return;
          }
          if (context.mounted) Navigator.pop(context);
          onFilePicked(File(selectedImage.path), selectedImage.name);
        }
      },
      onFileSelected: () async {
        FilePickerResult? result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: AppStrings.supportedFileTypes
        );
        if (result != null && result.files.single.path != null) {
          final ext = result.files.single.extension?.toLowerCase();
          if (ext == null || !AppStrings.supportedFileTypes.contains(ext)) {
            if (!context.mounted) return;
            CustomSnackBar(
              context: context,
              message: AppStrings.allowedFileTypesMessage,
              messageType: AppStrings.failure,
            ).show();
            return;
          }
          if (context.mounted) Navigator.pop(context);
          final file = File(result.files.single.path!);
          onFilePicked(file, result.files.single.name);
        }
      },
    );
  }
}
