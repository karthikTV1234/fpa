import 'dart:io';
import 'package:child_health_story/core/constants/strings/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

class FileUtils {
  static bool isImageFile(String path) {
    final extension = p.extension(path).toLowerCase().replaceAll('.', '');
    return AppStrings.imageSupportTypes.contains(extension);
  }

  static Future<void> previewOrDownloadFile(BuildContext context, String filePathOrUrl) async {
    if (isImageFile(filePathOrUrl)) {
      await showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(16),
          child: Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: InteractiveViewer(
                  child: filePathOrUrl.startsWith('http')
                      ? Image.network(filePathOrUrl)
                      : Image.file(File(filePathOrUrl)),
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: CircleAvatar(
                  backgroundColor: Colors.black54,
                  child: IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
  }


}
