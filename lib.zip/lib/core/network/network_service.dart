//To check network availability

class NetworkService {

}
