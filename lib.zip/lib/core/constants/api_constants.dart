class ApiConstants {

  static const String authBaseUrl = 'http://192.168.1.64:3003';
  static const String baseUrl = 'http://192.168.1.64:3004';
  static const String commonUrl = 'http://192.168.1.64:3005';
  static const String featureURL = 'http://192.168.1.64:3006';
  static const String openStreamBaseURL = 'https://nominatim.openstreetmap.org/search';

  // Auth endpoints
  static const String signUp = '/auth/signup';
  static const String login = '/auth/login';
  static const String loginWithOTP = '/auth/login-with-otp';
  static const String forgotPassword = '/auth/forgot-password';
  static const String validateResetCode = '/auth/validate-reset-code';
  static const String setNewPassword = '/auth/set-new-password';

  //Child Profile endpoints
  static const String childProfiles = '/child-profiles';

  //Image urls
  static const String fileUpload = '/file-upload/files';

  //Doctor endpoints
  static const String doctorSpecialityList = '/doctors/specialties';
  static const String addDoctor = '/doctors';
  static const String doctorList = '/doctors/specific_to_user';

  //Hospital endpoints
  static const String hospitalList = '/hospitals/list_specific_to_user';
  static const String addHospital = '/hospitals';

  //Medications endpoints
  static const String medicationsBaseURL = '/api/medications';
  static const String frequencyList = '$medicationsBaseURL/frequency-options';
  static const String medicationsList = '$medicationsBaseURL/child';
  static const String createMedication = '$medicationsBaseURL/create-medication';
  static const String medications = medicationsBaseURL;

  //Vaccination endpoints
  static const String vaccinationBaseURL = '/api/vaccinations';
  static const String createVaccination = '$vaccinationBaseURL/create-vaccination';
  static const String vaccinationList = '$vaccinationBaseURL/list';
  static const String vaccinationDetails = '$vaccinationBaseURL/get';
  static const String updateVaccination = '$vaccinationBaseURL/update-vaccination';
  static const String deleteVaccination = '$vaccinationBaseURL/delete';

  //Health Tracker endpoints
  static const String healthTrackerBaseURL = '/api/health';
  static const String createHealthRecord = '$healthTrackerBaseURL/add';
  static const String healthRecordList = '$healthTrackerBaseURL/list';
  static const String healthRecordDetails = '$healthTrackerBaseURL/get';
  static const String updateHealthRecord = '$healthTrackerBaseURL/update';
  static const String deleteHealthRecord = '$healthTrackerBaseURL';

  //Medical Conditions endpoints
  static const String medicalConditionBaseURL = '/api/medical-conditions';
  static const String createMedicalCondition = '$medicalConditionBaseURL/create-medical-condition';
  static const String medicalConditionList = '$medicalConditionBaseURL/list';
  static const String medicalConditionDetails = '$medicalConditionBaseURL/get-medical-condition';
  static const String updateMedicalCondition = '$medicalConditionBaseURL/update';
  static const String deleteMedicalCondition  = medicalConditionBaseURL;
  static const String medicalConditionStatusList  = '$medicalConditionBaseURL/get-medical-conditions-status-list';

  //Doctor Visit endpoints
  static const String doctorVisitBaseURL = '/api/doctor-visits';
  static const String createDoctorVisit = '$doctorVisitBaseURL/create-doctor-visit';
  static const String doctorVisitList = '$doctorVisitBaseURL/get-doctor-visits-list';
  static const String doctorVisitDetails = '$doctorVisitBaseURL/get-doctor-visit';
  static const String updateDoctorVisit = '$doctorVisitBaseURL/update-doctor-visit';
  static const String deleteDoctorVisit = '$doctorVisitBaseURL/delete';

  //Care Taker endpoints
  static const String careTakerBaseURL = '/api/caretakers';
  static const String createCareTaker = '$careTakerBaseURL/create-caretaker';
  static const String careTakerList = '$careTakerBaseURL/list';
  static const String careTakerRelationshipList = '$careTakerBaseURL/relationship-types';
  static const String careTakerDetails = careTakerBaseURL;
  static const String updateCareTakerRecord = '$careTakerBaseURL/set-primary';
  static const String deleteCareTaker = careTakerBaseURL;
}