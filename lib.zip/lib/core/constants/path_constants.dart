class PathConstants {
  static const String initScreen = '/';
  //Authentication screens
  static const String signUpScreen = '/signup';
  static const String loginScreen = '/login';
  static const String forgotPasswordScreen = '/forgotpassword';
  static const String otpScreen = '/otp';
  static const String loginWithOtp = '/loginwithotp';
  static const String changePasswordScreen = '/changepassword';
  //Child Profile screens
  static const String addChild = '/addchild';
  static const String childListScreen = '/selectchild';
  static const String viewChildProfile = '/viewchildprofile';
  static const String editChildProfile = '/editchildprofile';
  static const String homeScreen = '/home';
  static const String healthRecords = '/healthrecords';
  //CareTaker screens
  static const String careTakersScreen = '/caretakers';
  static const String addCareTakerScreen = '/addcaretaker';
  static const String careTakerDetailsScreen = '/caretakerdetails';
  //Vaccination Tracker screens
  static const String vaccinationListScreen = '/vaccinationlist';
  static const String addVaccinationScreen = '/addvaccination';
  static const String editVaccinationScreen = '/editvaccination';
  static const String vaccinationDetailScreen = '/vaccinationdetail';
  //Medications screens
  static const String medicationListScreen = '/medicationlist';
  static const String addMedicationScreen = '/addmedication';
  static const String medicationDetailScreen = '/medicationdetail';
  static const String editMedicationScreen = '/editmedication';
  //Medical Conditions screens
  static const String medicalConditionsList = '/medicalconditionslist';

  //HealthTracker screens
  static const String healthTrackerListScreen = '/healthtrackerlist';
  static const String addHealthTrackerScreen = '/addhealthtracker';
  static const String healthTrackerDetailScreen = '/healthtrackerdetail';
  static const String editHealthTrackerScreen = '/edithealthtracker';

  //Medical Conditions screens
  static const String medicalConditionsListScreen = '/medicalconditionslist';
  static const String addMedicalConditionScreen = '/addmedicalcondition';
  static const String medicalConditionDetailScreen = '/medicalconditiondetail';
  static const String editMedicalConditionScreen = '/editmedicalcondition';



  //Doctor Visits screens
  static const String doctorVisitListScreen = '/doctorvisitlist';
  static const String doctorVisitFormScreen = '/doctorvisitform';
  static const String doctorVisitDetailScreen = '/doctorvisitdetail';
}
