import 'dart:ui';

class AppColors {
  // Light Theme Colors
  static const Color lightPrimaryColor = Color(0xFF759AF6);
  static const Color lightAccentColor = Color(0xFF03DAC5);
  static const Color lightBackgroundColor = Color(0xFFF5F5F5);
  static const Color lightTextColor = Color(0xFF212121);
  static const Color lightErrorColor = Color(0xFFB00020);
  static Color appBackGroundColor = hexToColors("#F2F2F7");
  static Color cprimaryColor = hexToColors("#759AF6");
  //light Orange Colors
  static Color cLightOrangeColor = hexToColors('#FFD173');
  static Color vLightOrangeColor = hexToColors('#FFE088');
  static Color cOrangeColor = hexToColors('#FFCC80');
  //light Gray Colors
  static Color lightGreyColor = hexToColors("#E0E0E0");
  static Color greyColor = hexToColors("#545454");
  //very light grey
  static Color vLightGreyColor = hexToColors("#F2F2F2");
  static Color vvLightGreyColor = hexToColors("#CFCFCF");

  // Dark Theme Colors
  static const Color darkPrimaryColor = Color(0xFFBB86FC);
  static const Color darkAccentColor = Color(0xFF03DAC5);
  static const Color darkBackgroundColor = Color(0xFF121212);
  static const Color darkTextColor = Color(0xFFE1E1E1);
  static const Color darkErrorColor = Color(0xFFCF6679);

  //Blue Colors
  static Color cSkyBlueColor = hexToColors('#006BFD');
  static Color cBabyBlueColor = hexToColors('#AAE8FE');
  static Color cSteelBlueColor = hexToColors('#28648B');
  static Color cSkipButtonColor = hexToColors("#007BFF");
  static Color cBlueColor = hexToColors("#BBDEFB");
  static Color cRedColor = hexToColors('#FF0000');
  static Color clRedColor = hexToColors('#FFCDD2');
  //Green Colors
  static Color cgreenColor = hexToColors("#00FF00");
  static Color cLightGreenColor = hexToColors("#C8E6C9");
  //White Colors
  static Color cwhiteColor = hexToColors("#FFFFFF");
  //Black Colors
  static Color cblackColor = hexToColors("#000000");
  //Gray Colors
  static Color cmediumGrayColor = hexToColors("#979797");
  static Color yellowColor = hexToColors("#FFF59D");

  //light red color
  static Color lightRedColor = hexToColors("#F67575");
  static Color clightGrayColor = hexToColors("#E2E2E7");
  //red Colors
  static Color clightRedColor = hexToColors("#F67575");
  static Color circleBorderColor = hexToColors("#D8D8D8");
}

Color hexToColors(String s) {
  return Color(int.parse(s.substring(1, 7), radix: 16) + 0xFF000000);
}
