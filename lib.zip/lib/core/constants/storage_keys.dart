//Shared Preferences keys

class PreferenceKeys {
  static const String isLoggedIn = 'is_logged_in';
  static const String authToken = 'auth_token';
  static const String firstName = 'first_name';
  static const String lastName = 'last_name';
  static const String userId = 'user_id';
  static const String themeMode = 'theme_mode';
  //Child
  static const String selectedChildId = 'selected_child_id';
  static const String selectedChildName = 'selected_child_name';
  static const String selectedChildAge = 'selected_child_age';
  static const String selectedChildProfilePhoto = 'selected_child_profile_photo';
  static const String selectedChildCoverPhoto = 'selected_child_cover_photo';
  static const String childListSize = 'child_list_size';
}
