import 'package:flutter/material.dart';
import '../path_constants.dart';
import '../../utils/extensions.dart';

class AppStrings {
  static const appName = "Child Health Story";
  static const login = "Login";
  static const welcome = "Welcome!";

  static const String somethingWentWrong =
      'Something went wrong. Please try again.';
  static const noRouteFoundText = "No route found";
  //snackbar status
  static const String warning = "warning";
  static const String failure = "failure";
  static const String success = "success";

  //Email & Phone Number
  static const String emailLabel = "Email";
  static const String phoneLabel = "Phone Number";
  static const String phoneLabelWithOutAsterisk = "Phone";

  //label texts
  static const String babyNameLabel = "Baby Name";
  static const String genderLabel = "Gender";
  static const String dobLabel = "Date/Time of Birth";
  static const String heightLabelAtBirth = "Height (At Birth)";
  static const String weightLabelAtBirth = "Weight (At Birth)";
  static const String headCircumferenceLabel = "Head Circumference";
  static const String bloodGroupLabel = "Blood Group";
  static const String timeOfBirthLabel = "Time of Birth";
  static const String heightLabel = "Height";
  static const String weightLabel = "Weight";
  static const String aboutyourChildLabel = "About your child";
  static const String careTakerNameLabel = "Care Taker Name";
  static const String aboutChildLabel = "About Child";

  //hint texts
  static const String eamilOrPhoneHintText = "enter email or phone number";
  static const String passwordHintText = "enter password";
  static const String babyNameHintText = "Enter baby name";
  static const String babyHeightHintText = "Enter baby height";
  static const String babyWeightHintText = "Enter baby weight";
  static const String babyHeadCircumFranceHintText =
      "Enter baby head Circumfrance";
  static const String babyBloodGroupHintText = "Enter baby blood group";
  static const String aboutBabyHintText = "Enter about your baby";
  static const String genderHintText = "Select Gender";
  static const String careTakerHintText = "Enter Care Taker Name";
  static const String enterPhoneNumberHintText = "Enter Phone Number";
  static const String enterEmailHintText = "Enter email";
  static const String relationShipHintText = "Select Relationship";
  static const String enterAddressHintText = "Enter Address";
  static const String babyProfileTxt = "Baby Profile";

  //login screen texts
  static const String welcomeText = "Welcome back";
  static const String enterEmailOrPwdtext =
      "Enter your email or phone number to get started";
  static const String enterPhoneNumberText =
      "Enter your phone number to get started";
  static const String forgotPasswordText = "Forgot Password?";
  static const String dontHaveAccountText = "Don't have an account? ";
  static const String signUpText = "Sign Up";
  static const String passwordtext = "Password";
  static const String signInUsingText = "Sign in using my ";
  static const String mobileNumberText = "Mobile Number";

  static const String loginSuccess = "Login successful";


  //Forgot Password Screen
  static const String forgotPasswordHeadText = "Forgot Password";
  static const String sendEmail =
      "We will send an email to reset your password.";

  //otp screen texts
  static const String verifyAccountText = "Verify Account";
  static const String enterOtpText = "Enter OTP";
  static const String sentOtpPhoneNumberText =
      "We have sent you a 6 digit OTP via your Phone number";
  static const String sentOtpEmailText =
      "We have sent you a 6 digit OTP via your Email";
  static const String didReceiveText = "Didn't receive the code? ";
  static const String resendOtpText = "Resend OTP";
  static const String wantToUpdateText = "Want to update your details? ";
  static const String clickHereText = "Click Here";
  static const String otpResentSuccessfully = "OTP resent successfully";
  static const String countryCodeLabel = "Country";
  static const String countryCodeHintText = "Select Country";

  //Change Password Screen
  static const String setNewPasswordText = "Set New Password";
  static const String changePasswordText = "Change Password";
  static const String oldPasswordText = "Old Password";
  static const String newPasswordText = "New Password";
  static const String confirmNewPasswordText = "Confirm New Password";
  static const String oldPasswordHint = "Enter your old password";
  static const String newPasswordHint = "Enter your new password";
  static const String confirmNewPasswordHint = "Re-enter your new password";

  //signup screen texts
  static const createMyAccountText = "Create My Account!";
  static const letsGetStartedText = "Let's Get Started!!";
  static const createAccountDescriptionText =
      "Create an account to keep track of all your childs activities.";
  static const firstNameHint = "First Name*";
  static const lastNameHint = "Last Name*";
  static const emailHint = "Email*";
  static const phoneHint = "Phone*";
  static const passwordHint = "Password*";
  static const confirmPasswordHint = "Confirm Password*";
  static const String signUpAgreement =
      "By signing up to CHS, you are agreeing to the";
  static const String termsConditionsText = "Terms & Conditions";
  static const String and = " and ";
  static const String privacyPolicyText = "Privacy Policy";

  static const String signupSuccess = "Sign up successful";

  //button texts
  static const String continueText = "Continue";
  static const String verifyMyAccountText = "Verify My Account";
  static const String nextText = "Next  ";
  static const String saveText = "Save";
  static const String shareOTPText = "Share OTP";
  static const String cancelBtnText = "Cancel";
  static const String deleteBtnText = "Delete";
  static const String updateBtnText = "Update";
  static const String addHospitalBtnText = "Add Hospital";
  static const String addDoctorBtnText = "Add Doctor";
  static const String addCareTakerBtnText = "Add Care Taker";

  //add child screen texts
  static const String addaChildText = "Add a Child";
  static const String provideDetailsText =
      "Please provide the following details of your child";

  //child profile screen texts
  static const String deleteBabyProfileTitle = "Delete Baby Profile";
  static const String deleteBabyProfileConfirmationMessage = "Are you sure you want to delete this baby profile?";
  static const String childAddedSuccessMessage = "Child added successfully";
  static const String childUpdateSuccessMessage = "Child updated successfully";
  static const String childDeleteSuccessMessage = "Child deleted successfully";


  //doctor visits
  static const String doctorVisitsText = "Doctor Visits";
  static const String growthTrackerText = "Growth Tracker";
  //health records screen
  static const String sampleNetworkUrl =
      "https://www.livemint.com/lm-img/img/2025/06/04/optimize/unnamed_1749006115702_1749006119883.jpg";
  static const String switchChildText = "Switch Child";
  static const String parentProfileText = "Parent Profile";
  static const String healthRecordsText = "Health Records";
  static const String searchText = "Search";
  static const String deleteText = "Delete";
  //lists
  static List<String> gendersList = ["Male", "Female"];

  //Medical Condition
  static String appBarTitle = "Vaccination Details";
  static String attachmentsTxt = "Attachments";
  static String deleteTxt = "Delete";
  static String updateTxt = "Update";

  //Child Profile
  static String updateChildTxt = "Update Baby Information";
  static String conditionName = "Condition Name";
  static String diagonosedDate = "Diagonosed Date";
  static String hospitalName = "Hospital Name";
  static String currentStatus = "Current Status";
  static String treatmentNotes = "Treatment Notes";

  static List<Map<String, dynamic>> healthRecords = [
    {
      "title": "Vaccination Details",
      "icon": Icons.vaccines,
      "route": PathConstants.vaccinationListScreen,
    },
    {
      "title": "Medical Conditions",
      "icon": Icons.healing,
      "route": PathConstants.medicalConditionsListScreen,
    },
    {
      "title": "Medications",
      "icon": Icons.medication,
      "route": PathConstants.medicationListScreen,
    },
    {
      "title": "Allergies",
      "icon": Icons.access_alarm_sharp,
      "route": "",
    },
    {
      "title": "Health Tracker",
      "icon": Icons.monitor_heart,
      "route": PathConstants.healthTrackerListScreen,
    },
  ];

  //Choose child screen texts
  static const String chooseYourChildText = "Choose Your Child";
  static const String selectChildDetailsText = "Select which Child Details you wish to see.";
  static const String addNewText = "Add New";

  static List<BottomNavigationBarItem> navItems = [
    BottomNavigationBarItem(
      icon: Icon(Icons.favorite_border),
      activeIcon: Icon(Icons.favorite, color: Colors.blue),
      label: 'Health',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.emoji_events_outlined),
      activeIcon: Icon(Icons.emoji_events, color: Colors.blue),
      label: 'Growth & Milestone',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.medical_services_outlined),
      activeIcon: Icon(Icons.medical_services, color: Colors.blue),
      label: 'Doctor Visits',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.child_care_outlined),
      activeIcon: Icon(Icons.child_care, color: Colors.blue),
      label: 'My Child',
    ),
  ];
  static List<String> relationshipNames = [
    'Son',
    'Daughter',
    'Brother',
    'Sister',
    'Son-in-law',
    'Daughter-in-law',
    'Husband',
    'Wife',
    'Others',
  ];

  static List<Map<String, dynamic>> childProfileDetails = [
    {"title": "Profile", "icon": Icons.person},
    {"title": "Care Takers", "icon": Icons.cabin},
    {"title": "Alerts", "icon": Icons.add_alert_sharp},
    {"title": "Favorites", "icon": Icons.favorite},
    {"title": "Insurance", "icon": Icons.document_scanner},
  ];

  //View child
  static const String profileTxt = "Profile";
  static const String careTakersTxt = "Care Takers";
  static const String alertsTxt = "Alerts";
  static const String favoritesTxt = "Favorites";
  static const String insuranceText = "Insurance";
  static const String titleTxt = "title";

  //Loader messages
  static const String loading = "Loading";
  static const String requestingOTP = "Requesting OTP";
  static const String verifyingOTP = "Verifying OTP";
  static const String resendingOTP = "Resending OTP";

  //Units
  static const String kgUnit = "kg";
  static const String cmUnit = "cm";

  //Attachments
  static const String uploadAFile = "Upload a file.";
  static const String attachments = "Attachments";
  static const int maxFileSize = 10;
  static const List<String> supportedFileTypes = ['image', 'pdf', 'doc', 'docx'];
  static const List<String> imageSupportTypes = ['png', 'jpg', 'jpeg'];
  static const List<String> documentTypes = ['pdf', 'doc', 'docx'];
  static String get allowedImageTypesMessage =>
      'Only ${imageSupportTypes.map((e) => e.toUpperCase()).join(', ')} images are allowed.';
  static String get allowedFileTypesMessage =>
      'Only ${supportedFileTypes.map((e) => e.toUpperCase()).join(', ')} files are allowed.';
  static String fileSizeExceededMessage(int maxFileSizeMB) =>
      'File exceeds $maxFileSizeMB MB limit.';
  static String fileSizeLimit(int maxFileSizeMB) =>
      "File size must be less than ${maxFileSizeMB.toStringAsFixed(0)}MB.";
  static const String cameraText = "Camera";
  static const String galleryText = "Gallery";
  static const String pdfText = "PDF";

  //Hospital Screen Texts
  static const String hospitalNameLabel = "Hospital Name*";
  static const String hospitalNameHint = "Enter Hospital Name";
  static const String addressLabel = "Address*";
  static const String addressHint = "Enter Address";
  static const String availableHospitals = "Available Hospitals";
  static const String noHospitalAvailable = "No Hospital Available.";
  static const String addNewHospital = "Add New Hospital";
  static const String searchAddressLabel = "Search Address*";
  static const String searchAddressHint = "Enter address";
  static const String countryAddressSearchCodes = 'in,us';

  //Doctor Screen Texts
  static const String doctorNameLabel = "Doctor Name*";
  static const String doctorNameHint = "Enter Doctor Name";
  static const String doctorAddedSuccessMessage = "Doctor added successfully";
  static const String hospitalAddedSuccessMessage = "Hospital added successfully.";
  static const String availableDoctors = "Available Doctors";
  static const String noDoctorAvailable = "No Doctor Available.";
  static const String addNewDoctor = "Add New Doctor";
  static const String specialityLabel = "Speciality*";
  static const String specialityHint = "Select Speciality";
  static const String openAddHospitalDialog = "open_add_hospital";


  //Medications
  static const String medicationAddedSuccessMessage = "Medication added successfully";
  static const String medicationUpdateSuccessMessage = "Medication updated successfully";
  static const String medicationDeleteSuccessMessage = "Medication deleted successfully";
  //Medications list screen text
  static const String medicationText = "Medications";
  static String medicationDetailsText(String childName) =>
      "Medication details for $childName";
  static const String historyText = "History";
  static const nextDosagePrefix = 'Next Dosage: ';
  static const startDatePrefix = 'Start Date: ';
  static const endDatePrefix = 'End Date: ';
  static const doctorPrefix = "Doctor: ";
  static const notePrefix= "Note: ";
  //Add Medication Screen
  static const String addNewMedication = "Add New Medication";
  static const String medicationNameLabel = "Medication Name*";
  static const String reasonForUsageLabel = "Reason for Usage*";
  static const String dosageLabel = "Dosage*";
  static const String frequencyLabel = "Frequency*";
  static const String selectTimesADay = "Select how many times a day";
  static const String startDateLabel = "Start Date*";
  static const String endDateLabel = "End Date*";
  static const String doctorLabel = "Doctor*";
  static const String notesLabel = "Notes*";
  static const String notesLabelWithOutAsterisk = "Notes";
  static const String medicationNameHint = "Enter medication name";
  static const String reasonForUsageHint = "Enter reason for usage";
  static const String dosageHint = "Enter dosage";
  static const String frequencyHint = "Select frequency";
  static const String startDateHint = "Select start date";
  static const String endDateHint = "Select end date";
  static const String doctorHint = "Enter doctor name";
  static const String notesHint = "Enter notes";
  static const List<String> timesOfDayOptions = [
    'Morning',
    'Afternoon',
    'Evening',
  ];
  //Medication Detail Screen
  static const String medicationDetails = "Medication Details";
  static const String searchMedicationText = "Search for a medication";
  static const String timesADayLabel = "Times A Day";
  static const String deleteMedicationTitle = "Delete Medication";
  static const String deleteMedicationConfirmationMessage = "Are you sure you want to delete this medication?";
  //Medication Detail Screen Titles
  static const String medicationNameText = "Medication Name";
  static const String reasonForUsageText = "Reason for Usage";
  static const String dosageText = "Dosage";
  static const String frequencyText = "Frequency";
  static const String startDateText = "Start Date";
  static const String endDateText = "End Date";
  static const String doctorText = "Doctor";
  static const String notesText = "Notes";
  //Edit Medication Screen
  static const String editMedicationText = "Edit Medication";


  //Vaccination Screen Texts
  static const String vaccinationAddedSuccessMessage = "Vaccination added successfully";
  static const String vaccinationUpdateSuccessMessage = "Vaccination updated successfully";
  static const String vaccinationDeleteSuccessMessage = "Vaccination deleted successfully";
  //vaccination List screen
  static const String vaccinationText = "Vaccination";
  static const String vaccinationrecordsText = "Vaccination Records";
  static const String searchVaccineText = "Search for a vaccine";
  static const String noDataText = "No data found";
  static String vaccinationDetailsText(String childName) =>
      "Vaccination details for $childName";
  static const vaccinatedDatePrefix = 'Vaccinated Date: ';
  static const scheduledDatePrefix = 'Scheduled Date: ';
  static const pendingStatus = 'Pending';
  //Add New Vaccination Screen
  static const String addNewVaccinationText = "Add New Vaccination";
  static const String vaccineNameLabel = "Vaccine Name*";
  static const String diseaseLabel = "Disease*";
  static const String scheduledDateLabel = "Scheduled Date*";
  static const String vaccinatedDateLabel = "Vaccinated Date*";
  static const String vaccinatedDateWithoutAsteriskLabel = "Vaccinated Date";
  static const String hospitalLabel = "Hospital*";
  static const String vaccineNumberLabel = "Vaccine Number";
  static const String reactionsLabel = "Reactions";
  static const String vaccineNameHint = "Enter vaccine name";
  static const String diseaseHint = "Enter disease";
  static const String scheduledDateHint = "Select scheduled date";
  static const String vaccinatedDateHint = "Select vaccinated date";
  static const String hospitalHint = "Enter hospital name";
  static const String vaccineNumberHint = "Enter vaccine number";
  static const String reactionsHint = "Enter any reactions";
  //Edit Vaccination Screen
  static const String editVaccinationText = "Edit Vaccination";
  //Vaccination Detail Screen
  static const String vaccinationDetails = "Vaccination Details";
  static const String vaccineNameText = "Vaccine Name";
  static const String diseaseText = "Disease";
  static const String scheduledDateText = "Scheduled Date";
  static const String vaccinatedDateText = "Vaccinated Date";
  static const String hospitalNameText = "Hospital Name";
  static const String vaccineNumberText = "Vaccine Number";
  static const String reactionsText = "Reactions";
  static const String deleteVaccinationTitle = "Delete Vaccination";
  static const String deleteVaccinationConfirmationMessage = "Are you sure you want to delete this vaccination record?";




  //Health Tracker
  static const String healthRecordAddedSuccessMessage = "Health record added successfully";
  static const String healthRecordUpdateSuccessMessage = "Health record updated successfully";
  static const String healthRecordDeleteSuccessMessage = "Health record deleted successfully";
//Add Health Tracker Screen
  static const String addNewHealthTrackerText = "Add Health Tracker";
  static const String conditionNameLabel = "Condition Name*";
  static const String conditionNameHint = "Enter condition name";
  static const String dateLabel = "Date*";
  static const String dateHint = "Select date";
  static const String temperatureLabel = "Temperature*";
  static const String temperatureHint = "Enter body temperature (°F)";
  static const String heartRateLabel = "Heart Rate";
  static const String heartRateHint = "Enter heart rate (bpm)";
  static const String respiratoryLabel = "Respiratory Rate";
  static const String respiratoryHint = "Enter respiratory rate (breaths/min)";
  static const String healthTrackerNotesLabel = "Notes";
  static const String healthTrackerNotesHint = "Enter Notes";
  static const String addNewAttachmentText = "Add New Attachment";
  //Health Tracker List Screen
  static const String healthTrackerText = "Health Tracker";
  static String healthTrackerDetailsText(String childName) =>
      "Health Tracker details for $childName";
  static const String searchHealthTrackerText = "Search for a specific condition";
  static const String healthHistoryText = "Health History";
  static const temperaturePrefix = 'Temperature: ';
  static const degreeF = '°F';
  static const heartRatePrefix = 'Heart Rate: ';
  //Health Tracker Detail Screen
  static const String healthTrackerDetails = "Health Tracker Details";
  static const String conditionNameLabelDetail = "Condition Name";
  static const String dateLabelDetail = "Date";
  static const String temperatureLabelDetail = "Temperature";
  static const String heartRateLabelDetail = "Heart Rate";
  static const String respiratoryLabelDetail = "Respiratory Rate";
  static const String healthTrackerNotesLabelDetail = "Notes";
  static const String deleteHealthTrackerTitle = "Delete Health Tracker";
  static const String deleteHealthTrackerConfirmationMessage = "Are you sure you want to delete this health tracker entry?";
  //Edit Health Tracker Screen
  static const String editHealthTrackerText = "Edit Health Tracker";

  //Doctor Visits
  static const String doctorVisitTitleCase = "Doctor Visit";
  static const String doctorVisitLowerCase = "doctor visit";
  //Add Doctor Visit Screen
  static const String addNewDoctorVisitText = "Add New Doctor Visit";
  static const String purposeLabel = "Purpose*";
  static const String purposeHint = "Enter purpose";
  static const String dateOfVisitLabel = "Date of Visit*";
  static const String followUpDateLabel = "Follow Up Date";
  //Doctor Visit List Screen
  static const String doctorVisitText = "Doctor Visits";
  static String doctorVisitDetailsText(String childName) =>
      "Doctor Visit details for $childName";
  static const String searchDoctorVisitText = "Search";
  //Doctor Visit Detail Screen
  static const String doctorVisitDetails = "Doctor Visit Details";
  static const String purposeText = "Purpose";
  static const String dateOfVisitText = "Date of Visit";
  static const String followUpDateText = "Follow Up Date";
  static String treatmentNotesText = "Treatment Notes";
  static const String deleteDoctorVisitTitle = "Delete Doctor Visit";
  static const String deleteDoctorVisitConfirmationMessage = "Are you sure you want to delete this doctor visit?";
  //Edit Doctor Visit Screen
  static const String editDoctorVisitText = "Edit Doctor Visit";

  //Medical conditions
  static const String medicalConditionAddedSuccessMessage = "Medical condition added successfully";
  static const String medicalConditionUpdateSuccessMessage = "Medical condition updated successfully";
  static const String medicalConditionDeleteSuccessMessage = "Medical condition deleted successfully";
  //List Screen
  static const String medicalConditionsTxt = "Medical Conditions";
  static String medicalConditionDetailsText(String childName) =>
      "Medical Condition details for $childName";
  static const String medicalConditionsDesc =
      "Medical Condition details for Baby Name";
  static const String historyTxt = "History";
  static const String searchConditionText = "Search for a condition";
  static const String addMedicalCondition = "Add New Condition";
  static const String diagnosedDatePrefix = "Diagnosed Date: ";
  static const String statusAdmitted = 'admitted';
  static const String statusDischarged = 'discharged';
  static const String statusDeceased = 'deceased';
  static const String statusObservation = 'observation';
  static const String statusReceivingTreatment = 'receiving treatment';

  //Care Taker
  static const String careTakerTitleCase = "Care Taker";
  static const String careTakerLowerCase = "care taker";
  static const String updatePrimaryCareTakerTitle = "Update Care Taker Status";
  static const String setPrimaryCareTakerMessage = "Are you sure you want to make this care taker primary?";
  //Care Taker Detail Screen
  static const String deleteCareTakerTitle = "Delete Care Taker";
  static const String deleteCareTakerConfirmationMessage = "Are you sure you want to delete this care taker?";
  static const String careTakerText = "Care Takers";
  static const String careTakerDetailsText = "Care Taker Details";
  //List Screen
  static const String primaryCareTaker = "Primary Care Taker";
  static const String childCareTaker = "Child Care Taker";
  static const String phonePrefix = "Phone: ";
  static const String addressPrefix = "Address: ";
  //Add caretakers
  static const String addNewCareTakerText = "Add New Care Taker";
  static const String relationshipText = "Relationship";
  static const String addressText = "Address";
  static const String setPrimaryCareTakerText = "Set as Primary Care Taker";
  static const String addCareTakerText = "Add Care Taker";


  //Add Medical Condition Screen
  static List<String> severityList = ["High", "Low", "Medium"];
  static const String addNewCondition = "Add New Condition";
  static const String diagnosedDateLabel = "Diagnosed Date*";
  static const String diagnosedDateHint = "Select Diagnosed Date";
  static const String admissionDateLabel = "Admission Date*";
  static const String dischargeDateLabel = "Discharge Date";
  static const String severityLabel = "Severity";
  static const String severityHintText = "Select Severity";
  static const String currentStatusLabel = "Current Status*";
  static const String statusHint = "Select Status";
  static const String treatmentNotesLabel = "Treatment Notes";
  static const String treatmentNotesHint = "Enter Treatment Notes";
  //Medical Condition Detail Screen
  static const String medicationConditionDetails = "Medication Condition Details";
  static const String deleteMedicalConditionTitle = "Delete Medical Condition";
  static const String deleteMedicalConditionConfirmationMessage = "Are you sure you want to delete this medical condition record?";
  static const String admissionDateLabelDetail = "Admission Date";
  static const String dischargeDateLabelDetail = "Discharge Date";
  static String severityDetailLabel = "Severity";
  //Edit Medical Condition Screen
  static const String editCondition = "Edit Medical Condition";



  static String successMessage(EntityAction action, String entityName) {
    switch (action) {
      case EntityAction.add:
        return "$entityName added successfully";
      case EntityAction.update:
        return "$entityName updated successfully";
      case EntityAction.delete:
        return "$entityName deleted successfully";
      case EntityAction.fetch:
        return "$entityName fetched successfully";
      case EntityAction.fetchDetails:
        return "$entityName details loaded successfully";
    }
  }

  static String errorMessage(EntityAction action, String entityName) {
    switch (action) {
      case EntityAction.add:
        return "Failed to add $entityName. Please try again.";
      case EntityAction.update:
        return "Failed to update $entityName. Please try again.";
      case EntityAction.delete:
        return "Failed to delete $entityName. Please try again.";
      case EntityAction.fetch:
        return "Failed to fetch $entityName. Please try again.";
      case EntityAction.fetchDetails:
        return "Failed to load $entityName details. Please try again.";
    }
  }
}
