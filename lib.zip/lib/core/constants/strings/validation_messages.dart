class ValidationMessages {
  // General
  static const String invalidDate = "Date is required";
  static const String invalidLocation = "Location is required";
  static const String invalidPrice = "Price is required";
  static const String relationShip = "RelationShip is required";

  // Email
  static const String emailReq = "Email is required";
  static const String invalidEmail = "Email is invalid";
  static const String plsEnterEmail = "Please enter email";
  static const String plsEnterValidEmail = "Please enter valid email";

  // Phone
  static const String phoneNumberReq = "Phone number is required";
  static const String invalidPhoneNumber = "Phone number is invalid";
  static const String plsEnterPhoneNumber = "Please enter phone number";
  static const String plsEnterValidPhoneNumber =
      "Please enter valid phone number";
  static const String phoneNumberRequired = "Please enter phone number";

  // Email or Phone
  static const String emailOrPhoneNumberReq =
      "Email or Phone Number is required";

  // Password
  static const String passwordReq = "Password is required";
  static const String plsEnterPassword = "Please enter password";
  static const String plsEnterConfirmPassword = "Please enter confirm password";
  static const String passwordDoNotMatch = "Passwords do not match";
  static const String passwordPolicy =
      "Password must be at least 8 characters and include uppercase, lowercase, number, and special character";

  // Name
  static const String plsEnterFirstName = "Please enter first name";
  static const String plsEnterLastName = "Please enter last name";
  //caretaker
  static const String careTakerNameReq = "Care Taker Name is Required";
  //Address
  static const String addressReq = "Address is Required";

  //OTP Screen
  static const String plsEnterOTP = "Please enter OTP";
  static const String plsSelectCountryCode = "Please select country code";

  //Change Password
  static const String plsEnterOldPassword = "Please enter old password";
  static const String plsEnterNewPassword = "Please enter new password";
  static const String plsReEnterNewPassword = "Please re-enter your new password";

  //Hospital & Doctor
  static const String hospitalNameRequired = "Hospital Name is required";
  static const String addressRequired = "Address is required";
  static const String specialtyRequired = 'Please select at least one specialty';

  //Child Profile
  //Add Child
  static const String selectProfilePic = "Please select a profile picture";
  // Baby Profile
  static const String babyNameReq = "Baby name is required";
  static const String babyHeightReq = "Height is required";
  static const String babyWeightReq = "Weight is required";
  static const String babyHeadCircumfranceReq =
      "Head circumference is required";
  static const String babyBloodGroupReq = "Blood Group is required";
  static const String genderReq = "Please select gender";
  static const String dobReq = "Please enter date of birth and time";

  //Add Medication
  static const String medicationNameRequired = "Medication Name is required";
  static const String reasonForUsageRequired = "Reason for Usage is required";
  static const String dosageRequired = "Dosage is required";
  static const String frequencyRequired = "Frequency is required";
  static const String timeADayRequired = "Please select at least one time of the day.";
  static const String startDateRequired = "Start Date is required";
  static const String endDateRequired = "End Date is required";
  static const String doctorRequired = "Doctor is required";
  static const String notesRequired = "Notes are required";
  static const String pleaseSelectAtLeastOneFileRequired =
      "Please select at least one file";


  //Vaccination Screen
  //Add Vaccination
  static const String vaccineNameRequired = "Vaccine Name is required";
  static const String diseaseRequired = "Disease is required";
  static const String scheduledDateRequired = "Scheduled Date is required";
  static const String vaccinatedDateRequired = "Vaccinated Date is required";
  static const String hospitalRequired = "Hospital is required";
  static const String vaccineNumberRequired = "Vaccine Number is required";

  //Health Tracker
//Add
  static const String conditionNameValidation = "Condition name is required";
  static const String dateValidation = "Date is required";
  static const String temperatureEmptyValidation = "Temperature is required";
  static const String temperatureInvalidValidation = "Enter a valid number";
  static const String temperatureRangeValidation = "Enter a realistic temperature (30°C - 45°C)";
  static const String heartRateEmptyValidation = "Heart rate is required";
  static const String heartRateInvalidValidation = "Enter a valid number";
  static const String heartRateRangeValidation = "Enter a realistic heart rate (30 - 200 bpm)";
  static const String respiratoryEmptyValidation = "Respiratory rate is required";
  static const String respiratoryInvalidValidation = "Enter a valid number";
  static const String respiratoryRangeValidation = "Enter a realistic respiratory rate (10 - 60 breaths/min)";

  //Medical Conditions
//Add
  static const String conditionNameRequired = "Condition name is required";
  static const String diagnosedDateRequired = "Diagnosed date is required";
  static const String admissionDateRequired = "Admission date is required";
  static const String statusRequired = "Current Status is required";

  //Doctor Visit
  static const String purposeRequired = "Purpose is required";
  static const String dateOfVisitRequired = "Date of Visit is required";
}
