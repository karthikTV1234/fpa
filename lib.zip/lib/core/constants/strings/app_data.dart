import 'package:child_health_story/core/constants/color/app_colors.dart';

class AppData {
  static final List<Map<String, dynamic>> dummyMedicationsList = [
    {
      "category": "Daily",
      "status": "Next Dosage: 24 July, 12:30 PM",
      "statusColor": AppColors.cBabyBlueColor,
      "title": "Paracetamol 500mg Tablet",
      "subtitle": "Start Date: 10 July 2025\nEnd Date: 20 July 2025",
    },
    {
      "category": "Daily",
      "status": "Next Dosage: 25 July, 08:00 AM",
      "statusColor": AppColors.cBabyBlueColor,
      "title": "Amoxicillin 250mg Capsule",
      "subtitle": "Start Date: 12 July 2025\nEnd Date: 22 July 2025",
    },
    {
      "category": "As Required",
      "status": "",
      "statusColor": AppColors.cBabyBlueColor,
      "title": "Ibuprofen 200mg Tablet",
      "subtitle": "Start Date: 15 July 2025\nEnd Date: 30 July 2025",
    },
    {
      "category": "Once Weekly",
      "status": "Next Dosage: 27 July, 09:00 AM",
      "statusColor": AppColors.cBabyBlueColor,
      "title": "Vitamin D 60000 IU",
      "subtitle": "Start Date: 05 July 2025\nEnd Date: 05 August 2025",
    },
    {
      "category": "As Required",
      "status": "",
      "statusColor": AppColors.cBabyBlueColor,
      "title": "Cetirizine 10mg Tablet",
      "subtitle": "Start Date: 18 July 2025\nEnd Date: 28 July 2025",
    },
  ];


  static final dynamic medicationsDetails = {
    "medication_name": "AC para 100mg/325mg Tablet",
    "reason_for_usage": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    "dosage": "100 mg",
    "frequency": "Daily",
    "start_date": "12 July 2025",
    "end_date": "25 July 2025",
    "doctor": "Dr. Rajinikanth",
    "notes": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    "attachments": ["file1.jpg", "file2.jpg"]
  };
 //Add Medication frequency List
  static final List<String> frequencyList = [
    'Once Daily',
    'Twice Daily',
    'Thrice Daily',
    'Weekly',
    'Monthly',
    // Add other frequencies as needed
  ];

  static final dynamic medicalConditionDetails = {
    "condition_name": "Ear Pain",
    "diagonosed_date": "12th July 2025",
    "hosipal_name": "Apollo Hospital",
    "doctor": "Dr Rajinikanth",
    "current_status": "Active",
    "treatment_notes": "jdashiowajdksnfjkdhiaefkajfeiofkajsdlasla",
    "attachments": ["file1.jpg", "file2.jpg"],
  };

  //Medical condition List
  static List<Map<String, dynamic>> medicalConditions = [
    {
      "category": "Dr Rajinikanth",
      "title": "Ear Pain",
      "subtitle": "Diagnosed Date: 12 July 2025",
      "status": "Active",
      "statusColor": AppColors.cBabyBlueColor
    },
    {
      "category": "Dr Rajinikanth",
      "title": "Ear Pain",
      "subtitle": "Diagnosed Date: 12 July 2025",
      "status": "Active",
      "statusColor": AppColors.cBabyBlueColor
    },
    {
      "category": "Dr Rajinikanth",
      "title": "Ear Pain",
      "subtitle": "Diagnosed Date: 12 July 2025",
      "status": "Active",
      "statusColor": AppColors.cBabyBlueColor
    },
    {
      "category": "Dr Rajinikanth",
      "title": "Ear Pain",
      "subtitle": "Diagnosed Date: 12 July 2025",
      "status": "Active",
      "statusColor": AppColors.cBabyBlueColor
    },
    {
      "category": "Dr Rajinikanth",
      "title": "Ear Pain",
      "subtitle": "Diagnosed Date: 12 July 2025",
      "status": "Active",
      "statusColor": AppColors.cBabyBlueColor
    },
  ];

  static List<Map<String, dynamic>> vaccinationRecords = [
    {
      "category": "Polio",
      "title": "Oral Polio Vaccine (OPV)",
      "subtitle": "Scheduled Date: 15 July 2025",
      "status": "Pending",
      "statusColor": AppColors.cRedColor,
    },
    {
      "category": "Hepatitis B",
      "title": "Hepatitis B Birth Dose",
      "subtitle": "Scheduled Date: 20 July 2025",
      "status": "Pending",
      "statusColor": AppColors.cRedColor,
    },
    {
      "category": "Diphtheria, Tetanus, Pertussis",
      "title": "DTwP-HepB-Hib (Pentavalent) Vaccine",
      "subtitle": "Vaccinated Date: 05 June 2025",
      "status": "Completed",
      "statusColor": AppColors.cgreenColor,
    },
    {
      "category": "Measles",
      "title": "Measles-Rubella (MR) Vaccine",
      "subtitle": "Scheduled Date: 30 July 2025",
      "status": "Pending",
      "statusColor": AppColors.cRedColor,
    },
    {
      "category": "Rotavirus",
      "title": "Rotavirus Oral Vaccine",
      "subtitle": "Vaccinated Date: 18 May 2025",
      "status": "Completed",
      "statusColor": AppColors.cgreenColor,
    },
    {
      "category": "Influenza",
      "title": "Influenza (Flu) Vaccine",
      "subtitle": "Scheduled Date: 10 August 2025",
      "status": "Pending",
      "statusColor": AppColors.cRedColor,
    },
    {
      "category": "Varicella",
      "title": "Chickenpox (Varicella) Vaccine",
      "subtitle": "Vaccinated Date: 22 April 2025",
      "status": "Completed",
      "statusColor": AppColors.cgreenColor,
    },
  ];

  static final dynamic vaccinationDetails = {
    "vaccine_name": "BCG (Bacillus Calmette Guerin) Vaccine",
    "disease": "Tuberculosis (TB)",
    "scheduled_date": "12 July 2025",
    "vaccinated_date": "15 July 2025",
    "hospital_name": "Apollo Hospital",
    "doctor": "Dr. Rajinikanth",
    "vaccine_number": "12359781243",
    "reactions": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    "attachments": [
      "Vaccine Certificate.png",
      "Vaccine Certificate.png"
    ]
  };

  //Care Taker List
  static List<Map<String, String>> caretakersList = [
    {
      "category": "Child Care taker",
      "name": "Mark Smith",
      "phone": "123-456-7890",
      "address": "12 Grand Avenue, Chicago Illinois, USA",
      "badge": "Primary Care Taker",
    },
    {
      "category": "Child Care taker",
      "name": "Mark Smith",
      "phone": "123-456-7890",
      "address": "12 Grand Avenue, Chicago Illinois, USA",
    },
    {
      "category": "Child Care taker",
      "name": "Mark Smith",
      "phone": "123-456-7890",
      "address": "12 Grand Avenue, Chicago Illinois, USA",
    },
    {
      "category": "Child Care taker",
      "name": "Mark Smith",
      "phone": "123-456-7890",
      "address": "12 Grand Avenue, Chicago Illinois, USA",
    },
  ];

  //Child
  static final dynamic childDetails = {
    "child_name": "Mark",
    "gender": "Boy",
    "age": "3 Months",
    "time_of_birth": "21st July 2025, 8:03AM",
    "height": "173 CM",
    "weight": "3.5 KG",
    "head_circumference": "5 CM",
    // "blood_group": "B+ve",
    "about_child": "fsfjaorujaksfjlkarauoefaskncxsiqofcjkdfqoefujdklcjkljslkd",
    "profile_image":
    "https://m.media-amazon.com/images/I/519Hct2QoeL._UF1000,1000_QL80_.jpg",
    "wallpaper":
    "https://m.media-amazon.com/images/I/519Hct2QoeL._UF1000,1000_QL80_.jpg",
  };

  //Choose child screen List
  static final List<Map<String, String>> children = [
    {
      'name': 'Baby Name',
      'age': '5 months 18 days',
      'details': '50.00 cm, 3.50 KG',
      'profileImageUrl': 'https://example.com/child1.jpg',
    },
    {
      'name': 'Baby Name',
      'age': '5 months 18 days',
      'details': '50.00 cm, 3.50 KG',
      'profileImageUrl': 'https://example.com/child2.jpg',
    },
  ];

  static final List<String> countryCodes = ['+1', '+44', '+61', '+91', '+81'];
}


