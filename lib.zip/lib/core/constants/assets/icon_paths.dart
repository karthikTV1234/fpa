class AppIcons {
  static const String home = 'assets/icons/home.svg';
  static const String user = 'assets/icons/user.svg';
  static const String settings = 'assets/icons/settings.svg';
}
