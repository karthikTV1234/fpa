class AppFonts {

}
