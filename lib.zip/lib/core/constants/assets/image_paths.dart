class AppImages {
  static const String logo = 'assets/images/logo.png';
  static const String splash = 'assets/images/splash_bg.png';
  static const String placeholder = 'assets/images/placeholder.png';
}
