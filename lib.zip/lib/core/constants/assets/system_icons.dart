import 'package:flutter/material.dart';

class MyAppIcons {
  static const IconData home  = Icons.home;
  static const listEntries   = Icons.list;
  static const analytics   = Icons.analytics;
  static const settings = Icons.settings;
  static const add = Icons.add;
  static const delete = Icons.delete;
  static const edit = Icons.edit;

}